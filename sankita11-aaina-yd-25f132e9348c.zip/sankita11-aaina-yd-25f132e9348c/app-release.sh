#! /bin/sh
TODAY=`date "+%Y-%m-%d"`
CURR_DIR=`pwd`
APP_PATH='/Users/abdulrehmankhairdi/Desktop/Workspace/YourDOST/aaina_v1'
echo $TODAY
echo $APP_PATH

case $1 in
  local)
									echo "making release for local env"; cp $APP_PATH/config/local.config.js* $APP_PATH/app/scripts/helpers/config.js;
                  cd $APP_PATH
									grunt build
									mkdir -p dist/scripts/helpers
									cp -pr release/index.html dist/
									cp -pr app/bower_components/ckeditor dist/scripts/
									cp -pr app/bower_components/chosen dist/scripts/
									cp -pr app/bower_components/ajax-chosen dist/scripts/
									cp -pr app/images dist/
									cp -pr app/scripts/helpers/config.js dist/scripts/helpers/
									cp -pr app/bower_components/modernizr/modernizr.js dist/scripts/
									cp -pr build/styles dist/
									cp -pr app/scripts/json dist/scripts/
									cp -pr app/bower_components/materialize/dist/font dist/
									cp -pr app/bower_components/mdi/fonts dist/
									cp app/favicon.ico dist/favicon.ico
									cp app/robots.txt dist/
									cp -pr app/templates dist/
									cp app/bower_components/jquery/dist/jquery.min.js dist/scripts/
									cp app/bower_components/lodash/dist/lodash.min.js dist/scripts/
									cp app/bower_components/backbone/backbone-min.js dist/scripts/
									cp app/bower_components/requirejs/require.js dist/scripts/
									r.js -o build.js
									exit
							echo "hi";;
  production) if [ -z "$2" ]
                then
                  echo "version for release not present hence exiting";
                  exit
                else
				  echo "making release for prod env"; 
				  cp $APP_PATH/config/production.config.js* $APP_PATH/app/scripts/helpers/config.js;
                  cd $APP_PATH
                  echo "checking out production"
                  git checkout master
									grunt build
									mkdir -p dist/scripts/helpers
									cp -pr release/index.html dist/
									cp -pr app/bower_components/ckeditor dist/scripts/
									cp -pr app/bower_components/chosen dist/scripts/
									cp -pr app/bower_components/ajax-chosen dist/scripts/
									cp -pr app/images dist/
									cp -pr app/scripts/helpers/config.js dist/scripts/helpers/
									cp -pr app/bower_components/modernizr/modernizr.js dist/scripts/
									cp -pr build/styles dist/
									cp -pr app/scripts/json dist/scripts/
									cp -pr app/bower_components/materialize/dist/font dist/
									cp -pr app/bower_components/mdi/fonts dist/
									cp app/favicon.ico dist/favicon.ico
									cp app/robots.txt dist/
									cp -pr app/templates dist/
									cp app/bower_components/jquery/dist/jquery.min.js dist/scripts/
									cp app/bower_components/lodash/dist/lodash.min.js dist/scripts/
									cp app/bower_components/backbone/backbone-min.js dist/scripts/
									cp app/bower_components/requirejs/require.js dist/scripts/
									r.js -o build.js
                  git tag -a v$2 -m "releasing a new tag with verion "$2
                  git push --tags
              fi
							echo "hi";;
  staging) echo "making release for staging env"; 
							
							cp $APP_PATH/config/staging.config.js* $APP_PATH/app/scripts/helpers/config.js;
		    				cd $APP_PATH
									grunt build
									mkdir -p dist/scripts/helpers
									cp -pr release/index.html dist/
									cp -pr app/bower_components/ckeditor dist/scripts/
									cp -pr app/bower_components/chosen dist/scripts/
									cp -pr app/bower_components/ajax-chosen dist/scripts/
									cp -pr app/images dist/
									cp -pr app/scripts/helpers/config.js dist/scripts/helpers/
									cp -pr app/bower_components/modernizr/modernizr.js dist/scripts/
									cp -pr build/styles dist/
									cp -pr app/scripts/json dist/scripts/
									cp -pr app/bower_components/materialize/dist/font dist/
									cp -pr app/bower_components/mdi/fonts dist/
									cp app/favicon.ico dist/favicon.ico
									cp app/robots.txt dist/
									cp -pr app/templates dist/
									cp app/bower_components/jquery/dist/jquery.min.js dist/scripts/
									cp app/bower_components/lodash/dist/lodash.min.js dist/scripts/
									cp app/bower_components/backbone/backbone-min.js dist/scripts/
									cp app/bower_components/requirejs/require.js dist/scripts/
									r.js -o build.js
							echo "hi";;
	staging1) echo "making release for staging1 env"; 
							
							cp $APP_PATH/config/staging1.config.js* $APP_PATH/app/scripts/helpers/config.js;
		    				cd $APP_PATH
									grunt build
									mkdir -p dist/scripts/helpers
									cp -pr release/index.html dist/
									cp -pr app/bower_components/ckeditor dist/scripts/
									cp -pr app/bower_components/chosen dist/scripts/
									cp -pr app/bower_components/ajax-chosen dist/scripts/
									cp -pr app/images dist/
									cp -pr app/scripts/helpers/config.js dist/scripts/helpers/
									cp -pr app/bower_components/modernizr/modernizr.js dist/scripts/
									cp -pr build/styles dist/
									cp -pr app/scripts/json dist/scripts/
									cp -pr app/bower_components/materialize/dist/font dist/
									cp -pr app/bower_components/mdi/fonts dist/
									cp app/favicon.ico dist/favicon.ico
									cp app/robots.txt dist/
									cp -pr app/templates dist/
									cp app/bower_components/jquery/dist/jquery.min.js dist/scripts/
									cp app/bower_components/lodash/dist/lodash.min.js dist/scripts/
									cp app/bower_components/backbone/backbone-min.js dist/scripts/
									cp app/bower_components/requirejs/require.js dist/scripts/
									r.js -o build.js
							echo "hi";;
  *) echo "ONLY 'production' or 'staging'  is allowed"; exit;;
esac

cd $APP_PATH
#git checkout $1
bower install
cd $CURR_DIR

mkdir -p release_app;
tar -cvf release_app/aaina_$TODAY.tar $APP_PATH/dist
echo $TODAY+_+$2
aws s3 cp release_app/aaina_$TODAY.tar s3://dost-release-package/$1/app/aaina_"$TODAY"_"$2".tar
