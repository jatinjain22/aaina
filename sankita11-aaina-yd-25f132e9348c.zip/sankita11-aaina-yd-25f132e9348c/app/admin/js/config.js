
var apiUrl        = "http://local.yourdost.com:8080" ;
var appUrl        = "https://staging-app.yourdost.com"

var discussionUrl = "http://staging-forum.yourdost.com"     ;
var chatUrl       = "http://local.yourdost.com:8080/chat" ;
var chatDemoWorkgroup = "demo@workgroup.local.yourdost.com"  ;
var chatWorkgroup = "yd@workgroup.staging-chat.yourdost.com";
var appVersion       = "2.8" ;
var raygunKey      = '';
var mixpanelKey    = '8cde2238e48e56647a9e08e1dbff87d2';
var fbAPIID        = '1518194238499728';
var googleAPIID    = '1077064249033-g7foqc48mu138l73okl9hn8fs0m89n7v.apps.googleusercontent.com';
var blogUrl        = "https://blog.yourdost.com/api/get_recent_posts/?page=1";
var homeblogUrl    = "https://blog.yourdost.com/api/get_tag_posts/?tag_slug=homearticle";
var parentingBookPostId = 1214;
var blogOrigin	   = "http://local.yourdost.com:9001";
var socialShareUrl = "http://staging-app.yourdost.com/";