/*global require*/
'use strict';

require.config({
    shim: {
        'underscore': {
            exports: '_'
        },
        'underscore-string': {
            deps: [
                'underscore'
            ]
        },
        'handlebars-orig': {
            exports: 'Handlebars'
        },
        'backbone': {
            deps: [
                'underscore',
                'underscore-string',
                'jquery'
            ],
            exports: 'Backbone'
        },
        'jCookie': {
            exports: 'jCookie'
        },
        'wow': {
            exports: 'wow'
        },
        'sscr' : {
            exports: 'sscr'
        },
        'upclick':{
            deps: ['jquery']
        },
        'smooth-scroll' : {
            deps: ['jquery']
        },
        'iframe-transport':{
          deps: ['jquery']
        },
        'keystop' :{
            deps : ['jquery']
        },
        'materialize':{
            deps: ['jquery']
        },
        'jquery_ui_widget':{
            deps: ['jquery']
        },
        'chosen':{
            deps: ['jquery']
        },
        'ajax-chosen':{
            deps: ['chosen']
        },
        'moment-timezone-data' : {
            deps : ['moment']
        },
        'jquery' : {
            exports :"$" ,
        },
        'facebook' : {
            exports :"FB" ,
        },
        'jquery-ui' : {
            exports :"$" ,
            deps: ['jquery']
        },
        'ui-autocomplete':{
            exports :"$" ,
            deps: ['jquery-ui']
        },
        'jcarousel':{
            deps: ['jquery']
        },
        'datetimepicker' : {
          deps: ['jquery']
        },
        'Jcrop' : {
          deps: ['jquery']
        },
        'purl' : {

          deps: ['jquery']
        }
    },
    paths: {
        'jquery': '../bower_components/jquery/dist/jquery',
        'backbone': '../bower_components/backbone/backbone',
        'underscore': '../bower_components/lodash/dist/lodash',
        'velocity': '../bower_components/materialize/js/velocity.min',
        'hammerjs': '../bower_components/materialize/js/hammer.min',
        'materialize': './vendor/materialize.dost',
        'text': '../bower_components/text/text',
        'moment': '../bower_components/moment/moment',
        'moment-timezone-data': '../bower_components/moment-timezone/builds/moment-timezone-with-data-2010-2020',
        'jstz' : '../bower_components/jstz/jstz',
        'console': '../bower_components/console/console',
        'jCookie': '../bower_components/jquery.cookie/jquery.cookie',
        'hbs': '../bower_components/require-handlebars-plugin/hbs',
        "handlebars": '../bower_components/require-handlebars-plugin/hbs/handlebars.runtime',
        "underscore-string": '../bower_components/underscore.string/dist/underscore.string',
        'idle' : '../bower_components/Idle.Js/build/idle',
        'clipboard': '../bower_components/clipboard/dist/clipboard.min',
        'iframeResizer': '../bower_components/iframe-resizer/js/iframeResizer.min',
        'masonry': '../bower_components/masonry/dist/masonry.pkgd.min',
        'imagesloaded': '../bower_components/imagesloaded/imagesloaded.pkgd.min',
        'wow' : './vendor/wow.min',
        'sscr' : './vendor/sscr',
        "smooth-scroll" :'./vendor/jquery.smooth-scroll.min',
        'vm' :'./helpers/vm',
        'config' :'./helpers/config',
        'template': '../templates',
        'utils': './helpers/utils',
        'helpers/selfHelpTestUtils/trueColorUtils': 'helpers/selfHelpTestUtils/trueColorUtils',
        "ajax-chosen": '../bower_components/ajax-chosen/lib/ajax-chosen',
        "chosen":'./vendor/chosen.jquery.min',
        'purl' : '../bower_components/purl/purl',
        'facebook' : "facebook-sdk",
        'fingerprint' : '../bower_components/fingerprintjs2/dist/fingerprint2.min',
        'raygun' : '../bower_components/raygun4js/dist/raygun.min',
        'keystop' : '../bower_components/keystop/jquery.keystop.min',
        'mixpanel' : '../bower_components/backbone-mixpanel/vendor/assets/javascripts/backbone-mixpanel',
        'jquery-ui' : './vendor/jquery-ui/jquery-ui.min',
        'jcarousel' : '../bower_components/jcarousel/dist/jquery.jcarousel.min',
        'jcarousellite' : '../bower_components/jquery.jcarousellite/jcarousellite',
        'ui-autocomplete' : '../bower_components/jquery-ui/ui/minified/autocomplete.min',
        'Swiper' :    '../bower_components/Swiper/dist/js/swiper.min',
        'introjs' : '../bower_components/intro.js/minified/intro.min',
        'Jcrop': '../bower_components/Jcrop/js/jquery.Jcrop.min',
        'RazorPay' : 'razorpay-checkout',
        'sixpack' : 'sixpack',
        'autolink' : '../bower_components/Autolinker.js/dist/Autolinker.min',
        'backbone.viewcache' : '../bower_components/backbone.viewcache/backbone.viewcache',
        'datetimepicker' : '../bower_components/datetimepicker/jquery.datetimepicker',
        'chatNotification' : './json/chatNotification',
        'view/changePassword/page' :'./view/changePassword/page',
        'view/clientHistory/upage' :'./view/clientHistory/upage',
        'view/clientHistory/users' :'./view/clientHistory/users',
        'view/counselor/singlepageV2' :'./view/counselor/singlepageV2',
        'view/faq/page' :'./view/faq/page',
        'view/faq/singlepage' :'./view/faq/singlepage',
        'view/forgetPassword/page' :'./view/forgetPassword/page',
        'view/home/page' :'./view/home/page',
        'view/home2/page' :'./view/home2/page',
        'view/home3/page' :'./view/home3/page',
        'view/login/page': './view/login/page',
        'view/logout/page' : './view/logout/page',
        'view/messages/fpage' : './view/messages/fpage',
        'view/messages/fsinglepage' : './view/messages/fsinglepage',
        'view/messages/page' : './view/messages/page',
        'view/messages/singlepage' :'./view/messages/singlepage',
        'view/privacyPolicy/page' :'./view/privacyPolicy/page',
        'view/resetPassword/page' :'./view/resetPassword/page',
        'view/review/review' : './view/review/review',
        'view/talkItOut/page' : './view/talkItOut/page',
        'view/talkItOutV2/page' : './view/talkItOutV2/page',
        'view/teams/page' : './view/teams/page',
        'view/testimonials/page' : './view/testimonials/page',
        'view/tos/page' : './view/tos/page',
        'view/unsubscribe/page' : './view/unsubscribe/page',
        'view/users/page' : './view/users/page',
        'view/counselor/page' : './view/counselor/page',
        'view/cancelAppointment/page' : 'view/cancelAppointment/page',
        'view/partners/page' : './view/partners/page',
        'view/welcome/initial' : './view/welcome/initial' ,
        'view/messages/verifyemail' : 'view/messages/verifyemail',
        'view/mobileApps/page' : 'view/mobileApps/page' ,
        'view/bookAppointment/page' : 'view/bookAppointment/page' ,
        'view/appointmentFlow/page':'view/appointmentFlow/page',
        'view/bookAppointment/payment_success' : 'view/bookAppointment/payment_success' ,
        'view/bookAppointment/payment_failure' : 'view/bookAppointment/payment_failure',
        'view/bookAppointment/payment_pending' : 'view/bookAppointment/payment_pending',
        'view/process/page' : 'view/process/page',
        'view/counselorChatResource/page' : 'view/counselorChatResource/page',
        'view/relationship/page':'view/relationship/page',
        'view/careerCounselor/page':'view/careerCounselor/page',
        'view/homeNew/page' : 'view/homeNew/page',
        'view/sessions/page' : 'view/sessionsV2/page',
        'view/landingPages/page' : 'view/landingPages/page',
        'view/selfHelp/habitometer/page' : 'view/selfHelp/habitometer/page',
        'view/landingPages2/page' : 'view/landingPages2/page',
        'view/parentingTips/page' : 'view/parentingTips/page',
        'view/selfHelp/discoverYourself/page' : 'view/selfHelp/discoverYourself/page',
        'view/selfHelp/playBuzzTest/page': 'view/selfHelp/playBuzzTest/page',
        'view/selfHelp/page': 'view/selfHelp/page',
        'view/contactUs/page': 'view/contactUs/page',
        'view/contactUs/forms/anythingElse': 'view/contactUs/forms/anythingElse',
        'view/contactUs/forms/shareYourFeedback': 'view/contactUs/forms/shareYourFeedback',
        'view/contactUs/forms/issuesInOurService': 'view/contactUs/forms/issuesInOurService',
        'view/contactUs/forms/beASaviour': 'view/contactUs/forms/beASaviour',
        'view/contactUs/forms/beAVolunteer': 'view/contactUs/forms/becomeAVolunteer',
        'view/contactUs/forms/guestBlog': 'view/contactUs/forms/guestBlog',
        'view/selfHelp/trueColor/page': 'view/selfHelp/trueColor/page',
        'view/selfHelp/trueColor/resultPage': 'view/selfHelp/trueColor/resultPage',
        'view/selfHelp/shapeTest/page': 'view/selfHelp/shapeTest/page',
        'view/selfHelp/shapeTest/resultPage': 'view/selfHelp/shapeTest/resultPage',
        'view/selfHelp/habitometer/resultPage': 'view/selfHelp/habitometer/resultPage',
        'view/selfHelp/discoverYourself/resultPage': 'view/selfHelp/discoverYourself/resultPage',
        'view/tos/modal_page' : 'view/tos/modal_page',
        'view/sharePositiveChats/page': 'view/sharePositiveChats/page',
        'view/tipsLandingPage/page': 'view/tipsLandingPage/page',
        'view/joinUsExperts/page.js': 'view/joinUsExperts/page',
        'view/press/page': 'view/press/page',
        'view/notSupported/page' : 'view/notSupported/page',
        'view/hubsAndSpokes/page': 'view/hubsAndSpokes/page',
        'view/hubsAndSpokes/spokePage': 'view/hubsAndSpokes/spokePage',
        'view/jobs/page': 'view/jobs/page',
        'view/jobs/singlepage': 'view/jobs/singlepage',
        'view/counseling/page' : 'view/counseling/page',
        'view/donation/page' : 'view/donation/page',
        'view/whyDonation/page' : 'view/whyDonation/page',
        'view/messages/counselor_dropdown' : 'view/messages/counselor_dropdown',
        'view/packages/page' : 'view/packages/page',
        'view/packages/custompackage_modal' :'view/packages/custompackage_modal',
        'view/packages/single_page' : 'view/packages/single_page',
        'view/packages/package_booked' : 'view/packages/package_booked',
        'view/packages/package_schedule' : 'view/packages/package_schedule',
        'view/packages/packages_faq' : 'view/packages/packages_faq',
        'view/suicidePrevention/page' : 'view/suicidePrevention/page',
        'view/packages/packages_header' : 'view/packages/packages_header',
        'view/hubsAndSpokes/faqpage' : 'view/hubsAndSpokes/faqpage',
        'view/suicidePrevention/page' : 'view/suicidePrevention/page',
        'view/messages/message' : 'view/messages/message',
        'view/newYearPackages/page' : 'view/newYearPackages/page',
        'view/newYearPackages/single_page' : 'view/newYearPackages/single_page',
        'view/newYearPackages/schedule_page' : 'view/newYearPackages/schedule_page',
        'view/selfHelp/newYear/page':'view/selfHelp/newYear/page',
        'view/selfHelp/newYear/result' :'view/selfHelp/newYear/resultPage',
        'view/newYearResolution2017/page' : 'view/newYearResolution2017/page',
        'view/selfHelp/newYearQ2/page' : 'view/selfHelp/newYearQ2/page',
        'view/selfHelp/newYearQ2/result' : 'view/selfHelp/newYearQ2/result',
        'view/valentine/page' : 'view/valentine/page',
        'view/flames/page' : 'view/flames/page',
        'view/selfHelp/loveCompatibility/page' :'view/selfHelp/loveCompatibility/page',
        'view/selfHelp/loveCompatibility/result' : 'view/selfHelp/loveCompatibility/result',
        'view/selfHelp/emotionalWellness/page' : 'view/selfHelp/emotionalWellness/page',
        'view/selfHelp/emotionalWellness/result' : 'view/selfHelp/emotionalWellness/result',
        'view/mentalHealthQuiz/page' : 'view/mentalHealthQuiz/page',
        'view/mentalHealthQuiz/result' : 'view/mentalHealthQuiz/result',
        'view/announcement/page' : 'view/announcement/page',
        'view/userDashboard/page' : 'view/userDashboard/page',
        'view/indexSeo/page' : 'view/indexSeo/page',
        'view/womensDay/page' : 'view/womensDay/page',
        'view/womensDay/storyForm/page' : 'view/womensDay/storyForm/page',
        'view/womensDay/single/page' : 'view/womensDay/single/page',
        'view/womensDay/dacPage/page' : 'view/womensDay/dacPage/page',
        'view/whoDepressionDay/page' : 'view/whoDepressionDay/page',
        'view/whoDepressionDay/storyForm/page' : 'view/whoDepressionDay/storyForm/page',
        'view/whoDepressionDay/single/page' : 'view/whoDepressionDay/single/page',
        'view/whoDepressionDay/dacPage/page' : 'view/whoDepressionDay/dacPage/page',
        'view/whoDepressionDay/landing_page/page' : 'view/whoDepressionDay/landing_page/page',
        'view/subscription/page' : 'view/subscription/page',
        'view/campaign/page' : 'view/campaign/page',
        'view/campaign/storyForm/page' : 'view/campaign/storyForm/page',
        'view/ssoLogin/page' : 'view/ssoLogin/page',
        'view/homelatest/page' : 'view/homelatest/page',
        'view/mpbse/page' : 'view/mpbse/page',
        'view/under-construction/page' : 'view/under-construction/page',
        'view/selfHelp/kickthebutt/page':'view/selfHelp/kickthebutt/page',
        'view/selfHelp/kickthebutt/result':'view/selfHelp/kickthebutt/result'
    },

    urlArgs: 'v=v1.1'
});

require([
  'utils',
  'console',
  'view/app',
  'router/app-router',
  'model/users',
  'vm',
  'view/signup/page',
  'view/login/modal_page',
  'view/error403/page',
  'view/chatModal/modal',
  'view/messages/message',
  'view/messages/message_modal',
  'view/talkItOutV2/familiarExperts',
  'view/messages/counselor_dropdown',
  'view/donation/page',
  'event/dispatcher',
  'fingerprint',
  'backbone',
  'backbone-mixpanel',
  'raygun',
  'config',
  'materialize' ,
  'fb',
  'chatNotification',
  'view/home/page',
  'view/changePassword/page',
  'view/clientHistory/upage',
  'view/clientHistory/users',
  'view/counselor/singlepageV2',
  'view/faq/page',
  'view/faq/singlepage',
  'view/forgetPassword/page',
  'view/home/page',
  'view/home2/page',
  'view/home3/page',
  'view/login/page',
  'view/logout/page',
  'view/messages/fpage',
  'view/messages/fsinglepage',
  'view/messages/page',
  'view/messages/singlepage',
  'view/privacyPolicy/page',
  'view/resetPassword/page',
  'view/review/review',
  'view/talkItOut/page',
  'view/talkItOutV2/page',
  'view/teams/page',
  'view/testimonials/page',
  'view/tos/page',
  'view/unsubscribe/page',
  'view/users/page',
  'view/counselor/page',
  'view/template_helpers',
  'view/partners/page',
  'view/cancelAppointment/page',
  'view/welcome/initial',
  'view/messages/verifyemail',
  'view/mobileApps/page',
  'view/bookAppointment/page',
  'view/bookAppointment/payment_success',
  'view/bookAppointment/payment_failure',
  'view/bookAppointment/payment_pending',
  'view/process/page',
  'view/counselorChatResource/page',
  'view/relationship/page',
  'view/careerCounselor/page',
  'view/homelatest/page',
  'view/homeNew/page',
  //'view/sessions/page',
  'view/sessionsV2/page',
  'view/landingPages/page',
  'view/landingPages2/page',
  'view/selfHelp/habitometer/page',
  'view/parentingTips/page',
  'view/selfHelp/discoverYourself/page',
  'view/selfHelp/discoverYourself/resultPage',
  'view/selfHelp/playBuzzTest/page',
  'view/selfHelp/page',
  'view/contactUs/page',
  'view/appointmentFlow/page',
  'view/contactUs/forms/anythingElse',
  'view/contactUs/forms/shareYourFeedback',
  'view/contactUs/forms/issuesInOurService',
  'view/contactUs/forms/beASaviour',
  'view/contactUs/forms/becomeAVolunteer',
  'view/contactUs/forms/guestBlog',
  'view/selfHelp/trueColor/page',
  'view/selfHelp/trueColor/resultPage',
  'view/selfHelp/shapeTest/page',
  'view/selfHelp/shapeTest/resultPage',
  'view/selfHelp/habitometer/resultPage',
  'view/tos/modal_page',
  'view/sharePositiveChats/page',
  'view/tipsLandingPage/page',
  'view/joinUsExperts/page',
  'view/press/page',
  'view/notSupported/page',
  'view/hubsAndSpokes/page',
  'view/hubsAndSpokes/spokePage',
  'view/jobs/page',
  'view/jobs/singlepage',
  'view/counseling/page',
  'view/donation/page',
  'view/whyDonation/page',
  'view/appointmentFlow/page',
  'view/selfHelp/newYearQ2/page',
  'view/packages/page',
  'view/packages/custompackage_modal',
  'view/packages/single_page',
  'view/packages/package_booked',
  'view/packages/package_schedule',
  'view/packages/packages_faq',
  'view/suicidePrevention/page',
  'view/packages/packages_header',
  'view/hubsAndSpokes/faqpage',
  'view/suicidePrevention/page',
  'view/newYearPackages/page',
  'view/newYearPackages/single_page',
  'view/newYearPackages/schedule_page',
  'view/selfHelp/newYear/page',
  'view/selfHelp/newYear/resultPage',
  'view/newYearResolution2017/page',
  'view/selfHelp/newYearQ2/result',
  'view/valentine/page',
  'view/flames/page',
  'view/selfHelp/loveCompatibility/page',
  'view/selfHelp/loveCompatibility/result',
  'view/selfHelp/emotionalWellness/page',
  'view/selfHelp/emotionalWellness/result',
  'view/mentalHealthQuiz/page',
  'view/mentalHealthQuiz/result',
  'view/announcement/page',
  'view/userDashboard/page',
  'view/indexSeo/page',
  'view/womensDay/page',
  'view/womensDay/storyForm/page',
  'view/womensDay/single/page',
  'view/womensDay/dacPage/page',
  'view/whoDepressionDay/page',
  'view/whoDepressionDay/storyForm/page',
  'view/whoDepressionDay/single/page',
  'view/whoDepressionDay/dacPage/page',
  'view/whoDepressionDay/landing_page/page',
  'view/announcement/page',
  'view/subscription/page',
  'view/campaign/page',
  'view/campaign/storyForm/page',
  'view/ssoLogin/page',
  'view/mpbse/page',
  'view/under-construction/page',
  'view/selfHelp/stressTestProfessional/page',
  'view/selfHelp/stressTestProfessional/result',
  'view/selfHelp/kickthebutt/page',
  'view/selfHelp/kickthebutt/result',
  'sixpack'

], function(Utils, Console, AppView, AppRouter, UserModel, Vm, SignUpView, LoginModalView, Error403View, ChatModalView, UserMessageView, MessageView, CounselorDropdownView ,FamiliarExpertsView, DonationView, Dispatcher, Fingerprint2 ){


    var fbRootLength = $("#fb-root div") ;


    var fbRootHTML = $("#fb-root").html();



    window.onbeforeunload = function(){

      var title = window.location.pathname;
      if( !title ){
        title = 'Home';
      }
      if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

        mixpanel.track("ExitApplication", {"Title": title, "Source":"YD"});
      }
    }


      var distinctCookie = $.cookie("DYD");
      if(distinctCookie == undefined || !distinctCookie || distinctCookie == null){

        var chars = '#aA';
        var length = 32 ;

        var mask = '';
        if (chars.indexOf('a') > -1) mask += 'abcdefghijklmnopqrstuvwxyz';
        if (chars.indexOf('A') > -1) mask += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        if (chars.indexOf('#') > -1) mask += '0123456789';
        if (chars.indexOf('!') > -1) mask += '~`!@#$%^&*()_+-={}[]:";\'<>?,./|\\';
        var result = '';
        for (var i = length; i > 0; --i) result += mask[Math.round(Math.random() * (mask.length - 1))];

        var currentTime = new Date();

        result = result + currentTime.getTime() ;

          $.cookie("DID", result, {domain: ".yourdost.com"}) ;
          distinctCookie = result ;
      }

      window.fingerprint = distinctCookie ;


    Backbone.$.ajaxSetup({
        xhrFields: {
            withCredentials: true
        },
        beforeSend: function(xhr) {
            xhr.setRequestHeader('X-YDFP', window.fingerprint );
        },
        statusCode:{
            401 : function(){

                var hash =  window.location.pathname ;


                if( hash.match("logout") || ( ( $.cookie("DCU") == "null" ||
                    $.cookie("DCU") == undefined || $.cookie("DCU") == null ) && Utils.isLoggedIn() != 1 ) ){


                    if(window.location.pathname && !Utils.isLoggedInPage(window.location.pathname)){

                        if( window.location.pathname == "/!" || window.location.pathname == "/" || window.location.pathname == "/logout" )
                          return true;
                        else{
                          //location.href = window.location.pathname ;
                          Backbone.history.navigate(window.location.pathname + window.location.search, {trigger: true});
                        }

                    }else if(Utils.isLoggedInPage(window.location.pathname)){
                      if(hash.match("login")){
                        //location.href = window.location.pathname ;
                        Backbone.history.navigate(window.location.pathname, {trigger: true});
                      }else{
                        //location.href = "/login?r=" + hash ;
                        Backbone.history.navigate("/login?r=" + hash, {trigger: true});
                      }
                    }
                    else{
                          //location.href = "/!" ;
                          Backbone.history.navigate("/!", {trigger: true});
                    }
                }else{

                    //location.href = "/logout?r=" + hash ;
                    Backbone.history.navigate("/logout?r=" + hash, {trigger: true});

                }

            },
            403 : function(){
                var error403 = new Error403View() ;
                error403.render() ;
            },
        },
    });

    var mixpanelToken = Utils.getMixpanelToken() ;

    var source = '';
    if(document.location.href.search("utm_content") > -1){

        source = document.location.pathname.split('utm_content=')[1];
    }
    var categories = localStorage.getItem("categories");

    if( !categories || categories== null ){

      var category = {};
      var categories = {};
      $.ajax({
          method: "GET",
          url: Utils.contextPath()+'/category?include_faq=false'
      }).done(function(response){
        var category = {} ;
          _.each(response,function(cat){
            category[cat.id] = cat.name;
            categories["c_" + cat.id] = cat.name;
          });

          localStorage.setItem("categories",JSON.stringify(category));
          localStorage.setItem("c_categories",JSON.stringify(categories));
      }).fail(function(error){});
    }

    if(source != ''){

        $.ajax({
                method : "GET",
                url : '/scripts/json/utm_content.json' ,
             //   dataType: "json"
        }).done(function(response){


            for(var key in response){

                if(key == source){

                  $('meta[property="og:description"]').attr('content',response[source][0].description);
                  $('meta[property="og:title"]').attr('content',response[source][0].title);
                  $('meta[property="og:image"]').attr('content',response[source][0].imageUrl);
                }
            }

        }).error(function(error){

            console.log(error);
        });

    }

    var categories = localStorage.getItem("categories");

    if( !categories || categories== null ){

        var category = {};
        var categories = {};
        $.ajax({
            method: "GET",
            url: Utils.contextPath()+'/category?include_faq=false'
        }).done(function(response){
          var category = {} ;
            _.each(response,function(cat){
              category[cat.id] = cat.name;
              categories["c_" + cat.id] = cat.name;
            });
            localStorage.setItem("categories",JSON.stringify(category));
            localStorage.setItem("c_categories",JSON.stringify(categories));
        }).fail(function(error){});
      }


    Raygun.init(raygunKey,{
      ignoreAjaxAbort: true,
      ignoreAjaxError: true,
      ignore3rdPartyErrors : true
    }).attach();

    var urlHash = window.location.pathname ;
    if( !urlHash.match("forgetPassword") && !urlHash.match("resetPassword")){
        var userModel = new UserModel()  ;
        userModel.getAndSaveUser() ;
    }

    var appView = Vm.create({}, 'AppView', AppView);
    appView.render();

    Backbone.Mixpanel.init({
                 eventDataAttr: "desc" ,
                 customData: ['id', 'desc', "itemname"]
     });

    var signUpView = new SignUpView() ;

    var loginModalView = new LoginModalView() ;

    var chatModalView = new ChatModalView();

    var userMessageView = new UserMessageView();

    var messageView =  new MessageView();

    var counselorDropdownView = new CounselorDropdownView();

    var familiarExpertsView = new FamiliarExpertsView();
    var donationView = new DonationView();

    AppRouter.initialize({appView: appView});  // The router now has a copy of all main appview


    var fbRootLength = $("#fb-root div");


    setTimeout(function(){
      if( typeof Waves != undefined )
        Waves.displayEffect();
    },1000);

    $( window ).scroll(function() {

        if( $(window).scrollTop() > 150 ){
          $("#scroll-up-btn").removeClass("hide");
        }
        else{
          $("#scroll-up-btn").addClass("hide");

        }
        // console.log('appointmentFlow',$(window).scrollTop())


    });

    $(window).scroll(function(){

      if($(window).scrollTop() > 220){

        $('.single-package-footer').addClass("fixed");
      }else{

        $('.single-package-footer').removeClass("fixed");
      }

    })

    $.ajax({
      url : "https://d3dlm19tttbkds.cloudfront.net/contextSpecificMessages.json"
    }).done(function(response){
      localStorage.setItem("contextSpecificMessages", JSON.stringify(response));
    }).error(function(error){
      console.log(error);
    });

});
