define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'introjs',
], function($,_, Backbone, JST, Utils,UserModel) {

	var PaymentPendingPage = Backbone.View.extend({
		
		el: "main",
		initialize: function() {

			this.userModel = new UserModel() ;
	 	},
		events: {},
		PaymentPendingPageLayout : JST['app/templates/payment_pending.hbs'],
		render: function() {

			var self = this;
			var userID  = this.userModel.getUserID();
			$.ajax({
				url : Utils.contextPath() + "/v1/user/transaction/pending/" + userID
			}).done(function(response){
				if(response > 0){
					var directurl = "/sessions" ;
					if(self.$el.find(".msg-page").length > 0){

						self.$el.find(".payment-pending").removeClass("hide").find("a").attr("href", directurl)
					}else{

						self.$el.prepend( self.PaymentPendingPageLayout({directurl : directurl}));
					}
				}
			}).error(function(error){
				console.log(error)
			})
		}
	});

	PaymentPendingPage.prototype.remove = function() {
		
	};

	PaymentPendingPage.prototype.clean = function() {

	};


	return PaymentPendingPage;
});