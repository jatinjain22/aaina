define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'purl'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel) {

	var CancelAppointmentView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;

			var url           = window.location.href ;
    		url               = url.replace("/cancelAppointment", "" );
			var appointmentID = $.url( url ).param('appID') ;
			this.appointmentID = appointmentID ;

		},
		events: {},
		CancelAppointmentViewLayout: JST['app/templates/cancelAppointment/page.hbs'],
		render: function() {
			this.$el.html(this.CancelAppointmentViewLayout());

			var userID = this.userModel.getUserID();

			$.ajax({
				url : Utils.contextPath() + "/v2/users/" + userID + "/appointment/" + this.appointmentID + "/cancelappointment",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
			}).done(function(response){
			}).error(function(error){
				console.log(error) ;
			});



		}
	});

	CancelAppointmentView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	CancelAppointmentView.prototype.clean = function() {
		this.remove() ;
	};

	return CancelAppointmentView;
});
