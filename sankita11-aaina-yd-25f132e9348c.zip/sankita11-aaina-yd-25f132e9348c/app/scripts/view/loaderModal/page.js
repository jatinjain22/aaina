define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/leaveMessage/page' ,
	'utils'
], function($,_, Backbone, JST, LeaveMessageView, Utils) {

	var LoaderModalView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.leaveMessageView = new LeaveMessageView() ;
		},
		events: {
			'click #loader-modal .popup-close' : 'hideContainer'         ,
			'click #leaveOfflineMsg'           : 'leaveMessage'          ,
			'click #discussionOffline'         : 'redirectToDiscussion'  ,
		},
		redirectToDiscussion : function(e){
			this.hideContainer()         ;
			Utils.redirectToDiscussion() ;			
		},
		leaveMessage : function(e){
			//this.hideContainer()           ;
			$("#loader-modal").hide();
			this.leaveMessageView.render() ;
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "loader-modal"  ) ;
		},
		LoaderModalViewLayout : JST['app/templates/loaderModal/layout.hbs']         ,
		OfflineViewLayout     : JST['app/templates/loaderModal/offlineMessage.hbs'] ,
		render: function(username, workgroup, chatStartUrl) {
			this.$el.append( this.LoaderModalViewLayout() );
			Utils.openPopup( "loader-modal" ) ;

			var self = this ;
			$.ajax({
    			url : chatUrl + "/workgroup/isOnline?workgroup=" + workgroup ,
    		}).done(function(response){
    			console.log(response);
    			if(response == "true"){
    			location.href = chatStartUrl;
    			}else{
    				self.$el.find("#loader-main-content").html(self.OfflineViewLayout());
    			}
    		}).error(function(error){
    				self.$el.find("#loader-main-content").html(self.OfflineViewLayout());
    			console.log(error) ;
    		});	


		}
	});

	LoaderModalView.prototype.remove = function() {

	};

	LoaderModalView.prototype.clean = function() {

	};

	return LoaderModalView;
});
