define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'view/homeNew/subview/featured_in',
	'../../precompiled-templates',
	'event/dispatcher',
	'view/needHelp/page'
] , function( $, _, Backbone, Utils, FeaturedInView, JST, Dispatcher,NeedHelpView ) {

	var homeLatestPage = Backbone.View.extend({

		el: "main",

		initialize : function(){
			this.featuredInView = new FeaturedInView();
			this.needHelpView = new NeedHelpView()
		},

		events : {
			"click .hl-container .login": "login",
			"click .hl-container .chat": "chat",
			"click .hl-container .appointment": "bookAppointment",
			"click .hl-container #chat": "chat",
			"click .hl-container #chat-online": "chatOnline",
			"click .hl-container #appointment": "bookAppointment",
			"click .hl-container #direct-chat": "chatWithExpert",
			"click .hl-container #direct-appointment": "bookAppointmentWithExpert",
			"click .hl-container #direct-message": "messageExpert",
			"click .hl-container .browse": "browseAllExperts",
			"click .hl-container .package-container .content": "redirectToPackage",
			"click .hl-container .all-packages": "redirectToAllPackages",
			"click .hl-container .test": "redirectToTest",
			"click .hl-container .all-articles": "redirectToBlog",
			"click .hl-container .hl-articles .content": "redirectToArticle",
			"click .hl-container .hl-testimonials #opensavior": "referAFriend",
			"click .hl-container .header-link": "trackHeaderLink",
			"click .hl-container .expert-card": "openExpertProfile",
			'click .hl-container .hl-articles .close-popup' : 'closePopUp',
		},

		mainLayout : JST['app/templates/homeLatest/layout.hbs'],
		headerLayout : JST['app/templates/homeLatest/header.hbs'],
		bannerLayout : JST['app/templates/homeLatest/banner.hbs'],
		descLayout : JST['app/templates/homeLatest/desc.hbs'],
		helpLayout : JST['app/templates/homeLatest/help.hbs'],
		expertsLayout : JST['app/templates/homeLatest/experts.hbs'],
		packagesLayout : JST['app/templates/homeLatest/packages.hbs'],
		testLayout : JST['app/templates/homeLatest/test.hbs'],
		articlesLayout : JST['app/templates/homeLatest/articles.hbs'],
		testimonialsLayout : JST['app/templates/homeLatest/testimonials.hbs'],
		pressLayout : JST['app/templates/homeLatest/press.hbs'],

		render : function(options){
			this.isMobile = Utils.isMobileDevice();
			if (!this.isMobile) $('#main-header').hide();
			this.registerMixPanelEvent('Home-Page VISIT', { 'mediumSource' : 'website'});
			$(document).scroll(function (o) {
				var scrollTop = o.currentTarget.scrollingElement.scrollTop;
				if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1){
				     scrollTop = o.currentTarget.documentElement.scrollTop;
				}
				if (scrollTop > 50) {
					$('.hl-header .row').addClass("scrolled");
				} else {
					$('.hl-header .row').removeClass("scrolled");
				}
			});
			this.$el.html(this.mainLayout());
			$(".hl-banner").html(this.bannerLayout({'mobile': this.isMobile}));
			if (this.isMobile) {
				$(".hl-header").css('display', 'none');
			} else {
				this.checkForOrgId()
			}
			$(".hl-help").html(this.helpLayout({'mobile': this.isMobile}));
			$(".hl-test").html(this.testLayout({'mobile': this.isMobile}));
			$(".hl-press").html(this.pressLayout({'mobile': this.isMobile}));
			this.featuredInView.render(".hl-press .news");
			this.renderStats();
			this.renderExperts();
			this.renderPackages();
			this.renderArticles();
			this.renderTestimonials();
			this.needHelpView.render("homePage", true)
		},
		checkForOrgId : function(){
			var self = this;
			var showDiscussion = true;
			if(Utils.isLoggedIn()){
				var userObj = JSON.parse(localStorage.getItem("user"))
				var orgId = userObj['loggableUser']['orgId']
				this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
				.then(function(res){
					if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed == "0") showDiscussion = false
                    }
					$(".hl-header").html(self.headerLayout({ showDiscussion : showDiscussion }));
				}, function(err){
					$(".hl-header").html(self.headerLayout({ showDiscussion : showDiscussion }));
				})
			}else{
				this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
				.then(function(res){
					if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed == "0") showDiscussion = false
                    }
					$(".hl-header").html(self.headerLayout({ showDiscussion : showDiscussion }));
				}, function(err){
					$(".hl-header").html(self.headerLayout({ showDiscussion : showDiscussion }));
				})
			}
		},

		openExpertProfile: function (evt) {
			var id = evt.currentTarget.getAttribute("data-identifier");
			window.location.href = "/counselor/" + id;
		},

		trackHeaderLink : function(e){
		    var href = $(e.currentTarget).attr('href');
		    var url = href.replace(/^\//,'').replace('\#\!\/','');
		    this.registerMixPanelEvent('Header', {'itemName': url, 'mediumSource' : 'website' });
		},

		registerMixPanelEvent: function (eventName, options) {
			if ((typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){
		        mixpanel.track(eventName || 'Button Click', options);
			}
		},

		renderStats: function () {
			var self = this;
			this.sendRequest("GET", "https://d3dlm19tttbkds.cloudfront.net/statistics.json")
			.then(function (res) {
				$(".hl-desc").html(self.descLayout({'number': res[0].no_of_people, 'mobile': self.isMobile}));
				self.expertsCount = res[1].no_of_experts;
			});
			this.sendRequest("GET", Utils.contextPath() + "/v1/dashboard/ongoingCnt")
			.then(function (res) {
				$('.hl-banner .online').html('<span class="reddot"></span><span class="people"> ' + (res + 20) + ' People are currently seeking  guidance </span>');
			});
		},

		redirectToTest: function () {
			this.registerMixPanelEvent('', {'itemName': '#SelfTestBtn'});
			this.redirectToUrl({
				'url': '/selfhelp'
			});
		},

		referAFriend: function () {
			this.registerMixPanelEvent('Be a Saviour');
			this.redirectToUrl({
				'url': '/help-a-friend'
			});
		},

		renderTestimonials: function () {
			var self = this;
			this.sendRequest("GET","https://d3dlm19tttbkds.cloudfront.net/user_testimonials1.json",'','text/plain')
			.then(function (response) {
				$(".hl-testimonials").html(self.testimonialsLayout({'details' : response, 'mobile': self.isMobile}));

				var hlSwiper = new Swiper ('.hl-testimonials-swiper', {

				   	pagination: '.hl-testimonials-pagination',
	        		paginationClickable: true,
	        		autoplay: 10000,
	        		keyboardControl: true
				});
			});
		},

		redirectToPackage: function (evt) {
			this.registerMixPanelEvent('', {'itemName': '#HOME PROGRAMS SECTION'});
			var url = evt.currentTarget.getAttribute("data-url");
			this.redirectToUrl({
				'url': '/online-counseling-programs/' + url
			});
		},

		redirectToAllPackages: function () {
			this.registerMixPanelEvent('', {'itemName': ' #allProgramsBtn'});
			this.redirectToUrl({
				'url': "/online-counseling-programs"
			});
		},

		redirectToBlog: function () {
			this.registerMixPanelEvent('', {'itemName': '#allArticlesBtn'});
			this.redirectToUrl({
				'url': "http://yourdost.com/blog"
			});
		},
		closePopUp :  function(e){
				$("#yd-video").remove()
				$(".yd-popup").hide();
		},
		redirectToArticle: function (evt) {
			this.registerMixPanelEvent('', {'itemName': '.home-articles'});
			var video = evt.currentTarget.getAttribute("data-yUrl"),
					url = evt.currentTarget.getAttribute("data-url")
					title = evt.currentTarget.getAttribute("data-title")
			if(video && video != ''){
				var temp = '<iframe id="yd-video" src="'+video+'?autoplay=1"></iframe>'
				$(".yd-shareicons").find(".addthis_toolbox").attr("addthis:url", url)
				$(".yd-shareicons").find(".addthis_toolbox").attr("addthis:title", title)
				$("#yd-video").remove()
				$(".yd-popupcontent").append(temp);
				$(".yd-popup.videos").show();
				return;
			}
			var url = evt.currentTarget.getAttribute("data-url");
			this.redirectToUrl({
				'url': url
			});
		},

		browseAllExperts: function () {
			this.registerMixPanelEvent('', {'itemName': '#allExpertsBtn'});
			Backbone.history.navigate('/talkItOut?from=showAllExperts', {'trigger': true});
		},

		chatWithExpert: function (evt) {
			this.registerMixPanelEvent('', {'itemName': '#CHAT- Widget Expert Card'});
			var chatUrl = evt.currentTarget.getAttribute('data-url');
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						url: chatUrl
					},
					callback: this.redirectToUrl
				} ) ;
			} else {
				this.redirectToUrl({
					'url': chatUrl
				});
			}
		},

		messageExpert: function (evt) {
			this.registerMixPanelEvent('', {'itemName': ' #MSG- Widget Expert Card'});
			var expertId = evt.currentTarget.getAttribute('data-id');
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						id: expertId
					},
					callback: this.message
				} ) ;
			} else {
				this.message({
					'id': expertId
				});
			}
		},

		bookAppointmentWithExpert: function (evt) {
			this.registerMixPanelEvent('', {'itemName': '#Appointment- Widget Expert Card'});
			var expertId = evt.currentTarget.getAttribute('data-id');
			Backbone.history.navigate("/bookAppointment?from=counselor&conID=" + expertId +"&catID=Others", {trigger: true});
		},

		message: function (options) {
			Dispatcher.trigger("openComposeMessage", {
				info: {
					recipientId: options.id
				}
			});
		},

		redirectToUrl: function (options) {
			window.location.href = options.url;
		},

		sendRequest: function (method, url, dataType, contentType) {
			var deferred = $.Deferred();
			$.ajax({
				'method' : method,
				'url' : url,
				'dataType': dataType,
				'contentType': contentType
			})
			.done(function (response) {
				deferred.resolve(response);
			})
			.fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},
		renderArticles: function () {
			var self = this;
			this.sendRequest("GET", blogUrl, 'jsonp')
			.then(function (res) {
				var articles = res.posts.slice(0,4);
				var list = [];
				articles.forEach(function (article) {
					article.category = article.categories[0].slug;
					if (article.category == 'video') {
						article.type = 'VIDEO';
						var iframe = article.content.match(/(<iframe.*?>.*?<\/iframe>)/g)
						article.yUrl = $(iframe[0]).attr("src")
					} else {
						article.type = 'ARTICLE';
					}
					list.push(article);
				});
				$(".hl-articles").html(self.articlesLayout({'details': list, 'mobile': self.isMobile}));
			});
		},

		renderPackages: function () {
			var self = this;
			var packagesList = [];
			this.sendRequest("GET", Utils.contextPath() + "/packages")
			.then(function (res) {
				for (var i=0; i<5; i++) {
					var packageDetails = res[i];
					packageDetails.detailsUrl = Utils.packagesMap[packageDetails.id];
					packageDetails.mobile = packageDetails.illustration_url.split(",")[1];
					packageDetails.web = packageDetails.illustration_url.split(",")[0];
					packagesList.push(packageDetails);
				}
				$(".hl-packages").html(self.packagesLayout({'details': packagesList, 'mobile': self.isMobile}));
				if (!self.isMobile) {
					$(".hl-packages .content").mouseenter(function (evt) {
						$(this).find(".desc").css("top", "0");
					});
					$(".hl-packages .content").mouseleave(function (evt) {
						$(this).find(".desc").css("top", "100%");
					});
				}
			});
		},
		getThumbnailUrl: function (url) {
			var splitUrl = url.split(".net/");
			return splitUrl[0] + ".net/thumbnails/" + splitUrl[1];
		},
		expertIdentifier : function(expert){
			var hyphenatedName = expert.name.replace(/\s/g , "-");
			var counselorProfileIdentifier = hyphenatedName + '-'+expert.id;
			return counselorProfileIdentifier
		},
		renderExperts: function () {
			var self = this;
			var expertsPromise = this.sendRequest("GET", Utils.contextPath() + "/v1/counselor?page_number=1");
			//var reviewsPromise = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/rating/" + expertId);
			var statusPromise = this.sendRequest("GET", Utils.contextPath() + "/v1/counselor/status");
			$.when(expertsPromise, statusPromise)
			.then(function (experts, status) {
				var expert1 = experts[0];
				expert1.picUrl = self.getThumbnailUrl(expert1.picUrl);
				expert1.status = status[expert1.id]['status'] == 'true' ? true : false;
				expert1.chatUrl = status[expert1.id]['url'];
				expert1.identifier = self.expertIdentifier(expert1)
				var expert1rating = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/" + expert1.id + '/ratingFavoriteCnt');
				var expert2 = experts[1];
				expert2.picUrl = self.getThumbnailUrl(expert2.picUrl);
				expert2.status = status[expert2.id]['status'] == 'true' ? true : false;
				expert2.chatUrl = status[expert1.id]['url'];
				expert2.identifier = self.expertIdentifier(expert2)
				var expert2rating = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/" + expert2.id + '/ratingFavoriteCnt');
				var expert3 = experts[2];
				expert3.picUrl = self.getThumbnailUrl(expert3.picUrl);
				expert3.status = status[expert3.id]['status'] == 'true' ? true : false;
				expert3.chatUrl = status[expert1.id]['url'];
				expert3.identifier = self.expertIdentifier(expert3)
				var expert3rating = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/" + expert3.id + '/ratingFavoriteCnt');
				$.when(expert1rating, expert2rating, expert3rating)
				.then(function (rating1, rating2, rating3) {
					expert1.reviewCount = rating1.rating;
					expert2.reviewCount = rating2.rating;
					expert3.reviewCount = rating3.rating;
					var counselorDetails = [];
					counselorDetails.push(expert1);
					counselorDetails.push(expert2);
					counselorDetails.push(expert3);
					$(".hl-experts").html(self.expertsLayout({'details': counselorDetails, 'number': self.expertsCount, 'mobile': self.isMobile}));
				});
			});
		},

		login: function () {
			this.registerMixPanelEvent('', {'itemName': '.login-clicked'});
			if(!Utils.isLoggedIn()){
			  Dispatcher.trigger("renderLogin", "click Landing Home Page", "login", "loginButton") ;
			}
		},

		redirect: function () {
			Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {});
		},

		chat: function (e) {
			var itemName = $(e.target).hasClass('action-content') ? 'Home_Chat_3_ways' : '#Home Chat Icon';
			this.registerMixPanelEvent('', {'itemName':itemName});
			this.initiateChat();
		},

		initiateChat: function () {
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat'
					},
					callback: this.redirect
				} ) ;
			} else {
				this.redirect();
			}
		},

		chatOnline: function () {
			this.registerMixPanelEvent('Home_Chat_Online_Testimonials');
			initiateChat();
		},

		bookAppointment: function (e) {
			var itemName = $(e.target).hasClass('action-content') ? 'Home_Appointment_3_ways' : '#Home Appointment Icon';
			this.registerMixPanelEvent('', {'itemName':itemName});
			Backbone.history.navigate("/bookAppointment", {trigger: true});
		}
	});

	homeLatestPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	homeLatestPage.prototype.clean = function() {

		this.remove() ;
	};

	return homeLatestPage;
});
