define([
	'jquery',
	'underscore',
  	'event/dispatcher',
  	'backbone',
  	'../../precompiled-templates',
  	'utils',
  	'model/users'
], function($,_, Dispatcher, Backbone, JST, Utils, UserModel) {

	var JobPage = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.userModel = new UserModel();
		},
		events: {
      		"click .jobs-category-open-role-view": "redirectToJobDescription",
      		"click .job-view-all-open-roles": "scrollToOpenRoles"

    	},
		Layout: JST["app/templates/jobs/layout.hbs"],

		scrollToOpenRoles: function(e) {
			Utils.scrollTo('.jobs-open-roles-row', 0);
		},

		redirectToJobDescription: function(e) {

			var currentTarget = $(e.currentTarget);
			console.log( "currentTarget", currentTarget );
			var targetUrl = currentTarget.context.dataset.target;
			console.log( "targetUrl", targetUrl );
			targetUrl = "/jobs/" + targetUrl; 
			Backbone.history.navigate(targetUrl, {trigger: true});
		},
		render: function() {
			
			var self = this;
			document.title="Jobs | Career at YourDOST";
				$('meta[name=description]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
				$('meta[name=title]').attr('content',"Jobs | Career at YourDOST");
				$('meta[property="og:description"]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
				$('meta[property="og:title"]').attr('content',"Jobs | Career at YourDOST");
				$('link[rel="canonical"]').attr('href', 'https://yourdost.com/jobs');
			var url = Backbone.history.getFragment();
			$.ajax({
				method : "GET",
				url : Utils.scriptPath() + "/jobs/jobs.json",
				cache: false
        	}).done(function(response){
        		console.log("response", response);

        		self.$el.html( self.Layout({response: response}) );
        		var openRolesVal = $.url( url ).param( 'openRoles' );
        		if ( openRolesVal == 'true' ) {
        			self.scrollToOpenRoles();
        		}
        	
        	}).error(function(error){
        		console.log("error", error);
        	});


		},
	});

	JobPage.prototype.remove = function() {
		
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.undelegateEvents();
    	//this.stopListening();
	};

	JobPage.prototype.clean = function() {
		
		this.remove() ;
	};

	return JobPage;
});
