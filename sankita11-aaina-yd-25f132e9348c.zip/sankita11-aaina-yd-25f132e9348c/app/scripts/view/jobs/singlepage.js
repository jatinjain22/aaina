define([
	'jquery',
	'underscore',
  	'event/dispatcher',
  	'backbone',
  	'../../precompiled-templates',
  	'utils',
  	'model/users'
], function($,_, Dispatcher, Backbone, JST, Utils, UserModel) {

	var JobDescriptionPage = Backbone.View.extend({
		
		el: "main",
		initialize: function(options) {
			this.name = options.name
			this.userModel = new UserModel();
		},
		events: {
      		"click .job-description-apply-button": "applyForJob",
      		"click .job-description-apply-button-bottom": "applyForJob",
      		"click .job-submit-application": "submitApplicationForJob",
      		"click .close-job-application-modal": "closeApplication",
      		// "click #resume-file-attachment": "attachFile",
      		// "click .job-application-resume-file-attachment": "attachFile",
      		"click .jobs-description-breadcrumb-openroles": "viewOpenRoles"

    	},
		Layout: JST["app/templates/jobs/jobDescriptionLayout.hbs"],
		UploadResumeLayout: JST["app/templates/jobs/uploadResume.hbs"],

		viewOpenRoles: function(e) {
			Backbone.history.navigate('/jobs?openRoles=true', {trigger: true});
		},
		
		closeApplication: function(e) {
			// $("#job-application-modal").remove();
			// $('.job-description-overlay').addClass('hide');
			$("#job-application-modal").remove();
			$(".job-description-overlay").addClass("hide");
		},
		attachFile: function(e) {
			console.log( "click" );
			var resumeName = $("#resume-file-attachment").val().split('/').pop().split('\\').pop();
			$('.job-application-resume-attached-name').text( resumeName );
			$('.job-application-resume-attached-name').removeClass('hide');
		},
		submitApplicationForJob: function(e) {

			var resumeName = $("#resume-file-attachment").val().split('/').pop().split('\\').pop();

			var data = new FormData();
			var self =  this;
			var name = $("#job-application-name").val();
			var email = $("#job-application-email").val();
			var phoneNo = $("#job-application-phone").val();
			var linkedInUrl = $("#job-application-linkedin-url").val();
			var jobPosition = this.name;

			console.log( "name", name );
			console.log( "email", email );
			console.log("phoneNo", phoneNo);
			console.log("jobPosition", jobPosition );
			
			
			var isValidName = this.checkForName() ;
        	var isValidEmail = this.checkForEmail() ;
        	var isValidMobile = this.checkForMobile() ;
			
			var file = $('#resume-file-attachment').get(0).files[0];
			
			if ( isValidName == 0 || isValidEmail == 0 || isValidMobile == 0) {
				return false;
			} 
			
			if(file.type == "application/x-ms-dos-executable"){

				$(".message-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			$('.job-application-resume-attached-name').html( resumeName );
			$('.job-application-resume-attached-name').removeClass('hide');
			$('.job-application-div-submit').addClass('hide');
			$('.job-application-div-submit-progress').removeClass('hide');
			data.append('name', name);
			data.append('email', email);
			data.append('mobile', phoneNo);
			data.append('linkedIn', linkedInUrl);
			data.append('position', jobPosition);
			data.append('file', file );

			
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/resume',
			}).done(function(response){

				console.log("Response: ",response);
				$('.job-application-div-submit').removeClass('hide');
				$('.job-application-div-submit-progress').addClass('hide');
				$('.job-application-resume-attached-name').addClass('hide');
				self.closeApplication();

				if (response.fileID > 0) {
					
					Utils.displaySuccessMsg("Thanks for applying to YourDOST. We will get back to you soon.");
					
				} else {
					Utils.displaySuccessMsg("Oops some error occured. Send your resume to work@yourdost.com");					
				}

			}).error(function(error){
				$('.job-application-div-submit').removeClass('hide');
				$('.job-application-div-submit-progress').addClass('hide');
				$('.job-application-resume-attached-name').addClass('hide');
				self.closeApplication();
				Utils.displaySuccessMsg("Oops some error occured. Send your resume to work@yourdost.com");
				console.log("Error: "+error);
			})
		},

		applyForJob: function(e) {

			var self = this;
			$('.job-description-overlay').removeClass('hide');
			$('#apply-form-job-description').html( self.UploadResumeLayout() );
			Utils.scrollTo("#job-application-modal", -100);
			
			$("#job-application-name").keystop( function(event){
            		self.checkForName(event) ;
          	}, 1000 ) ;

			$("#job-application-email").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;

			$("#job-application-phone").keystop( function(event){
				self.checkForMobile(event) ;
			}, 1000 ) ;
			$('#resume-file-attachment').change(function(e){
					console.log( "click", "file input");
					self.attachFile(e);
			});
		},

		checkForName : function(e){

	        var name = $("#job-application-name").val().trim();
	        if( !Utils.checkForNameField(name) ){
	          console.log("hello");
	          $("#jobapp-name-error").html("Please tell us your name!");
	          $("#jobapp-name-error").removeClass("hide");
	          $("#job-application-name").addClass("invalid").removeClass("valid") ;
	          Utils.formDisableSubmit('job-submit-application');
	          // document.getElementById('volunteer-name').scrollIntoView(true);
	          
	          return 0 ;
	        }else{
	          $("#jobapp-name-error").addClass("hide");
	          Utils.formEnableSubmit('job-submit-application');
	          $("#job-application-name").addClass("valid").removeClass("invalid") ;
	          return 1 ;
	        }

      	},


		checkForEmail : function(e){
			var isValidEmail = Utils.formEmailCheck($("#job-application-email").val().trim());
			if(!isValidEmail){
			  $("#jobapp-email-error").html("Please provide a valid email ID - so we can contact you");
			  $("#jobapp-email-error").removeClass("hide");
			  $("#job-application-email").addClass("invalid").removeClass("valid") ;
			  Utils.formDisableSubmit('job-submit-application');
			  // document.getElementById('volunteer-email').scrollIntoView(true);
			  
			  return 0 ;
			}else{
			  $("#jobapp-email-error").addClass("hide");
			  $("#job-application-email").addClass("valid").removeClass("invalid") ;
			  Utils.formEnableSubmit('job-submit-application');
			  return 1 ;
			}
		},
      
		checkForMobile : function(e){
			var isValidMobile = Utils.formMobileCheck($("#job-application-phone").val().trim());
			if(!isValidMobile){
			  $("#jobapp-phone-error").html("Please provide a valid contact number - so we can contact you");
			  $("#jobapp-phone-error").removeClass("hide");
			  $("#job-application-phone").addClass("invalid").removeClass("valid") ;
			  Utils.formDisableSubmit('job-submit-application');
			  // document.getElementById('volunteer-phone').scrollIntoView(true);
			  
			  return 0 ;
			}else{
			  $("#jobapp-phone-error").addClass("hide");
			  $("#job-application-phone").addClass("valid").removeClass("invalid") ;
			  Utils.formEnableSubmit('job-submit-application');
			  return 1 ;
			}
		},

		render: function() {
			
			document.title="Jobs | Career at YourDOST";
				$('meta[name=description]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
				$('meta[name=title]').attr('content',"Jobs | Career at YourDOST");
				$('meta[property="og:description"]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
				$('meta[property="og:title"]').attr('content',"Jobs | Career at YourDOST");
				$('link[rel="canonical"]').attr('href', 'https://yourdost.com/jobs');
				
			var self = this;
			$.ajax({
				method : "GET",
				url : Utils.scriptPath() + "/jobs/jobsDescription.json",
				cache: false
        	}).done(function(response){
        		console.log( "name", self.name );
        		console.log("response", response[self.name]);
        		var response = response[self.name];
        		self.$el.html( self.Layout({response: response}) );
        		// self.$el.append( self.UploadResumeLayout() );
        		Utils.scrollTo('.job-description-body-container', -70);
        		
        		
				
				


        	}).error(function(error){
        		console.log("error", error);
        	});


		},
	});

	JobDescriptionPage.prototype.remove = function() {
		
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.undelegateEvents();
    	//this.stopListening();
	};

	JobDescriptionPage.prototype.clean = function() {
		
		this.remove() ;
	};

	return JobDescriptionPage;
});
