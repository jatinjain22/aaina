define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'purl',
], function($, _, Backbone, Utils ) {

	var LogoutPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			var url = window.location.href ;
    		url = url.replace("/logout", "" );
			var redirectTo = $.url( url ).param('r') ;
			if(redirectTo == undefined){
				redirectTo = "" ;
			}
			redirectTo = redirectTo.replace(/^\//, "");
			this.redirectTo = redirectTo ;
			var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo;
			this.mpbseUser = false;
		},
		generateNewID: function() {
  			function s4() {
    			return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
  			}
  			return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
		},
		events: {},
		render: function() {
		  document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
		  var self          = this ;
		  var mixpanelToken = Utils.getMixpanelToken() ;
          $.ajax({
          	url : Utils.contextPath() + "/v2/users/logout",
          	method: "POST" ,
          	statusCode:{
         		401 : function(){
					if(localStorage.getItem("user")){
						if(JSON.parse(localStorage.getItem("user")).loggableUser["orgId"] == 9) self.mpbseUser = true
					}
	 	           	localStorage.removeItem("user");
	 	           	localStorage.removeItem("isLoggedIn");
	 	           	//localStorage.removeItem("categories");
	 	           	localStorage.removeItem("skipCouponNotification");
            	   	localStorage.removeItem("hideCouponNotificationHeader");
		          	$.cookie('DCU', null, { expires: null, path: '/', domain: '.yourdost.com', secure: true });
		          	$.cookie('_t', "", { expires: null, path: '/', domain: '.yourdost.com', secure: true });
		          	$.cookie('mp_' + mixpanelToken + "_mixpanel", "", { expires: null, path: '/', domain: '.yourdost.com', secure: true });
				  	Raygun.setUser( "" ) ;
				  	//$.removeCookie('DCU', { domain: '.yourdost.com' });
				  	//location.href = self.extredirectTo;
					if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
						mixpanel.cookie.clear();
						mixpanel.identify(self.generateNewID());
					}
					if(self.mpbseUser){
						Backbone.history.navigate("/mpbse", {trigger: true});
						return;
					}
		          	if(window.location.pathname == "" || window.location.pathname == "/!" ){
		            	window.location.reload();
		          	}else{
		          		if( self.redirectTo && !Utils.isLoggedInPage( self.redirectTo )){
		          			//location.href = "/" + self.redirectTo ;
		          			Backbone.history.navigate("/" + self.redirectTo, {trigger: true});
		          		}else if(Utils.isLoggedInPage(window.location.pathname)){
                     		if(self.redirectTo != undefined && self.redirectTo.match("login")){
                        	//location.href = "/" + self.redirectTo ;
                        	Backbone.history.navigate("/" + self.redirectTo, {trigger: true});
                      	}else{
                        	//location.href = "/login?r=" + self.redirectTo ;
                        	Backbone.history.navigate("/login?r=" + self.redirectTo, {trigger: true});
                      	}
                    }else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
						location.href =self.extredirectTo;
					}else{
		            	//location.href = "/!" ;
		            	Backbone.history.navigate("/!", {trigger: true});
		          	}
		          }
	   	    	}
	        },
        }).done(function(response){
			//clear all memories
			delete window.msgType;
			if(localStorage.getItem("user")){
				if(JSON.parse(localStorage.getItem("user")).loggableUser["orgId"] == 9) self.mpbseUser = true
			}
			localStorage.removeItem('user');
			localStorage.removeItem("isLoggedIn");
			//localStorage.removeItem("categories");
			localStorage.removeItem("skipCouponNotification");
           	localStorage.removeItem("hideCouponNotificationHeader");
			$.cookie('DCU', null, { expires: null, path: '/', domain: '.yourdost.com', secure: true });
			$.cookie('_t', "", { expires: null, path: '/', domain: '.yourdost.com', secure: true });
			$.cookie('mp_' + mixpanelToken + "_mixpanel", "", { expires: null, path: '/', domain: '.yourdost.com', secure: true });
			Raygun.setUser( "" ) ;
			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
				mixpanel.cookie.clear();
				mixpanel.identify(self.generateNewID());
			}
			if(self.mpbseUser){
				Backbone.history.navigate("/mpbse", {trigger: true});
				return;
			}
	        if(window.location.pathname == "" || window.location.pathname == "/!" ){
	            window.location.reload();
	        }else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
				location.href = self.extredirectTo;
			}else{
	            //location.href = "/!" ;
	            Backbone.history.navigate("/!", {trigger: true});
	        }
        }).error(function(error){
          	console.log(error) ;
        });

		},
	});

	LogoutPage.prototype.remove = function() {
		this.undelegateEvents();
	};

	LogoutPage.prototype.clean = function() {

		this.unbind();
    	this.remove();

    	delete this.$el;
    	delete this.el;

	};

	return LogoutPage;
});
