define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher) {

	var ReviewView = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.listenTo(Dispatcher, 'renderReview', this.render);
			this.userModel = new UserModel() ;

			var url         = window.location.href ;
    		url             = url.replace("/review", "" );
			var counselorID = $.url( url ).param('counselor') ;
			var userID      = $.url( url ).param('user') ;
			var chatID      = $.url( url ).param('chatID') ;
			var token       = $.url( url ).param('_t') ;

			this.chatID     = chatID      ;
			this.id         = counselorID ;
			this.userID     = userID      ;
			this.token      = token       ;
			this.skipInProgress = 0 ;
			console.log(this.userID);

		},
		events: {
			'click #review-modal .popup-close'  : 'hideContainer' ,
			'click #skip-review' : 'hideContainer' ,
			'click input[name="rating"]' : 'checkForRating',
			'click input[name="feeling"]' : 'checkForFeeling',
			'submit .reviewForm' : 'reviewCounselor',
			"click .donate-money-btn" : "clickedCertainAmount",
		    "keyup .donate-money-input" : "insideMoneyInput"
		},
		hideContainer : function(e){			
			var counselorObj = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
		      var chatID ;
		      if(this.chatID){
		      	chatID = this.chatID ;
		      }else{
			    var counselorObj = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
			    chatID = counselorObj.id                               ;
		      }

			this.markReviewAsDone(chatID) ;
		},
   		checkForRating: function(e){
	   	
	   		var  star  = $("input[name='rating']:checked").val() ;
        	if( star >= 4 ){

        		if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
	        	    mixpanel.track('Chat Rating', {'mediumSource' : 'website', 'itemName': 'Chat Feedback Rating '+star });
	          
	        	}
	        	$(".donate-info").removeClass("hide");
	        	$(".donate-submit-btn").addClass("hide");
	        	$(".submit-btn").removeClass("hide");
	        }else{

	        	$(".donate-info").addClass("hide");
	        	$(".donate-submit-btn").addClass("hide");
	        	$(".submit-btn").removeClass("hide");
	        }
        	$(".rating-text").html("("+ star +"/5)");

        	var  star  = $("input[name='rating']:checked").val() ;

        	if(star == undefined){
          		$("#rating-error").removeClass("hide");
        	}else{
          		$("#rating-error").addClass("hide");
        	}

  		},
  		clickedCertainAmount : function(e){

			var value = '';
			if($(e.currentTarget).hasClass("selected")){

				$(".donate-money-btn").removeClass("selected")
				$(".donate-money-btn").find("img").attr("src", "https://d1763776ly2p7c.cloudfront.net/images/ruppe+(1).png")
				$(e.currentTarget).removeClass("selected")
				$(e.currentTarget).find("img").attr("src", "https://d1763776ly2p7c.cloudfront.net/images/ruppe+(1).png")
				value = ''
			}else{

				$(".donate-money-btn").removeClass("selected")
				$(".donate-money-btn").find("img").attr("src", "https://d1763776ly2p7c.cloudfront.net/images/ruppe+(1).png")
				$(e.currentTarget).addClass("selected")
				$(e.currentTarget).find("img").attr("src", "https://d1763776ly2p7c.cloudfront.net/images/ruppe-white.png")
				value = $(e.currentTarget).attr("data-href");
			}
			
			$(".donate-submit-btn").removeClass("hide");
			$(".submit-btn").addClass("hide");
			$(".donate-money-input").val(value);

		},
		insideMoneyInput : function(e){

			var value = $(".donate-money-input").val();
			if(parseInt(value) < 50 || value == ''){

				$(".donate-money-input-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.");
				$(".donate-submit-btn").addClass("hide");
				$(".submit-btn").removeClass("hide");
			}else{


				$(".donate-money-input-error").addClass("hide").html("")
				$(".donate-submit-btn").removeClass("hide");
				$(".submit-btn").addClass("hide");
			}

			var data = $(".donate-money-btn");

			$.each(data , function(index){

				if($(data[index]).attr("data-href") == value){

					$(".donate-money-btn").removeClass("selected");
					$(data[index]).addClass("selected");
				}else{

					$(".donate-money-btn").removeClass("selected");					
				}
			})
		},
		submitDonation : function(userID, amount){

			$.ajax({
				url         : Utils.contextPath() + '/v1/user/'+ userID +'/donate/'+ amount,
				method      : 'GET',
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				statusCode:{
					401 : function(){

						Backbone.history.navigate("/talkItOut", {trigger: true});
					}
				}
			}).done(function(response){

				console.log(response);

				if($("#review-modal").length){

					$(".review-bar").addClass("hide");
					$("body").css("overflow", "auto") ;
					Utils.closePopup( "review-modal"  );
					$("#review-modal").remove();
				}

				if( !response.error){

					location.href = response.uri;
				}else{

					var ret = Backbone.history.navigate("/talkItOut", {trigger: true});	
							
					if (ret === undefined) {

						Backbone.history.loadUrl("/talkItOut");
					}
				}
			}).error(function(error){

				console.log(error);
				if($("#review-modal").length){

					$(".review-bar").addClass("hide");
					$("body").css("overflow", "auto") ;
					Utils.closePopup( "review-modal"  );
					$("#review-modal").remove();
				}
				var ret = Backbone.history.navigate("/talkItOut", {trigger: true});	
							
				if (ret === undefined) {

					Backbone.history.loadUrl("/talkItOut");
				}

			});
		},
		checkForFeeling: function(){

	        var feeling  = $("input[name='feeling']:checked").val() ;
	        if(feeling == undefined){
	          $("#feeling-error").removeClass("hide");
	        }else{
	          $("#feeling-error").addClass("hide");
	        }
		 
		},

  		checkForInputFields : function(){

	        var  star     = $("input[name='rating']:checked").val() ;
	        var  feeling  = $("input[name='feeling']:checked").val() ;

	        var validationError = 0 ;
	        if( feeling == undefined ){
	          $("#feeling-error").removeClass("hide");
	          validationError = 1 ;
	        }

	        if(star == undefined){
	          $("#rating-error").removeClass("hide");
	          validationError = 1 ; 
	        }

	        return validationError ;
  		},

  		markReviewAsDone : function( chatID , star ){

  			if(this.skipInProgress == 1){
  				return false ;
  			}

  			var self = this;

  			var userID ;
  	        if(this.userID){
	      		userID = this.userID;
	     	}else{
	      		userID = this.userModel.getUserID();
	      	}

			var headersToPass = {} ;
	      	if(this.token){
		      	headersToPass = {
					"X-DOST-ZION-AUTH" : this.token ,
				} ;
		    }

		    this.skipInProgress = 1 ;
		    $(".popup-close").addClass("grey-text text-lighten-2");

		    $("#skip-review").hide() ;
		    $("#review-chat").hide() ;
		    $(".donate-submit-btn").hide();
			$(".submit-btn").hide();
		    $("#submit-progress").show() ;

  			$.ajax({
  				url : Utils.contextPath() + "/v1/users/"+ userID +"/rating/"+ chatID +"/pending",
  				method : "POST" ,
		        dataType: "JSON",
		        contentType: "application/json; charset=utf-8",
		        headers : headersToPass,
  			}).done(function(response){


  				if($(".donate-info").is(":visible")){

					var moneyValue = $(".donate-money-input").val();

					if(parseInt(moneyValue) >= 50){

						self.submitDonation(userID, moneyValue);
					}else{

						if($("#review-modal").length){

							$(".review-bar").addClass("hide");
							$("body").css("overflow", "auto") ;
							Utils.closePopup( "review-modal"  );
							$("#review-modal").remove();
						}

						if(star > 3 ){

							Backbone.history.navigate("/share-positive-chats", {trigger: true});
						}else{

							var ret = Backbone.history.navigate("/talkItOut", {trigger: true});	
							
							if (ret === undefined) {

	    						Backbone.history.loadUrl("/talkItOut");
							}
						}
					}	
				}else{

					if($("#review-modal").length){

						$(".review-bar").addClass("hide");
						$("body").css("overflow", "auto") ;
						Utils.closePopup( "review-modal"  );
						$("#review-modal").remove();
					}else{

						var ret = Backbone.history.navigate("/talkItOut", {trigger: true});	
							
						if (ret === undefined) {

    						Backbone.history.loadUrl("/talkItOut");
						}
					}
				}

				this.skipInProgress = 0 ;
  			}).error(function(error){
		        console.log("error"); console.log(error);
  			});
  		},
  		reviewCounselor : function(){

  			var self =  this ;
		      var validationError =  this.checkForInputFields() ;
		      if(validationError == 1 ){
		        return 0 ;
		      }

		      var counselorID ;
		      if(this.id){
		      	counselorID = this.id ;
		      }else{
			    var counselorObj = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
			    counselorID = counselorObj.counselor_id                               ;
		      }

		      var userID  ;

		      if(this.userID){
		      	userID = this.userID;
		      }else{
		      	userID  = this.userModel.getUserID();
		      }

		      var chatID ;
		      if(this.chatID){
		      	chatID = this.chatID ;
		      }else{
			    var counselorObj = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
			    chatID = counselorObj.id                               ;
		      }

		      var formData = {
		        "feeling" : $("input[name='feeling']:checked").val() ,
		        "star" : $("input[name='rating']:checked").val() ,
		        "description" : $("#chat-desc").val(),
		        "gender" : $("input[name='gender']:checked").val(),
		        "age" : $("#age-options").val(),
		        "area" : $("input[name='area']:checked").val()
		      };

		      var star = $("input[name='rating']:checked").val();
		      var headersToPass = {} ;

		      if(this.token){
		      	headersToPass = {
					"X-DOST-ZION-AUTH" : this.token ,
				} ;
		      }

		    $("#skip-review").hide() ;
		    $("#review-chat").hide() ;
		    $(".donate-submit-btn").hide();
			$(".submit-btn").hide();
		    $("#submit-progress").show() ;

		    $.ajax({
		        url : Utils.contextPath() + '/v1/users/'+ userID +'/counselor/'+ counselorID +'/rating',
		        method : "POST",
		        dataType: "JSON",
		        contentType: "application/json; charset=utf-8",
		        data : JSON.stringify(formData),
		        headers : headersToPass,
		    }).done(function(response){

				console.log(response);
				
				if($("#review-modal").length){

					Utils.displaySuccessMsg("Thank you for your feedback");
					self.markReviewAsDone(counselorObj.id , star) ;
				}else{
					Utils.displaySuccessMsg("Thank you for your feedback");
					self.markReviewAsDone(chatID , star) ;
					//location.href = "/!" ;
					//Backbone.history.navigate("/!", {trigger: true});
				}
				
		    }).error(function(error){
		        console.log("error"); console.log(error);
		    });
  		},
  		PopupLayout : JST['app/templates/review/popup.hbs'], 
  		ReviewLayout: JST['app/templates/review/main.hbs'], 
  		ReviewPageLayout: JST['app/templates/review/page.hbs'], 
  		LoaderLayout: JST['app/templates/loader.hbs'],
		render: function( type ) {


			if(type == "modal"){
			var counselorObj  = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
		    var counselorName = counselorObj.name                                       ;
				this.$el.append( this.PopupLayout({ popupContent : this.ReviewLayout({ counselorName : counselorName }) }) );
				Utils.openPopup( "review-modal" ) ; 
				return ;
			}

			var self = this ;

			this.$el.html(this.LoaderLayout()) ;
			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/" + this.id
			}).done(function(response){

				self.$el.html(  self.ReviewPageLayout({ pageContent : self.ReviewLayout({ counselorName : response.name }) }) );

			});	


		}

	});

	ReviewView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	ReviewView.prototype.clean = function() {
		this.remove() ;
	};

	return ReviewView;
});