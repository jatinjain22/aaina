define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
], function( $, _, Backbone, JST, Utils, Dispatcher) {

	var campaignPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
            'click .cm-common-articles-show-more-button' : 'loadMoreArticles',
            'click .cm-common-playable-media' : 'openArticles',
            'click .close-popup' : 'closePopUp',
            'click .cm-common-btn' : 'actionData',
            'click .cm-common-footer-subscrible-send' : 'subscribe'
		},
		mainLayout : JST['app/templates/campaigns/layout.hbs'],
        bannerLayout:JST['app/templates/campaigns/subview/banner.hbs'],
        dataLayout : JST['app/templates/campaigns/subview/data.hbs'],
        storyLayout: JST['app/templates/campaigns/subview/stories.hbs'],
        packagesLayout : JST['app/templates/campaigns/subview/packages.hbs'],
        articlesLayout : JST['app/templates/campaigns/subview/articles.hbs'],
        footerLayout : JST['app/templates/campaigns/subview/footer.hbs'],
        articlesCards : JST['app/templates/campaigns/subview/article_single.hbs'],
        galleryLayout : JST['app/templates/campaigns/subview/gallery.hbs'],
		getContent : function(url, method){
			var defer = $.Deferred();
			$.ajax({url:url, method : method})
			.done(function(response){
				defer.resolve(response)
			}).fail(function(error){
				defer.reject(error)
			})
			return defer.promise()
		},
        actionData : function(e){
            var actionType = $(e.currentTarget).attr("data-action-type")
            var self = this;
            switch(actionType){
                case "link":
                    var url = $(e.currentTarget).attr("data-action-url")
					self.registerMixapnel({action_data : "link_clicked", action_loc : url})
                    window.open(url, "_blank")
                break;
                case "chat":
					self.registerMixapnel({action_data : "chat_clicked"})
                    self.chatConnect()
                break;
                case "api":
					self.registerMixapnel({action_data : "notify_clicked"})
                    self.subscribeCall("notify", $(".cm-common-input").val())
                break;
                default:
            }
        },
        redirect: function (options) {
            if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "Fired2FiredUp","Fired2FiredUp", "homeCat" + options.categoryID);
        },
        chatConnect : function(){
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "Fired2FiredUp",  "Fired2FiredUp", "free_chat", {options : {type: 'chat',categoryID : 1},callback: this.redirect}) ;
			}else{
				this.redirect({"type"	: 'chat',categoryID : 1});
			}
        },
        subscribe : function(e){
			this.registerMixapnel({action_data : "subscribe_clicked"})
            this.subscribeCall("cm-common-subscribe-form", $(".cm-common-footer").find(".subscribe-email").val())
        },
        subscribeCall : function(form,email){
            $("."+form).find(".cm-common-error").addClass("hide")
            var self = this;
			var isValidEmail = Utils.formEmailCheck(email) ;
			if(!isValidEmail){
                $("."+form).find(".cm-common-error").removeClass("hide")
				return false ;
			}
			$.ajax({
				method: "POST",
				url: Utils.contextPath()+'/subscribe',
				data : email
			}).done(function(response){
                $("."+form).find("input").val('');
                self.showSuccess(form)
			})
        },
        showSuccess : function(form){
            if(form == "notify"){
                $("."+form).find(".cm-common-submit-story-description").removeClass("l4").addClass("l8")
                $("."+form).find(".cm-common-data-input").hide()
                $("."+form).find(".cm-common-data-action").hide()
                $("."+form).find(".header").html("Thanks for letting us know that you're interested.")
                $("."+form).find(".subHeader").html("We'll notify you the moment our helpline is up and running.")
            }else{
                $("."+form).html("Got it! You'll start receiving our newsletters soon")
            }
        },
        loadMoreArticles : function(evt){
			var remainArticles = this.articlesArr.slice(this.articleCnt*3+5, this.articleCnt*3+8)
            if(this.articleCnt == 2 || remainArticles.length < 1) {
                window.open($(evt.currentTarget).attr('data-url'), '_blank')
                return;
            }
            $(".cm-common-articles").append(this.articlesCards({articles : remainArticles}))
            this.articleCnt += 1;
        },
        openArticles : function(evt){
            var type = $(evt.currentTarget).attr("data-type")
            if(type == "post"){
				this.registerMixapnel({action_data : 'articles', action_type: 'Button Click'})
                window.open($(evt.currentTarget).attr('data-url'), '_blank')
                return;
            }
            this.openVideoArticle($(evt.currentTarget))
        },
        openVideoArticle : function(trgt){
            var vId = trgt.attr("data-video"),
                url = trgt.attr("data-url"),
			    title = trgt.attr("data-title")
            //reg = /(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com(?:\/embed\/|\/v\/|\/watch\?v=))([\w-]{10,12})/g;
			$(".yd-shareicons").find(".addthis_toolbox").attr("addthis:url", url)
			$(".yd-shareicons").find(".addthis_toolbox").attr("addthis:title", title)
            //vId = reg.exec(vId)[1]
            if(vId.search("facebook") > -1){
                temp = '<iframe id="yd-video" src="'+vId+'&amp;autoplay=true"></iframe>'
			}else{
				temp = '<iframe id="yd-video" src="'+vId+'?autoplay=1"></iframe>'
			}
            $("#yd-video").remove()
			$(".yd-popupcontent").append(temp);
			$(".yd-popup.videos").show();
        },
        renderMeta: function(data){
            document.title = data.title;
            $('meta[name=description]').attr('content', data.description);
            $('meta[name=title]').attr('content',data.title);
            $('meta[property="og:description"]').attr('content', data.description);
            $('meta[property="og:title"]').attr('content', data.title);
            $('meta[property="og:image"]').attr("content", data.imgUrl);
            $('link[rel="canonical"]').attr('href', window.location.href);
            $('meta[property="og:url"]').attr('content', window.location.href);
        },
        fectchStories: function(data){
            var self = this;
            this.getContent(Utils.scriptPath()+'/campaigns/'+data.fileName+'.json', 'GET')
            .then(function(res){
                data.stories = res.stories;
                $(".cm-common-main-stories").append(self.storyLayout({data:data}))
            })
        },
        getPackagesData : function(data){
            var self = this;
            this.getContent(Utils.contextPath()+data.url, 'GET')
            .then(function(res){
				self.parsePackages(data, res)
            })
        },
		parsePackages : function(data, res){
			var packageArr = []
			res.forEach(function(package){
				if(data.ids.indexOf(package.id) > -1 ) {
					if(package.id == 13){
						package.url = 'laid-off-fired-up'
					}else if(package.id == 14) {
						package.url = 'confident-career'
					}else{
						if(package.id == 15){
							package.url = 'develop-discipline'
						}
					}
					packageArr.push(package)
				}
			})
			data.packages = packageArr
			$(".cm-common-main-packages").html(this.packagesLayout({data:data}))
		},
        getArticlesData : function(data){
            var self = this;
            this.getContent(Utils.scriptPath()+'/campaigns/duplicate_posts.json', 'GET')
            .then(function(res){
                self.parseArticles(data, res.posts);
                self.articleCnt = 0;
            })
        },
        parseArticles : function(content, data){
            this.articlesArr = []
            var self = this
			var index = 0;
            _.each(data, function(article){
				index += 1;
                var articleObj = {}
                articleObj["title"] = article.title;
                articleObj["category"] = article.type;
				if(article.type == "video") articleObj["videoId"] = article.videoUrl
            	articleObj["imageUrl"] = article.imageUrl
                articleObj["url"] = article.url;
                self.articlesArr.push(articleObj)
            })
            content.articlesArr = this.articlesArr.slice(this.articleCnt, 5)
            $(".cm-common-main-articles").html(this.articlesLayout({data:content}))
        },
        fectInitialData : function(data){
            var self = this;
            _.each(data.urls, function(item){
                if(item.name == "packages"){
                    self.getPackagesData(item)
                }else if(item.name == "articles") {
                    self.getArticlesData(item)
                }else{
                }
            })
        },
        parseJson : function(data){
            if(data["banner"] && data["banner"].visibility) $(".cm-common-main-banner").append(this.bannerLayout({name: "banner", banner : data["banner"].content}))
            if(data["stories"] && data["stories"].visibility) this.fectchStories(data["stories"].content)
            if(data["notify"] && data["notify"].visibility) $(".cm-common-main-notify").append(this.dataLayout({name: "notify", data : data["notify"].content}))
            if(data["chat"] && data["chat"].visibility) $(".cm-common-main-chat").append(this.dataLayout({name: "chat", data : data["chat"].content}))
            if(data["referals"] && data["referals"].visibility) $(".cm-common-main-refer").append(this.dataLayout({name: "referals", data : data["referals"].content}))
            if(data["submitStory"] && data["submitStory"].visibility) $(".cm-common-main-submitStory").append(this.dataLayout({name: "story", data : data["submitStory"].content}))
            if(data["getInTouch"] && data["getInTouch"].visibility) $(".cm-common-main-getInTouch").append(this.dataLayout({name: "story", data : data["getInTouch"].content}))
            if(data["footer"] && data["footer"].visibility) $(".cm-common-outer").append(this.footerLayout())
            if(data["stats"] && data["stats"].visibility) this.loadStats(data["stats"].content)
			if(data["packages"] && data["packages"].visibility) this.getPackagesData(data["packages"].content)
			if(data["articles"] && data["articles"].visibility) this.getArticlesData(data["articles"].content)
			//if(addthis) addthis.toolbox()
        },
        loadStats : function(stats){
            var self = this;
            this.getContent(Utils.scriptPath()+'/campaigns/'+stats.fileName+'.json', 'GET')
            .then(function(res){
				$(".cm-common-main-stats").html(self.galleryLayout({header: stats.header,images : res.images}))
				if(!Utils.isMobileDevice()) {
                    self.loadSwiper('cm-common-gallery-inner-container', '.cm-gallery-next', '.cm-gallery-prev')
                }else{
                    self.loadSwiper('cm-common-gallery-inner-container', '', '')
                }
            })
        },
        loadSwiper : function(container, next, prev){
            var space = 20,
				time = 15000
            if(Utils.isMobileDevice()) {
				space = 5
				time = 2000
			}
            var mySwiper = new Swiper ('.'+container, {
                autoplay: time,
                keyboardControl: true,
                slidesPerView: '3',
                nextButton: next,
                prevButton: prev,
                loop:true,
                spaceBetween: space,
                centeredSlides: true,
                breakpoints: {
                    640: {
                        slidesPerView: 'auto',
                        spaceBetweenSlides: 10
                    }
                },
            });
        },
        closePopUp :  function(e){
            $("#yd-video").remove()
            $(".yd-popup").hide();
        },
		registerMixapnel : function(options){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				mixpanel.track(this.mixpanelEvent, options);
			}
		},
		render: function() {
            $("#main-header").hide();
    		$(".feedback-form-btn").addClass("hide")
			this.$el.html(this.mainLayout({}))
            var self = this,
                campaign = window.location.pathname.split("/")[window.location.pathname.split("/").length -1]
			this.getContent(Utils.scriptPath() + "/campaigns/campaigns.json", "GET")
			.then(function(response){
				self.mixpanelEvent = response[campaign].mixpanel.eventName
				self.registerMixapnel({action_data : "Campaign Rendered"})
                self.parseJson(response[campaign])
                self.renderMeta(response[campaign].metaData)
			},function(err){})
            $(document).on('keyup', function(e) {
      			if (e.keyCode == 27 && $(".yd-popup").is(':visible')){
                    $("#yd-video").remove()
                    $(".yd-popup").hide();
                }
    		})
		}
	});
	campaignPage.prototype.remove = function() {
        $("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};
	campaignPage.prototype.clean = function() {
		this.remove() ;
	};
	return campaignPage;
});
