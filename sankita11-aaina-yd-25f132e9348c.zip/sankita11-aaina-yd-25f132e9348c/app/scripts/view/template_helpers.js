define([
	'jquery',
	'underscore',
	'backbone',
	'templates/helpers/if_eq',
	'templates/helpers/if_uneq',
	'templates/helpers/ifQuotes',
	'templates/helpers/ifCond',
	'templates/helpers/trimHtml',
	'templates/helpers/for',
	'templates/helpers/ratingHtml',
	'templates/helpers/formatDate',
	'templates/helpers/htmlDecode',
	'templates/helpers/debug',
	'templates/helpers/getAvatarUrl',
	'templates/helpers/replaceBrackets',
	'templates/helpers/getDiscountAmount',
	'templates/helpers/getDiscount',
	'templates/helpers/formatDateString',
	'templates/helpers/math',
	'templates/helpers/if_even',
	'templates/helpers/getMoreDiscount'
], function($, _, Backbone ) {


});
