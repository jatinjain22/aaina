define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl',
	'ajax-chosen'
], function($,_,Backbone, JST, Utils, UserModel, Dispatcher){

	var PackedBookedPage = Backbone.View.extend({

		el : "main",

		initialize : function(){

			var url = window.location.href;

			url = url.replace("/packagebooked", "" );

			this.success = $.url( url ).param('success') ;
			this.failure = $.url( url ).param('failure') ;
			this.userModel = new UserModel()
		},

		events : {

			'click .book-session-app' : 'bookAppointment',
			'click .book-session-footer-app' : 'bookAppointment',
			'click .package-payment-try-again' : 'tryPayment',
			'click .start-session-now-btn' : 'goToSchedule',
			'keyup .package-phone-input input[name="phone"]' : 'checkforPhoneNumber',
			'click .package-phone-input input[type="button"]' : 'submitPhoneNumber',
			"click #submit-otp":"SubmitOtp",
			"click .resend-code" : "resendCode",
			"click #close-otp":"closeOTP",
			"focusout #phone" : "validatePhoneno",
		},

		goToSchedule : function(e){

			var packageId = $(e.currentTarget).attr("data-packageId");

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Package Schedule", "packageId" : packageId});
			}

			Backbone.history.navigate("/online-counseling-programs/"+packageId+"/schedule", {trigger: true});
		},

		tryPayment : function(e){

			$(".package-payment-try-again").html("Redirecting to PayU...")
			var userID = this.userModel.getUserID();

			var packageId = $(e.currentTarget).attr("data-packageId")
			var amount = $(e.currentTarget).attr("data-amount");

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Package Buy Try Again", "packageId" : packageId});
			}

	    	$.ajax({
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				url : Utils.contextPath()+ "/v1/user/"+userID+"/package/"+packageId+"/amount/"+amount,
			}).done(function(response){

				$(".package-payment-try-again").html("Try Again")
				console.log("Response ", response)
				if(!response.error){

					location.href = response.uri;
				}
			}).error(function(error){

				$(".package-payment-try-again").html("Try Again")
				console.log("Error: ", error)
			})
		},


		bookAppointment : function(e){

			var counselorId = $(e.currentTarget).attr("data-cId")
			var categoryId = ''//this.package

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track(" Button Click", {"itemName" : "Package Booked Page"});
			}

			Backbone.history.navigate('bookAppointment?from=packages&conID=' + counselorId + '&catID=' + categoryId, {trigger: true});
		},

		PackedBookedLayout : JST['app/templates/packages/package_booked.hbs'],
		PackageNotBookedLayout : JST['app/templates/packages/package_bookedFailed.hbs'],
		LodingLayout : JST['app/templates/packages/loader.hbs'],

		isInt : function (value) {

		  	return 	!isNaN(value) && parseInt(Number(value)) == value && !isNaN(parseInt(value, 10));
		},

		checkforPhoneNumber : function(){

			var phone = $(".package-phone-input input[name=phone]").val();

			$(".error-phone").addClass("hide").html("")


			if(phone == "" || phone.length != 10 ){

				$(".error-phone").removeClass("hide").html("Please enter a 10 digit phone no.")
				// Utils.scrollTo()
				return false;
			}

			if(!this.isInt(phone)){

				$(".error-phone").removeClass("hide").html("Please enter a 10 digit phone no.")
				// Utils.scrollTo()
				return false;
			}

			return true;
		},

		closeOTP:function(){
			$('#verifyOtpModal').closeModal();
		},

		resendCode :function(){
			var self = this;
			var phno = self.entered_phoneno;
			$('#resend-otp-msg').removeClass('hide');
			setTimeout(function(){
				$('#resend-otp-msg').addClass('hide');
			}, 30*1000)
			self.verifyMobileNo(phno,true);

		},

		validatePhoneno: function(){
			var self =this;
			var mobno = $("#phone").val();
			self.entered_phoneno = mobno;
			var isNumber = /^\d+$/.test(mobno)
			var length = 10;

			if(mobno == ""){
					$("#phone").addClass('invalid');
					$("#error-phoneno-msg").text("Please enter phone no.");
					$("#error-phoneno-msg").addClass('red-text');
					$('#error-phoneno-msg').removeClass('hide')
					return false;

			}else{
				if(mobno.length == length && isNumber){
					$('#phone').removeClass('invalid');

					$('#error-phoneno-msg').removeClass('red-text');
					$("#error-phoneno-msg").text("We will send the verfication code on this number");
					$('#error-phoneno-msg').addClass('hide')
					$('#phone').addClass('valid')
					return true;
				}
				if(mobno.length < 10){
					$("#phone").addClass('invalid');
					$("#error-phoneno-msg").text("Phone number should be minimum of 10 digits.");
					$('#error-phoneno-msg').addClass('red-text');
					$('#error-phoneno-msg').removeClass('hide')
					return false;

				}
				if(!isNumber){
					$("#phone").addClass('invalid');
					$("#error-phoneno-msg").text("Phone number should not have any alphabets.");
					$('#error-phoneno-msg').addClass('red-text');
					$('#error-phoneno-msg').removeClass('hide')
					return false;

				}
			}

		},

		submitPhoneNumber: function() {
			var self = this;
			var phoneNumber = $("#phone").val();
			var valid_phn = self.validatePhoneno();

			if(valid_phn) {
				if(Utils.isLoggedIn()){
					var userPhone = self.userModel.getPhoneNo();
					console.log("userPhone", userPhone);
					if( phoneNumber == userPhone){
						self.checkPhoneVerified(phoneNumber, function(){
							if(self.phoneVerified){
								$(".package-booked-conatainer").addClass("hide");
								$(".package-phone-success-container").removeClass("hide");
							}
							else{
								self.verifyMobileNo(phoneNumber,false);
								$('#phoneno').removeClass('invalid');
								$('#error-phoneno-msg').removeClass('red-text');
							}
						});
					}
					else {
						console.log(self.userModel.getUserID());
						$.ajax({
							url :   Utils.contextPath() + '/v2/users/'+self.userModel.getUserID()+'/mobile/'+parseInt(phoneNumber)+'/free',
							statusCode:{
					    			417 : function(errorResponse){
					    				var responseText_free = errorResponse.responseText;
										var responseJson_free = JSON.parse(responseText_free) ;

										var errorMessage_free = responseJson_free.message ;
										var errorType_free    = responseJson_free.type ;
										$("#phone").addClass('invalid');
										$('#error-phoneno-msg').text(errorMessage_free);
										$('#error-phoneno-msg').addClass('red-text');
										$('#error-phoneno-msg').removeClass('hide')
										// $("#update-info-form").show() ;
										// $("#update-info-progress").hide() ;

					    			}},
							}).done(function(resp){
								if(!resp.inUse){
									/*if(username == ""|| username == null){
										$('#appointment-user-info #username').addClass('invalid');
										$("#error-username-msg").text("Account will be created for you with this username.")
									}
									if(emailUpdate == "" || emailUpdate == null){
										$('#appointment-user-info #email').addClass('invalid');
										$("#error-email-msg").text("Please enter your email Id.")

									}
									if(username != "" && emailUpdate != "" ){
										self.appointmentModel.set('emailNew',emailUpdate);
										self.appointmentModel.set('usernameNew',username);
										self.verifyMobileNo(phoneNumber,false);
									}*/
									self.verifyMobileNo(phoneNumber,false);
								}


							});
					}
				}
			}

			// self.updateUser('MobileNumber', phone);
		},

		checkPhoneVerified: function(phno, cb){
			var self =this;
			$.ajax({
				url :   Utils.contextPath() + '/v2/users/'+self.userModel.getUserID()+'/mobile/'+phno.toString()+'/verified',
			}).done(function(response){
				console.log('verified response',response);
				if(response.verified){
					self.phoneVerified = true;
					cb();
					return true;
				}
				else{
					self.phoneVerified = false;
					cb();
					return false;
				}
			});
		},

		updateUser :function(type,value){
			//type can be Mobile Number, Age, Gender
			var self = this;

			$.ajax({
					method : "GET",
					url : Utils.contextPath()+"/v2/users/"+ this.userModel.getUserID() +"/profile",
				}).done(function(response){
					console.log('user object from profile api',response);


					var infoToEdit = response;
					var samePhone = true;

					if(type== "MobileNumber"){
						samePhone = infoToEdit['phone'] == value;
						infoToEdit['phone'] = value;
					}
					if(type == 'Gender'){
						infoToEdit['customProperties']['gender'] = [value];
					}
					if(type == 'Age'){
						infoToEdit['customProperties']['age'] = [value];
					}
					console.log(JSON.stringify(infoToEdit));
					if(!samePhone) {
						$.ajax({
							url : Utils.contextPath() + "/v2/users/"+self.userModel.getUserID()+"/modify/profile",
							method : "POST" ,
							dataType : "json" ,
							xhrFields: {
			     				 withCredentials: true
						    },
							contentType: "application/json",
							data : JSON.stringify(infoToEdit)
						}).done(function(response){
				 	       	console.log('modified user api ',response);

							if (response) {
								$(".package-booked-conatainer").addClass("hide");
								$(".package-phone-success-container").removeClass("hide");
								self.closeOTP();
							}


						}).error(function(error){
							console.log("error") ;
							console.log(error) ;
						});
					}
				});


		},

		verifyMobileNo :function(mobNo,resend_flag){
			var self = this;
			var dataToSend = {'mobile': mobNo};
			$.ajax({
				url :   Utils.contextPath() + '/v2/users/mobile/otp/send',
				method : 'POST',
				dataType : "json",
				xhrFields: {
	     				 withCredentials: true
				    },
				contentType: "application/json",
				data: mobNo,
			}).done(function(res){
				console.log('otp send',res);
				if(res.status){
					if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	         			mixpanel.track("OTP Send", { "mediumSource" : "website", "itemName" : 'Package Booked Page' });
	       			}
					if(!resend_flag){
						$('#verifyOtpModal').openModal({dismissible: false, keyboard: true});

						// 	$("#update-info-form").show() ;
						// $("#update-info-progress").hide() ;
						/*setTimeout(function(){
							if($('#verifyOtpModal').is(":visible")){
								console.log("user stuck at otp screen");
								var self = views.PackedBookedPage;
								var today = new Date();
								var y = today.getFullYear();
								var slotTime = self.appointmentModel.get('slotdate') + " "+y+" "+self.appointmentModel.get('slottime');
								var formattedslotTime = new Date(slotTime).getTime();
								var username = '';
								var phone;
								if(Utils.isLoggedIn()){
									username = self.userModel.getUserName();
									phone = self.userModel.getPhoneNo();

								if(self.appointmentModel.get('mobno') == ''||self.appointmentModel.get('mobno') == null || self.appointmentModel.get('mobno') == undefined){
									phone = null;
								}
								console.log('user is away in non paid state for more than 5 mins');
								var dataToSend ={'phone':phone,'email':self.appointmentModel.get('emailNew'),'slotStartTime':formattedslotTime,'username':username};
								$.ajax({
								url :    Utils.contextPath() + '/users/trigger/inactivity/otp',
								method : 'POST',
								dataType : "json" ,
								contentType: "application/json",
								data: JSON.stringify(dataToSend),
								}).done(function(res){
										console.log('otp inactivity mailer send')
									if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
						     		 mixpanel.track("Inactivity Mailer Appointment", { "mediumSource" : "website", "itemName" : 'OTP state' });
						    		}
								});
								}
							}
						},180000);*/
					}
					$('#otp-phn').text(mobNo)
					$('#verify-code').val('');
					$('otp-resend-msg').removeClass('hide');
					$('#verify-code').removeClass('valid');
					$('#verify-code').removeClass('invalid');
				}
				else{
					console.log("OtP send api failed.")
					//self.verifyMobileNo();
				}
			});

		},

		SubmitOtp:function(){
			var self= this;
			var otp = $('#verify-code').val();
			if(otp == ""){
				$('#verify-code').addClass('invalid');
			 	$('#error-otp-msg').text("Please enter otp!");
			  $('#error-otp-msg').addClass('red-text');
			}else{
				$("#submit-otp").hide() ;
				$("#submit-otp-progress").show() ;
				console.log('otp',otp);
				var dataToSend = {'verificationCode': otp};
				$.ajax({
					url :   Utils.contextPath() + '/v2/users/mobile/'+self.entered_phoneno+'/validate',
					method : 'POST',
					dataType : "json" ,
					xhrFields: {
		     				 withCredentials: true
					    },
					contentType: "application/json",
					data: otp,
					statusCode:{
					    417 : function(response){
					    	var responseText = response.responseText;
							var responseJson = JSON.parse(responseText) ;

							var errorMessage = responseJson.message ;
							var errorType    = responseJson.type ;
							$('#verify-code').addClass('invalid');
					    	$('#error-otp-msg').text(errorMessage);
					    	$('#error-otp-msg').addClass('red-text');
					    	$("#submit-otp").show() ;
							$("#submit-otp-progress").hide() ;
					    	if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
			         			mixpanel.track("Incorrect OTP", { "mediumSource" : "website", "itemName" : 'Incorrect OTP entered' });
			       			}

					  	}
					},
				}).done(function(res){
					if(res.status){
						if(Utils.isLoggedIn()){

							self.updateUser('MobileNumber',self.entered_phoneno);
							//save user details api
							// book appointment api without payment

							/*self.$el.html(self.loaderHTML());

							self.appointmentModel.set('usernameNew',self.userModel.getUserName());
							self.updateUser('MobileNumber',self.appointmentModel.get('mobno'));
							if(self.applyOfferEnable){
								self.applyOffer();
							}
							self.redirectToPayment();*/



						}else{
							/*self.$el.html(self.loaderHTML());
							self.signupNew();*/


						}
						$('#verify-code').removeClass('invalid');
						$('#verify-code').addClass('valid');
				    	$('#error-otp-msg').text('');
				    	$('#error-otp-msg').removeClass('red-text')
				    	$("#submit-otp").show() ;
						$("#submit-otp-progress").hide() ;
					}
				});

			}

		},


		render : function(){

			var self = this;
			this.$el.html(this.LodingLayout());

			if(this.success){

				getProductDetails(true, this.success)

			}

			if(this.failure){

				getProductDetails(false, this.failure)

			}

			function getProductDetails(success, txnId){


				$.ajax({
					url : Utils.contextPath()+ "/v1/user/transaction/"+txnId,
					contentType : "application/json; charset=utf-8",
					xhrFields   : {
				    	withCredentials: true
					},
				}).done(function(response){

					var product = response.lineItems[0].product;

					if(success){


						self.$el.html(self.PackedBookedLayout({response:response, product:product, phoneNo: self.userModel.getPhoneNo()}));
						if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

							mixpanel.track("Home Page", {"itemName" : "Package Booked Success Page", "PackageName" : product.productDetails.name});
						}
						Utils.appendGoogleConversion(response.amount)
					}
					if(!success){

						self.$el.html(self.PackageNotBookedLayout({response:response, product:product}));
						if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

							mixpanel.track("Home Page", {"itemName" : "Package Booked Failure Page",  "PackageName" : product.productDetails.name});
						}
					}


				}).error(function(error){

				})
			}

			// $('.dost-main').css({'min-height' : 'auto'})

			// $.ajax({

	  //       	url: Utils.scriptPath() + "/packages/packages_schedule.json",
	  //         	cache: false
	  //       }).done(function(response){

	  //       	var packgedetails = response[self.package];

			// }).error(function(error){

			// 	console.log("error ", error)
			// });
		}
	});

	PackedBookedPage.prototype.remove = function() {

	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	PackedBookedPage.prototype.clean = function() {

	    this.remove();

	};

    return PackedBookedPage;

})
