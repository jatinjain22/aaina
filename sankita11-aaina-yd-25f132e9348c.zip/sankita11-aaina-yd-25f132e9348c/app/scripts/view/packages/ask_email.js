define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    'raygun' ,
    'purl', 
    'ajax-chosen'
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, UserModel ) {

	var askEmailModal = Backbone.View.extend({

		el: "main",

		initialize: function() {	
			
			this.packageName = "";
			this.userModal = new UserModel();
		},
		events: {
			
			'click .close-ask-modal' : 'closeAskEmailModal',
			'click .ask-email-btn' : 'submitQuestion',
			'focusout #ask-email' : 'checkforEmailEnter'
		},

		closeAskEmailModal : function(){

			Utils.closePopup('askEmailModal') ;
			$("#askEmailModal").remove();
		},

		checkforEmailEnter : function(e){

			var email = $("#ask-email").val();

			$(".ask-error-email").addClass("hide").html("")


			if(email != "" ){

				var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
						
				if( !pattern.test(email) ){
					
					$(".ask-error-email").removeClass("hide").html("Please enter a valid email.")
					return false;
				}
			}

			if(e.which == 13 ){

				if(email == ""){

					$(".ask-error-email").removeClass("hide").html("Please enter a valid email.")
					return false;
				}else{

					if(email != "" ){

						var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
								
						if( !pattern.test(email) ){
							
							$(".ask-error-email").removeClass("hide").html("Please enter a valid email.")
							return false;
						}else{

							this.callAskQuestionApi();
						}
					}
				}
				
			}

		},

		checkforEmail : function(){

			var email = $("#ask-email").val();

			$(".ask-error-email").addClass("hide").html("")


			if(email != "" ){

				var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
						
				if( !pattern.test(email) ){
					
					$(".ask-error-email").removeClass("hide").html("Please enter a valid email.")
					return false;
				}

			}

			return true;
		},

		callAskQuestionApi : function(email){

			$(".ask-email-btn").html("SUBMITING ...")
			
			var self = this;

			var obj = {

				"packageName" : this.packageName,
         		"email" : email,
         		"question" : this.question
			}

			$.ajax({
				method: "POST",
				url : Utils.contextPath()+'/packages/query',
				data: JSON.stringify(obj),
				xhrFields: {
 				 withCredentials: true
			    },
				contentType: "application/json",
			}).done(function(response){

				self.closeAskEmailModal();
				Utils.displaySuccessMsgWithDelay("Thank you for your query. Our team will get back to you on this.", 5000)
				$(".ask-email-btn").html("SUBMIT QUESTION")
				$(".package-question").val("");
			}).error(function(error){

				$(".ask-email-btn").html("SUBMIT QUESTION")
			})
		},

		submitQuestion : function(e){

			var self = this;

			var email = $("#ask-email").val();
			if(email == "" ){

				$(".ask-error-email").removeClass("hide").html("Please enter a valid email.")
				return false;
			}
			
			if(this.checkforEmail()){

				if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
					mixpanel.track("Button Click", {"itemName" : "Submit Question on Package", "Package Name" : this.packageName});
				}
				this.callAskQuestionApi(email)
			}

		},
		
	    askEmailModalLayout : JST["app/templates/packages/askemail_modal.hbs"],

	 	render: function(question, packageName) {

			var self = this ;

			self.question = question;
			
			self.packageName = packageName;

			var email = "";

			if(Utils.isLoggedIn()){

				email = userModel.getUserEmail();
			}

			self.$el.append(self.askEmailModalLayout({email : email}));		

			Utils.openPopup('askEmailModal') ;	
		}

	});

	askEmailModal.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	askEmailModal.prototype.clean = function() {
		
		this.remove();
	};

	return askEmailModal;
});