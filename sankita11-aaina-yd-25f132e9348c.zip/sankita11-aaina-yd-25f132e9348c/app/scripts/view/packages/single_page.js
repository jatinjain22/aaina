define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'view/packages/ask_email',
	'view/packages/packages_faq',
	'view/newYearPackages/single_page',
	'purl'
], function($,_,Backbone, JST, Utils, UserModel, Dispatcher, AskEmailModal, FaqPage, NYSingle){

	var SinglePackagesPage = Backbone.View.extend({

		el : "main",

		initialize : function(){

			this.askEmailModal = new AskEmailModal();
			this.faqPage = new FaqPage();
			this.nySingle = new NYSingle();
			this.userModel = new UserModel();

			this.packageId = "";

			var url = window.location.href;
			this.openRazorPay = $.url( url ).param('login') ;

			this.metaTitle = "";
			this.metaDesc = "";
			this.metaImage = "";

			this.activity
		},

		events : {

			'click .package-post-question' : 'postPackageQuestion',
			'keyup .package-question' : 'postPackageQuestionClicked',
			'click .package-buy-now' : "buyPackage",
			'click .facebook-package-share' : "registerFbMixpanel",
			'click .twitter-package-share' : "registerTwMixpanel",
			'click .google-package-share' : "registerGoMixpanel",
			'click .single-package-faq li' : 'registerFAQMixpanel',
			'click .facebook-package-share' : 'shareOnFacebook',
		},

		checkforInactivity : function(inactivityTimeOut){

			var self = this ;

			this.chatVisible = 0 ;

			inactivityTimeOut = inactivityTimeOut * 1000 ;

			this.inactivityTimer = setTimeout(function(){

				if(self.chatVisible == 0){
					self.showChat() ;
				}

			}, inactivityTimeOut);

		},

		showChat : function(){

			var self = this ;

			self.chatVisible = 1 ;
			clearTimeout(self.inactivityTimer);

			$zopim(function() {
				$zopim.livechat.window.show();
			});


		},


		registerFbMixpanel : function(e){

			var self = this;

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Facebook Share", "Package Name" : self.packageName});
			}
		},
		registerGoMixpanel : function(e){

			var self = this;

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Google Share", "Package Name" : self.packageName});
			}
		},
		registerTwMixpanel : function(e){

			var self = this;

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Twitter Share", "Package Name" : self.packageName});
			}
		},
		shareOnFacebook : function(e){

			var self = this;

			var fbShareDate = {};

			fbShareDate.title = this.metaTitle;
			fbShareDate.description = this.metaDesc;
			fbShareDate.imageUrl = this.metaImage;
			fbShareDate.url = window.location.href;

			Utils.shareOnFacebook(fbShareDate, "Package Share on Facebook").then(function(){

				if(response){

	        		if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

						mixpanel.track("Button Click", {"itemName" : "Facebook Share", "Package Name" : self.packageName});
					}
	            }else{


	            }
			})
		},

		registerFAQMixpanel : function(){

			var self = this ;

			if(showZopimAppointment == 1){
				clearTimeout(self.inactivityTimer) ;
				self.checkforInactivity(30) ;
			}

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Package FAQs", "Package Name" : this.packageName});
			}
		},

		SinglePackagesLayout : JST['app/templates/packages/single_layout.hbs'],
		SinglePackagesNYLayout : JST['app/templates/newYearPackages/single_page.hbs'],
		NYBannerLayout : JST['app/templates/newYearPackages/banner_layout.hbs'],
		LodingLayout : JST['app/templates/packages/loader.hbs'],

		buyPackage : function(e){

			var self = this ;

			if(showZopimAppointment == 1){
				clearTimeout(self.inactivityTimer) ;
				self.checkforInactivity(30) ;
			}

			var position = "top";

			if($(e.currentTarget).hasClass("bottom-btn")){

				position = "bottom"
			}

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track("Button Click", {"itemName" : "Package Buy Now", "Package Name" : this.packageName, "Position" : position});
			}

			if(!Utils.isLoggedIn()){

				var amount = 200//$(e.currentTarget).attr("data-amount")
				var packageInfo = {

					"packageId" : this.packageId,
					"amount" : amount,
					"packageName" : this.packageName
				}

				Dispatcher.trigger("renderLogin", "Package Buy Now", "Package Detail Page", "buy_package", packageInfo ) ;
			}else{

				var amount = 200//$(e.currentTarget).attr("data-amount");
				this.redirectToPayu(amount);
			}

		},
		redirectToPayu : function(amount){

			$(".body-overlay").removeClass("hide");

			var userID = this.userModel.getUserID();

	    	$.ajax({
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				url : Utils.contextPath()+ "/v1/user/"+userID+"/package/"+this.packageId+"/amount/"+amount,
			}).done(function(response){

				console.log("Response ", response)
				if(!response.error){

					location.href = response.uri;
				}
				$(".body-overlay").addClass("hide");
			}).error(function(error){

				$(".body-overlay").addClass("hide");
				console.log("Error: ", error)
			})
		},
		postPackageQuestionClicked : function(){

			var self = this ;
			var question = $(".package-question").val();

			if(question == "" || question.length > 0){

				$(".error-question").show().html("")
			}else{

				$(".error-question").show().html("Please enter a question")
			}

			if(showZopimAppointment == 1){
				clearTimeout(self.inactivityTimer) ;
				self.checkforInactivity(30) ;
			}
		},

		postPackageQuestion : function(){

			var self = this ;

			if(showZopimAppointment == 1){
				clearTimeout(self.inactivityTimer) ;
				self.checkforInactivity(30) ;
			}

			$(".error-question").show().html("")

			var question = $(".package-question").val();

			if(question == ""){

				$(".error-question").show().html("Please enter a question")
				return;
			}

			this.askEmailModal.render(question, this.packageName);
		},

		getOutcomes : function(data){

			var outcomes = [];

			$.each(data.packageDetails, function(index,item){

				if(item.type=="OUTCOME"){

					outcomes.push(item)
				}
			})

			return outcomes;
		},
		getFeatures : function(data){

			var features = [];

			$.each(data.packageDetails, function(index,item){

				if(item.type=="FEATURE"){

					features.push(item)
				}
			})

			return features;
		},
		sendRequest : function(options){
			var defer = $.Deferred();
			$.ajax(options).done( function( response ){
				defer.resolve(response);
			}).error( function( error ){
				defer.reject( error )
			})
			return defer.promise();
		},
		render : function(){

			var urlFragment = Backbone.history.location.pathname.split("/")[2];

			var objUrls = {

				"building-self-confidence" : {

					"name" : "",
					"id" : 2
				},
				"cope-with-lose-of-someone" : {

					"name" : "",
					"id" : 3
				},
				"career-advice" : {

					"name" : "",
					"id" : 6
				},
				"advice-on-exam-preparation" : {

					"name" : "",
					"id" : 4
				},
				"overcoming-loneliness" : {

					"name" : "",
					"id" : 5
				},
				"pre-marital-counseling" : {

					"name" : "",
					"id" : 7
				},
				"post-marriage-counseling" : {

					"name" : "",
					"id" : 1
				},
				"quit-smoking" : {

					"name" : "",
					"id" : 8
				},
				"become-stress-free" : {

					"name" : "",
					"id" : 9
				},
				"get-organised" : {

					"name" : "",
					"id" : 10
				},
				"build-family-relationships" : {

					"name" : "",
					"id" : 11
				},
				"build-marriage-relationships" : {

					"name" : "",
					"id" : 12
				},
				"laid-off-fired-up" : {

					"name" : "",
					"id" : 13
				},
				"confident-career" : {

					"name" : "",
					"id" : 14
				},
				"develop-discipline" : {

					"name" : "",
					"id" : 15
				}
			}
			this.packageId = objUrls[urlFragment].id;

			//var replacedContent = urlFragment.replace(/-/g, " ");

			var self = this;

			if(showZopimAppointment == 1){
				self.checkforInactivity(30) ;
			}

			this.$el.html(this.LodingLayout());

			if(this.openRazorPay){

				this.callRazorPay()
			}else{
				// self.$el.html(self.SinglePackagesNYLayout());
				$.ajax({
					method: "GET",
					url : Utils.contextPath()+ "/packages/"+this.packageId,
					contentType: "application/json",
				}).done(function(response){
					//add flag for integrating optin
					var isConfidence = self.packageId == 2 ? true: false;
					if(self.packageId > 7 && self.packageId <= 12) {
						 self.nySingle.render();
						// self.$el.find(".ny-details").html(self.NYBannerLayout({response:response}));
					}else {
							self.$el.html(self.SinglePackagesLayout({isConfidence : isConfidence,response:response, outcomes : self.getOutcomes(response), features : self.getFeatures(response)}));
					}
					//self.faqPage.render();
					setMetaData(response)
				}).error(function(error){

					console.log("Error: ", error)
				})
				// $.ajax({

		  //       	url: Utils.scriptPath() + "/packages/"+urlFragment,
		  //         	cache: true
		  //       }).done(function(response){

				// 	self.$el.html(self.SinglePackagesLayout({response:response[urlFragment]}));

				// 	setMetaData(response[urlFragment])
				// }).error(function(error){

				// 	console.log("Error ", error);
				// });

				var setMetaData = function(data){

					document.title= data.metaTitle;
					$('meta[name=description]').attr('content', data.metaDescription);
					$('meta[name=title]').attr('content',data.metaTitle);
					$('meta[property="og:description"]').attr('content', data.metaDescription);
					$('meta[property="og:title"]').attr('content', data.metaTitle);
					$('meta[property="og:image"]').attr('content', data.image);
					$('meta[name=image]').attr('content', data.image);
					$('link[rel="canonical"]').attr('href', 'https://yourdost.com/online-counseling-programs/'+data.id);

					self.metaTitle = data.metaTitle;
					self.metaDesc = data.metaDescription;
					self.metaImage = data.image;


					if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

						mixpanel.track("Package Details Page", {"itemName" : data.title});
					}



					self.packageName = data.title;
					$(".single-package-container-row.hide-on-med-and-up").css("height", $(".single-package-container-row.hide-on-med-and-up .package-content").height());

				}

		        setTimeout(function(){

		            $(window).scroll(function(){

		              if($(window).scrollTop() > 380){

		                $('.single-package-footer').addClass("fixed");
		              }else{

		                $('.single-package-footer').removeClass("fixed");
		              }
		            })



		        }, 1000);

		        setTimeout(function(){

		            $('.collapsible').collapsible({

				    });

		        }, 1500);


		        setTimeout(function(){

					// addthis.toolbox('.addthis_toolbox');

				}, 1500)

		    }

		}
	});

	SinglePackagesPage.prototype.remove = function() {

		var self = this ;
		if(showZopimAppointment == 1){
			clearTimeout(self.inactivityTimer) ;
		}

	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	SinglePackagesPage.prototype.clean = function() {

		var self = this ;
		if(showZopimAppointment == 1){
			clearTimeout(self.inactivityTimer) ;
		}

		this.remove();

	};

    return SinglePackagesPage;

})
