define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'view/packages/custompackage_modal',
	'event/dispatcher',
	'purl',
	'ajax-chosen'
], function($,_,Backbone, JST, Utils, UserModel, CustomPackageModal, Dispatcher){

	var PackagesPage = Backbone.View.extend({

		el : "main",
		
		initialize : function(){

			this.customPackageModal = new CustomPackageModal();
		},

		events : {

			'click .openCustomPackage' : 'openCustomPackage',
			'click .package-img' : 'registerMixpanel',
			'click .package-learn-more' : 'registerMixpanel',
			'click .package-card-title' : 'registerMixpanel',
			'click .packages-filters-content .packages-filter' : 'filterPackage'
		},	

		filterPackage: function(e) {
			var self = this,
				$target = $(e.target),
				filter_value = $target.attr("data-value");

			if(!$target.hasClass("active")) {
				$(".packages-filters-content .packages-filter").removeClass("active");
				$target.addClass("active");

				if(filter_value === "All") {
					$(".package-card").addClass("active");
				}
				else {
					$(".package-card").removeClass("active");
					$(".package-card[data-filter="+filter_value+"]").addClass("active");

				}
			}

			$(".package-custom-card").addClass("active");

		},

		registerMixpanel : function(e){

			var packageName = $(e.currentTarget).parents(".package-card").attr("data-name")

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Button Click", {"itemName" : packageName});
			}
		},

		openCustomPackage : function(e){

			e.preventDefault();

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Button Click", {"itemName" : "Build Custom Package"});
			}

			this.customPackageModal.render("","");

		},

		PackagesLayout : JST['app/templates/packages/layout.hbs'],
		PackagesCardsLayout : JST['app/templates/packages/package_card.hbs'],
		LodingLayout : JST['app/templates/packages/loader.hbs'],


		getOrderedResponse : function(data){

			var orderedResponse = data;
			var filters = {};

			Array.prototype.move = function (from, to) {

			  this.splice(to, 0, this.splice(from, 1)[0]);
			};

			// orderedResponse.move(5,0);
			// orderedResponse.move(2,1);
			// orderedResponse.move(6,2);

			var objUrls = {

				"2" : {

					"name" : "building-self-confidence",
					"id" : 2
				},
				"3" : {

					"name" : "cope-with-lose-of-someone",
					"id" : 3
				},
				"6" : {

					"name" : "career-advice",
					"id" : 6
				},
				"4" : {

					"name" : "advice-on-exam-preparation",
					"id" : 4
				},
				"5" : {

					"name" : "overcoming-loneliness",
					"id" : 5
				},
				"7" : {

					"name" : "pre-marital-counseling",
					"id" : 7
				},
				"1" : {

					"name" : "post-marriage-counseling",
					"id" : 1
				},
				"8" : {

					"name" : "quit-smoking",
					"id" : 8
				},
				"9" : {

					"name" : "become-stress-free",
					"id" : 9
				},
				"10" : {

					"name" : "get-organised",
					"id" : 10
				},
				"11" : {

					"name" : "build-family-relationships",
					"id" : 11
				},
				"12" : {

					"name" : "build-marriage-relationships",
					"id" : 12
				},
				"13" : {

					"name" : "laid-off-fired-up",
					"id" : 13
				},
				"14" : {

					"name" : "confident-career",
					"id" : 14
				},
				"15" : {

					"name" : "develop-discipline",
					"id" : 15
				}
			}

			$.each(orderedResponse, function(index){

				if(objUrls[orderedResponse[index].id]){

					orderedResponse[index].url = "/online-counseling-programs/"+objUrls[orderedResponse[index].id].name;
				}

				filters[orderedResponse[index].filters] = 1;
			})
			
			return {
				orderedResponse: orderedResponse,
				filters: filters
			};

		},

		render : function(){

			document.title="Counselling Programs | Career, Marriage, Personality Development";
			
			$('meta[name=description]').attr('content', "Customised counseling programs from YourDOST for Career Decisions, building self confidence, dealing with lonliness, pre & post Marital Counseling, exam preparation");
			$('meta[name=title]').attr('content',"Counselling Programs | Career, Marriage, Personality Development");
			
			$('meta[property="og:description"]').attr('content', "Customised counseling programs from YourDOST for Career Decisions, building self confidence, dealing with lonliness, pre & post Marital Counseling, exam preparation");
			$('meta[property="og:title"]').attr('content',"Counselling Programs | Career, Marriage, Personality Development");
			
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/online-counseling-programs');
			
			var self = this;

			this.$el.html(this.PackagesLayout());

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Home Page", {"itemName" : "Program LIsting Page"});
			}

			self.$el.find(".packages-cards-container").html(this.LodingLayout());

			$.ajax({
				method: "GET",
				url : Utils.contextPath()+'/packages',
				contentType: "application/json",
			}).done(function(response){

				console.log("Response: ",response)
				var result = self.getOrderedResponse(response) ;
				self.$el.find(".packages-cards-container").html(self.PackagesCardsLayout({response:result.orderedResponse, filters: result.filters}));
			}).error(function(error){

				console.log("Error: ", error)
			})
			// $.ajax({

	  //       	url: Utils.scriptPath() + "/packages/packages.json",
	  //         	cache: false
	  //       }).done(function(response){

			// 	self.$el.find(".packages-cards-container").html(self.PackagesCardsLayout({response:response}));
			// });
		}
	});

	PackagesPage.prototype.remove = function() {

	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	PackagesPage.prototype.clean = function() {

	    this.remove();

	};

    return PackagesPage;

})