define([
    'jquery',
    'underscore',
    'backbone',
    '../../precompiled-templates',
    'utils',
    'event/dispatcher',
    'model/users',
    'smooth-scroll',
    'jCookie',
    'purl',
], function($,_, Backbone, JST, Utils, Dispatcher, UserModel){

    var PackagesHeaderView = Backbone.View.extend({

        el: 'header',

        initialize: function() {

          this.userModel = new UserModel() ;

        },

        events: {
                       
          'click .user-dropdown' : 'userPersonalMenu',
          'click .packages-login' : 'showLoginModal',

        },
       
        showLoginModal : function(){

          var packageInfo = {};

          if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
            
            mixpanel.track("Button Click", {"itemName" : "Packages Header Login"});
          }
          
          Dispatcher.trigger("renderLogin", "Package Login", "Package login Header", "packages_header", packageInfo ) ;
        },

        PackagesheaderLayoutTemplate : JST['app/templates/packages/packages_header.hbs'],

        renderHTML : function(){

            this.setElement($("header")).render();

        },

        render: function() {

            var username    = "" ;
            var userAvatar  = "" ;
            var firstName   = "" ;
            var userType = "VICTIM";
            var picUrl = "" ;
            var user_id = '';
            if( Utils.isLoggedIn() ){ 

              username = this.userModel.getUserName() ;
              firstName = this.userModel.getFirstName() ;
              picUrl = this.userModel.getPicUrl();
              user_id = this.userModel.getUserID() ; 
              if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){

                username = firstName ;
              }
              if(picUrl){

                userAvatar = picUrl ;
              }else{

                userAvatar = this.userModel.getUserAvatar() ;
                userAvatar = Utils.avatarToImage(userAvatar) ;
              }
              userType = this.userModel.getUserType();
            }

            var currentPage = window.location.pathname;
            currentPage     = currentPage.replace("/", "") ;
            if(!currentPage || currentPage == "!"){

              currentPage = "home";
            }

            var layoutType = this.layoutType;

            this.$el.html( this.PackagesheaderLayoutTemplate({ userAvatar: userAvatar, user_id : user_id, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, currentPage: currentPage, blogOrigin : blogOrigin}));

            if(layoutType == "selfTest"){

              $(".selftest-active").css({"border" : '1px solid #00bfa5'});
            }

            $(document).mouseup(function (e){

                var container = $("#loggedin-dropdown1");

                if ( !container.is(e.target) 
                    && container.has(e.target).length === 0) 
                  {
                    container.addClass("hide").removeClass("fadeInDown animated");
                    $(".user-dropdown").removeClass("active");
                  }
            });

            $('.dropdown-button').dropdown({

              belowOrigin: true,
            });

            if( !sessionStorage.getItem("unread") && Utils.isLoggedIn() ){

              var userObject = JSON.parse(localStorage.getItem("user"));
              
              $.ajax({
                method: "GET",
                  url: Utils.contextPath()+'/v1/users/'+userObject.id+'/messages/count?type=unread'
              }).done(function(response){

                sessionStorage.setItem("unread",response.count);
                $(".iheader-msg-badge,.mobile-msg-badge").text( response.count );
                if( response.count > 0 ){

                  $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
                }
              }).fail(function(error){});
            }else{

              $(".iheader-msg-badge,.mobile-msg-badge").text( sessionStorage.getItem("unread") );
              if( sessionStorage.getItem("unread") > 0 )
                $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
            }

            setTimeout(function(){

              $( window ).scroll(function() {             
                   
                   if( $(window).scrollTop() > 50 ){
                    $('#small-logo-container').addClass('hide');
                    $('#small-logo-container-scrolled').removeClass('hide');
                  }
                  else{
                    $('#small-logo-container-scrolled').addClass('hide');
                    $('#small-logo-container').removeClass('hide');
                  }
                });

            }, 1000)

            return this;
        },

        userPersonalMenu : function(e){

          $("#loggedin-dropdown1").removeClass("hide").addClass("fadeInDown animated");

          var top = 60;
          var left = $(".user-dropdown").addClass("active").offset().left - 75 ;
          $('#loggedin-dropdown1').css({

            top:top,
            left:left
          });
        }
    });

  PackagesHeaderView.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	};

	PackagesHeaderView.prototype.clean = function() {

      this.remove();

	};

    return PackagesHeaderView;
});
