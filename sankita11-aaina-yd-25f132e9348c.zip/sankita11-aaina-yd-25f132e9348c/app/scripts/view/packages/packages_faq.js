define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    'raygun' ,
    'purl', 
    'ajax-chosen'
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, UserModel ) {

	var PackagesFaqsPage = Backbone.View.extend({

		el: "main",

		initialize: function() {	
			
		},
		events: {
			
		},

		
	    PackagesFaqsLayout : JST["app/templates/packages/packages_faq.hbs"],

	 	render: function() {

			var self = this ;

			$.ajax({

	        	url: Utils.scriptPath() + "/packages/packages_faq.json",
	          	cache: false
	        }).done(function(response){

				self.$el.find(".single-package-faq").html(self.PackagesFaqsLayout({response:response["faqs"]}));
			});

			setTimeout(function(){ 

	            $('.collapsible').collapsible({

			    });
	        }, 1000);

		}

	});

	PackagesFaqsPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	PackagesFaqsPage.prototype.clean = function() {
		
		this.remove();
	};

	return PackagesFaqsPage;
});