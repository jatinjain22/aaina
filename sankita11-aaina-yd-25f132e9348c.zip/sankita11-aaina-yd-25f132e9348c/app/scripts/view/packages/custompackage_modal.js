define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    'raygun' ,
    'purl', 
    'ajax-chosen'
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, UserModel ) {

	var customPackageModal = Backbone.View.extend({

		el: "main",

		initialize: function() {	
			
			
		},
		events: {
			
			'focus .custompackage-phone': 'scrollToTop',
			'click .submit-custom-package' : 'submitCustomPackage',
			'keyup .custompackage-email' : 'checkforEmail',
			'click #customPackageModal .close-modal' : 'closeCustomPackageModal',
			'keyup .custompackage-phone' : 'checkforPhoneNumber',
			'keyup .custompackage-achieve' : 'checkForIssue'
		},

		scrollToTop : function(){

			$('#customPackageModal .modal-content').animate({scrollTop: 180}, '600');
		},

		closeCustomPackageModal : function(){

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Button Click", {"itemName" : " Close Custom Package pop up"});
			}

			Utils.closePopup('customPackageModal') ;
			$("#customPackageModal").remove();

		},

		isInt : function (value) {

		  	return 	!isNaN(value) && parseInt(Number(value)) == value && !isNaN(parseInt(value, 10));
		},

		checkforPhoneNumber : function(){

			var phone = $(".custompackage-phone").val();

			$(".error-phone").addClass("hide").html("")


			if(phone == "" || phone.length != 10 ){

				$(".error-phone").removeClass("hide").html("Please enter a 10 digit phone no.")
				this.scrollToTop()
				return false;
			}

			if(!this.isInt(phone)){

				$(".error-phone").removeClass("hide").html("Please enter a 10 digit phone no.")
				this.scrollToTop()
				return false;
			}

			return true;
		},

		checkForIssue : function(){

			var issue = $(".custompackage-achieve").val();

			$(".error-achieve").addClass("hide").html("")

			if( issue == ""){

				$(".error-achieve").removeClass("hide").html("Please enter what you want to achieve");
				return false;
			}

			return true;
		},
		checkforEmail : function(){

			var email = $(".custompackage-email").val();

			$(".error-email").addClass("hide").html("")

			if(email == "" ){

				$(".error-email").removeClass("hide").html("Please enter a valid email.")
				this.scrollToTop()
				return false;
			}

			if(email != "" ){

				var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
						
				if( !pattern.test(email) ){
					
					$(".error-email").removeClass("hide").html("Please enter a valid email.")
					this.scrollToTop()
					return false;
				}
			}

			return true;
		},

		submitCustomPackage :function(){

			var self = this;



			$(".error-category").addClass("hide").html("");
			$(".error-acgieve").addClass("hide").html("");

			var phone = $(".custompackage-phone").val();
			var email = $(".custompackage-email").val();
			var issue = $(".custompackage-achieve").val();
			
			var categoryId = $("#custompackage-category").val() ;
			var category = $("#custompackage-category option:selected").text();//

			category = category.replace(/-/g, " ");

			if( categoryId == null || categoryId == "" || category == '' ){

				$(".error-category").removeClass("hide").html("Please select a category");
				return false;
			}


			if(this.checkForIssue() && this.checkforPhoneNumber() && this.checkforEmail() ){

				if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
					mixpanel.track("Button Click", {"itemName" : "Custom Package Submit","upsellFrom":self.upsellFrom});
				}

				$(".submit-custom-package").html("BUILDING ...");
				if(self.fromselfHelp){
					var obj = {
						"category" : category,
	              		"goal" : issue,
	              		"phone" : phone,
	              		"email" : email,
	              		"upsellSelfHelp":self.upsellFrom,
	              		"upsellResult":self.upsellResult
	              		
					}
				}else{
					var obj = {
						"category" : category,
	              		"goal" : issue,
	              		"phone" : phone,
	              		"email" : email
					}
				}
				$.ajax({
					method: "POST",
					url : Utils.contextPath()+'/packages/goal',
					data: JSON.stringify(obj),
					xhrFields: {
     				 withCredentials: true
				    },
					contentType: "application/json",
				}).done(function(response){

					$(".submit-custom-package").html("Build my Custom Program");
					if(response.success){

						self.showThankYouMessage(category);
					}
				}).error(function(error){

					$(".submit-custom-package").html("Build my Custom Program");
				})
			}


		},

		showThankYouMessage : function(category){

			$("#customPackageModal").addClass("show-flex")
			$(".package-building").addClass("hide");
			$(".package-built").removeClass("hide");
			setTimeout(function(){

				Utils.closePopup('customPackageModal') ;
				$("#customPackageModal").remove();

				location.href="https://yourdost.com/blog?s="+category;

			}, 4000)
		},
		
	    customPackageModalLayout : JST["app/templates/packages/custompackage_modal.hbs"],

	 	render: function(str,upsellFrom) {

			var self = this ;
			self.upsellFrom = upsellFrom;
			self.$el.append(self.customPackageModalLayout());

			
			Utils.openPopup('customPackageModal') ;	

			var searchType = '/v1/counselor/search' ;

			var category = localStorage.getItem("categories");

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Build Custom Package pop up", {"itemName" : "Build Custom Package pop up Served","upsellFrom":upsellFrom});
			}
			 
			setTimeout(function(){

				var option = "<option value=''>Choose a category for your program</option>";
				
				$.each(JSON.parse(category),function(key,value){

	          		option += "<option value='"+key+"'>"+value+"</option>";
	            });

				$("#custompackage-category").append( option );
				if(str != ""){
					self.fromselfHelp = true;
					self.upsellResult = str;
					self.upsellFrom = upsellFrom;

				$('.custompackage-achieve').text(str);
             	$('#custompackage-category').val(5)
			}
			}, 100)

		}

	});

	customPackageModal.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	customPackageModal.prototype.clean = function() {
		
		this.remove();
	};

	return customPackageModal;
});