define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl',
	'ajax-chosen'
], function($,_,Backbone, JST, Utils, UserModel, Dispatcher){

	var PackageSchedulePage = Backbone.View.extend({

		el : "main",
		
		initialize : function(){

			var url = window.location.href;

			url = url.replace("/packagebooked", "" );

			this.package = Backbone.history.fragment.split("/")[1];//$.url( url ).param('package') ;
		},

		events : {

			'click .book-session-app' : 'bookAppointment',
			'click .book-session-footer-app' : 'bookAppointment'
		},


		bookAppointment : function(e){

			var counselorId = $(e.currentTarget).attr("data-cId")
			var categoryId = this.package

			Backbone.history.navigate('bookAppointment?from=packages&conID=' + counselorId + '&catID=' + categoryId, {trigger: true});
		},

		PackageScheduleLayout : JST['app/templates/packages/package_schedule.hbs'],

		render : function(){


			

			var packageName = this.package.replace(/-/g, " ")
			document.title=" Self Improvement Packages at YourDOST";
			$('meta[name=description]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
			$('meta[name=title]').attr('content',"Self Improvement Packages at YourDOST");
			$('meta[property="og:description"]').attr('content', "Looking for an exciting opprtunity to work with us? Drop in your resume here & we shall contact you soon");
			$('meta[property="og:title"]').attr('content',"Self Improvement Packages at YourDOST");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/packages');
			
			var self = this;

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
					
				mixpanel.track("Package Schedule Page", {"packageName" : packageName});
			}

			$.ajax({
				method: "GET",
				url : Utils.contextPath() + "/packages/"+self.package+"/schedule",
				contentType: "application/json",
			}).done(function(response){

	        	//var packgedetails = response[self.package];
				self.$el.html(self.PackageScheduleLayout({response:response}));
				console.log("response ", response)
			}).error(function(error){

				console.log("error ", error)
			});

			setTimeout(function(){ 

	            $(window).scroll(function(){

	              if($(window).scrollTop() > 150){

	                $('.package-booked-stick-footer').addClass("active");
	              }else{

	                $('.package-booked-stick-footer').removeClass("active");
	              }

	            })

	        }, 1000);
		}
	});

	PackageSchedulePage.prototype.remove = function() {

	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	PackageSchedulePage.prototype.clean = function() {

	    this.remove();

	};

    return PackageSchedulePage;

})