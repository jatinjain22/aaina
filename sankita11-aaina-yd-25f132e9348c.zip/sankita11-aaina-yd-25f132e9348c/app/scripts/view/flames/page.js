define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher',
	'view/flames/exitModal'
] , function($, _, Backbone, Utils, JST, Dispatcher, ExitModal) {

	var FlmaesPage = Backbone.View.extend({

		el: "main",

		initialize : function(){
			
			this.exitModal = new ExitModal()
			var self = this;

			$(document).mouseleave(function () {
			    
				self.showExitpopup();
			});

		},

		events : {

			'click .fl-btn' : 'process',
			'keyup #firstName' : 'enterData',
			'keyup #secondName' : 'enterData',
			'click .fl-chat-btn' : 'directToChat',
			'click .fl-fb-share' : 'registerFBEvent',
			'click .fl-tt-share' : 'registerTTEvent',
		},

		showExitpopup : function(){

			this.exitModal.render();
			date = new Date()
            date.setTime(date.getTime()+(60*60*1000))

		 	$.cookie("popup-showed", "yes", { path: '/', expires:date })
		},	

		directToChat : function(){

			this.registerMixpanelEvents("Button Click", "Flames chat clicked")
			Dispatcher.trigger('chatQuickCheck', 'demo', 0, "","", "flames");
		},
		enterData : function(evt){

			var txt = $(evt.currentTarget).val()
			
			if( txt != ''){

				$(".error").addClass("hide")
			}
		},

		registerTTEvent : function( evt ){

			this.registerMixpanelEvents("Button Click", "Twitter Share")
		},
		registerFBEvent : function( evt ){

			this.registerMixpanelEvents("Button Click", "FB Share")
		},

		process : function(){

			var firstName = document.getElementById("firstName").value;
			var secondName = document.getElementById("secondName").value;

			$(".error").addClass("hide")

			if( firstName == "" || secondName == ""){

				$(".error").removeClass("hide")
				return ;
			}

			firstName = firstName.replace(/ /g, '');
			secondName = secondName.replace(/ /g, '');


			var is_login = false;

			if( Utils.isLoggedIn()){

				is_login = true;
				this.processFlames( firstName, secondName)
			}else{

				var callback = this.processFlamesLogin.bind(this)
				Dispatcher.trigger("renderLogin", "", "flames", "flames", {
					options : {
						type: 'flames',
						firstName : firstName,
						secondName : secondName,
					},
					callback: callback
				} ) ;
			}
			this.registerMixpanelEvents("Button Click", {"Name1" : firstName, "Name2" : secondName, "is_login" : is_login}, "")
		},

		processFlamesLogin : function( options ){

			this.processFlames(options.firstName, options.secondName)
		},

		processFlames : function( firstName, secondName){

			for(var i=0; i<firstName.length; i++){

		        for(var j=0; j<secondName.length; j++){

		            if(firstName[i] == secondName[j]){

		                var first1 = firstName.substring(0,i);
		                var first2 = firstName.substring(i+1,firstName.length);
		                firstName = first1+first2;
		                i=-1;
		                var second1 = secondName.substring(0,j);
		                var second2 = secondName.substring(j+1,secondName.length);
		                secondName = second1+second2;
		                j=-1;
		                break;
		            }
		        }
		    }

		    this.findFlames(firstName+secondName)
		},

		findFlames : function( data ){

			var score = data.length;
			var tmp = 1;
			var flamesArr = "FLAMES".split("")
			for( j=6; j > 1; j--){

				var g=((score%j)+tmp)-1;

		        if(g>j){

		            g=g%j;
		        }
		        if(g==0){
		            
		            g=flamesArr.length;
		        }

		        flamesArr.splice(g-1,1);
		        tmp=g;
			}
			this.displyFinal(flamesArr[0])
		},

		displyFinal : function( letter ){

			var wordArr = "FLAMES".split("")
			var index = wordArr.indexOf(letter)
			var html = ''
			var resultObj = {"M" : "Marriage", "F" :"Friendship", "L" : "Love", "A" : "Affection","E" : "Enemy", "S" : "Sister"}
			for( var i =0; i< wordArr.length; i++){

				if(index == i){

					html += '<span class="letter">'+wordArr[i]+'<span class="letter-result"><span class="first-child"><img src="https://s3-ap-southeast-1.amazonaws.com/yourdost-images/flames/Line+(1).png"></span><span class="second-child"><span class="result-txt-div"><span class="result-txt">'+resultObj[wordArr[i]]+'</span></span><img width="150px" src="https://s3-ap-southeast-1.amazonaws.com/yourdost-images/flames/paint+(1).png"></span></span></span>'
				}else{

					html +='<span class="letter">'+wordArr[i]+'<span class="cross-line"></span></span>'
				}
			}

			this.registerMixpanelEvents("Result Loaded", {"Result" : resultObj[letter]}, "")
			$(".fl-form").find(".fl-name").html(html);
			//$(".fl-form").find("input").addClass("disabled")
			//$(".fl-btn").addClass("disabled")
			if(Utils.isMobileDevice()){
				
				$("html, body").animate({ scrollTop: $(document).height() }, 1000);
				$(".mobile-view").removeClass("hide")
			}
			$(".fl-sub-txt").addClass("hide");
			$(".web-view").addClass("expanded")
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		mainLayout: JST['app/templates/flames/layout.hbs'],

		render : function(){

			var self = this;

			var mobile = false;
			if(Utils.isMobileDevice()){

				mobile = true
			}

			this.registerMixpanelEvents("Flames page loaded", "flames page", "")
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			if(!mobile)
				$('body').css("overflow","hidden");
			
			document.title="FLAMES - The Fun Love Calculator";
			$('meta[name=description]').attr('content', "Remember FLAMES, the awesome love calculator we played in high school? It is back in a brand new online version.");
			$('meta[name=title]').attr('content',"FLAMES - The Fun Love Calculator");
			var url = "https://yourdost.com/flames"
			if( window.location.pathname.indexOf("/flames-love-calculator") > -1){

				url = "https://yourdost.com/flames-love-calculator"
			}

			$('link[rel="canonical"]').attr('href', url);
			$('meta[property="og:url"]').attr('content',url);	
			$('meta[property="og:description"]').attr('content', "Remember FLAMES, the awesome love calculator we played in high school? It is back in a brand new online version.");
			$('meta[property="og:title"]').attr('content',"FLAMES - The Fun Love Calculator");
			$('meta[property="og:image"]').attr('content', "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/flames/Flames_Promotion+on+FB+%26+Twitter.jpg");

			
			this.$el.html(this.mainLayout({mobile : mobile, url : url}))

			//this.exitModal.render();
		}
		
	});

	FlmaesPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		$('body').css("overflow","auto");
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	FlmaesPage.prototype.clean = function() 
	{

		this.remove() ;
	};

	return FlmaesPage;
});
