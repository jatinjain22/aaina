define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
], function( $, _, Backbone, JST, Utils, Dispatcher ) {

	var exitModal = Backbone.View.extend({

		el: "main",

		initialize: function() {	
			
		},

		events: {
				
			'click .cht-btn' : 'directToChat',
			'click .can-btn' : 'closePopup'
		},

		closePopup : function(){

			Utils.closePopup('exitModal') ;
			$("#exitModal").remove();
			this.registerMixpanelEvents("Button CLick", "Pop up Closed", "")
		},

		directToChat : function(){

			if(!Utils.isLoggedIn()){
				
				Dispatcher.trigger("renderLogin", "exit popup flames", "flames", "home_chat") ;
			}else{
	
				Dispatcher.trigger('chatQuickCheck', 'demo', 0, "","", "flames");
			}
			this.registerMixpanelEvents("Button CLick", "Flames Chat Clicked", "")
		},

	    exitModalLayout : JST["app/templates/flames/exit_modal.hbs"],

	    registerMixpanelEvents : function(eventName, itemName, itemType){

	    	if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}
	    },

	 	render: function() {

			var self = this ;
			
			if(typeof jQuery.cookie('popup-showed') != 'undefined' 
				&& 
				jQuery.cookie("popup-showed") == "yes"){
				
			}else{

				self.$el.append(self.exitModalLayout());		
				Utils.openPopup('exitModal') ;	
				self.registerMixpanelEvents("Pop-up Served", "", "")
			}
		}

	});

	exitModal.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	exitModal.prototype.clean = function() {
		
		this.remove();
	};

	return exitModal;
});