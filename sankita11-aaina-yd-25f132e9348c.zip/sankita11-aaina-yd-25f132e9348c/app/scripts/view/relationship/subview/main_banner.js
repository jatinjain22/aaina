define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousel'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) {

	var StartChatView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		events: {
			'click #home2-scroll-down' : 'scrollToFeaturedExperts'
		},
		scrollToFeaturedExperts : function(e){
			$('html,body').animate({
        		scrollTop: $("#home2-featured-block").offset().top},
        	'slow');
		},
		StartChatViewLayout: JST['app/templates/relationship/main_banner.hbs'],
		render: function() {

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			$(".start-chat-block").html(this.StartChatViewLayout({ "isLoggedIn" : Utils.isLoggedIn(), userType : userType, isMobileDevice:Utils.isMobileDevice() }));

		}
	});

	StartChatView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	StartChatView.prototype.clean = function() {
		this.remove() ;
	};

	return StartChatView;
});
