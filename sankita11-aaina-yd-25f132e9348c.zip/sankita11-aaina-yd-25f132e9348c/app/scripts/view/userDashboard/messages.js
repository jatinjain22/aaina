define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'

] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var MessagesView = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		events : {
			"click .chat-demo" : "redirectToChat",
			"click .messages-container .content" : "redirectToInbox"
		},

		layout : JST['app/templates/userDashboard/messages.hbs'],

		render : function(options){
			var self = this;
			var unreadCount = sessionStorage.getItem("unread");
			if (unreadCount && parseInt(unreadCount) > 0) {
				$(".messages-container").html(self.layout({
					messages: true,
					count: unreadCount
				}));
				return;
			}
			self.userObject = JSON.parse(localStorage.getItem("user"));
			$.ajax({
			  method: "GET",
			  url: Utils.contextPath()+'/v1/users/'+self.userObject.id+'/messages/count?type=unread'
			})
			.done(function (res) {
				if (res.count) {
					$(".messages-container").html(self.layout({
						messages: true,
						count: res.count
					}));
					return;	
				}
				$(".messages-container").html(self.layout({
					messages: false
				}));
					
			})
			.fail(function (err) {
				$(".messages-container").html(self.layout({
					messages: false
				}));
			});
		},

		registerMixpanelEvents : function(attributes){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				attributes.version = "1.0";
				mixpanel.track("Dashboard", attributes);
			}
		},

		redirectToChat: function () {
			window.open(blogOrigin + "/chatSession/?workgroup=" + chatDemoWorkgroup + "&noUI=true&username=" + this.userObject.username);
		},

		redirectToInbox: function () {
			this.registerMixpanelEvents({
				"action_type": "check_unread_msg"
			});
			Backbone.history.navigate('/user/messages', {"trigger":true});
			return;
		}
		
	});

	MessagesView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	MessagesView.prototype.clean = function() {

		this.remove() ;
	};

	return MessagesView;
});
