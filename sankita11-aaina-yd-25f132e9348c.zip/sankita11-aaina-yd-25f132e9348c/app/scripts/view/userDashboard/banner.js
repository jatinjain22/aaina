define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'

] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var BannerView = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		events : {
			"click .banner-container img": "bannerRedirect"
		},

		layout : JST['app/templates/userDashboard/banner.hbs'],

		render : function(options){
			var self = this;
			$(".banner-container").html(self.layout());
			// $.ajax({
			//   method: "GET",
			//   url: "https://rmgud7qqdk.execute-api.us-east-1.amazonaws.com/Staging/get-banner?query=active",
			//   xhrFields: {
			//   	withCredentials: false
			//   },
			//   beforeSend: function (xhr) {
			//   	// body...
			//   }
			// })
			// .done(function (res) {
			// 	if (res.message.length) {
			// 		$(".banner-container").html(self.layout({
			// 			bannerList: res.message
			// 		}));
			// 		var mySwiper = new Swiper ('.banner-swiper', {
		    //     		autoplay: 6000,
		   	// 			keyboardControl: true,
		   	// 			pagination: '.paginate',
	        // 			paginationClickable: true,
			// 		});
			// 	}
			// })
			// .fail(function (err) {
			// 	console.log(err);
			// });
		},

		bannerRedirect: function (evt) {
			window.open(evt.currentTarget.getAttribute("data-cta"));
		}
	});

	BannerView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	BannerView.prototype.clean = function() {

		this.remove() ;
	};

	return BannerView;
});
