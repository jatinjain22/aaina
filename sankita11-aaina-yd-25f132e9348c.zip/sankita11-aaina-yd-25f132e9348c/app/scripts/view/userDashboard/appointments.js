define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'

] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var AppointmentsView = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		events : {
			"click .book" : "bookAppointment"
		},

		layout : JST['app/templates/userDashboard/appointments.hbs'],
		loader: JST['app/templates/packages/loader.hbs'],

		render : function(options){
			$(".appointments-container").html(this.loader({}));
			var self = this;
			var userObject = JSON.parse(localStorage.getItem("user"));
			$.ajax({
				method: "GET",
				url: Utils.contextPath() + "/v2/users/" + userObject.id + "/appointment/upcoming"
			})
			.done(function (res) {
				if (res.length) {
					self.getParsedResponse(res)
					.then(function (list) {
						$(".appointments-container").html(self.layout({
							appointments: true,
							items: list
						}));
					});
				} else {
					$(".appointments-container").html(self.layout({
						appointments: false
					}));
				}
			})
			.fail(function (err) {
				$(".appointments-container").html(self.layout({
					appointments: false
				}));
			});
		},

		registerMixpanelEvents : function(attributes){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				attributes.version = "1.0";
				mixpanel.track("Dashboard", attributes);
			}
		},

		bookAppointment: function () {
			this.registerMixpanelEvents({
				"action_type": "new_appointment"
			});
			Backbone.history.navigate('/bookAppointment', {"trigger":true});
			return;
		},

		getParsedResponse: function (list) {
			var defer = $.Deferred();
			var parsedList = [];
			Utils.fetchCounselorList()
			.then(function (res) {
				list.forEach(function (item) {
					var date = new Date(item.appointment.slotStartTime) + "";
					var splittedDate = date.split(" ");
					var hash = {};
					var showTime = true;
					showTime = item.appointment.type === "FACE2FACE" ? false : true
					hash.showTime = showTime;
					hash.day = splittedDate[2];
					hash.month = splittedDate[1];
					hash.year = splittedDate[3];
					var time = splittedDate[4];
					var splittedTime = time.split(":");
					if (parseInt(splittedTime[0]) >= 12) {
						var hours = splittedTime[0] - 12;
						if (hours ==0) hours = 12;
						hash.slot = splittedDate[0] + ', ' + hours + ":" + splittedTime[1] + " PM";
					} else {
						hash.slot = splittedDate[0] + ', ' + splittedTime[0] + ":" + splittedTime[1] + " AM";
					}
					var id = item.appointment.counselorID;
					res.every(function (counselor, index) {
						if (counselor.id == id) {
							hash.name = counselor.name;
							return false;
						}
						return true;
					});
					parsedList.push(hash);
				});
				defer.resolve(parsedList);
			});
			return defer.promise();
		}

	});

	AppointmentsView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	AppointmentsView.prototype.clean = function() {

		this.remove() ;
	};

	return AppointmentsView;
});
