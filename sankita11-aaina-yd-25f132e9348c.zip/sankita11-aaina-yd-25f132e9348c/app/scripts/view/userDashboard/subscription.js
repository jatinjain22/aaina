define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'

] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var SubscriptionView = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		events : {
			"click .renew" : "renewSubscription"
		},

		layout : JST['app/templates/userDashboard/subscription.hbs'],

		render : function(options){
			var self = this;
			$.ajax({
				url: Utils.contextPath() + "/v2/user/account"
			})
			.done(function (response) {
				var subscriptionOptions = {
					'type': '',
					'msg': '',
					'cta':''
				};
				//response = {"is_chat_allowed":true,"plan":{"price":"0","total_chats":"2","name":"PAID", 'expiry_date': 1500716691000},"report":{"total_chats_used":"0"}};
				if (response.is_chat_allowed) {
					if (response.plan.name == 'FREE') {
						self.registerMixpanelEvents({
							"action_type": "rendered",
							"action_data": "Free Chats"
						});
						subscriptionOptions.type = 'FREE_REMAINING';
						var chatsRemaining = response.plan.total_chats - response.report.total_chats_used;
						subscriptionOptions.msg	= 'You have <strong>' + chatsRemaining + '</strong>' + ' free chat ' + (chatsRemaining == 1 ? 'session' : 'sessions') + ' left.';
						subscriptionOptions.cta =  'Purchase a care plan now';
						if(parseInt(chatsRemaining) === 0){
							subscriptionOptions.msg	= 'Get the guidance you need from top Experts right away.';
							subscriptionOptions.cta =  'buy a Care Plan Now';
						}
					} else {
						self.registerMixpanelEvents({
							"action_type": "rendered",
							"action_data": "Care Plan Expires On"
						});
						var date = new Date(response.plan.expiry_date);
						var dateArr = (date + "").split(" ");
						subscriptionOptions.msg = 'Remember, your Care Plan expires on ' + '<strong>' + dateArr[1] + " " + dateArr[2] + ", " + dateArr[3] + '</strong>.';
						subscriptionOptions.type = 'ACTIVE';
					}
				} else {
					if (response.plan.name == 'FREE') {
						self.registerMixpanelEvents({
							"action_type": "rendered",
							"action_data": "Free Chats Expired"
						});
						subscriptionOptions.type = 'FREE_EXPIRED',
						subscriptionOptions.msg	= 'Your free chat sessions have ended.';
						subscriptionOptions.cta =  'Upgrade to Care Plan Now';
						var chatsRemaining = response.plan.total_chats - response.report.total_chats_used;
						if(parseInt(chatsRemaining) === 0){
							subscriptionOptions.msg	= 'Get the guidance you need from top Experts right away.';
							subscriptionOptions.cta =  'buy a Care Plan Now';
						}
					} else {
						self.registerMixpanelEvents({
							"action_type": "rendered",
							"action_data": "Care Plan Expired"
						});
						subscriptionOptions.type = 'PAID_EXPIRED',
						subscriptionOptions.msg	= 'Your Care Plan has expired.';
						subscriptionOptions.cta =  'Renew Now';
					}
				}
				$(".subscription-container").html(self.layout(subscriptionOptions));
				if (!subscriptionOptions.cta) $(".subscription-container .content-container").addClass("padding2");
			})
			.fail(function (error) {
				console.log(error);
			});
		},

		registerMixpanelEvents : function(attributes){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				attributes.version = "2.0";
				mixpanel.track("Dashboard", attributes);
			}
		},

		renewSubscription: function (evt) {
			var type = evt.currentTarget.getAttribute('data-type');
			if (type == 'FREE_REMAINING') {
				this.registerMixpanelEvents({
					"action_type": "Buy Subscription",
					"action_data": "Free Chats Remaining"
				});
			} else if (type == 'FREE_EXPIRED') {
				this.registerMixpanelEvents({
					"action_type": "Buy Subscription",
					"action_data": "Free Chats Expired"
				});
			} else if (type == 'PAID_EXPIRED') {
				this.registerMixpanelEvents({
					"action_type": "Buy Subscription",
					"action_data": "Care Plan Expired"
				});
			}
			Backbone.history.navigate("/care-plan/subscribe",{trigger:true});
		}
	});

	SubscriptionView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	SubscriptionView.prototype.clean = function() {

		this.remove() ;
	};

	return SubscriptionView;
});
