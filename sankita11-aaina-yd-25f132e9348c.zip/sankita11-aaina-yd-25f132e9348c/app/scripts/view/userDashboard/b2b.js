define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'
] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var b2bsView = Backbone.View.extend({
		el: "main",
		initialize : function(){},
		events : {
            'click .b2b-content .action' : 'expandB2b',
			'click .b2b-inner-content .b2b-list .offerCode' : 'copyCode',
			'click .b2b-show-more' : 'showMore',
			'click .b2b-inner-content .action' : 'eventListener'
        },
		eventListener : function(evt){
			var self = this;
			var type = $(evt.currentTarget).attr("data-type")
			switch (type) {
				case "link":
					var url = $(evt.currentTarget).attr("data-url")
					self.registerMixpanelEvents({action_data : "Redirect: "+url, action_type: "Button Click"})
					window.open(url, "_blank")
					break;
				case "chat":
					self.chatConnect()
					break;
				default:
			}
		},
		redirect: function (options) {
            if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "b2b","b2b", "homeCat" + options.categoryID);
        },
        chatConnect : function(){
			this.registerMixpanelEvents({action_data : "chat connection", action_type: "Button Click"})
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "b2b",  "b2b", "free_chat", {options : {type: 'chat',categoryID : 1},callback: this.redirect}) ;
			}else{
				this.redirect({"type"	: 'chat',categoryID : 1});
			}
        },
		showMore : function(e){
			this.registerMixpanelEvents({action_data : "show more services", action_type: "Button Click"})
			if($(e.currentTarget).hasClass("more")){
				$(e.currentTarget).removeClass("more").addClass("less")
				$(".subscription-container").find(".b2b-mob-inner").append(this.mobLayout({data : this.dataObj.services.slice(3,this.dataObj.services.length)}))
				return;
			}
			$(e.currentTarget).addClass("more").removeClass("less")
			$(".subscription-container").find(".b2b-mob-inner").html(this.mobLayout({data : this.dataObj.services.slice(0,3)}))
		},
        expandB2b : function(evt){
			var self = this
            var item = $(evt.currentTarget)
			$(".b2b-inner-content").remove()
            if(item.parents(".b2b-row").hasClass("expanded")){
                item.parents(".b2b-row").addClass("collapsed").removeClass("expanded")
				if(item.parents(".b2b-content").hasClass("show"))	item.parents(".b2b-content").removeClass("show").addClass("hideDetails")
				else  self.renderContent(item)
                return;
            }
			self.renderContent(item)
        },
		renderContent : function( item ){
			$(".b2b-row").addClass("collapsed").removeClass("expanded")
			$(".b2b-content").removeClass("show").addClass("hideDetails")
            item.parents(".b2b-row").addClass("expanded").removeClass("collapsed")
			item.parents(".b2b-content").addClass("show").removeClass("hideDetails")
			item.parents(".b2b-row").append(this.innerLayout({content : this.dataObj.services[parseInt(item.attr("data-id")) - 1].content}))
			if(!Utils.isMobileDevice()) this.positionArrow(parseInt(item.attr("data-id")))
		},
		positionArrow : function(index){
			if(index > 3) index = index-3
			$(".triangle1").css({"left" : ((index-1) * 33)+18.2+'%'})
			$(".triangle").css({"left" : ((index-1) * 33)+18.9+'%'})
		},
		layout : JST['app/templates/userDashboard/b2b.hbs'],
		innerLayout : JST['app/templates/userDashboard/b2b_inner.hbs'],
		mobLayout : JST['app/templates/userDashboard/mob_b2b.hbs'],
        sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
			.done(function (response) {
				deferred.resolve(response);
			}).fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},
		copyCode : function( evt ){
			$(".offerCode").removeClass("disabled").html("copy code")
			this.copyToBoard($(evt.currentTarget).attr("id"))
		},
        copyToBoard : function( ele ){
            var aux = document.createElement("input");
            aux.setAttribute("value", document.getElementById(ele).getAttribute("data-value"));
			this.registerMixpanelEvents({action_data : "offer code copied", action_type: "Button Click"})
            document.body.appendChild(aux);
            aux.select();
            document.execCommand("copy");
			$("#"+ele).html("copied").addClass("disabled")
            document.body.removeChild(aux);
        },
		render : function(options){
			var self = this;
			this.registerMixpanelEvents({action_data : "B2B Page", action_type: "Rendered"})
            this.sendRequest({"url":Utils.scriptPath()+'/b2b.json', "method":"GET"})
            .then(function(res){
				if(res["visibility"]){
					self.dataObj = res[options].content;
					$(".subscription-container").html(self.layout({name: res[options].content.name, data : res[options].content.services, num : res[options].content.services.length}))
				}
			}, function(err){
                console.log("Error: ", err)
            })
		},
		registerMixpanelEvents : function(options){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				mixpanel.track("B2B-Dashboard", options);
			}
		}
	});
	b2bsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};
	b2bsView.prototype.clean = function() {
		this.remove() ;
	};

	return b2bsView;
});
