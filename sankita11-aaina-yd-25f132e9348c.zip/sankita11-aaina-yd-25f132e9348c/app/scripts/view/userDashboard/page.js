define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher',
	'view/userDashboard/appointments',
	'view/userDashboard/messages',
	'view/userDashboard/banner',
	'view/userDashboard/experts',
	'view/userDashboard/subscription',
	'view/userDashboard/b2b'

] , function( $, _, Backbone, Utils, JST, Dispatcher, Appointments, Messages, Banner, Experts, Subscription, B2b) {

	var userDashboard = Backbone.View.extend({

		el: "main",

		initialize : function(){

			// this.appointmentsView = new Appointments();
			// this.messagesView = new Messages();
			// this.banner = new Banner();
			// this.expertsView = new Experts();
		},

		events : {
			"click .article": 	"redirectToBlog",
			"click .discussion": "redirectToBlog",
			"click .package": 	"redirectToPackage",
			"click .test"	: 	"redirectToTest",
			"click .video"	: 	"redirectToBlog",
			"click .ebooks-container .content": "downloadEbook",
			"click .share-icon": "openShareOptions",
			"click .social-share": "preventRedirect",
			"click .read-messages": "redirectToInbox",
			"click .feeling-action": "flipFeeling",
			"click .connect": "redirectToDemoChat",
			"click .questions-container.1 .answer": "flipQuestion1",
			"click .questions-container.2 .answer": "flipQuestion2",
			"click .know-more": "redirect"
		},

		mainLayout : JST['app/templates/userDashboard/layout.hbs'],
		feedLayout : JST['app/templates/userDashboard/feed.hbs'],
		ebookLayout : JST['app/templates/userDashboard/ebooks.hbs'],
		articleTopLayout : JST['app/templates/userDashboard/article_top.hbs'],
		articleBottomLayout : JST['app/templates/userDashboard/article_bottom.hbs'],
		packagesLayout : JST['app/templates/userDashboard/packages.hbs'],
		discussionsLayout : JST['app/templates/userDashboard/discussions.hbs'],
		quotesLayout : JST['app/templates/userDashboard/quotes.hbs'],
		selfTestLayout : JST['app/templates/userDashboard/self_test.hbs'],
		unreadMsgLayout : JST['app/templates/userDashboard/unread_msg.hbs'],
		videoBlogLayout : JST['app/templates/userDashboard/video_blog.hbs'],
		feelingLayout : JST['app/templates/userDashboard/feeling.hbs'],
		feelingReactionLayout : JST['app/templates/userDashboard/feeling_reaction.hbs'],
		questionLayout : JST['app/templates/userDashboard/question.hbs'],
		suggestionsLayout : JST['app/templates/userDashboard/suggestion.hbs'],
		newsLayout : JST['app/templates/userDashboard/news.hbs'],

		redirect: function () {
			this.registerMixpanelEvents({
				"action_type": "announcement"
			});
			window.open('/announcement');
		},

		render : function(options){
			Utils.getVariantType({
                'name': 'SubscriptionExperiment',
                'alternatives': ['singlePlan','doublePlan','allPlans']
            })
            .then(function (res) {
            	// body...
            }, function (err) {
            	// body...
            });
			Utils.fetchCarePlanStats();
			if (!Utils.isLoggedIn()) {
				Backbone.history.navigate("/", {trigger: true});
				//Dispatcher.trigger('renderLogin');
				return;
			}
			this.isMobileDevice = Utils.isMobileDevice();
			this.userObject = localStorage.getItem('user');
			this.appointmentsView = new Appointments();
			this.messagesView = new Messages();
			this.banner = new Banner();
			this.expertsView = new Experts();

			document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
			$('meta[name=description]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
			$('meta[name=title]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
			$('meta[property="og:description"]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
			$('meta[property="og:title"]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/');
			this.registerMixpanelEvents({
				"action_type": "page_load"
			});
			this.$el.html(this.mainLayout());
			// $(".news-container").html(this.newsLayout({
			// 	'mobile': this.isMobileDevice
			// }));
			$(".feed-container").html(this.feedLayout({'page': "0"}));
			this.appointmentsView.render();
			this.messagesView.render();
			this.banner.render();
			if (JSON.parse(this.userObject)['loggableUser']['orgId'] < 0) {
				this.subscriptionView = new Subscription();
				this.subscriptionView.render();
			}else{
				this.b2bLayout = new B2b()
				this.b2bLayout.render(JSON.parse(this.userObject)['loggableUser']['orgId'])
			}
			this.fetchFeed();
			this.packagesMap = Utils.packagesMap;
			var self = this;
		},


		scrollHandler: function (evt) {
			this.scrolled.call(this, evt);

		},

		scrollHandler: function (evt) {
			this.scrolled.call(this, evt);
		},

		quoteBackgroundColors: ["#76b7d8", "#e0848e", "f0905c", "#b7dc92", "#928bab", "#f5b52d", "7aa5c3"],

		preventRedirect: function (evt) {
			evt.stopPropagation();
		},

		openShareOptions: function (evt) {
			var elm = $(evt.currentTarget).parent().parent().find(".title").parent().find(".social-share");
			if (elm.css("opacity") == '0') {
				elm.css("opacity", "1");
				setTimeout(function () {
					elm.css("opacity", "0");
				}, 2500);
			} else {
				elm.css("opacity", "0");
			}
			evt.stopPropagation();
		},

		redirectToDemoChat: function (evt) {
			var elm = evt.currentTarget;
			var feeling = elm.getAttribute('data-feeling');
			if (feeling) {
				window.open(blogOrigin + "/chatSession/?workgroup=" + chatDemoWorkgroup + "&noUI=true&username=" + this.userObject.username + '&feeling=' + feeling);
			} else {
				var ques = elm.getAttribute('data-ques');
				var ans = elm.getAttribute('data-ans');
				window.open(blogOrigin + "/chatSession/?workgroup=" + chatDemoWorkgroup + "&noUI=true&username=" + this.userObject.username + '&ques=' + ques + "&ans=" + ans);
			}
		},

		registerMixpanelEvents : function(attributes){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				attributes.version = "2.0";
				mixpanel.track("Dashboard", attributes);
			}
		},

		feelingMap: {
			'web': {
				'happy': "Woohoo! That's great to hear. You're in a good place mentally.<br>Remember to check back in with us, should you ever find your happiness quotient decreasing - we can help!",
				'anxious':"Oh dear, that doesn't sound good.<br>However, it can be handled well if you know the right techniques.<br>Our experts can help.",
				'angry':"Grrr! I know it's awful to feel angry and this is not helping you.<br>Talk to an expert and together we'll figure out what we can do.",
				'demotivated': "Oh no! Fret not. We're here to help you out.<br>Tell us what you need motivation for, or what's putting you down.<br>Together we can fix this.",
				'worthless':"That sounds rather distressing. We believe in you and are here for you.<br>Let's chat, together we can fix this.",
				'sad':"Aww Damn! That must feel awful.<br>Would you like to share what has been making you feel this way?<br>We can help!",
			},
			'mobile': {
				'happy': "Woohoo! That's great to hear. You're in a good place mentally.Remember to check back in with us, should you ever find your happiness quotient decreasing - we can help!",
				'anxious':"Oh dear, that doesn't sound good.However, it can be handled well if you know the right techniques.Our experts can help.",
				'angry':"Grrr! I know it's awful to feel angry and this is not helping you.Talk to an expert and together we'll figure out what we can do.",
				'demotivated': "Oh no! Fret not. We're here to help you out.Tell us what you need motivation for, or what's putting you down.Together we can fix this.",
				'worthless':"That sounds rather distressing. We believe in you and are here for you.Let's chat, together we can fix this.",
				'sad':"Aww Damn! That must feel awful.Would you like to share what has been making you feel this way?We can help!",
			}
		},

		answers:[
			{
				'mixpanel': 'FC Compliment',
				'ques': "If you like someone and want to express your admiration for them, what will you do?",
				'answers': [{'name':'bold', 'answer':'Be bold and express yourself'}, {'name':'discuss', 'answer': 'Avoid discussing your feelings'}, {'name':'help', 'answer': 'Ask a friend for help'}, {'name':'hint', 'answer': 'Drop subtle hints'}],
				'suggestions': {
					'web': {
						'bold': {
							'ques': 'Compliment',
							'ans': 'bold',
							'connect': false,
							'title': "Awesome!",
							'reaction': "Fortune indeed favors the brave :)"
						},
						'discuss': {
							'ques': 'Compliment',
							'ans': 'discuss',
							'connect': true,
							'reaction': "All relationships, including the blooming ones *wink wink* bring joy when you express yourself better.<br>With a little guidance, you can do that with ease."
						},
						'help': {
							'ques': 'Compliment',
							'ans': 'help',
							'connect': true,
							'reaction': "Your friends know you, but they might not know how you feel.<br>So why not learn to express yourself better?"
						},
						'hint': {
							'ques': 'Compliment',
							'ans': 'hint',
							'connect': true,
							'reaction': "Communication is the most important aspect of any relationship.<br>Instead of assuming that people will get your hints,<br>why not go ahead and express yourself better?"
						},
					},
					'mobile': {
						'bold': {
							'ques': 'Compliment',
							'ans': 'bold',
							'connect': false,
							'title': "Awesome!",
							'reaction': "Fortune indeed favors the brave :)"
						},
						'discuss': {
							'ques': 'Compliment',
							'ans': 'discuss',
							'connect': true,
							'reaction': "All relationships, including the blooming ones *wink wink* bring joy when you express yourself better.With a little guidance, you can do that with ease."
						},
						'help': {
							'ques': 'Compliment',
							'ans': 'help',
							'connect': true,
							'reaction': "Your friends know you, but they might not know how you feel.So why not learn to express yourself better?"
						},
						'hint': {
							'ques': 'Compliment',
							'ans': 'hint',
							'connect': true,
							'reaction': "Communication is the most important aspect of any relationship.Instead of assuming that people will get your hints,why not go ahead and express yourself better?"
						},
					}
				}
			},
			{
				'mixpanel': 'FC Work',
				'ques': "What motivates you to work?",
				'answers': [{'name':'passion', 'answer':'Passion for work'}, {'name':'fame', 'answer': 'Fame and Power'}, {'name':'society', 'answer': 'Societal expectations'}, {'name':'money', 'answer': 'Money'}],
				'suggestions': {
					'web': {
						'passion': {
							'ques': 'Work',
							'ans': 'passion',
							'connect': false,
							'title': "Awesome!",
							'reaction': "Doing what you love helps you lead a happy life :)"
						},
						'fame': {
							'ques': 'Work',
							'ans': 'fame',
							'connect': true,
							'reaction': "Fame & power can be powerful motivators.<br>But they shouldn't be the only things that drive you.<br>Get a fresh perspective."
						},
						'society': {
							'ques': 'Work',
							'ans': 'society',
							'connect': true,
							'reaction': "A lot of people give up on their dreams due to societal pressure.<br>But with a little timely guidance, you can be on the path<br>towards the life of your dreams."
						},
						'money': {
							'ques': 'Work',
							'ans': 'money',
							'connect': true,
							'reaction': "Money gives you the means to survive, but it can't buy you happiness.<br>To know how to thrive & not just survive."
						},
					},
					'mobile': {
						'passion': {
							'ques': 'Work',
							'ans': 'passion',
							'connect': false,
							'title': "Awesome!",
							'reaction': "Doing what you love helps you lead a happy life :)"
						},
						'fame': {
							'ques': 'Work',
							'ans': 'fame',
							'connect': true,
							'reaction': "Fame & power can be powerful motivators.But they shouldn't be the only things that drive you.Get a fresh perspective."
						},
						'society': {
							'ques': 'Work',
							'ans': 'society',
							'connect': true,
							'reaction': "A lot of people give up on their dreams due to societal pressure.But with a little timely guidance, you can be on the path towards the life of your dreams."
						},
						'money': {
							'ques': 'Work',
							'ans': 'money',
							'connect': true,
							'reaction': "Money gives you the means to survive, but it can't buy you happiness.To know how to thrive & not just survive."
						},
					}
				}
			},
			{
				'mixpanel': 'FC Weekend',
				'ques': "How does your weekend look like?",
				'answers': [{'name':'party', 'answer':'I party every week'}, {'name':'friends', 'answer': 'I meet friends'}, {'name':'books', 'answer': 'I read books'}, {'name':'plans', 'answer': 'I never have plans'}],
				'suggestions': {
					'web': {
						'party': {
							'ques': 'Weekend',
							'ans': 'party',
							'connect': false,
							'title': "Awesome!",
							'reaction': "If we ever throw a party, you'll be on our list for sure :)"
						},
						'friends': {
							'ques': 'Weekend',
							'ans': 'friends',
							'connect': false,
							'title': "That's nice!",
							'reaction': "After a hectic work-week, catching up<br>with loved ones can help you de-stress.<br>Keep it up!"
						},
						'books': {
							'ques': 'Weekend',
							'ans': 'books',
							'connect': true,
							'reaction': "Reading could be therapeutic at times.<br>If you are doing it out of passion, keep it up.<br>It will help you de-stress. However, if you are doing it to kill time"
						},
						'plans': {
							'ques': 'Weekend',
							'ans': 'plans',
							'connect': true,
							'reaction': "Having no plans is not bad at all.<br>In fact, lazing around doing nothing can cheer you up.<br>If having no plans seems to bother you at times."
						},
					},
					'mobile': {
						'party': {
							'ques': 'Weekend',
							'ans': 'party',
							'connect': false,
							'title': "Awesome!",
							'reaction': "If we ever throw a party, you'll be on our list for sure :)"
						},
						'friends': {
							'ques': 'Weekend',
							'ans': 'friends',
							'connect': false,
							'title': "That's nice!",
							'reaction': "After a hectic work-week, catching up with loved ones can help you de-stress.Keep it up!"
						},
						'books': {
							'ques': 'Weekend',
							'ans': 'books',
							'connect': true,
							'reaction': "Reading could be therapeutic at times.If you are doing it out of passion, keep it up.It will help you de-stress. However, if you are doing it to kill time"
						},
						'plans': {
							'ques': 'Weekend',
							'ans': 'plans',
							'connect': true,
							'reaction': "Having no plans is not bad at all.In fact, lazing around doing nothing can cheer you up.If having no plans seems to bother you at times."
						},
					}
				}
			},
			{
				'mixpanel': 'FC Conflict',
				'ques': "When you don't like something, your partner just said, you ...",
				'answers': [{'name':'fight', 'answer':'Fight with them'}, {'name':'manipulate', 'answer': 'Start to manipulate'}, {'name':'agree', 'answer': 'Silently agree'}, {'name':'negotiate', 'answer': 'Negotiate with respect'}],
				'suggestions': {
					'web': {
						'negotiate': {
							'ques': 'Conflict',
							'ans': 'negotiate',
							'connect': false,
							'title': "Fantastic!",
							'reaction': "The key to a happy & healthy relationship lies in managing your differences well."
						},
						'fight': {
							'ques': 'Conflict',
							'ans': 'fight',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.<br>The trick is in handling the differences well.<br>With a little guidance from our experts, you'll be able to do that and more."
						},
						'manipulate': {
							'ques': 'Conflict',
							'ans': 'manipulate',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.<br>The trick is in handling the differences well.<br>With a little guidance from our experts, you'll be able to do that and more."
						},
						'agree': {
							'ques': 'Conflict',
							'ans': 'agree',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.<br>The trick is in handling the differences well.<br>With a little guidance from our experts, you'll be able to do that and more."
						},
					},
					'mobile': {
						'negotiate': {
							'ques': 'Conflict',
							'ans': 'negotiate',
							'connect': false,
							'title': "Fantastic!",
							'reaction': "The key to a happy & healthy relationship lies in managing your differences well."
						},
						'fight': {
							'ques': 'Conflict',
							'ans': 'fight',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.The trick is in handling the differences well.With a little guidance from our experts, you'll be able to do that and more."
						},
						'manipulate': {
							'ques': 'Conflict',
							'ans': 'manipulate',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.The trick is in handling the differences well.With a little guidance from our experts, you'll be able to do that and more."
						},
						'agree': {
							'ques': 'Conflict',
							'ans': 'agree',
							'connect': true,
							'reaction': "Since two different individuals are involved, disagreement is natural.The trick is in handling the differences well.With a little guidance from our experts, you'll be able to do that and more."
						},
					}
				}
			},
			{
				'mixpanel': 'FC Presentation',
				'ques': "An important presentation's coming up, what's the first thing you would do?",
				'answers': [{'name':'anxious', 'answer':'Feel anxious'}, {'name':'ignore', 'answer': 'Ignore the pressure'}, {'name':'prepared', 'answer': 'Be prepared'}],
				'suggestions': {
					'web': {
						'prepared': {
							'ques': 'Presentation',
							'ans': 'prepared',
							'connect': false,
							'title': "That’s great!",
							'reaction': "Preparation is the key to success."
						},
						'anxious': {
							'ques': 'Presentation',
							'ans': 'anxious',
							'connect': true,
							'reaction': "Getting anxious about your performance is normal.<br>In fact, nearly 50% of people experience it.<br>But with expert guidance, you can ace that big presentation with little effort :) "
						},
						'ignore': {
							'ques': 'Presentation',
							'ans': 'ignore',
							'connect': true,
							'reaction': "Pressure works in your favor when you manage it well.<br>Our experts can certainly help you do that."
						}
					},
					'mobile': {
						'prepared': {
							'ques': 'Presentation',
							'ans': 'prepared',
							'connect': false,
							'title': "That’s great!",
							'reaction': "Preparation is the key to success."
						},
						'anxious': {
							'ques': 'Presentation',
							'ans': 'anxious',
							'connect': true,
							'reaction': "Getting anxious about your performance is normal.In fact, nearly 50% of people experience it.But with expert guidance, you can ace that big presentation with little effort :) "
						},
						'ignore': {
							'ques': 'Presentation',
							'ans': 'ignore',
							'connect': true,
							'reaction': "Pressure works in your favor when you manage it well.Our experts can certainly help you do that."
						}
					}
				}
			},
			{
				'mixpanel': 'FC Punctuality',
				'ques': "When someone promises you for a 10'o clock meeting and doesn't show up, you...",
				'answers': [{'name':'discontent', 'answer':'Politely express discontent'}, {'name':'agitated', 'answer': 'Stay agitated'}, {'name':'blame', 'answer': 'Blame external factors'}],
				'suggestions': {
					'web': {
						'discontent': {
							'ques': 'Punctuality',
							'ans': 'discontent',
							'connect': false,
							'title': "Good!",
							'reaction': "Communicating one's concerns<br>effectively without getting angry, helps<br>in resolving big and small conflicts."
						},
						'agitated': {
							'ques': 'Punctuality',
							'ans': 'agitated',
							'connect': true,
							'reaction': "Most of the times, anger is the first response.<br>But if you manage it well, anger can be an asset.<br>Learn how to make anger work in your favor."
						},
						'blame': {
							'ques': 'Punctuality',
							'ans': 'blame',
							'connect': true,
							'reaction': "Blaming won't help you resolve your problems.<br>But learning to manage your emotions effectively will<br>help you work well with others."
						}
					},
					'mobile': {
						'discontent': {
							'ques': 'Punctuality',
							'ans': 'discontent',
							'connect': false,
							'title': "Good!",
							'reaction': "Communicating one's concerns<br>effectively without getting angry, helps in resolving big and small conflicts."
						},
						'agitated': {
							'ques': 'Punctuality',
							'ans': 'agitated',
							'connect': true,
							'reaction': "Most of the times, anger is the first response.But if you manage it well, anger can be an asset.Learn how to make anger work in your favor."
						},
						'blame': {
							'ques': 'Punctuality',
							'ans': 'blame',
							'connect': true,
							'reaction': "Blaming won't help you resolve your problems.But learning to manage your emotions effectively will help you work well with others."
						}
					}
				}
			}
		],

		flipFeeling: function (evt) {
			var feeling;
			if (evt.currentTarget) {
				feeling = evt.currentTarget.getAttribute("data-feeling");
			} else {
				feeling = evt.feel;
			}

			$(".feeling-container .back").html(this.feelingReactionLayout({
				'feeling': feeling,
				'msg': this.isMobileDevice ? this.feelingMap['mobile'][feeling] : this.feelingMap['web'][feeling],
				'mobile': this.isMobileDevice
			}));
			$(".feeling-container #card").addClass("flipped");
			this.userInteraction.feeling.flipped = true;
			this.userInteraction.feeling.feel = feeling;
			this.userInteraction.feeling.time = this.userInteraction['feeling']['time'] ? this.userInteraction['feeling']['time'] : Date.now();
			localStorage.setItem('userInteraction', JSON.stringify(this.userInteraction));
			this.registerMixpanelEvents({
				"action_type": "FC Feeling",
				"action_data": feeling
			});
		},

		flipQuestion1: function (evt) {
			this.showSuggestions({
				'type': 1,
				'evt': evt
			});
		},

		flipQuestion2: function (evt) {
			this.showSuggestions({
				'type': 2,
				'evt': evt
			});
		},

		showSuggestions: function (options) {
			var answer;
			var index = this.userInteraction["card" + options.type]['index'];
			if (options.evt.currentTarget) {
				answer = options.evt.currentTarget.getAttribute("data-answer");
				this.userInteraction["card" + options.type]['answer'] = answer;
			} else {
				answer = options.evt.answer;
			}

			var renderOptions = this.isMobileDevice ? this.answers[index]['suggestions']['mobile'][answer] : this.answers[index]['suggestions']['web'][answer];
			renderOptions.mobile = this.isMobileDevice;
			$(".questions-container." + options.type + " .back").html(this.suggestionsLayout(renderOptions));
			$(".questions-container." + options.type + " .question-card").addClass("flipped");
			this.userInteraction["card" + options.type]['flipped'] = true;
			localStorage.setItem('userInteraction', JSON.stringify(this.userInteraction));
			this.registerMixpanelEvents({
				"action_type": this.answers[index]['mixpanel'],
				"action_data": answer
			});
		},

		downloadEbook: function (evt) {
			this.registerMixpanelEvents({
				"action_type": "download_ebook"
			});
			var postId = evt.currentTarget.getAttribute("data-id");
			var emailJSON = {
				"email": this.userObject.email
			};

			$.ajax({
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)
			})
			.done(function (res) {
				$(".content[data-id=" + postId + "] .status-msg").css("opacity","1");
				setTimeout(function () {
					$(".content[data-id=" + postId + "] .status-msg").css("opacity","0");
				}, 10000);
			});
		},

		scrolled: function (o) {
			if (window.location.href.indexOf("dashboard") == -1) return;
			var bottomOffset = Utils.isMobileDevice() ? 1500 : 600;
			var offsetHeight = o.currentTarget.body.offsetHeight;
			var scrollHeight = o.currentTarget.body.scrollHeight;
			var scrollTop = o.currentTarget.body.scrollTop;
			if(navigator.userAgent.toLowerCase().indexOf('firefox') > -1){
			     scrollTop = o.currentTarget.documentElement.scrollTop;
			}
			if(offsetHeight + scrollTop > (scrollHeight - bottomOffset))
            {
                this.currentFeedPage += 1;
                this.loadFeed();
            }
		},

		sendRequest: function (url, dataType) {
			var deferred = $.Deferred();
			var options = {};
			options.method = "GET";
			options.url = url;
			if (dataType) options.dataType = dataType;
			$.ajax(options)
			.done(function (response) {
				deferred.resolve(response);
			})
			.fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},

		redirectToBlog: function (evt) {
			var url = evt.currentTarget.getAttribute("data-url");
			var type = evt.currentTarget.getAttribute("data-type");
			var title = evt.currentTarget.getAttribute("data-title");
			this.registerMixpanelEvents({
				"action_type": "view_content",
				"action_data": {
					"content_type": type,
					"content_detail": title
				}
			});
			window.open(url);
		},

		redirectToInbox: function () {
			this.registerMixpanelEvents({
				"action_type": "check_unread_msg",
				"scroll": this.currentFeedPage
			});
			Backbone.history.navigate('/user/messages', {"trigger":true});
			return;
		},

		redirectToPackage: function (evt) {
			var id = evt.currentTarget.getAttribute("data-id");
			this.registerMixpanelEvents({
				"action_type": "view_content",
				"action_data": {
					"content_type": "packages",
					"content_detail": id
				}
			});
			window.open(blogOrigin + "/online-counseling-programs/" + this.packagesMap[id]);
		},

		redirectToTest: function (evt) {
			var url = evt.currentTarget.getAttribute("data-url");
			this.registerMixpanelEvents({
				"action_type": "view_content",
				"action_data": {
					"content_type": "self_test",
					"content_detail": url
				}
			});
			window.open(blogOrigin + url);
		},

		renderEbooks: function () {
			var list = this.ebooks.slice(this.currentFeedPage * 3, this.currentFeedPage * 3 + 3);
			if (list.length) {
				if (this.currentFeedPage) {
					$(".ebooks-container." + this.currentFeedPage).html(this.ebookLayout({
						"list" : list
					}));
					return;
				}
				$(".ebooks-container").html(this.ebookLayout({
					"list" : list
				}));
			}
		},

		renderArticles: function () {
			if (!this.newScrollHandler) {
				this.newScrollHandler = this.scrollHandler.bind(this);
				$(document).scroll(this.newScrollHandler);
			}
			var listTop = this.articles.slice(this.currentFeedPage * 3, this.currentFeedPage * 3 + 1);
			if (listTop.length) {
				if (this.currentFeedPage) {
					$(".article-top-container." + this.currentFeedPage).html(this.articleTopLayout({
						"list" : listTop
					}));
				} else {
					$(".article-top-container").html(this.articleTopLayout({
						"list" : listTop
					}));
				}
			}
			var listBottom = this.articles.slice(this.currentFeedPage * 3 + 1, this.currentFeedPage * 3 + 3);
			if (listBottom.length) {
				this.renderUnreadMsg();
				this.expertsView.render({
					page: this.currentFeedPage
				});
				if (this.currentFeedPage) {
					$(".article-bottom-container." + this.currentFeedPage).html(this.articleBottomLayout({
						"list" : listBottom
					}));
				} else {
					$(".article-bottom-container").html(this.articleBottomLayout({
						"list" : listBottom
					}));
				}
			}
		},

		renderPackage: function () {
			var list = this.packages.slice(this.currentFeedPage * 1, this.currentFeedPage * 1 + 1);
			if (list.length) {
				if (this.currentFeedPage) {
					$(".package-container." + this.currentFeedPage).html(this.packagesLayout({
						"list" : list
					}));
					return;
				}
				$(".package-container").html(this.packagesLayout({
					"list" : list
				}));
			}
		},

		renderDiscussions: function () {
			var list = this.discussions.slice(this.currentFeedPage * 2, this.currentFeedPage * 2 + 2);
			if (list.length) {
				if (this.currentFeedPage) {
					$(".discussions-container." + this.currentFeedPage).html(this.discussionsLayout({
						"list" : this.getParsedDiscussionsList(list)
					}));
					return;
				}
				$(".discussions-container").html(this.discussionsLayout({
					"list" : this.getParsedDiscussionsList(list)
				}));
			}
		},

		renderFeeling: function () {
			$(".feeling-container").html(this.feelingLayout({'mobile': this.isMobileDevice}));
			this.registerMixpanelEvents({
				"action_type": "rendered",
				"action_data": 'FC Feeling'
			});
			if (this.userInteraction['feeling']['flipped']){
				var renderTime = this.userInteraction['feeling']['time'];
				var currentTime = Date.now();
				var diff = Math.floor((currentTime - renderTime)/1000);
				if (diff >= 8 * 3600) {
					this.userInteraction['feeling']['flipped'] = false;
					this.userInteraction['feeling']['time'] = null;
					localStorage.setItem('userInteraction', JSON.stringify(this.userInteraction));
					return;
				}
				this.flipFeeling({
					'feel': this.userInteraction['feeling']['feel']
				});
			}
		},

		renderQuestion: function (number) {
			var renderOptions;
			this.registerMixpanelEvents({
				"action_type": "rendered",
				"action_data": this.answers[this.questionIndex]['mixpanel']
			});
			if (!this.userInteraction["card" + number]['time']) {
				this.userInteraction["card" + number]['time'] = Date.now();
				this.userInteraction["card" + number]['index'] = this.questionIndex;
				this.questionIndex += 1;
				this.questionIndex = this.questionIndex % this.answers.length;
				renderOptions = this.answers[this.userInteraction["card" + number]['index']];
				renderOptions.mobile = this.isMobileDevice;
				$(".questions-container." + number).html(this.questionLayout(renderOptions));
			} else {
				renderOptions = this.answers[this.userInteraction["card" + number]['index']];
				renderOptions.mobile = this.isMobileDevice;
				$(".questions-container." + number).html(this.questionLayout(renderOptions));
				var renderTime = this.userInteraction["card" + number]['time'];
				var currentTime = Date.now();
				var diff = Math.floor((currentTime - renderTime)/1000);
				if (diff >= 12 * 3600) {
					this.userInteraction["card" + number]['time'] = null;
					this.userInteraction["card" + number]['flipped'] = false;
					this.renderQuestion(number);
				} else {
					if (this.userInteraction["card" + number]['flipped']) {
						if (number == 1) {
							this.flipQuestion1({
								'answer': this.userInteraction["card" + number]['answer']
							})
						} else {
							this.flipQuestion2({
								'answer': this.userInteraction["card" + number]['answer']
							})
						}
					}
				}
			}
			localStorage.setItem('questionIndex', this.questionIndex);
			localStorage.setItem('userInteraction', JSON.stringify(this.userInteraction));
		},

		renderQuotes: function () {
			var list = this.quotes.slice(this.currentFeedPage * 1, this.currentFeedPage * 1 + 1);
			if (list.length) {
				list  = this.getParsedQuotesList(list);
				if (this.currentFeedPage) {
					$(".quotes-container." + this.currentFeedPage).html(this.quotesLayout({
						"list" : list
					}));
					$(".quotes-container." + this.currentFeedPage).css("background-color", this.quoteBackgroundColors[this.currentFeedPage % 7]);
					return;
				}
				$(".quotes-container").html(this.quotesLayout({
					"list" : list
				}));
				$(".quotes-container").css("background-color", this.quoteBackgroundColors[this.currentFeedPage % 7]);
			}
		},

		renderUnreadMsg: function () {
			if (this.unreadMsgCount) {
				if (this.currentFeedPage) {
					$(".unread-msg-container." + this.currentFeedPage).html(this.unreadMsgLayout({
						"count" : this.unreadMsgCount
					}));
					return;
				}
				$(".unread-msg-container").html(this.unreadMsgLayout({
					"count" : this.unreadMsgCount
				}));
			}
		},

		renderTest: function () {
			var list = this.tests.slice(this.currentFeedPage * 1, this.currentFeedPage * 1 + 1);
			if (list.length) {
				if (this.currentFeedPage) {
					$(".self-test-container." + this.currentFeedPage).html(this.selfTestLayout({
						"list" : list
					}));
					return;
				}
				$(".self-test-container").html(this.selfTestLayout({
					"list" : list
				}));
			}
		},

		renderVideoBlogs: function () {
			var list = this.videoBlogs.slice(this.currentFeedPage * 1, this.currentFeedPage * 1 + 1);
			if (list.length) {
				list = this.getParsedVideoBlogList(list);
				if (this.currentFeedPage) {
					$(".video-blog-container." + this.currentFeedPage).html(this.videoBlogLayout({
						"list" : list
					}));
					return;
				}
				$(".video-blog-container").html(this.videoBlogLayout({
					"list" : list
				}));
			}
		},

		getParsedVideoBlogList: function (list) {
			var parsedList = [];
			list.forEach(function (item) {
				if (item.content.indexOf("iframe") > -1) {
					var videoUrl = item.content.split("iframe src=")[1].split(" ")[0];
					var length = videoUrl.length;
					videoUrl = videoUrl.substring(1, length - 1);
					item.videoUrl = videoUrl;
				} else {
					if (item.content.indexOf("[embed]") > -1) {
						var videoUrl = item.content.split("[embed]")[1].split("[/embed]")[0];
						item.videoUrl = videoUrl;
					}
				}
				if (item.title.indexOf(":") > -1 || item.title.indexOf("]") > -1) item.title = item.title.split(": ")[1] || item.title.split("] ")[1];
				if (item.videoUrl.indexOf("watch") > -1) item.videoUrl = item.videoUrl.replace("watch?v=", "embed/");
				parsedList.push(item);
			});
			return parsedList;
		},

		getParsedQuotesList: function (list) {
			var parsedList = [];
			list.forEach(function (item) {
				if (item.title.indexOf(":") > -1) item.title = item.title.split(": ")[1];
				parsedList.push(item);
			});
			return parsedList;
		},

		getParsedDiscussionsList: function (list) {
			var self = this;
			var parsedList = [];
			list.forEach(function (item) {
				var id = item.category_id;
				self.forumCategoriesMap.every(function (category, index) {
					if (id == category.id) {
						item.category = category.name;
						return false;
					}
					return true;
				});
				item.url  = blogOrigin + "/forum/t/" + item.slug + "/" + item.topic_id;
				parsedList.push(item);
			});
			return parsedList;
		},

		loadFeed: function () {
			$(".feed-container").append(this.feedLayout({"page": "" + this.currentFeedPage}));
			if (this.ebooks) this.renderEbooks();
			if (this.articles) this.renderArticles();
			if (this.packages) this.renderPackage();
			if (this.discussions) this.renderDiscussions();
			if (this.quotes) this.renderQuotes();
			if (this.tests) this.renderTest();
			if (this.videoBlogs) this.renderVideoBlogs();
			if (this.currentFeedPage == 1) this.renderQuestion(1);
			if (this.currentFeedPage == 2) this.renderQuestion(2);
			setTimeout(function () {
				addthis.toolbox(".addthis_toolbox");
			}, 1000);
			var feedPage = this.currentFeedPage + 1;
			var self = this;
			if (feedPage % 2 == 0) {
				this.sendRequest(blogUrl.split("?")[0] + "?page=" + (feedPage / 2 + 1), 'jsonp')
				.then(function (res) {
					var articles = [];
					res.posts.forEach(function (item) {
						var isQuote = false;
						item.categories.every(function (category, index) {
							if (category.slug == 'quotes') {
								isQuote = true;
								return false;
							}
							return true;
						});
						if (!isQuote) articles.push(item);
					});
					self.articles = self.articles.concat(articles);
				});
			}
			if (feedPage % 6 == 0) {
				this.sendRequest(relatedArticlesBlogUrl + "video&page=" + (feedPage / 6 + 1), "jsonp")
				.then(function (res) {
					self.videoBlogs = self.videoBlogs.concat(res.posts);
				});
				this.sendRequest(relatedArticlesBlogUrl + "quotes&page=" + (feedPage / 6 + 1), "jsonp")
				.then(function (res) {
					self.quotes = self.quotes.concat(res.posts);
				});
			}
		},

		fetchFeed: function () {
			var self = this;
			self.currentFeedPage = 0;
			self.questionIndex = localStorage.getItem('questionIndex') || 0;
			self.userInteraction = JSON.parse(localStorage.getItem('userInteraction')) || {'feeling': {}, 'card1': {}, 'card2': {}};
			self.expertsView.render();
			self.updateOnlineStatusPromise = setInterval(function () {
				self.expertsView.updateOnlineStatus();
			}, 60 * 1000);
			var ebooksPromise = this.sendRequest(blogOrigin + "/scripts/json/ebooksOnHomePage.json");
			//var ebooksPromise = this.sendRequest("http://local.yourdost.com:9001/scripts/json/ebooksOnHomePage.json");
			var articlesPromise = this.sendRequest(blogUrl, 'jsonp');
			var packagesPromise = this.sendRequest(Utils.contextPath() + "/packages");
			self.userObject = JSON.parse(localStorage.getItem("user"));
			var unreadMsgPromise = this.sendRequest(Utils.contextPath() + '/v1/users/'+self.userObject.id+'/messages/count?type=unread');
			var discussionsPromise = this.sendRequest(blogOrigin + "/forum/user_actions.json?username=" + self.userObject.username + "&filter=1,4,5");
			var selfTestPromise = this.sendRequest(blogOrigin + "/scripts/json/selfHelp/selfHelp.json");
			//var selfTestPromise = this.sendRequest("http://local.yourdost.com:9001/scripts/json/selfHelp/selfHelp.json");
			var videoBlogsPromise = this.sendRequest(relatedArticlesBlogUrl + "video", "jsonp");
			var quotesPromise = this.sendRequest(relatedArticlesBlogUrl + "quotes", "jsonp");
			self.renderFeeling();
			ebooksPromise.then(function (res) {
				self.ebooks = [];
				var keys = Object.keys(res);
				keys.forEach(function (index) {
					var hash = res[index];
					hash.id = index;
					self.ebooks.push(hash);
				});
				self.ebooks = self.ebooks.slice(0,3);
				self.renderEbooks();
			});
			articlesPromise.then(function (res) {
				self.articles = [];
				res.posts.forEach(function (item) {
					var isQuote = false;
					item.categories.every(function (category, index) {
						if (category.slug == 'quotes') {
							isQuote = true;
							return false;
						}
						return true;
					});
					if (!isQuote) self.articles.push(item);
				});
				self.renderArticles();
			});
			packagesPromise.then(function (res) {
				self.packages = res;
				self.renderPackage();
			});
			unreadMsgPromise.then(function (res) {
				self.unreadMsgCount = res.count;
				self.renderUnreadMsg();
			});
			Utils.fetchForumCategories()
			.then(function (res) {
				self.forumCategoriesMap = res;
				discussionsPromise.then(function (res) {
					self.discussions = res.user_actions;
					self.renderDiscussions();
				});
			}, function (err) {
				// body...
			});
			quotesPromise.then(function (res) {
				self.quotes = res.posts;
				self.renderQuotes();
			});
			selfTestPromise.then(function (res) {
				self.tests = res;
				self.renderTest();
			});
			videoBlogsPromise.then(function (res) {
				self.videoBlogs = res.posts;
				self.renderVideoBlogs();
			});
		}

	});

	userDashboard.prototype.remove = function() {
		clearInterval(this.updateOnlineStatusPromise);
		$(document).off("scroll", self.newScrollHandler);
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	userDashboard.prototype.clean = function() {

		this.remove() ;
	};

	return userDashboard;
});
