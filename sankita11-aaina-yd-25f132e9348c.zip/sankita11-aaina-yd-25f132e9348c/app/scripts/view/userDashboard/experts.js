define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'

] , function( $, _, Backbone, Utils, JST, Dispatcher) {

	var ExpertsView = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		events : {
			"click .chat": "redirectToChat",
			"click #chat": "redirectToDemoChat",
			"click .chat-cta": "redirectToDemoChat",
			"click .message": "openCompose",
			"click .call": "bookAppointment",
			"click .details-container": "openExpertProfile",
			"click .all-experts": "showAllExperts"
		},

		layout : JST['app/templates/userDashboard/experts.hbs'],

		renderList: function (expertsList, status, options) {
				var self = this;
				var expertsCount = expertsList.length;
				var list = [];
				if (expertsCount) {
					for (var i=0; i<expertsCount; i++) {
						var details = expertsList[i];
						var statusDetails = status[details.id];
						if (statusDetails && statusDetails.status == "true") {
							details.isOnline = true;
							details.chatUrl = statusDetails.url;
							self.expertAvailable = true;
						}
						list.push(details);
					}
					if (!self.expertAvailable) {
						var counselorPromise = Utils.fetchCounselorList()
						.then(function (counselors) {
							list.push({
								expertNotAvailable: true,
								expertList: counselors.slice(3,7)
							});
							if (options && options.page) {
								self.page = options.page
								$(".experts-container." + options.page).html(self.layout({
									experts: true,
									list: list,
									page: options.page
								}));
								if (!Utils.isMobileDevice()) {
									self["mySwiper" + options.page] = new Swiper ('.expert-swiper' + options.page, {
						   				keyboardControl: true,
						   				slidesPerView: 'auto',
						   				nextButton: '.nav-next' + options.page,
				        				prevButton: '.nav-prev' + options.page,
				        				mousewheelControl: true
									});	
								}
								return;
							}
							$(".experts-container").html(self.layout({
								experts: true,
								list: list
							}));
							if (!Utils.isMobileDevice()) {
								self.mySwiper = new Swiper (".expert-swiper", {
						   			keyboardControl: true,
						   			slidesPerView: 'auto',
						   			nextButton: ".nav-next",
				        			prevButton: ".nav-prev",
				        			mousewheelControl: true
								});
							}
						});
						self.sendRequest(Utils.contextPath() + '/v1/dashboard/ongoingCnt')
						.then(function (count) {
							if (options && options.page) {
								self.page = options.page;
								$(".experts-container." + options.page + " .count").html(" " + eval(count + 20) + " people are currently speaking to experts");
								//$(".experts-container." + options.page + " .dot").css("visibility", "visible");
								return;
							}
							//$(".experts-container .dot").css("visibility", "visible");
							$(".experts-container .count").html(" " + eval(count + 20) + " people are currently speaking to experts");
						});
						return;
					}
					if (options && options.page) {
						self.page = options.page;
						$(".experts-container." + options.page).html(self.layout({
							experts: true,
							list: list,
							page: options.page
						}));
						if (!Utils.isMobileDevice()) {
							self["mySwiper" + options.page] = new Swiper ('.expert-swiper' + options.page, {
				   				keyboardControl: true,
				   				slidesPerView: 'auto',
				   				nextButton: '.nav-next' + options.page,
								prevButton: '.nav-prev' + options.page,
								mousewheelControl: true
							});
						}
						return;
					}
					$(".experts-container").html(self.layout({
						experts: true,
						list: list
					}));
					if (!Utils.isMobileDevice()) {
						self.mySwiper = new Swiper (".expert-swiper", {
						   	keyboardControl: true,
						   	slidesPerView: 'auto',
						   	nextButton: ".nav-next",
				        	prevButton: ".nav-prev",
				        	mousewheelControl: true
						});
					}
					return;	
				}
				self.renderNoExperts(options);			
		},

		updateOnlineStatus: function () {
			var self = this;
			this.sendRequest(Utils.contextPath() + "/v1/counselor/status")
			.then(function (status) {
				self.status = status;
			});
		},

		render : function(options){
			var self = this;
			self.expertAvailable = false;
			self.userObject = JSON.parse(localStorage.getItem("user"));
			if (self.expertsList) {
				self.renderList(self.expertsList, self.status, options);
				return;
			}
			var familiarExpertsPromise = self.sendRequest(Utils.contextPath()+'/v1/counselor?user='+self.userObject.id + '&familiar=true');
			var statusPromise = self.sendRequest(Utils.contextPath() + "/v1/counselor/status");
			$.when(familiarExpertsPromise, statusPromise)
			.then(function (expertsList, status) {
				self.expertsList = expertsList;
				self.status = status;
				self.renderList(self.expertsList, self.status, options);
			}, function (err) {
				self.renderNoExperts();
			});
		},

		registerMixpanelEvents : function(attributes){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				attributes.version = "2.0";
				mixpanel.track("Dashboard", attributes);
			}
		},

		redirectToDemoChat: function () {
			this.registerMixpanelEvents({
				"action_type": "chat_now",
				"scroll": this.page
			});
			window.open(blogOrigin + "/chatSession/?workgroup=" + chatDemoWorkgroup + "&noUI=true&username=" + this.userObject.username);
		},

		showAllExperts: function () {
			Backbone.history.navigate('/talkItOut?from=showAllExperts', {"trigger":true});
			return;
		},

		renderNoExperts: function (options) {
			var self = this;
			Utils.fetchCounselorList()
			.then(function (res) {
				var list = res.slice(2,5);
				list[1].middle = true;
				if (options && options.page) {
					$(".experts-container." + options.page).html(self.layout({
						experts: false,
						list: list
					}));
					return;
				}
				$(".experts-container").html(self.layout({
					experts: false,
					list: list
				}));
			});
			self.sendRequest(Utils.contextPath() + '/v1/dashboard/ongoingCnt')
			.then(function (count) {
				if (options && options.page) {
					self.page = options.page;
					$(".experts-container." + options.page + " .count").html(eval(count + 20) + " people are currently speaking to experts");
					//$(".experts-container." + options.page + " .dot").css("visibility", "visible");
					return;
				}
				$(".experts-container .count").html(eval(count + 20) + " people are currently speaking to experts");
				//$(".experts-container .dot").css("visibility", "visible");
			});
		},

		sendRequest: function (url) {
			var deferred = $.Deferred();
			$.ajax({
				method : "GET",
				url : url
			})
			.done(function (response) {
				deferred.resolve(response);
			})
			.fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},

		redirectToChat: function (evt) {
			var chatUrl = evt.currentTarget.getAttribute("data-url");
			var expertName = evt.currentTarget.getAttribute("data-name");
			this.registerMixpanelEvents({
				"action_type": "chat_myexpert",
				"scroll": this.page,
				"action_data": {
					"expert_name": expertName 
				}
			});
			window.location.href = chatUrl;
		},

		openCompose: function (evt) {
			var expertId = evt.currentTarget.getAttribute("data-id");
			var expertName = evt.currentTarget.getAttribute("data-name");
			this.registerMixpanelEvents({
				"action_type": "msg_myexpert",
				"scroll": this.page,
				"action_data": {
					"expert_name": expertName 
				}
			});
			Dispatcher.trigger("openComposeMessage", {
				info: {
					recipientId: expertId
				}
			});
		},

		bookAppointment: function (evt) {
			var expertId = evt.currentTarget.getAttribute("data-conId");
			var expertName = evt.currentTarget.getAttribute("data-name");
			this.registerMixpanelEvents({
				"action_type": "appointment_myexpert",
				"scroll": this.page,
				"action_data": {
					"expert_name": expertName 
				}
			});
			Backbone.history.navigate('/bookAppointment?from=talkItOut&conID=' + expertId + '&catID=Others', {"trigger":true});
			return;
		},

		openExpertProfile: function (evt) {
			var expertId = evt.currentTarget.getAttribute("data-id");
			var expertName = evt.currentTarget.getAttribute("data-name");
			this.registerMixpanelEvents({
				"action_type": "profile_myexpert",
				"scroll": this.page,
				"action_data": {
					"expert_name": expertName 
				}
			});
			Backbone.history.navigate("/counselor/" + expertId, {"trigger":true});
			return;
		}
		
	});

	ExpertsView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	ExpertsView.prototype.clean = function() {

		this.remove() ;
	};

	return ExpertsView;
});
