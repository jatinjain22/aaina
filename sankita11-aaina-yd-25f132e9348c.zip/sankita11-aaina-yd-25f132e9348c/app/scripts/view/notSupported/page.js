define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'keystop'
], function( $, _, Backbone, JST, Utils ) {
	
	var NotSupportedPage = Backbone.View.extend({

		el: "main",
		initialize: function() {

			
		},
		events: {
			
			'click .continue-text' : 'continueHere'
		},
		
		NotSuopportedView:JST['app/templates/notSupported/layout.hbs'],

		continueHere : function(e){

			e.preventDefault();
			e.stopPropagation();

			var url = $(e.currentTarget).attr("href");
			sessionStorage.setItem("insideChrome", "true");
			location.href = url;
		},
		render: function(url) {	
			
			var self = this ;
			var redirectUrl = url;
			this.$el.html(this.NotSuopportedView({url:redirectUrl}));
			//sessionStorage.setItem("insideChrome", "true");
		}
	});

	NotSupportedPage.prototype.remove = function() {
		
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	NotSupportedPage.prototype.clean = function() {
		
		this.remove();
	};

	return NotSupportedPage;
});