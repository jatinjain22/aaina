define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel',
	'model/users',
	'ajax-chosen'
], function($,_, Backbone, JST,Utils, EventBus, UserMsgModel, UserModel ) {

	var MessagePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.model = new UserMsgModel();
			this.userModel = new UserModel() ;

			this.selectedCategories = {} ;
			this.selectedUsers = {} ;

			this.timeoutId = -1;
			this.threadID = 0;
			this.messageID = 0;
			this.attachmentIds = [];
			this.selectedCounselorObj = {};
			var _originalSize = $(window).width() + $(window).height();
			if (Utils.isMobileDevice()) {
				$(window).resize(function(){
					if($(window).width() + $(window).height() != _originalSize){
						console.log("keyboard show up");
						if($(".input-field #message").is(":focus")) {
							$("#send-category").hide();
							$("#subject").hide();
						}
					} else {
						$("#send-category").show();
						$("#subject").show();
					}
				});
			}
		},
		BlogThumbailLayout: JST["app/templates/home2/blog_thumbnails.hbs"],
		events: {

			"click #compose-send-btn": "composeMsg",
			"click #compose .mclose" : "hideCompose" ,
			"click .change-sender": "changeSender",
			"click .back-change-sender": "backChangeSender",
			"click #message-counselor-modal .popup-close"  : "hideContainer" ,
			"click #message-counselor-modal .mclose"  : "hideContainer",
			"click #book-appointment-modal .mclose"  : "hideContainer",
			"click .article-link" : "ThumbnailClick",
			"keyup #subject": "isSubject",
			"keyup #searchCounselorList": "isSendTo",
            "keyup #searchCounselorList": "isSendToInMobile",
            "keyup #message ": "isMessage",
            "change #send-category": "isCategory",
            "keyup #send-category": "isCategoryInMobile",
			"click .confirm-save-draft-modal-dont-save": "discardDraft",
            "click .confirm-save-draft-modal-save": "saveDraft",
            "change #message-file-attachment" : "uploadFileInMessage",
            "click .remove-attached-file" : "uploadNewFile",
            "focus .input-field #message" : "hideOtherFields",
            "blur .input-field #message"  : "showAllFields"
		},
		discardDraft: function(e) {

			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();
			Utils.discardDraft( this.userModel.getUserID(), this.messageID );
			$("#compose").remove();
		},
		saveDraft: function(e) {

			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();
			//this.autoSaveMessage("saveDraft");
			$("#compose").remove();
		},
        hideOtherFields : function() {
        	if (Utils.isMobileDevice()) {
        		$("#send-category").hide();
        		$("#subject").hide();
        	}
        },
        showAllFields : function() {
        	if (Utils.isMobileDevice()) {
        		$("#send-category").show();
        		$("#subject").show();
        	}
        },
		hideCompose : function(){

			Utils.closePopup('compose') ;
			$("#compose").remove();
			Utils.closePopup('message-counselor-modal');
			$("#message-counselor-modal").remove();

			//Utils.openPopup( "confirm-save-draft" );
			$("div#lean-overlay:last").css({'display':'block', 'opacity':'0.5'});

		},
		hideContainer: function(){
			Utils.closePopup('message-counselor-modal') ;
			$("#message-counselor-modal").remove();
		},
		uploadNewFile : function(e){

			$(".file-name-attached-message").addClass("hide");
			$(".file-attachment-message-send").removeClass("hide");
		},
		uploadFileInMessage : function(e){

			var file = e.target.files[0];
			var data = new FormData();
			var self =  this;

			$(".message-upload-error").addClass("hide")
			if(file.type == "application/x-ms-dos-executable"){

				$(".message-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			$(".file-name-attached-message").removeClass("hide");
			$(".file-attachment-message-send").addClass("hide");
			$(".file-name-attached").html("Uploading ...");

			data.append('file', $('#message-file-attachment').get(0).files[0] );
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){

				console.log("Response: "+response)
				$(".file-name-attached-message").removeClass("hide");
				$(".file-attachment-message-send").addClass("hide");
				$(".file-name-attached").html(file.name);

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	        	    mixpanel.track('File Attached', {'mediumSource' : 'website', 'itemName': 'File Attached in Leave Message'});

	        	}
				self.attachmentIds.push(response.fileID);

			}).error(function(error){

				$(".file-name-attached-message").addClass("hide");
				$(".file-attachment-message-send").removeClass("hide");
				$(".message-upload-error").removeClass("hide").html("Upload Error");
				console.log("Error: "+error);
			})
		},
		isCategory: function() {

			console.log('hello');
			if ( $(".category-field").hasClass("error") ) {
				$(".isend-category").hide();
				$(".category-field").removeClass("error");
			}
		},
		isSubject: function() {
			console.log("hello");
			if ( $(".isubject").parent().hasClass('error') ) {

				$(".isubject").hide();
				$(".isubject").parent().removeClass('error');
			}

		},
		isSendTo: function() {

			var sendTo = $("#searchCounselorList").val();

			if (sendTo == null || sendTo == "") {

			}else{

				$(".isend-to").hide();
				$(".isend-to").parent().removeClass('error');
			}

			var sendTo = $("#send-to").val();

				if (sendTo != null) {
					var sendToLength = sendTo.length;
				}

			if ( sendToLength === 1 ) {
				if( $(".isend-to").parent().hasClass('error') ) {

					$(".isend-to").hide();
					$(".isend-to").parent().removeClass('error');
				}
			}
		},
		isSendToInMobile: function() {

			var sendTo = $("#searchCounselorList").val();

			if (sendTo == null || sendTo == "") {

			}else{

				$(".isend-to").hide();
				$(".isend-to").parent().removeClass('error');
			}

			if (Utils.isMobileDevice) {

				var sendTo = $("#send-to").val();

				if (sendTo != null) {
					var sendToLength = sendTo.length;
				}

				if ( sendToLength === 1 ) {
					if( $(".isend-to").parent().hasClass('error') ) {

						$(".isend-to").hide();
						$(".isend-to").parent().removeClass('error');
					}
				}
			}
		},
		autoSaveMessage: function(msg) {

			console.log( 'Autosave!' );
            if(window.pendingDraftsaveRequest)
                return;
        	$(".email-draft-bar").removeClass( "hide" );
	        $( ".email-draft-saving-msg" ).removeClass( "hide" );
	        $( ".email-draft-saved-msg" ).addClass("hide");


			var subject = $("#subject").val() || null;

			var sendTo = $(".user-friend").hasClass("hide") ? $("#send-to").val() : null;
			var sendCategory = $("#send-category").val();

			var self = this ;
			var categoryArr = sendCategory ;
			if(Utils.isMobileDevice()){
				categoryArr = new Array() ;
				var categorySelected = sendCategory.split(",");
				_.each(categorySelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					categoryArr.push(self.selectedCategories[elem.trim()]) ;
				});
			}


			var userArr = sendTo ;
			if(Utils.isMobileDevice() && userArr != null){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){

				if ( CKEDITOR.instances.message == undefined ) {
					var body = encodeURI(CKEDITOR.instances.reply_message.getData()) || null;
					self.threadID = $("#single-msg-block").attr("data-msgid");

				} else {
					var body = encodeURI(CKEDITOR.instances.message.getData()) || null;

				}


			}else{
				var body = encodeURI($("#message").val().trim()) || null;
				if ( $("#single-msg-block").attr("data-msgid") ) {
					self.threadID = $("#single-msg-block").attr("data-msgid");
				}
			}
			console.log( "subject", subject );
			console.log( "userArr", userArr );
			console.log( "categoryArr", categoryArr );
			console.log( "body", body );

			var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"categoryIds":categoryArr,
					"recipients":userArr,
					"status":"DRAFT"

			};


			msgJSON["threadID"] = self.threadID;
			console.log( "threadID", self.threadID );


			console.log( "msgJSON", msgJSON );
            window.pendingDraftsaveRequest = true;
			$.ajax({
        		method: "POST",
        		url: Utils.contextPath()+'/v1/users/'+this.userModel.getUserID()+'/messages',
        		data: JSON.stringify(msgJSON),
       			contentType: "application/json"
      		}).done(function(response){
                window.pendingDraftsaveRequest = false;
      			console.log( response );
      			self.threadID = response.conversationDetail.threadID;
      			var userMessages = response.conversationDetail.userMessage;
      			var lastMsg = userMessages[userMessages.length - 1];
      			self.messageID = lastMsg.msgID;
      			console.log( "autoSaveMessage messageID", self.messageID );
      			// messageID = 13340;
	        	if (msg == "saveDraft") {
      				Utils.displaySuccessMsg("Your draft has been saved");
      			}
	        	$( ".email-draft-saving-msg" ).addClass( "hide" );
	        	$( ".email-draft-saved-msg" ).removeClass("hide");

	        	return true;
			}).error(function(error){
                window.pendingDraftsaveRequest = false;
				console.log(error);
			});
		},
		isMessage: function(e) {

			//console.log("hello");
			//console.log(e.currentTarget);
			var self = this;

			clearTimeout(self.timeoutId);
    		self.timeoutId = setTimeout(function() {
        		// Runs 1 second (1000 ms) after the last change
        		//self.autoSaveMessage();

    		}, 500);


			console.log("one who knocks");

			if ( $(".imessage").parent().hasClass('error') ) {
				$(".imessage").hide();
				$(".imessageCnt").hide();
				$(".imessage").parent().removeClass('error');


			}
		},
		// isMessage: function(e) {

		// 	console.log("hello");
		// 	//console.log(e.currentTarget);
		// 	var body = $("#message").val().trim();
		// 	if ( $(".imessage").parent().hasClass('error') ) {

		// 		$(".imessage").hide();
		// 		$(".imessageCnt").hide();
		// 		$(".imessage").parent().removeClass('error');
		// 		// if (body.trim().length < 100) {
		// 		// 	$(".imessage").hide();
		// 		// 	$(".imessage").parent().removeClass('error');
		// 		// }
		// 		// else {
		// 		// 	$(".imessageCnt").hide();
		// 		// 	$(".imessage").parent().removeClass('error');
		// 		// }
		// 	}
		// },
		isCategoryInMobile: function(e) {

			if (Utils.isMobileDevice) {

					if ( $(".category-field").hasClass("error") ) {
						$(".isend-category").hide();
						$(".category-field").removeClass("error");
				}

			}
		},
		backChangeSender: function(e){

			var self = this;
			$(e.currentTarget).parent().addClass("hide");
			self.$el.find("#send-to").addClass("hide");
			self.$el.find(".user-friend").removeClass("hide");
			self.$el.find("#send_to_chosen").hide();
		},
		changeSender: function(e){

			var self = this;
			var userType = this.userModel.getUserType() ;

			$(e.currentTarget).parent().addClass("hide");
			self.$el.find("#send-to").removeClass("hide");
			if(userType == 'VICTIM'){
				self.$el.find(".default-user-friend").removeClass("hide");
			}

			if(self.$el.find("#send_to_chosen")){
				if( self.$el.find("#send_to_chosen").length > 0 ){
					self.$el.find("#send_to_chosen").show();
					return true;
				}
			}

			var searchType = '/v1/counselor/search' ;
			if( userType != 'VICTIM'){
				searchType = '/v2/users/list' ;
			}

			if(Utils.isMobileDevice()){

					$( "#send-to" )
				      // don't navigate away from the field on tab when selecting an item
				      .bind( "keydown", function( event ) {
				        if ( event.keyCode === $.ui.keyCode.TAB &&
				            $( this ).autocomplete( "instance" ).menu.active ) {
				          event.preventDefault();
				        }
			      })
			      .autocomplete({
			        source: function( request, response ) {

			        	$.ajax({
						method: 'GET',
						url: Utils.contextPath()+ searchType + '?name=' + Utils.JUIextractLast( request.term ),
						}).done(function (data) {
							var usersArr = new Array() ;
							console.log(data);
							$.each(data, function (i, val) {
							usersArr.push({
								"key" : val,
								"value" : i
							});
							});
							response( usersArr );
						});


			        },
			        search: function() {
			          // custom minLength
			          var term = Utils.JUIextractLast( this.value );
			          if ( term.length < 2 ) {
			            return false;
			          }
			        },
			        focus: function() {
			          // prevent value inserted on focus
			          return false;
			        },
			        select: function( event, ui ) {

			          self.selectedUsers[ui.item.value] = ui.item.key ;
			          var terms = Utils.JUIsplit( this.value );
			          // remove the current input
			          terms.pop();
			          // add the selected item
			          terms.push( ui.item.value );
			          // add placeholder to get the comma-and-space at the end
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
			        }
			      });



			}else{

				if(userType != 'VICTIM'){

					self.$el.find("#send-to").ajaxChosen({
						type: 'GET',
						url: Utils.contextPath()+ searchType,
						dataType: 'json',
						jsonTermKey:"name",
						minTermLength:1
					}, function (data) {

						var terms = {};
						$.each(data, function (i, val) {
							terms[val] = i;
						});
						return terms;
					});
				}else{

					EventBus.trigger("renderCounselorDropDown", "counselor_dropdownlist_search")
				}
			}

		},
		composeMsg: function(e){

			var isError = false;
			var userType = this.userModel.getUserType() ;
			var sendTo = [];
			var sendToval = "";
			if(userType == 'VICTIM'){

				sendToval = $(".user-friend").hasClass("hide") ? $("#searchCounselorList").val() : null;
				if(sendToval == "" || sendToval == null){

					sendTo = []
				}else{

					sendTo.push($("#searchCounselorList").attr("data-cId"))
				}
			}
			if(userType != 'VICTIM'){

				sendTo = $("#send-to").val() ;
			}



			var sendCategory = $("#send-category").val();
			var subject = $("#subject").val();
			if( !Utils.isMobileDevice() ){
				var body = encodeURI(CKEDITOR.instances.message.getData());
			}else{
				var body = encodeURI($("#message").val().trim());
			}

			var self = this ;
			var categoryArr = sendCategory ;
			if(Utils.isMobileDevice() && userType == 'VICTIM' ){
				categoryArr = new Array() ;
				var categorySelected = sendCategory.split(",");
				_.each(categorySelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					categoryArr.push(self.selectedCategories[elem.trim()]) ;
				});
			}


			var userArr = sendTo ;
			// if(Utils.isMobileDevice() && userArr != null){
			// 	userArr = new Array() ;
			// 	var usersSelected = sendTo.split(",");
			// 	_.each(usersSelected, function(elem){
			// 		if(!elem.trim()){
			// 			return false ;
			// 		}
			// 		userArr.push(self.selectedUsers[elem.trim()]) ;
			// 	});
			// }

			if(userType != 'VICTIM'){
				if( userArr == null || userArr.length < 1 ){
					$(".isend-to").show().parent().addClass("error");
					isError = true;
				}
			}else{


				if( $(".user-friend").hasClass("hide") ){

					if( userArr == null || userArr.length < 1 ){

						$(".isend-to").show().parent().addClass("error");
						isError = true;
					}

				}
				if( $(".user-friend").hasClass("hide") ){

					if( sendTo != null && userArr.length > 1 ){

						$(".counselor-count-error.isend-to").show().parent().addClass("error");
						$(".counselor-count-error.isend-to").removeClass("hide");
						isError = true;
					}
				}
			}

			if(userType == 'VICTIM'){
				if( sendCategory == null || categoryArr.length < 1 ){
					$(".isend-category").show();
					$(".category-field").addClass("error");
					isError = true;
				}
			}

			if( subject == "" ){
				$(".isubject").show().parent().addClass("error");
				isError = true;
			}

			if( body.trim() == "" ){
				$(".imessage").show().parent().addClass("error");
				isError = true;
			}else if(body.trim().length < 100 && userType == 'VICTIM'){
				$(".imessageCnt").show().parent().addClass("error");
				isError = true;
			}

			if( !isError ){

				if(self.attachmentIds.length == 0){

					self.attachmentIds = [-1];
				}

				var msgJSON = {
					"threadID":0,
					"subject":subject,
					"content":body,
					"attachmentIDs" : self.attachmentIds
				};

				if(Utils.isMobileDevice()){
					body = body.trim() ;
					body = body.replace(/%0A/g, '<br />');
				}
				if( userType != 'VICTIM' ){

					var msgJSON = {
						"threadID":self.threadID,
						"subject":subject,
						"content":body,
						"recipients":userArr
					};

				}else if( sendTo == null ){

					var msgJSON = {
						"threadID":self.threadID,
						"subject":subject,
						"content":body,
						"categoryIds":categoryArr
					};

				}else{

					var msgJSON = {
						"threadID":self.threadID,
						"subject":subject,
						"content":body,
						"recipients":userArr,
						"categoryIds":categoryArr
					};

				}

				if(Utils.isMobileDevice()){

					$(".compose-overlay-div").removeClass("hide");
				}else{

					$("#compose-send-btn").addClass("disabled").html("Sending...");
				}
		          var key = "sendmessage";
		          if( !Array.isArray( window.sendMessageToCounselor ) ){
		            window.sendMessageToCounselor = [];
		          }

		          if( window.sendMessageToCounselor[key] === true ){
		            return;
		          }

		          window.sendMessageToCounselor[key] = true;
		          setTimeout(function(){
		            delete window.sendMessageToCounselor[key];
		          }, 500);

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json",
	              statusCode : {
              		417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						$(".iauthentication-error").html(errorMessage);
						$(".iauthentication-error").show() ;

					},
              		500 : function(){
						$(".iauthentication-error").html("Something went wrong. Please try again");
						$(".iauthentication-error").show() ;
					},

	              }
	          	}).done(function(response){

	          		if(!Utils.isMobileDevice()){

	          			$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          		}else{

	          			$(".compose-overlay-div").addClass("hide");
	          			$("#compose-send-btn").removeClass("disabled").html('<i class="mdi-content-send right"></i>');
	          		}

	          		Utils.closePopup('compose') ;
	          		$("#compose").remove();
	          		//show modal
	          		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

			            mixpanel.track('Button Click', {'mediumSource' : 'website', 'itemName': 'MESSAGE NEW', 'itemtype': 'MESSAGE'});

			        }
	          		self.$el.find("#message-counselor-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg" style="padding:5%;display:flex;justify-content:center;align-items:center;"><span class="icon-done"><i class="mdi mdi-check"></i></span>Your message has been sent. You shall hear from us soon.</p><p style="padding:0% 5%">In the meanwhile, take a look at some of our trending content:</p><div class="trending_articals"><div class="row"><div class="col article-scroll-left"><i class="mdi-hardware-keyboard-arrow-left"></i></div><div class="col article-jcarousel"> <img class="popup-loader hide" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50"><ul class="articals_div"></ul></div><div class="col article-scroll-right"><i class="mdi-hardware-keyboard-arrow-right"></i></div></div>') ;

					var ArtcalsHtml = '';
					//self.$el.find(".articals_div").html('<img class="popup-loader" src="http://res.cloudinary.com/http-yourdost-com/image/upload/v1449585815/icons/loader.gif" width="50" height="50">');
					$('.article-jcarousel .popup-loader').removeClass('hide');
					$.ajax({
						method : "GET",
						url : Utils.blogJson(),
						dataType: 'jsonp' // //"http://local.yourdost.com:9001/scripts/json/sample_blog.json" //
					}).done(function(response){
						$('.article-jcarousel .popup-loader').addClass('hide');
						console.log("blog response " + response.posts);
						self.$el.find(".articals_div").html(self.BlogThumbailLayout({ post : response.posts }));
						$('.trending_articals .article-jcarousel').jCarouselLite({
						  btnNext: '.article-scroll-right',
						  btnPrev: '.article-scroll-left',
						});
					}).error(function(error){
						console.log(error);
					});

					self.$el.find("#message-counselor-modal .fixed-position-container").html( '<p class="modal-thank-msg" style="padding:55% 12%">Your message has been sent. You shall hear from us soon.</p>') ;
					Utils.openPopup( "message-counselor-modal" ) ;
					$("#message-counselor-modal.modal").css("max-height", "600px");
					//end modal
					$(".compose-overlay-div").removeClass("hide");
					return true;
	          	}).fail(function(error){
	          		console.log(error);
	          		if(!Utils.isMobileDevice()){

	          			$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          		}else{

	          			$(".compose-overlay-div").addClass("hide");
	          			$("#compose-send-btn").removeClass("disabled").html('<i class="mdi-content-send right"></i>');
	          		}
	          	});
			}else{
				return false;
			}
		},
		ThumbnailClick : function(e){
			e.preventDefault();
			e.stopPropagation();
			var url = "";
			if($(e.target).parents().hasClass("article-author")){
				url = $(e.target).parents(".article-author").find("a").attr("href");
			}else{
			 	url = $(e.currentTarget).attr("data-href");
			}
			window.open(url, "_blank");
		},
		ComposePageLayout : JST['app/templates/messages/compose.hbs'],
		ConfirmSaveDraftLayout: JST['app/templates/messages/confirmSaveDraft.hbs'],

		render: function( counselorInfo ) {

			var self = this;

			var userType = this.userModel.getUserType() ;
			$("#compose").remove();
			self.$el.append(self.ComposePageLayout({isMobileDevice:Utils.isMobileDevice(), userType : userType } ));
			self.$el.append( self.ConfirmSaveDraftLayout() );

			var categories = localStorage.getItem("categories");

	        if( !categories || categories== null ){

            	var category = {};
            	var categories = {};
            	$.ajax({
                	method: "GET",
                	url: Utils.contextPath()+'/category?include_faq=false'
            	}).done(function(response){
            		var category = {} ;
              		_.each(response,function(cat){
                		category[cat.id] = cat.name;
                		categories["c_" + cat.id] = cat.name;
              		});

              		localStorage.setItem("categories",JSON.stringify(category));
              		localStorage.setItem("c_categories",JSON.stringify(categories));
            	}).fail(function(error){});
          	}



			$("#send-to").addClass("hide");
			if(counselorInfo){

				if(typeof counselorInfo === 'object'){

					counselorInfo = counselorInfo;
				}else{

					counselorInfo = JSON.parse(counselorInfo);
				}

				if(Utils.isMobileDevice()){

					if(userType == "VICTIM"){

						/*var checkIfCounselorIsBlocked = checkIfCounselorIsBlocked || Utils.checkIfCounselorIsBlocked( counselorInfo.id);

						checkIfCounselorIsBlocked.then(function(blocked){

							if(blocked){

								$("#searchCounselorList").val("");
								$("#searchCounselorList").attr("");
								$("#searchCounselorList").focus()
							}else{*/

								self.selectedCounselorObj["id"] = counselorInfo.id;
								self.selectedCounselorObj["name"] = counselorInfo.name;
								$("#searchCounselorList").val(self.selectedCounselorObj.name);
								$("#searchCounselorList").attr("data-cId", counselorInfo.id)
						/*	}
						})*/

					}else{

						$("#send-to").removeClass("hide");
						$("#send-to").val(counselorInfo.name + ", ") ;
						self.selectedUsers[counselorInfo.name] = counselorInfo.id ;
						$(".change-sender").click() ;
					}
					// $("#send-to").removeClass("hide");
					// $("#send-to").val(counselorInfo.name + ", ") ;
					// self.selectedUsers[counselorInfo.name] = counselorInfo.id ;
					// $(".change-sender").click() ;

				}else{

					if(userType == "VICTIM"){

						/*var checkIfCounselorIsBlocked = checkIfCounselorIsBlocked || Utils.checkIfCounselorIsBlocked( counselorInfo.id);

						checkIfCounselorIsBlocked.then(function(blocked){

							if(blocked){

								$("#searchCounselorList").val("");
								$("#searchCounselorList").attr("");
								$("#searchCounselorList").focus()
							}else{*/

								self.selectedCounselorObj["id"] = counselorInfo.id;
								self.selectedCounselorObj["name"] = counselorInfo.name;
								$("#searchCounselorList").val(self.selectedCounselorObj.name);
								$("#searchCounselorList").attr("data-cId", counselorInfo.id)
							/*}
						})*/

					}else{

						$(".change-sender").click() ;
						$("#send-to").append("<option value='"+ counselorInfo.id +"'>" + counselorInfo.name + "</option>") ;
						$(".user-friend").addClass("hide") ;
						setTimeout( function(){
							$("#send-to").val(counselorInfo.id) ;
							$("#send-to").chosen({
								width: "100%"
							});
							$("#send-to").trigger("chosen:updated");
							$("#subject").focus();
						},100);

						$("#send-to").addClass("hide");
					}
				}

			}
			EventBus.trigger("renderCounselorDropDown", "counselor_dropdownlist_search")

			var user = JSON.parse( localStorage.getItem("user") );

			$(".msg-to-name").text("")// user.username );

			if(counselorInfo == undefined ){
				$(".user-friend").removeClass("hide");
			}

			if(userType != 'VICTIM'){
				$(".user-header").addClass("hide");
				$(".friend-header").removeClass("hide");
				$(".default-user-friend").addClass("hide");
			}else{
				$(".user-header").removeClass("hide");
				$(".friend-header").addClass("hide");
			}

			$('body').css({'overflow-y' : 'hidden'});

			Utils.openPopup("compose");

			if(userType == 'VICTIM'){


				$(".category-field").removeClass("hide");
				var category = localStorage.getItem("categories");
				if(Utils.isMobileDevice()){

					var categoriesArr = new Array() ;
					$.each(JSON.parse(category),function(key,value){
						categoriesArr.push({
							"key" : key ,
							"value" : value
						}) ;

						if( value.toLowerCase() == "others" ){
							//$("#send-category").val("Others, ") ;
							//self.selectedCategories[value] = key ;
						}

					});

					$( "#send-category" )
				      // don't navigate away from the field on tab when selecting an item
				      .bind( "keydown", function( event ) {
				        if ( event.keyCode === $.ui.keyCode.TAB &&
				            $( this ).autocomplete( "instance" ).menu.active ) {
				          event.preventDefault();
				        }
				      })
				      .bind('focus', function(){ $(this).autocomplete("search"); } )
				      .autocomplete({
				        minLength: 0,
				        source: function( request, response ) {
				          // delegate back to autocomplete, but extract the last term
				          	response( $.ui.autocomplete.filter(
				            categoriesArr, Utils.JUIextractLast( request.term ) ) );
				        },
				        focus: function() {
				          // prevent value inserted on focus
				          return false;
				        },
				        select: function( event, ui ) {
				        	self.selectedCategories[ui.item.value] = ui.item.key ;

				          var terms = Utils.JUIsplit( this.value );
				          // remove the current input
				          terms.pop();
				          // add the selected item
				          terms.push( ui.item.value );
				          // add placeholder to get the comma-and-space at the end
				          terms.push( "" );
				          this.value = terms.join( ", " );
				          return false;
				        }
				      });
				}else{

					$.each(JSON.parse(category),function(key,value){
	              	var option = "<option value='"+key+"'>"+value+"</option>";
		              $("#send-category").append( option );
		            });
					setTimeout( function(){
						$("#send-category").chosen({
							width: "100%"
						});
						$("#subject").focus();

						$(".composeForm .chosen-select").find(".select-dropdown").hide();
						$('.composeForm .chosen-select').find("i").hide();
					},100);
				}
			}

			if( !Utils.isMobileDevice() )
				CKEDITOR.replace( 'message' );

			CKEDITOR.on('instanceCreated', function(e) {
				var buffer = this.tools.eventsBuffer( 500, function() {
                	//self.autoSaveMessage();

            	} );
            	e.removeListener('change', buffer.input);
			    e.editor.on('change', buffer.input);
			  //   	function (event) {
			  //       // change event in CKEditor 4.x

			  //       buffer.input;
			  //       console.log( event );
			  //       console.log('hello2');
			  //       $(".email-draft-bar").removeClass( "hide" );
			  //       $( ".email-draft-saving-msg" ).removeClass( "hide" );
			  //       $( ".email-draft-saved-msg" ).addClass("hide");

			  //       var body = $("#message").val().trim();
			  //       console.log( $(".imessageCnt").is(':visible') );
			  //       if ( $(".imessageCnt").is(':visible') ) {
			  //       	console.log("pikachu");
			  //       	$(".imessage").hide();
					// 	$(".imessageCnt").hide();
					// 	$(".imessage").parent().removeClass('error');
			  //       }

					// if ( $(".imessage").parent().hasClass('error') ) {
					// 	$(".imessage").hide();
					// 	$(".imessageCnt").hide();
					// 	$(".imessage").parent().removeClass('error');

					// }

			  //   }

			    e.editor.on('change', function (event) {
			        // change event in CKEditor 4.x
			        //console.log('hello');
			        var body = $("#message").val().trim();
					if ( $(".imessage").parent().hasClass('error') ) {

						$(".imessage").hide();
						$(".imessageCnt").hide();
						$(".imessage").parent().removeClass('error');
					}
			    });
			});
			// CKEDITOR.on('instanceCreated', function(e) {



			//     e.editor.on('change', function (event) {
			//         // change event in CKEditor 4.x
			//         console.log( event );
			//         console.log('hello');
			//         $(".email-draft-bar").removeClass( "hide" );
			//         $( ".email-draft-saving-msg" ).removeClass( "hide" );
			//         $( ".email-draft-saved-msg" ).addClass("hide");

			//         var body = $("#message").val().trim();
			// 		if ( $(".imessage").parent().hasClass('error') ) {

			// 			$(".imessage").hide();
			// 			$(".imessageCnt").hide();
			// 			$(".imessage").parent().removeClass('error');
			// 		}

			//     });


			// });

		},
	});

	MessagePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();

	};

	MessagePage.prototype.clean = function() {
		this.remove();
	};

	return MessagePage;
});
