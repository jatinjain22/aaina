define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/ClientHistoryMsgModel',
	'view/leaveMessage/page' ,
	'view/clientHistory/upage',
	'model/users',
	'model/clientHistory'
], function($,_, Backbone, JST, Utils, EventBus, ClientHistoryMsgModel, LeaveMessageView,ClientHistoryUserPage, UserModel, ClientUserModel) {

	var ClientHistoryChatPage = Backbone.View.extend({
		el: "main",
		ClientHistoryUsersLayout : JST['app/templates/clientHistory/user_layout.hbs'],	
		ClientHistorySingleMsgLayout : JST['app/templates/clientHistory/single_msg_layout.hbs'],
		initialize: function() {
			this.locationString = cdopenfireURL;
			var url = window.location.href;
    		url = url.replace(this.locationString+"/client", "" );
    		url =url.replace("%20"," ");
    		var arrStr = url.split(/[//]/);

			this.userModel     = new UserModel() ;
			this.userID        = this.userModel.getUserID() ;
			this.model = new ClientHistoryMsgModel;
			
			this.id = arrStr[1];
			this.model.set("clientID",this.id);
			this.model.set("name",arrStr[2]);
			this.leaveMessage = new LeaveMessageView() ;
			this.selectedSentBy = "" ;
			this.eMsgList = [];
			this.msgOrder = [];
			$(document).unbind("scroll");
			this.clientUserModel = new ClientUserModel();

		},
		events: {
			"click #msg-search-btn": "searchMessage",
            "keyup #msg-search-txt": "searchMessageByEnter",
            "click .dost-ch-bar": "renderList",
            "click .msg-back": "backToList",
            "click #add-notes": "openNotes",
            "click #save-note": "addNotes",
            "keyup #add-user-note": "addNotesByEnter",
			"click #close-notes": "closeNotes",
			"click #client-msg-compose" : "messageClient",
			"click #open-reply": "singleMsgReply",
			"click #post-reply": "postReply",
			'click .msg-single-reply' : 'singleMsgReply',
			"click #delete-reply": "deleteReply",
			"click .user-name-history" : "gobacktouser",
			"click #fsmsg-close" : "CloseThread",
			"click #fsmsg-open" : "OpenThread",
			"click .read-more" : "expandAssociated",
			"click #msg-follow" : "FollowThread",
			"click #msg-unfollow" : "UnfollowThread"
		},
		addTagsOption:function( categories ){

			var cats = [];
			$.each(categories,function(key,value){
				var tspan = '<span class="tag" data-id="'+value.id+'">'+value.name+'</span>';
				$(".left-tag-list").prepend( tspan );
				cats[value.id] = value.name;
			});
		},
		render:function(){
			//views.ClientHistoryUserPage.render();

			var self = this;
			var selectedSuperviseeObj = self.getSuperviseeObj();
			self.model.addWait();
			
			this.$el.html(this.ClientHistoryUsersLayout({ "id":this.id, "name":this.model.get("name") }));
			
			if ( !$.isEmptyObject(selectedSuperviseeObj) ) { 
				if ( selectedSuperviseeObj.superviseeSelected ) {
					if ( !$("#client-msg-compose").hasClass("hide") ) {
						$("#client-msg-compose").addClass("hide");
					}
					$(".supervisee-name").html( "(" + selectedSuperviseeObj.superviseeSelectedText + ")" );
					$(".supervisee-name").removeClass("hide");
					self.model.set("userID", selectedSuperviseeObj.superviseeSelectedId);
				}else {
					console.log("hello");
					$("#client-msg-compose").removeClass("hide");
				}
			}


			var associatedUsernames;


			setTimeout(function(){
				$(".client-history").addClass("active");
				$(".page-title-user").text(self.model.get("name"));
				$("#mpage-title-user").attr("data-href",
				self.$el.find(+".page-title-user").attr("data-href"));
				if ( self.userID == 101 ) {
					$(".associatedUsernames").text( associatedUsernames );
				}
			},100);

			var type = "msg";


			$.ajax({
				method: "GET",
				url: Utils.contextPath() + "/v2/users/"+this.id+"/related",
				dataType: 'json'
			}).done(function(response){
				console.log(response);
				if (response.length > 0) {
					associatedUsernames = 'Associated Usernames: ';
					var associatedUsernamesList = '';
					var lengthUsernames = 0;
					for(var i=0; i<response.length; i++) {
						lengthUsernames += response[i].length;
						associatedUsernamesList += '<li class="z-depth-1 white username">' + response[i] + '</li>';
					}
					associatedUsernames =  '<li class="username">Associated Usernames: </li>' + associatedUsernamesList;
					//console.log('associatedUsernames '+ associatedUsernames);
					if ( self.userID == 101 ) {

						$('.associated-usernames-div').prepend(associatedUsernames);
						if (lengthUsernames > 70) {
							$(".read-more-button").text("Show More");
						}

					}
					//length of strings

				}
			}).fail(function(error){
          		Utils.adjustViewPortSize();
          		self.model.removeWait();
          	});

			self.model.setUserUrl();

			$.ajax({
              method: "GET",
              url: self.model.url,
              dataType: 'json'
          	}).done(function(response){

          		if( response.length > 0 ){

          			self.removeNoMessage();
          			_.each(response, function(msg){
						self.checkTypeAndCleanupMsgList( msg );
					});

					self.renderMsgs( type );

					self.model.set("pgNo", 1);
					self.bindScroll();
          		}else{

          			if( self.$el.find("#msg-block").find(".umsg-list-"+type).html() == "" ){
          				self.renderNoMessage();
          				console.log('pika!');
          			}else{
          				self.unbindScroll();
          			}
          		}

          		self.$el.find("#msg-block").removeClass("hide");
          		Utils.adjustViewPortSize();

          		self.model.removeWait();
          	}).fail(function(error){

          		Utils.adjustViewPortSize();
          		self.model.removeWait();
          	});


			//Chat Page rendering starts here
			this.$el.html(this.ClientHistoryUsersLayout({ "id":this.id, "name":this.model.get("name") }));
			var self = this;
			var url = window.location.pathname;
    		url = url.replace(this.locationString+"/client", "" );
    		
			var locked = $.url(url).param('locked') ;
			if (locked=='false'|| locked == '') {
				var msgId = $.url(url).param("data-msgid");
				var type = $.url(url).param("data-type");
		
				$(document).unbind("scroll");

				this.model.setUserThreadUrl( msgId , type );
				var ajaxCall = Utils.contextPath() + "/v1/counselors/" + self.userModel.getUserID()+"/users/"+self.model.get('clientID')+"/messages/"+msgId+"?type="+type;
				$.ajax({
	              method: "GET",
	              url: ajaxCall,
	              dataType: 'json'
	          	}).done(function(response){

	          		self.$el.find("#msg-block").addClass("hide");
	          		$('.user-list-item').addClass('hide')
	          		self.$el.find("#msg-block").before(
						self.ClientHistorySingleMsgLayout(response)
					);

	          		$(".msg-page-search-bar").addClass("hide");

	          		if( type == "CHAT" )
						self.$el.find(".msg-notes").addClass("hide");
					else{
						self.$el.find(".msg-notes").removeClass("hide");
						//self.$el.find(".msg-notes").css("margin-top","20vh");
					}

	          		if( response.conversationDetail.categories )
						self.addTagsOption( response.conversationDetail.categories );

					setTimeout(function(){

						if( type != "CHAT" ){
							self.$el.find(".msg-toids").each(function(){
								$(this).html( $(this).html().slice(0,-2) );
							});
						}

						if( Utils.isMobileDevice() ){
							$(".mmsg-single-view-header").removeClass("hide");
							$(".mmsg-list-view-header").addClass("hide");
	        			}

	        			Utils.adjustViewPortSize();
					},10);

	          	}).fail(function(error){

	          		Utils.adjustViewPortSize();
	          	});
	        }
			

		},

		getSuperviseeObj: function() {
			
			var selectedSuperviseeObj = $.parseJSON( window.sessionStorage.getItem( "selectedSupervisee" ) );
			console.log( "selectedSuperviseeObj", selectedSuperviseeObj );
			return selectedSuperviseeObj;
		},
		addNotesByEnter: function(e) {
			var self = this;
			if(event.keyCode == 13){
        		self.addNotes();
    		}

		},
		addNotes: function(){

			var notes = $("#add-user-note").val();

			if( notes ){

				var msgID = $("#single-msg-block").attr("data-msgid");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/notes',
	              data: notes,
	              contentType: "application/json"
	          	}).done(function(response){
	          		$("#user_notes").find(".no-notes").remove();
	          		var note = '<li class="collection-item"><div class="note-text">'+notes+'</div><span class="note-time">'+Utils.getDateDiff(new Date().getTime())+'</span></li>';
					$("#user_notes").find(".notes-list").prepend( note );
					Utils.displaySuccessMsg("Your note has been added.");
					$("#add-user-note").val("").focus();
	          	}).fail(function(error){
	          		console.log(error);
	          	});
			}else{
				$("#add-user-note").focus();
				return false;
			}
		},
		expandAssociated : function(e){
			console.log($(e.currentTarget));
			var parent = $('.associated-usernames-div');
			console.log(parent);
			if (!parent.hasClass('expand')) {
				//$(".associated-usernames-div").css("max-height", "150px");
				$(".read-more-button").text("Show Less");
				$(".associated-usernames-div").addClass('expand');
			}
			else {
				console.log("hello");
				//$(".associated-usernames-div").css("max-height", "54px");
				$(".read-more-button").text("Show More");
				$(".associated-usernames-div").removeClass('expand');

			}
		},
		deleteReply: function(e){

			if( !Utils.isMobileDevice() ){

				if( CKEDITOR.instances.reply_message.getData() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}else{

				if( $("#reply_message").text().trim() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}

			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$(".msg-single-reply").attr("clicked",false);
		},

		openPostReply: function(e){

			if( $(".msg-single-reply").attr("clicked") == "true" )
				return true;

			$(".msg-single-reply").attr("clicked",true);
			$("#open-reply").before( $(".reply-block").html() ).addClass("hide");

			if( !Utils.isMobileDevice() )
				Utils.addRTD('reply_message');
			else
				$("#reply_message").focus();

			Utils.scrollTo("#reply-form",-50);
		},

		singleMsgReply : function(e){

			this.openPostReply(e);
			var self = this ;
			var targetID = $(e.currentTarget).attr("id") ;
			var msgID    = targetID.split(/-/)[1] ;
			if(targetID == "open-reply"){
				var allMsgs = $(".single-thread .dost-msg-item")           ;
				var lastMsg = allMsgs[ allMsgs.length - 1 ] ;

				var msgID = $(lastMsg).attr("id") ;
				msgID     = msgID.split(/-/)[1]   ;
			}
			var msgSentByID   = $("#msg-" + msgID).find(".msg-sent-by").attr("data-fromid") ;
			var msgSentByName = $("#msg-" + msgID).find(".msg-sent-by").html()              ;

			var userID = this.model.get("userID") ;

			var replyFrom = [] ;
			if(msgSentByID == userID){
				var msgSentTo = $("#msg-" + msgID).find(".msg-toids span");
				$.each(msgSentTo, function(index, elem){
					var userInfo = {
						"id"   : $(elem).attr("data-toids"),
						"name" : $(elem).html().trim()
					}

					replyFrom.push(userInfo) ;
				});
			}else{
				replyFrom = [{
					"id" : msgSentByID.trim() ,
					"name" : msgSentByName.trim() ,
				}];
			}
			if(Utils.isMobileDevice()){

				var replyFromStr = "" ;
				$.each(replyFrom, function(index, elem){
					console.log(elem.name) ;
					replyFromStr += elem.name + ", " ;
					self.selectedSentBy[elem.name] = elem.id ;
				});

				$("#msg-send-to").val(replyFromStr) ;
			}else{

				replyFromIDs = [] ;
				$.each(replyFrom, function(index, elem){
					$("#msg-send-to").append("<option value='"+ elem.id +"'>" + elem.name + "</option>") ;
					replyFromIDs.push(elem.id) ;
				});
				setTimeout( function(){
					$("#msg-send-to").val(replyFromIDs) ;
					$("#msg-send-to").chosen({
						width: "100%"
					});
					$("#msg-send-to").trigger("chosen:updated");
				},100);

				$("#msg-send-to").addClass("hide");
			}

			this.populateSender() ;

		},
		gobacktouser : function (e) {

			this.$el.find("#msg-block").removeClass("hide");
			$('.user-list-item').removeClass('hide')
			$(".msg-page-search-bar").removeClass("hide");
			$(".ch-single").remove();
			this.bindScroll();
		},
		populateSender : function(){

			var self = this ;
			var searchType = '/v2/users/list' ;

			if(Utils.isMobileDevice()){

				$( "#msg-send-to" )
			      // don't navigate away from the field on tab when selecting an item
			      .bind( "keydown", function( event ) {
			        if ( event.keyCode === $.ui.keyCode.TAB &&
			            $( this ).autocomplete( "instance" ).menu.active ) {
			          event.preventDefault();
			        }
		      })
		      .autocomplete({
		        source: function( request, response ) {

		        	$.ajax({
					method: 'GET',
					url: Utils.contextPath()+ searchType + '?name=' + Utils.JUIextractLast( request.term ),
					}).done(function (data) {
						var usersArr = new Array() ;

						$.each(data, function (i, val) {
						usersArr.push({
							"key" : val,
							"value" : i
						});
						});
						response( usersArr );
					});


		        },
		        search: function() {
		          // custom minLength
		          var term = Utils.JUIextractLast( this.value );
		          if ( term.length < 2 ) {
		            return false;
		          }
		        },
		        focus: function() {
		          // prevent value inserted on focus
		          return false;
		        },
		        select: function( event, ui ) {

		          self.selectedSentBy[ui.item.value] = ui.item.key ;
		          var terms = Utils.JUIsplit( this.value );
		          // remove the current input
		          terms.pop();
		          // add the selected item
		          terms.push( ui.item.value );
		          // add placeholder to get the comma-and-space at the end
		          terms.push( "" );
		          this.value = terms.join( ", " );
		          return false;
		        }
		      });
			}else{
				self.$el.find("#msg-send-to").ajaxChosen({
					type: 'GET',
					url: Utils.contextPath()+ searchType,
					dataType: 'json',
					jsonTermKey:"name",
					minTermLength:1
				}, function (data) {

					var terms = {};
					$.each(data, function (i, val) {
						terms[val] = i;
					});
					return terms;
				});
			}

		},
		addThreadAfterPostReply: function( response ){

			var cMsg = response.conversationDetail;

			var threadID = cMsg.threadID;
			var important = cMsg.important;
			var message = cMsg.userMessage[ cMsg.userMessage.length-1 ];

			var body = message.body.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
			var receivedTime = Utils.getDateDiff( message.receivedDate, 1, false );
			var subject = message.subject;
			var read = message.read;
			var sender = message.fromRecipient.firstName != null ? message.fromRecipient.firstName : message.fromRecipient.username;

			if( message.fromRecipient.picUrl != undefined ){
				var fAvatar = message.fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+message.fromRecipient.avatar+'.png';
			}

			var tos = [];
            for( var i = 0 ; i < message.toRecipients.length ; i++ ){
            	var to = message.toRecipients[i];
            	var firstName = to.firstName != null ? to.firstName : to.username;
 				tos.push( '<span class="msg-toid" data-toids="'+to.id+'">'+firstName+'</span>' );
            }

			var item = '<li class="collection-item avatar dost-msg-item rhover expanded" id="msg-'+message.msgID+'" data-msgid="'+threadID+'" data-type="MAIL">'
              				+'<div class="msg-img-holder">'
                  				+'<img src="'+fAvatar+'" class="circle msg-avatar z-depth-1">'
              				+'</div>'
              				+'<p class="msg-senders msg-sent-by" data-fromid="'+message.fromRecipient.id+'">'+sender+'</p>'
              				+'<p class="msg-senders msg-toids">To: '+tos.join(", ")+'</p>'
                			+'<p class="bcollapsed truncate hide">'
                			+message.bodyCollapsed+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
              				+'</p>'
              				+'<p class="msg-content">'+body+'</p>'
              				+'<span class="secondary-content msg-time">'+receivedTime+'</span>'
                          	+'<i class="mdi mdi-reply smoothscroll msg-single-reply" id="reply-'+message.msgID+'" href="#reply-form" title="Reply"></i>'
						+'</li>';

			this.$el.find("#single-msg-block").find(".single-thread").append( item );

			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$(".msg-single-reply").attr("clicked",false);
		},
		postReply: function(e){

			$(".iauthentication-error").hide() ;

			var isError = false;
			var self = this;

			var sendTo = $("#msg-send-to").val();
			if(sendTo == null){
				$(".isend-to").show();//.parent().addClass("error");
				isError = true;
			}
			var sentByArr = sendTo ;
			console.log(self.selectedSentBy);
			if(Utils.isMobileDevice()){
				var senders = sentByArr;
				sendersArr = senders.split(",");
				console.log(sendersArr);
				sentByArr = [] ;
				$.each(sendersArr, function(index,elem){
					if(!elem.trim()){
						return false ;
					}
					sentByArr.push(self.selectedSentBy[elem.trim()])
				});
			}
/*			var sendTo = [];
			$(".msg-senders").each(function(){
				if( $(this).attr("data-fromid") != undefined ){
					if( sendTo.indexOf($(this).attr("data-fromid")) < 0
						&&
						( $(this).attr("data-fromid") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-fromid"));
					}
				}
			});

			$(".msg-toid").each(function(){
				if( $(this).attr("data-toids") != undefined ){
					if( sendTo.indexOf($(this).attr("data-toids")) < 0
						&&
						( $(this).attr("data-toids") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-toids"));
					}
				}
			});
*/
			var subject = $(".msg-header").text();
			if( !Utils.isMobileDevice() ){

				var body = encodeURI(CKEDITOR.instances.reply_message.getData());
				if( body == "" ){
					CKEDITOR.instances.reply_message.focus();
					$(".imessage").show();
					isError = true;
				}
			}else{

				var body = encodeURI($("#reply_message").val().trim());
				if( body == "" ){
					$("#reply_message").focus();
					$(".imessage").show();
					isError = true;
				}
			}
			console.log("reply");

			if( !isError ){
				if(Utils.isMobileDevice()){
					body = body.replace(/%0A/g, '<br />');
				}

				var msgJSON = {
					"threadID":$("#single-msg-block").attr("data-msgid"),
					"subject":subject,
					"content":body,
					"recipients":sentByArr
				};

				$("#post-reply").addClass("disabled").html("Sending...");
				$("#delete-reply").addClass("disabled");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json",
	              statusCode : {
              		417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						$(".iauthentication-error").html(errorMessage);
						$(".iauthentication-error").show() ;

					},
              		500 : function(){
						$(".iauthentication-error").html("Something went wrong. Please try again");
						$(".iauthentication-error").show() ;
					},

	              }
	          	}).done(function(response){
	          		Utils.displaySuccessMsg("Your message has been sent.");
	          		self.addThreadAfterPostReply( response );
	          		$("#post-reply")
	          			.removeClass("disabled")
	          			.html( 'Reply<i class="mdi-content-send right"></i>' );
					$("#delete-reply").removeClass("disabled");
	          	}).fail(function(error){
	          		console.log(error);
	          		$("#post-reply")
	          			.removeClass("disabled")
	          			.html( 'Reply<i class="mdi-content-send right"></i>' );
					$("#delete-reply").removeClass("disabled");
	          	});
			}else{
				setTimeout(function(){$(".error-msg").hide();$(".input-field").removeClass("error");},3000);
				return false;
			}
		},

		messageClient : function(e){
			var userInfo = {
				id : this.id ,
				name : this.model.get("name")
			};
			this.leaveMessage.render(userInfo);
		},
		backToList: function(e){


			Backbone.history.navigate("/client/"+this.id+"/"+this.model.get("name"), {trigger: true});


			//location.href = "/client/"+this.id+"/"+this.model.get("name")
			/*this.$el.find("#msg-block").removeClass("hide");
			$('.user-list-item').removeClass('hide')
			$(".msg-page-search-bar").removeClass("hide");
			$(".ch-single").remove();
			this.bindScroll();*/
		},
		renderList: function(e){

			var href = $(e.currentTarget).attr("data-href");
			if( href == location.pathname ){
				$(".umsg-list-msg").removeClass("hide");
				$(".umsg-list-search").addClass("hide").html("");
				this.clearSearch();
				this.unbindScroll();
			}else{
				//location.href = href;
				this.unbindScroll();
				Backbone.history.navigate(href, {trigger: true});
			}
			return true;
		},
		searchMessageByEnter: function(e){
			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#msg-search-btn").trigger("click");
 			}

 			if( $("#msg-search-txt").val().trim() == "" ){
 				this.clearSearch();
 				if( $(".umsg-list-msg").html() == "" ){
 					this.loadMsgs( "msg" );
 				}else{
 					this.$el.find("#msg-block").find(".umsg-list-msg").removeClass("hide");
 				}
 			}
		},
		searchMessage: function(e){

			var self = this;

			if( $("#msg-search-txt").val().trim() == "" )
				return false;

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			this.$el.find("#msg-block").attr("data-type","search");
			this.$el.find("#msg-block").find(".umsg-list-msg").addClass("hide");
			this.$el.find("#msg-block").find(".umsg-list-search").removeClass("hide").html("");

			var search = "content_search="+$("#msg-search-txt").val();
			var params = {"search":search};

			this.model.set("searchTerm",$("#msg-search-txt").val());
			this.model.set("pgNo", 1);
			this.model.setUserUrl( 1 , params );
			this.loadMsgs( "search" );
			this.bindScroll();
		},
		BookAppointmentViewLayout: JST["app/templates/home2/book_appointment.hbs"],
		openMsgDetails: function(e){
			var locked = $(e.currentTarget).hasClass('locked');
			if (!locked) {
				var msgId = $(e.currentTarget).attr("data-msgid");
				var type = $(e.currentTarget).attr("data-type");
				var self = this;

				$(document).unbind("scroll");

				this.model.setUserThreadUrl( msgId , type );

				$.ajax({
	              method: "GET",
	              url: this.model.url,
	              dataType: 'json'
	          	}).done(function(response){

	          		self.$el.find("#msg-block").addClass("hide");

	          		self.$el.find("#msg-block").before(
						self.ClientHistorySingleMsgLayout(response)
					);
	          		$('.user-list-item').removeClass('hide')
	          		$(".msg-page-search-bar").addClass("hide");

	          		if( type == "CHAT" )
						self.$el.find(".msg-notes").addClass("hide");
					else{
						self.$el.find(".msg-notes").removeClass("hide");
						//self.$el.find(".msg-notes").css("margin-top","20vh");
					}

	          		if( response.conversationDetail.categories )
						self.addTagsOption( response.conversationDetail.categories );

					setTimeout(function(){

						if( type != "CHAT" ){
							self.$el.find(".msg-toids").each(function(){
								$(this).html( $(this).html().slice(0,-2) );
							});
						}

						if( Utils.isMobileDevice() ){
							$(".mmsg-single-view-header").removeClass("hide");
							$(".mmsg-list-view-header").addClass("hide");
	        			}

	        			Utils.adjustViewPortSize();
					},10);

	          	}).fail(function(error){

	          		Utils.adjustViewPortSize();
	          	});
	        }
		},
		checkTypeAndCleanupMsgList: function( msg ){

			if( msg.type == "MAIL" ){
				this.parseEmailObj( msg.conversationDetail );
			}else if( msg.type == "CHAT" ){
				this.parseChatObj( msg.conversationDetail );
			}else{
				return false;
			}
		},
		parseEmailObj: function( cMsg ){

			if( cMsg.userMessage[0] == undefined )
				return false;

			var threadID = cMsg.threadID;
			var body = cMsg.userMessage[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userMessage[0].receivedDate, 1, false );
			var subject = cMsg.userMessage[0].subject;
			var read = cMsg.userMessage[0].read;

			//chat history consent
			var chatHistoryConsent = cMsg.userMessage[0].messageConsent;
			//end//

			if( cMsg.userMessage[0].messageType == "SENT_MAIL" ){
				var sender = [];
				_.each(cMsg.userMessage[0].toRecipients,function(user){
					var name = user.firstName != null ? user.firstName : user.username;
					sender.push(name);
				});
				sender = sender.join(",");
			}else{
				var sender = cMsg.userMessage[0].fromRecipient.firstName != null ? cMsg.userMessage[0].fromRecipient.firstName : cMsg.userMessage[0].fromRecipient.username;
			}

			if( cMsg.userMessage[0].fromRecipient.picUrl != undefined ){
				var fAvatar = cMsg.userMessage[0].fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userMessage[0].fromRecipient.avatar+'.png';
			}

			var msg = {
				"threadID" : threadID,
				"body" : body,
				"subject" : subject,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "MAIL",
				"icon" : "mdi-arrow-left-bold-circle-outline received",
				"read" : read,
				"chatHistoryConsent": chatHistoryConsent
			};

			if( cMsg.userMessage[0].messageType == "SENT_MAIL" ){
				msg.icon = "mdi-arrow-right-bold-circle-outline sent";
				msg.read = true;
				msg.type = "SENT_MAIL";
			}

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		parseChatObj: function( cMsg ){

			if( cMsg.userChats[0].chatGroupUsers[0] == undefined )
				return false;

			var threadID = cMsg.threadID;
			var body = cMsg.userChats[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userChats[0].sentDate, 1, false );
			var sender = cMsg.userChats[0].chatGroupUsers[0].firstName != null ? cMsg.userChats[0].chatGroupUsers[0].firstName : cMsg.userChats[0].chatGroupUsers[0].username;

			if( cMsg.userChats[0].chatGroupUsers[0].picUrl != undefined ){
				var fAvatar = cMsg.userChats[0].chatGroupUsers[0].picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userChats[0].chatGroupUsers[0].avatar+'.png';
			}
			var chatHistoryConsent = cMsg.userChats[0].hasConsent;
			var msg = {
				"threadID" : threadID,
				"body" : body,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "CHAT",
				"chatHistoryConsent": chatHistoryConsent
			};

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		renderMsgs: function( type ) {

			var self = this;
			if( self.msgOrder.length > 0 ){

				_.each(self.msgOrder, function(threadID){

					var msg = self.eMsgList[threadID];

					if( msg.type == "CHAT" ){
						self.renderChatMsg( msg , type );
					}else{
						self.renderEmailMsg( msg , type );
					}
				});
				self.eMsgList = [];
				self.msgOrder = [];
			}
		},
		CloseThread : function(e){
			e.stopPropagation();
			var msgID = $(e.currentTarget).parents(".dost-msg-item").data("msgid");
			var usrID = this.model.attributes.userID;
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+usrID+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been closed.");
			    $(e.currentTarget).parents(".dost-msg-item").find("#fsmsg-open").removeClass("hide");
				$(e.currentTarget).parents(".dost-msg-item").find("#fsmsg-close").addClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		OpenThread : function(e){
			e.stopPropagation();
			var msgID = $(e.currentTarget).parents(".dost-msg-item").data("msgid")
			var usrID = this.model.attributes.userID;
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+usrID+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been opened.");
			    $(e.currentTarget).parents(".dost-msg-item").find("#fsmsg-open").addClass("hide");
				$(e.currentTarget).parents(".dost-msg-item").find("#fsmsg-close").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		FollowThread : function(e){
			e.stopPropagation();
			if($(e.currentTarget).hasClass("txt-inactive")){
				return;
			}
			var msgID = $(e.currentTarget).parents(".dost-msg-item").data("msgid")
			var usrID = this.model.attributes.userID;
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+usrID+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			     Utils.displaySuccessMsg("This thread has been followed.");
			    $(e.currentTarget).parents(".dost-msg-item").find("#msg-follow").addClass("hide");
				$(e.currentTarget).parents(".dost-msg-item").find("#msg-unfollow").removeClass("hide").
										removeClass("txt-inactive").addClass("txt-teal").attr("title", "Unfollow");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},

		UnfollowThread : function(e){
			e.stopPropagation();
			var msgID = $(e.currentTarget).parents(".dost-msg-item").data("msgid")
			var usrID = this.model.attributes.userID;
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+usrID+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("Not following this thread.");
			    $(e.currentTarget).parents(".dost-msg-item").find("#msg-unfollow").addClass("hide");
				$(e.currentTarget).parents(".dost-msg-item").find("#msg-follow").removeClass("hide")
							.removeClass("txt-inactive").addClass("txt-teal").attr("title","Follow");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},


		renderEmailMsg: function( cMsg , type ){

			if (!cMsg.chatHistoryConsent) {
				return true ;
			}
			console.log("Message " + JSON.stringify(cMsg));
			console.log("type "+ type);
			console.log("hello");
			var lock_html = '';
			var locked = '';

			if(!cMsg.chatHistoryConsent){
				return true;
			}

			if (!cMsg.chatHistoryConsent) {
				lock_html = '<i class="mdi mdi-lock email"></i>';
				locked = 'locked';
				cMsg.body = 'User has kept conversation history private';
				cMsg.subject = '';
			}
			else {
				lock_html = '<i class="mdi mdi-dots-horizontal msg-dots"></i>';
			}
			var redirectUrl= window.location.pathname + "/chatPage?locked="+locked+"&data-msgid="+cMsg.threadID+"&data-type=MAIL"
			var item = '<a href="'+redirectUrl+'" class="msgid-'+cMsg.threadID+ ' '+ locked + ' collection-item ch-item avatar cpointer dost-msg-item hoverable'+ (( cMsg.read == true ) ? 'old' : '' )+'" data-msgid="'+cMsg.threadID+'" data-type="MAIL">'
						 	+'<div class="msg-img-holder">'
						+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
						+'</div>'
						+'<span class="title msg-title truncate '+ (( cMsg.read == true ) ? 'read' : 'notRead') +' ">'
						+'<i class="mdi mdi-email-open" title="Close thread" id="fsmsg-close" style="color:teal;" ></i>'
						              +'<i class="mdi mdi-check" title="Open thread" id="fsmsg-open"></i>'
						              +'<i class="mdi mdi-thumb-up txt-inactive hide" id="msg-follow"></i>'
						              +'<i class="mdi mdi-thumb-down txt-inactive hide" id="msg-unfollow"></i>'
						+'<i class="mdi '+cMsg.icon+' msg-icon"></i> '
						+cMsg.subject+ ( (cMsg.count > 1) ? ' <span class="msg-count">('+cMsg.count+')</span>' : '' ) +'</span>'
						+'<p class="msg-senders">'+cMsg.sender+'</p>'
						+'<p class="truncate msg-content email '+ locked +' ">'+cMsg.body+'</p>'
						+'<a class="secondary-content msg-time">'+cMsg.receivedTime+'</a>'
						+lock_html
						+'</a>';



			this.$el.find("#msg-block").find(".umsg-list-"+type).removeClass("hide").append( item );

			var msgID = cMsg.threadID;
			var userID = this.model.attributes.userID;

			$.ajax({
				method: 'GET',
				url: Utils.contextPath()+"/v1/users/"+userID+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			   if(data["status"]==true){
				    $(".msgid-"+msgID).find("#fsmsg-open").removeClass("hide");
					$(".msgid-"+msgID).find("#fsmsg-close").addClass("hide");
				}else{
					$(".msgid-"+msgID).find("#fsmsg-open").addClass("hide");
					$(".msgid-"+msgID).find("#fsmsg-close").removeClass("hide");
				}
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});

          	$.ajax({
				method: 'GET',
				url: Utils.contextPath()+"/v1/users/"+userID+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

				if(data["status"]==-1){
				    $(".msgid-"+msgID).find(".mdi-thumb-up").removeClass("hide");
				    $(".msgid-"+msgID).find(".mdi-thumb-up").removeClass("txt-teal").addClass("txt-inactive").removeAttr("title");
				    $(".msgid-"+msgID).find(".mdi-thumb-down").addClass("hide");
				}else if(data["status"]== 0){
					$(".msgid-"+msgID).find(".mdi-thumb-up").removeClass("hide");
					$(".msgid-"+msgID).find(".mdi-thumb-up").removeClass("txt-inactive").addClass("txt-teal").attr("title", "Follow");
					$(".msgid-"+msgID).find(".mdi-thumb-down").addClass("hide");
				}else{
					$(".msgid-"+msgID).find(".mdi-thumb-down").removeClass("hide");
					$(".msgid-"+msgID).find(".mdi-thumb-down").removeClass("txt-inactive").addClass("txt-teal").attr("title","Unfollow");
					$(".msgid-"+msgID).find(".mdi-thumb-up").addClass("hide");


				}

				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		renderChatMsg: function( cMsg , type ){

			if (!cMsg.chatHistoryConsent) {
				return true ;
			}

			var lock_html = '';
			var locked = '';
			var hide = '';
			if (!cMsg.chatHistoryConsent) {
				lock_html = '<i class="mdi mdi-lock chat"></i>';
				locked = 'locked';
				cMsg.body = 'User has kept conversation history private';
			}
			else {
				lock_html = '<i class="mdi mdi-dots-horizontal msg-dots"></i>';
			}
			var redirectUrl= window.location.pathname + "/chatPage?locked="+locked+"&data-msgid="+cMsg.threadID+"&data-type=CHAT"
			var item = '<a href = "'+redirectUrl+'"  class="collection-item ' + locked +' ch-item avatar cpointer dost-msg-item hoverable old chat" data-msgid="'+cMsg.threadID+'" data-type="CHAT">'

				  			+'<div class="msg-img-holder">'
								+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
							+'</div>'
							+'<p class="msg-senders"><i class="mdi mdi-comment-multiple-outline"></i> Chat with: '+cMsg.sender+'</p>'

							+'<p class="truncate msg-content chat '+ locked+' ">'+cMsg.body+'</p>'
							+'<span class="secondary-content msg-time">'+cMsg.receivedTime+'</span>'
							+lock_html
						+'</a>';

			this.$el.find("#msg-block").find(".umsg-list-"+type).removeClass("hide").append( item );
			$('.user-list-item').removeClass('hide')
		},
		bindScroll: function(){
			var self = this;

			$(document).scroll(function() {
		        self.checkScroll();
		    });
		},
		unbindScroll: function(){
			$(document).unbind("scroll");
		},
	    checkScroll: function () {

	        var triggerPoint = 300; // 20px from the bottom
	        var type = $("#msg-block").attr("data-type");
	        if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {
				var pgNo = this.model.get("pgNo");
				pgNo += 1;

				var params = {};
				var type = "msg";
				if(this.model.get("searchTerm") != undefined && this.model.get("searchTerm") != "" ){
					var search = "content_search="+this.model.get("searchTerm");
					params["search"] = search;
					type = "search";
				}

				this.model.setUserUrl( pgNo , params );

	    		this.loadMsgs( type );
	    		this.model.set("pgNo", pgNo);
	        }
	    },
	    loadMsgs: function( type ){

			var self = this;

			self.model.addWait();

			if( self.$el.find("#msg-block").find(".umsg-list-"+type).html() != "" ){
				//console.log("one charkha");
				$(".main-loader").addClass("mmain-loader");
			}

			this.isLoading = true;

			$.ajax({
              method: "GET",
              url: self.model.url,
              dataType: 'json'
          	}).done(function(response){

          		if( response.length > 0 ){

          			self.removeNoMessage();
          			_.each(response, function(msg){
						self.checkTypeAndCleanupMsgList( msg );
					});
					self.renderMsgs( type );
          		}else{

          			if( self.$el.find("#msg-block").find(".umsg-list-"+type).html() == "" ){
          				self.renderNoMessage();
          			}else{
          				self.unbindScroll();
          			}
          		}

          		self.$el.find("#msg-block").removeClass("hide");
          		$('.user-list-item').removeClass('hide')
          		Utils.adjustViewPortSize();
				self.model.removeWait();
				self.isLoading = false;

          	}).fail(function(error){

          		Utils.adjustViewPortSize();
          		self.model.removeWait();
				console.log(error);
          	});
		},
		renderNoMessage: function(){
			this.$el.find("#msg-list-block").addClass("hide");
			this.$el.find("#no-msg-list-block").removeClass("hide");
		},
		removeNoMessage: function(){
			this.$el.find("#msg-list-block").removeClass("hide");
			this.$el.find("#no-msg-list-block").addClass("hide");
		},
		clearSearch: function(){
	    	$("#msg-search-txt").val("");
	    	this.model.set("searchTerm","");
			this.model.set("pgNo", 1);
			this.model.setUserUrl( 1 );
	    	this.$el.find(".umsg-list-search").addClass("hide").html("");
	    },
		addTagsOption:function( categories ){

			var cats = [];
			$.each(categories,function(key,value){
				var tspan = '<span class="tag" data-id="'+value.id+'">'+value.name+'</span>';
				$(".left-tag-list").prepend( tspan );
				cats[value.id] = value.name;
			});
		},
		closeNotes: function(e){
			$(".msg-notes-list").addClass("hide");
			$(".feedback-form-btn").removeClass("hide");
			$("#close-notes").addClass("hide");
			$(".msg-notes").width("55px");
			e.stopPropagation();
		},
		openNotes: function(e){
			$(".msg-notes-list").removeClass("hide");
			$(".msg-notes").addClass("fadeInRightBig animated").width("300px");
			$(".feedback-form-btn").addClass("hide");
			$("#close-notes").removeClass("hide");
			setTimeout(function(){$("#add-user-note").focus();},1100);
		}
	





		});
	ClientHistoryChatPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.undelegateEvents();
    	this.unbind();
	};

	ClientHistoryChatPage.prototype.clean = function() {

    	this.remove();
	};

	return ClientHistoryChatPage;
});
	