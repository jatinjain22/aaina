define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'model/clientHistory',
	'model/users' ,
	'utils'
], function($, _, Backbone, JST, ClientUserModel, UserModel, Utils) {

	var ClientHistoryUsersPage = Backbone.View.extend({
		el: "main",
		ClientHistoryLayout: JST['app/templates/clientHistory/layout.hbs'],
		ClientHistoryUsersLayout: JST['app/templates/clientHistory/users.hbs'],
		SelectSuperviseeOptionsLayout: JST['app/templates/clientHistory/superviseeOption.hbs'],

		initialize: function() {
			this.clientUserModel = new ClientUserModel() ;
			this.userModel       = new UserModel() ;
			this.selectedSupervisee = {};
			var userType = 	this.userModel.getUserType() ;

			if(userType != "OPERATOR"){
				//location.href = "/!" ;
				Backbone.history.navigate("/!", {trigger: true});
			}
		},
		events: {
			'click .user-status' : 'changeUserStatus',
			'click .user-msg-status' : 'closeAllMessages',
			"click #client-search-btn": "searchClient",
            "keyup #client-search-txt": "searchClientByEnter",
            "click .select-supervisee li": "selectASupervisee"
		},

		renderNoClients: function(){
			if ( !this.$el.find(".client-user-list").hasClass("hide") ) {
				this.$el.find(".client-user-list").addClass("hide");	
			}
			this.$el.find(".no-client-user-list").removeClass("hide");
		},

		removeNoClients: function(){
			this.$el.find(".client-user-list").removeClass("hide");
			if ( !this.$el.find(".no-client-user-list").hasClass("hide") ) {
				this.$el.find(".no-client-user-list").addClass("hide");	
			}
		},

		getSuperviseeObj: function() {
			
			var selectedSuperviseeObj = $.parseJSON( window.sessionStorage.getItem( "selectedSupervisee" ) );
			return selectedSuperviseeObj;
		},

		selectASupervisee: function(e) {

			
			var val = $("#select-supervisee").val();
			
			var self = this;
			self.clientUserModel.addWait();
			self.bindScroll();
			$(".mmain-loader").addClass('hide');
			var selectedText = $("#select-supervisee option:selected").text();
			if ( self.userModel.getUserID() != val ) {
			
				self.selectedSupervisee = {
											"superviseeSelected" : true,
											"superviseeSelectedId" : val, 
											"superviseeSelectedText": selectedText
										  }

			
			}else {

				self.selectedSupervisee = {
											"superviseeSelected" : false,
											"superviseeSelectedId": self.userModel.getUserID(),
											"superviseeSelectedText": selectedText
										  }
			
			}
			window.sessionStorage.setItem( "selectedSupervisee", JSON.stringify(self.selectedSupervisee) );
			self.$el.find(".client-users-list").html("");
			this.clientUserModel.setUserID(val);
			this.clientUserModel.setUrl();
			self.clientUserModel.addWait();
			$.ajax({
	    		url : this.clientUserModel.url,
	    	}).done(function(response){
	    		
				if(response.length > 0 ){
					
					var superviseeSelected = self.getSuperviseeObj().superviseeSelected;
					_.each( response, function(eachUser, index){
						if(eachUser.id != -1){
							
							self.$el.find(".client-users-list").append(self.ClientHistoryUsersLayout({user : eachUser, superviseeSelected: superviseeSelected}));
						}

					});

					if(self.userModel.getUserID() != 101){
						$(".user-status").addClass("hide");
					}

					self.clientUserModel.set("pgNo", 1) ;
				}
				self.clientUserModel.removeWait();

	    	}).error(function(error){
          		Utils.adjustViewPortSize();
          		self.clientUserModel.removeWait();
	    		console.log(error)
	    	});


		},
		searchClientByEnter : function(e){

			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#client-search-btn").trigger("click");
 			}

 			if( $("#client-search-txt").val().trim() == "" ){
				$("#client-search-btn").trigger("click");
 			}

		},
		searchClient : function(e){
			var searchTerm = $("#client-search-txt").val() ;

			var userID = this.clientUserModel.getUserID() ;
			this.clientUserModel.set("searchTerm", searchTerm) ;
			this.clientUserModel.set("pgNo", 1) ;
			this.$el.find(".client-users-list").html("") ;
			this.bindScroll() ;
			this.clientUserModel.url = Utils.contextPath() + '/v1/counselor/'+ userID +'/user/list?name=' + searchTerm ;
    		this.populateUsers() ;

		},
		changeUserStatus : function(e){
			e.preventDefault();
			e.stopPropagation();

			var blockID = $(e.currentTarget).attr("id") ;
			var userToblock = blockID.split( "_")[1] ;

			var parent = $(e.currentTarget.ownerDocument.activeElement.firstElementChild);
			var child  = $(e.currentTarget)

			$.ajax({
				url : Utils.contextPath() + "/v2/users/"+ userToblock +"/modify/status" ,
				method : "POST" ,
			}).done(function(response){

				if(parent.hasClass("user-inactive")){
					parent.removeClass("user-inactive") ;
					child.html("Deactivate")
				}else{
					parent.addClass("user-inactive") ;
					child.html("Activate")
				}
			}).error(function(error){
				console.log("Error") ;
			});

			return false ;
		},
		closeAllMessages : function(e){
			e.preventDefault();
			e.stopPropagation();

			var blockID = $(e.currentTarget).attr("id") ;
			var userID = blockID.split( "_")[1] ;

			$.ajax({
				url : Utils.contextPath() + "/v1/users/"+ userID +"/close/message" ,
				method : "POST" ,
			}).done(function(response){
				Utils.displaySuccessMsg("All the threads for user is closed");
			}).error(function(error){
				console.log("Error") ;
			});

			return false ;
		},
		showSpanButton : function(e){
			if($(e.currentTarget).hasClass("user-inactive")){
				$(e.currentTarget).find(".activate-user").removeClass("hide") ;
			}else{
				$(e.currentTarget).find(".block-user").removeClass("hide") ;
			}
		},
		hideSpanButton : function(e){
			if($(".client-user-row").hasClass("user-inactive")){
				$(e.currentTarget).find(".activate-user").addClass("hide") ;
			}else{
				$(e.currentTarget).find(".block-user").addClass("hide") ;
			}
		},
		bindScroll: function(){
			var self = this;

			$(document).scroll(function() {
		        self.checkScroll();
		    });
		},
		unbindScroll: function(){
			$(document).unbind("scroll");
		},
	    checkScroll: function () {

	        var triggerPoint = 300; // 20px from the bottom
	        var type = $("#msg-block").attr("data-type");
	        if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {
				var pgNo = this.clientUserModel.get("pgNo") ;
				pgNo     += 1  ;

				var searchQuery = "" ;
				if(this.clientUserModel.get("searchTerm") != undefined && this.clientUserModel.get("searchTerm") != "" ){
					searchQuery = "&name=" + this.clientUserModel.get("searchTerm") ;
				}

				var userID = this.clientUserModel.getUserID() ;
				this.clientUserModel.url = Utils.contextPath() + '/v1/counselor/'+ userID +'/user/list?page_number=' + pgNo + searchQuery;
	    		this.populateUsers() ;
	    		this.clientUserModel.set("pgNo", pgNo) ;
	        }
	    },
	    populateUsers : function(){

	    	var self = this ;

	    	self.isLoading = true;
	    	self.clientUserModel.addWait();
	    	var selectedSuperviseeObj = self.getSuperviseeObj();
    		var counselorId;
    		var superviseeSelectedBool;
    		if ( $.isEmptyObject(selectedSuperviseeObj) ){
    			counselorId = self.userModel.getUserID()
    			superviseeSelectedBool = false;
			} else {
				counselorId = selectedSuperviseeObj.superviseeSelectedId;
				superviseeSelectedBool = selectedSuperviseeObj.superviseeSelected;
			}
			console.log( superviseeSelectedBool );
	    	
	    	$.ajax({
	    		url : this.clientUserModel.url,
	    	}).done(function(response){
				if(response.length > 0 ){
					console.log( "self.removeNoClients()" );
					self.removeNoClients();
					_.each( response, function(eachUser, index){
						if(eachUser.id != -1){
							self.$el.find(".client-users-list").append(self.ClientHistoryUsersLayout({user : eachUser, superviseeSelected: superviseeSelectedBool}));
						}
					});

					if(self.userModel.getUserID() != 101){
						$(".user-status").addClass("hide");
					}

					self.isLoading = false;
				}else{

					if ( self.clientUserModel.get("pgNo") == 1 ) {
						self.renderNoClients();
					}
					self.unbindScroll();
				}

          		Utils.adjustViewPortSize();
          		self.clientUserModel.removeWait();
	    	}).error(function(error){
          		Utils.adjustViewPortSize();
          		self.clientUserModel.removeWait();
	    		console.log(error)
	    	})


	    },
		render: function() {

			setTimeout(function(){$(".client-history").addClass("active");},10);
			var self = this ;

			var selectedSuperviseeObj = self.getSuperviseeObj();
    		var counselorId;
    		var superviseeSelectedBool;
    		if ( $.isEmptyObject(selectedSuperviseeObj) ){
    			counselorId = self.userModel.getUserID()
    			superviseeSelectedBool = false;
			} else {
				counselorId = selectedSuperviseeObj.superviseeSelectedId;
				superviseeSelectedBool = selectedSuperviseeObj.superviseeSelected;
			}
			console.log( superviseeSelectedBool );
    		this.clientUserModel.setUserID( counselorId );
			this.clientUserModel.setUrl();
    		self.$el.html(self.ClientHistoryLayout()) ;
    		
 			$.ajax({
	    		url : this.clientUserModel.getSuperviseeUrl(),
	    		withCredentials: true
	    	}).done(function(response){
	    		if (response.length > 0) {

	    			self.removeNoClients();
	    			var userObject = {
	    				id: self.userModel.getUserID(),
	    				picUrl: self.userModel.getPicUrl(),
	    				firstName: "My Clients ( " +self.userModel.getFirstName() + " )"
	    			}
	    			response.unshift(userObject);
	    		
					$( ".select-supervisee-row" ).html(self.SelectSuperviseeOptionsLayout({response: response}));
					var selectedOptionWithVal = $( "#select-supervisee" ).val( counselorId );
					selectedOptionWithVal.removeAttr( "selected" );
					$( 'select' ).material_select();

	    		}
	    		else {
	    			self.renderNoClients();
	    		}
	    	}).error(function(error){
          		console.log(error);
	    	});

			self.clientUserModel.addWait();
			self.bindScroll();

			$.ajax({
	    		url : this.clientUserModel.url,
	    	}).done(function(response){
				if(response.length > 0 ){
					
					_.each( response, function(eachUser, index){
						if(eachUser.id != -1){
							self.$el.find(".client-users-list").append(self.ClientHistoryUsersLayout({ user : eachUser, superviseeSelected: superviseeSelectedBool }));
						}
					});

					if(self.userModel.getUserID() != 101){
						$(".user-status").addClass("hide");
					}

					self.clientUserModel.set("pgNo", 1) ;
				}
          		self.clientUserModel.removeWait();

	    	}).error(function(error){
          		Utils.adjustViewPortSize();
          		self.clientUserModel.removeWait();
	    		console.log(error)
	    	});


		}
	});

	ClientHistoryUsersPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	ClientHistoryUsersPage.prototype.clean = function() {
		this.remove() ;
	};

	return ClientHistoryUsersPage;
});
