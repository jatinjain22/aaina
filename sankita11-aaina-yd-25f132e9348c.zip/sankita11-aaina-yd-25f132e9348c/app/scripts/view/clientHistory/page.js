define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel'
], function($,_, Backbone, JST, Utils, EventBus, UserMsgModel) {

	var ClientHistoryPage = Backbone.View.extend({
		el: "main",
		template: JST['app/templates/messages/user_layout.hbs'],
		initialize: function() {
			this.model = new UserMsgModel;
		},
		events: {},
		render: function() {
			
			self.model.addWait();
			return this;

		}
	});

	ClientHistoryPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	ClientHistoryPage.prototype.clean = function() {
		this.remove();
	};

	return ClientHistoryPage;
});
