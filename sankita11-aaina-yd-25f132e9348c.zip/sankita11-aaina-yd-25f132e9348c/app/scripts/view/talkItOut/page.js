define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/talkItOut/subview/start_chatting',
	'view/talkItOut/subview/search_bar',
	'view/talkItOut/subview/filter',
	'view/talkItOut/subview/counselors_list',
	'view/paymentPending/payment_pending',
	'utils',
	'model/users',
	'event/dispatcher',
	'view/leaveMessage/page' ,
	'introjs',
	'purl',
], function($,_, Backbone, JST, StartChattingView, SearchBarView, FilterView, CounselorsView, PaymentPendingView, Utils, UserModel, Dispatcher, LeaveMessage) {

	var TalkItOutPage = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			var url = window.location.href ;
    		url = url.replace("/talkItOut", "" );
			this.messageExists = $.url( url ).param('messageExists') ;
			this.categoryId = $.url( url ).param('category') ;
			var url = window.location.href ;
    		url = url.replace("/talkItOut", "" );
    		this.sendCounselorId = $.url( url ).param('counselorID') ;
    		this.fromPage = $.url( url ).param('from') ;

			this.startChattingView = new StartChattingView() ;
			this.filterView        = new FilterView() ;
			this.counselorsView    = new CounselorsView() ;
			this.paymentPendingView = new PaymentPendingView() ; 
			this.searchBarView     = new SearchBarView() ;
			this.userModel 		   = new UserModel() ;
			this.leaveMessage = new LeaveMessage();
			

	 	},
		events: {
			"click #remove-counselor-modal .mclose" : "closeRemoveModal",
			"click .remove-counselor-text-link" : "showRemoveReasonText",
			"click #submit-remove-counselor" : "submitRemoveCounselor",
			"click #cancel-remove-counselor" : "closeRemoveModal",
			"click .browse-all-btn" : "showAllExperts"
		},

		showAllExperts : function(e){
			var self = this ;

        	self.$el.html( self.TalkItOutPageLayout() );
			self.filterView.render() ;
			self.counselorsView.render() ;
			$('select').not('.disabled').material_select();
			self.searchBarView.render() ;
			self.startChattingView.render();
		},

		submitRemoveCounselor : function(e){

			var self = this ;

			var counselorID = $(e.currentTarget).attr("cID");
			var removeReason = $("#remove-reason").val();

			var userID = this.userModel.getUserID();

			var dataToSend = {
				userID : userID,
				counselorID : counselorID,
				type : "NOT_FAMILIAR",
				updatedBy : userID,
				reason : removeReason,
			};

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          		mixpanel.track("Submit Remove Counselor", { "mediumSource" : "website", 'itemName':  $(e.currentTarget).attr("cName") });
        	}

			$.ajax({
				url : Utils.contextPath() + "/users/blockUser",
				method : "POST",
				data : JSON.stringify(dataToSend),
				dataType: "JSON",
				contentType: "application/json; charset=utf-8",
			}).done(function(response){
				self.closeRemoveModal();
				$(".my-expert-container").html(self.LoaderLayout());
        		var userID = self.userModel.getUserID() ;

        		$.ajax({
        			url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"
        		}).done(function(response){
        			if(response.length > 0){
        				self.$el.html(self.MyExpertLayout({}));
						Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "My Experts");
						$(".my-experts-slider").css("border-bottom", "2px solid white");

        			}else{
        				self.$el.html( self.TalkItOutPageLayout() );
						self.filterView.render() ;
						self.counselorsView.render() ;
						$('select').not('.disabled').material_select();
						self.searchBarView.render() ;
						self.startChattingView.render();
        			}
        		})
			}).error(function(error){
				console.log(error);
			})


		},

		showRemoveReasonText : function(e){
			$(".remove-counselor-text").removeClass("hide");
		},

		closeRemoveModal : function(e){
			Utils.closePopup('remove-counselor-modal');
		},

		TalkItOutPageLayout : JST['app/templates/talkItOut/layout.hbs'],
		template: JST['app/templates/homeNew/layout.hbs'],
		MyExpertLayout : JST['app/templates/talkItOut/myexperts.hbs'],
		LoaderLayout           : JST['app/templates/loader.hbs'], 
		render: function() {
			
			var self = this ;
			document.title="Online Counselors, Psychologists, Life Coaches | YourDOST";
			$('meta[name=description]').attr('content', "List of career experts, psychologists counsellors at YourDOST to help you out with problems or need advice in career, relationships, parenting & more in India");
			$('meta[name=title]').attr('content',"Online Counselors, Psychologists, Life Coaches | YourDOST");
			$('meta[property="og:description"]').attr('content', "List of career experts, psychologists counsellors at YourDOST to help you out with problems or need advice in career, relationships, parenting & more in India");
			$('meta[property="og:title"]').attr('content',"Online Counselors, Psychologists, Life Coaches | YourDOST");
        	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/talkItOut');
			
			setTimeout(function(){$(".chat-page").addClass("active");},10);

			//var user_id = this.userModel.getUserID() ; 
			var url = window.location.href ;
		    url = url.replace("/talkItOut", "" );
			var fromPage = $.url( url ).param('fromPage') ;
			console.log( "fromPage " + fromPage );
			
			
			//this.$el.html( this.TalkItOutPageLayout() );
			// this.$el.append( this.template() );
			$.ajax({
        
          		url: Utils.scriptPath() + "/banner.json",
        		cache: false
        	}).done( function( data ) {
            
            	if ( data.visibility == "on") {
            		// $(".page-title").css("margin-bottom", "0px !important");
            		$(".banner-high-traffic-row-talkitout").removeClass("hide");
            	}
 
        	}).error(function(error){
        
          		console.log(error)
        
        	});
			

        	self.$el.html(self.LoaderLayout({}));

        	if(Utils.isLoggedIn()){		


        		var userID = self.userModel.getUserID() ;
        		var userType = self.userModel.getUserType();

        		if(userType != 'VICTIM'){
					if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	          			mixpanel.track("Expert Listing page", { "mediumSource" : "website" });
	        		}

	        		this.$el.html( this.TalkItOutPageLayout() );
	        		this.filterView.render() ;
					this.counselorsView.render() ;
					$('select').not('.disabled').material_select();
					this.searchBarView.render() ;
					this.startChattingView.render();

        		}else{
	        		$.ajax({
	        			url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"
	        		}).done(function(response){
	        			if(response.length > 0){
	        				self.$el.html(self.MyExpertLayout({}));

	        				$(".my-expert-container").html(self.LoaderLayout());

							if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	          					mixpanel.track("My Experts Page", { "mediumSource" : "website" });
	        				}

							Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "My Experts");
							$(".my-experts-slider").css("border-bottom", "2px solid white");

	        			}else{

	        				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	          					mixpanel.track("Expert Listing page", { "mediumSource" : "website" });
	        				}
	        				
	        				self.$el.html( self.TalkItOutPageLayout() );
							self.filterView.render() ;
							self.counselorsView.render() ;
							$('select').not('.disabled').material_select();
							self.searchBarView.render() ;
							self.startChattingView.render();
	        			}
	        			if( typeof self.sendCounselorId != 'undefined' && self.sendCounselorId != ''
							&&
							typeof self.fromPage != 'undefined' && self.fromPage == 'message'){

							self.leaveMessage.render(self.sendCounselorId)
						}
	        		})

        		}

        	}else{

				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          			mixpanel.track("Expert Listing page", { "mediumSource" : "website" });
        		}

        		this.$el.html( this.TalkItOutPageLayout() );
        		this.filterView.render() ;
				this.counselorsView.render() ;
				$('select').not('.disabled').material_select();
				this.searchBarView.render() ;
				this.startChattingView.render();
        	}		
			
			if(Utils.isLoggedIn()){

				this.paymentPendingView.render() ;
			}
			
			
			if(this.messageExists =="true"){

				if(this.categoryId == "31"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on parenting? Here are some counselors who can help:", 10000 );
				}else if(this.categoryId == "13"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Don't let anger or anxiety eat you up. Here are some counselors you can talk to:", 10000);
				}else if(this.categoryId == "100"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on personality development? These YourDOST counselors can help:", 10000);
				}else if(this.categoryId == "33"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Want to know more about handling exam stress? These YourDOST counselors can help:", 10000);
				}
			}
			

		}
	});

	TalkItOutPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();
	};

	TalkItOutPage.prototype.clean = function() {
    	this.remove();
	};

	return TalkItOutPage;
});