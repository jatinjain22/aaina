define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/filter',
	'utils',
	'purl'
], function($,_, Backbone, JST, FilterModel, Utils ) {

	var FilterView = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.filterModel = new FilterModel() ;
		},
		events: {
			'click #filter-close-btn'   : 'hideFilter',
		},
		hideFilter : function(e){
			$("#filter-mobile").animate({'top': '105%'}, "slow") ;
			$("body").css("overflow-y", "auto");
		},
		FilterLayout : JST['app/templates/talkItOut/filter.hbs'],
		render: function() {

			var self = this ;
			this.filterModel.fetch({
				success : function( response ) {
					var filtersJson = response.attributes ;
					var isLoggedIn = Utils.isLoggedIn() ;
					self.$el.find("#left-filter-block").html( self.FilterLayout({ filterData : filtersJson, isLoggedIn : isLoggedIn }) );
					var url = window.location.href ;
		    		url = url.replace("/talkItOut", "" );
					var categoryFilter = $.url( url ).param('category') ;
					
					if(Utils.isMobileDevice()){

						if(categoryFilter){

							$("#mobile-category_"+categoryFilter).attr("checked", "checked");
							if($(".filter-category input:checked").length > 0 ){	

								$(".filter-mob-cnt").removeClass("hide");
								$(".filter-mob-cnt").html($(".filter-category input:checked").length);
							}else{

								$(".filter-mob-cnt").addClass("hide");					
							}
						}
					}else{

						if(categoryFilter){

							$("#category_" + categoryFilter ).attr("checked", "checked")
						}
					}

				},
				error : function(error){
					console.log(error) ;
				}
			});

			
		}
	});

	FilterView.prototype.remove = function() {
		this.undelegateEvents();
	};

	FilterView.prototype.clean = function() {
		this.unbind();
    	this.remove();
 
    	delete this.$el;
    	delete this.el;

	};

	return FilterView;
});