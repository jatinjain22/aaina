define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'jcarousel'
], function($,_, Backbone, JST) {

	var SearchBarView = Backbone.View.extend({
		
		el: "main",
		initialize: function() {},
		events: {
			'click .filter-scroll-left' : 'scrollLeft',
			'click .filter-scroll-right' : 'scrollRight',
		},
		scrollLeft : function(){
			 $('.jcarousel').jcarousel('scroll', '-=1');		
		},
		scrollRight : function(){
			 $('.jcarousel').jcarousel('scroll', '+=1');		
		},
		SearchBarLayout : JST['app/templates/talkItOut/search_bar.hbs'],
		render: function() {
			this.$el.find("#search-block").html( this.SearchBarLayout() );
			 $('.jcarousel').jcarousel();
			 $('.jcarousel').jcarousel('scroll', 0);
		}
	
		});

	SearchBarView.prototype.remove = function() {

	};

	SearchBarView.prototype.clean = function() {

	};

	return SearchBarView;
});