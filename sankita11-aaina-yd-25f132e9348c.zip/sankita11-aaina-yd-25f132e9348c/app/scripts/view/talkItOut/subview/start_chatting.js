define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	//'view/signup/page',
	//'view/loaderModal/page'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel) {

	var StartChattingView = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.userModel       = new UserModel()       ;
	//		this.loaderModalView = new LoaderModalView() ;
		},
		events: {
			'click #talkItOut-chat-btn' : 'startChatting',
			'click #talkItOut-chat-btn-mobile' : 'startChatting',	
			'click #book-appointment-btn' : 'bookAppointment',
			'click #book-appointment-btn-mobile' : 'bookAppointment'
		},
		startChatting : function(e){

			var buttonDesc = $(e.currentTarget).attr("data-desc");

			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut-banner",  "home_chat") ;

			}else{

				
				
				Dispatcher.trigger('chatQuickCheck', 'demo', 0);

				//var username     = this.userModel.getUserName() ;
				//var chatStartUrl = Utils.chatUrl() + username   ;
				//location.href = chatStartUrl ;
				//this.loaderModalView.render(username, "demo", chatStartUrl);

			}
			

		},
		bookAppointment : function(e){

			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut-banner",  "book_appointment") ;
			}else{

				//location.href = "/bookAppointment" ;
				Backbone.history.navigate("/bookAppointment", {trigger: true});
				//this.loaderModalView.render(username, "demo", chatStartUrl);

			}

		},
		StartChattingLayout : JST['app/templates/talkItOut/start_chatting.hbs'],
		render: function() {
			this.$el.find("#start-chatting-block").html( this.StartChattingLayout() );
		}
	});

	StartChattingView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	StartChattingView.prototype.clean = function() {
		this.remove() ;
	};

	return StartChattingView;
});