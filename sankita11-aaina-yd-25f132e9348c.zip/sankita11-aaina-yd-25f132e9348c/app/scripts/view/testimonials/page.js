define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'model/testimonials',
	'view/homeVariation/testimonials',
	'Swiper'
], function( $, _, Backbone, JST, TestimonialModel, HvTestimonials ) {
	
	var TestimonialsPage = Backbone.View.extend({
		el: "main",
		initialize: function() {

			this.model = new TestimonialModel();
			this.hvTestimonials = new HvTestimonials();
		},
		events: {},
		TestimonialsLayout : JST['app/templates/testimonials/layout.hbs'],
		render: function() {	
			var self = this ;

			
			

			this.model.fetch({
				success : function(response){
					
					self.$el.html(self.TestimonialsLayout({testimonials:response.attributes}));
					self.hvTestimonials.render();
				},
				error : function(error){
					console.log(error) ;
				}
			}) ;
			return this;
		}
	});

	TestimonialsPage.prototype.remove = function() {};

	TestimonialsPage.prototype.clean = function() {};

	return TestimonialsPage;
});