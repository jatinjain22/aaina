define([
	'jquery',
	'underscore',
	'backbone',
	'event/dispatcher',
	'view/homeNew/subview/articles',
	'view/homeNew/subview/experts',
	'view/homeNew/subview/main_banner',
	'view/home/subview/be_savior',
	'view/home/subview/share_experience',
	'view/home/subview/become_volunteer',
	'view/homeNew/subview/featured_in',
	'view/homeNew/subview/user_reviews',
	'view/homeNew/subview/ebooks',
	'model/users',
	'../../precompiled-templates',
	'smooth-scroll',
	'utils',
	'Swiper',
	'event/dispatcher',
	'view/homeVariation/page',
	'view/homelatest/page',
	'view/leaveMessage/page' ,
	'view/homeNew/subview/survey',
	'view/packages/page'
], function($,_, Backbone, EventBus, ArticlesView, ExpertsView, MainBannerView, BeSaviorView, ShareExperienceView, BecomeVolunteerView,

			FeaturedInView, TestimonialsView, EbooksView, UserModel, JST, SmoothScroll, Utils, Swiper, Dispatcher, HomeVariationView, HomeLatestView,

			LeaveMessageView, SurveyView, PackageView) {

	var HomePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.articlesView = new ArticlesView();
			this.ebooksView = new EbooksView();
	      	this.expertsView  = new ExpertsView() ;
	      	this.mainBannerView = new MainBannerView();
	      	this.userModel       = new UserModel();
	      	this.beSaviorView = new BeSaviorView();
	      	this.shareExperienceView = new ShareExperienceView();
	      	this.becomeVolunteer = new BecomeVolunteerView() ;
	      	this.featuredInView  = new FeaturedInView() ;
	      	this.testimonialsView = new TestimonialsView() ;
	      	this.iInterval = null;
	      	this.swiper = null;
	      	this.iStart = 0;
	      	this.postID = 0 ;
	      	this.packageShow = 0;
	      	window.clearInterval(this.iInterval);
	      	this.leaveMessage       = new LeaveMessageView();
	      	this.homeVariationView  = new HomeVariationView();
			this.packageView = new PackageView();
	      	this.homeLatestView  = new HomeLatestView();
	      	//Utils.fetchCounselorList(this.userModel.getUserID());
			// _.bindAll(this, "reRender")                ;
			this.surveyView = new SurveyView();
			Dispatcher.bind('reRender', this.reRender )
		},
		events: {
      		'click .smoothscroll': 'smoothScroll',
      		'click #home-be-savior' : 'showBeSaviorForm' ,
      		'click #home-share-experience' : 'showShareExperienceForm' ,
      		'click #home-become-volunteer' : 'showBecomeVolunteerForm',
      		'click .go-down': 'goDown',
      		"click .go-to-testimonials": "goToTestimonials",
      		'click #home-chat-online.enabled' : 'openSignUpNowModal' ,
			'click #home-book-appointment' : 'openBookAppModal',
			'click .fexp-chat' : "chatCounselor",
			'click .fexp-msg'  : "msgCounselor",
			'click #home-start-chat-btn-header.enabled' : 'openSignUpNowModal' ,
			'click #video' : 'playVideo',
			'click .home-subscribe-submit' : 'homeSubscribeEmail',
			'keyup .home-subscribe-email' : 'checkForSubscribeEmail',
			'click #allExpertsBtn' : 'takeToExperts',
			'click .download-app-btn' : 'takeToplayStore',
			'click .ban-header-link' : 'trackBannerLinks',
			"click .banner-high-traffic-div a": "leaveMessageBanner",
			"click .banner-high-traffic-row-close": "closeHighTrafficBanner",
			"click .try-it-out":"tryItOut",
			"click .view-more-packages":"viewMorePackages",
			"click .home-ny-container .resolution a" : "redirectToNewYearPage",
			"click .homepage-who-promo-link": "redirectToLetsTalk",
			// "click .hv-promote-action-btn" : "connectToChat"

    	},
    	redirectToLetsTalk: function (e) {
    		var $el = $(e.target),
    			desc = $el.attr("data-desc");

    		if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : desc });
    	},
		redirect: function (options) {
            if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "Fired2FiredUp","Fired2FiredUp", "homeCat" + options.categoryID);
        },
        connectToChat : function(){
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "Fired2FiredUp HomePage",  "Fired2FiredUp HomePage", "free_chat", {options : {type: 'chat',categoryID : 2},callback: this.redirect}) ;
			}else{
				this.redirect({"type"	: 'chat',categoryID : 2});
			}
        },

    	redirectToNewYearPage: function () {
    		if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'NY_HOME' });
    		window.location.href = '/new-year-resolution';
    	},

    	viewMorePackages:function(){
    		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

	           mixpanel.track('Upsell served - View more packages - homepage', { 'mediumSource' : 'website'});
	        }
	       Backbone.history.navigate("/online-counseling-programs", {trigger: true});
    	},
    	tryItOut:function(){
    		var package = this.packageShow;
    		var packageName ="";
    		var url ="";
    		if(package == 0){
				url = "/online-counseling-programs/building-self-confidence";
    			packageName = "Boost your Confidence & Self Esteem";

    		}
    		else if(package == 1){
    			url = "/online-counseling-programs/cope-with-lose-of-someone";
    			packageName = "Grief Counseling";
    		}
    		else if(package == 2){
    			url = "/online-counseling-programs/career-advice";
    			packageName = "Career Decision Making";
    		}
    		else if(package == 3){
    			url = "/online-counseling-programs/advice-on-exam-preparation";
    			packageName = "Effective Exam Preparations";
    		}
    		else if(package == 4){
    			url = "/online-counseling-programs/overcoming-loneliness";
    			packageName = "Overcoming Loneliness";
    		}
    		else if(package == 5){
    			url = "/online-counseling-programs/pre-marital-counseling";
    			packageName = "Pre-Marital Counseling";
    		}
    		else if(package == 6){
    			url = "/online-counseling-programs/post-marriage-counseling";
    			packageName = "Post-Marriage Counseling";
    		}



			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

	           mixpanel.track('Upsell served - packages - homepage', { 'mediumSource' : 'website',  'itemName' : packageName, 'packageName': packageName});
	       }
	       Backbone.history.navigate(url, {trigger: true});

    	},

    	closeHighTrafficBanner: function (e) {
			console.log('hello');
			$('.banner-high-traffic-row').addClass('hide');
		},
    	leaveMessageBanner: function(e) {


			var buttonDesc = 'leaveMessage';
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "message", '' ) ;
			}else{

				this.leaveMessage.render(  ) ;

			}

		},
    	closeEbookEmailPopup : function(e){
    		Utils.closePopup('download-ebook-modal');
    	},

    	downloadWithEmail : function(e){

    		// if ( this.postId == 0 ) {
    		var url = window.location.href ;
			url = url.replace("/talkItOut", "" );
			var postID = $.url( url ).param('postId') ;
			var categoryId = $.url( url ).param('category');
			if ( postID ) {
				this.postID = postID;
			}
			console.log( this.postID );
    		// }
    		var email = $("#download-ebook-email").val() ;
    		console.log( email );
    		$("#ebook-email-error" ).addClass("hide");
			var emailRegex = new RegExp("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$") ;

			if(email.length == 0 || !email.match(emailRegex)){
				$("#ebook-email-error" ).removeClass("hide");
				$("#ebook-email-error" ).html("Please give a valid email id") ;
				return 0 ;
			}

			Utils.closePopup('download-ebook-modal');
			console.log( this.postID );
			this.downloadEbookCall(this.postID,categoryId, email)
			// Utils.displaySuccessMsg("Thank you. The eBook download link has been sent to your email id");
    	},
    	downloadEbookCall: function( postId, categoryId, email ) {

    		var emailJSON = {
				"email": email
			}
			console.log ( postId );
    		$.ajax({
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)
			}).done(function( response ) {
				console.log( response );
				if (categoryId == 100) {
        			Backbone.history.navigate("/talkItOut", {trigger: true});
        		}else {
        			Backbone.history.navigate("/talkItOut?category="+ categoryId, {trigger: true});
        		}

        		if ( categoryId == 31) {
					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on parenting? Here are some counselors who can help:", 8000 );
				}
				else if ( categoryId == 13 ) {
					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Don't let anger or anxiety eat you up. Here are some counselors you can talk to:", 8000);
				}
				else if ( categoryId == 100) {
					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on personality development? These YourDOST counselors can help:", 8000);
				}

			});

    	},
    	browseDownloadEbook: function(e) {
    		var self = this;
    		self.swiper.params.autoplay = 4000
    		self.swiper.startAutoplay();

    		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

	            mixpanel.track('Button Click', { 'mediumSource' : 'website',  'itemName' : "Downloadprompt_browse", 'itemtype': 'ebook download prompt browse'});

			}


    	},
    	downloadEbook: function(e) {
    		console.log( "hello" );
    		var self = this;
    		self.swiper.stopAutoplay();
    		var email;
    		var target = $(e.currentTarget);
    		console.log( 'target' );
    		console.log( target );
    		var downloadEbookTitle = target.context.dataset.ebooktitle;
    		var postId = target.context.dataset.postid;
    		var categoryId = target.context.dataset.categoryid;
    		var extraParams = [postId, categoryId];
    		this.postID = postId;

    		console.log( 'postId: '+postId );
    		console.log( 'ebookTitle '+ downloadEbookTitle );
    		console.log('download ebook button clicked');

    		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

	            mixpanel.track('PDF DOWNLOADS', { 'mediumSource' : 'website',  'itemName' : "Downloadprompt_download", 'desc' : downloadEbookTitle});

			}

    		if ( !Utils.isLoggedIn() ) {

         		Dispatcher.trigger("renderLogin", "Download Free Ebook", "Home Page Download EBook Popup", "download_free_ebook", extraParams ) ;

        	}
        	else {

        		email = self.userModel.getUserEmail();
        		console.log ("email "+ email);
        		if (!email) {
        			// email = Utils.openPopup('download-ebook-modal');
        			if (categoryId == 0) {
        				Backbone.history.navigate("/talkItOut?fromPage=ParentingPrompt&postId="+postId, {trigger: true});
        			}else {

        				Backbone.history.navigate("/talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId, {trigger: true});
        			}

        		}else{
        			self.downloadEbookCall( postId, categoryId, email );
        		}

			}

    	},

    	closePopupEbook: function(e) {
    		$(".ebook-download-div").addClass("hide");
    	},
    	trackBannerLinks : function(e){

    		Utils.trackHomeBannerLinks();
    	},
		openBookAppModal : function (e) {
			var buttonDesc = $(e.currentTarget).attr("data-desc");

				//this.bookAppointmentView.render();
				//location.href = "/bookAppointment" ;
				Backbone.history.navigate("/bookAppointment", {trigger: true});

		},
		takeToExperts : function(e){

			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

				mixpanel.track('ALL EXPERTS', {'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : 'All Experts Button', 'itemMedium' : 'NORMAL'  });
			}

			//location.href = '/talkItOut';
			Backbone.history.navigate("/talkItOut", {trigger: true});

		},
		checkForSubscribeEmail : function(e){

			var email = $(".home-subscribe-email").val();
			var isValidEmail = Utils.formEmailCheck($(".home-subscribe-email").val()) ;
		    if(email != ""){
		        if(!isValidEmail){
			    	$(".home-subscribe-submit span").html("SUBSCRIBE")
			        $(".home-subscribe-submit-error").html("Please enter valid email id");
			        $(".home-subscribe-submit-error").removeClass("hide") ;
			        return false ;
			    }else{

			    	$(".home-subscribe-submit-error").html("");
			    	$(".home-subscribe-submit-error").addClass("hide") ;
			    }
			    if(isValidEmail && e.keyCode == 13){

			    	$(".subscribe-input-div").find(".subscribe-img").removeClass("hide");
			    	//$(".home-subscribe-submit span").html("SUBSCRIBE...")
			    	this.SubscribeArticles(email);
			    }
			}else{

		    	$(".home-subscribe-submit-error").html("");
		    	$(".home-subscribe-submit-error").addClass("hide") ;
		    }
		},
		playVideo :  function(e) {

			var video = document.getElementById("video")
			if(video.paused){

				video.play()
				$(".video-overlay").css({"background" : "rgba(0,191,165,0)"});
			}else{

				video.pause()
				$(".video-overlay").css({"background" : "rgba(0,191,165,0.8)"});
			}
		},
		openSignUpNowModal : function (e) {

			var buttonDesc = $(e.currentTarget).attr("data-desc"),
				$this = $(e.currentTarget);
			Utils.convert({
				'name': 'homePageNew',
				'kpi' : 'banner_chat'
			});

			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "home_chat") ;
			//EventBus.trigger("renderLogin", buttonDesc, "home", "home_chat") ;
			}else{

				/*if ( $(e.currentTarget).hasClass("enabled") ) {

					$(e.currentTarget).removeClass("enabled");
				}*/

			//	if ( !$(e.currentTarget).hasClass("disabled") ) {
					EventBus.trigger('chatQuickCheck', 'demo', 0, "","","home");
					//$(e.currentTarget).html('CONNECTING <img src="https://d1hny4jmju3rds.cloudfront.net/talkItOut/ellipsis.gif" style="vertical-align: middle;">') ;
					//$(e.currentTarget).addClass("disabled");
			//	}

				/*var username = this.userModel.getUserName() ;
				location.href = Utils.chatUrl() + username;*/
			}
			// if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
			// 	mixpanel.track($this.attr('data-mp-title'), {'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : $this.attr('data-mp-desc'), 'itemMedium' : 'NORMAL'  });
			// }



		},
		msgCounselor : function(e){

			var counselorIdName = $(e.currentTarget).attr("data-attr");

			var counselorInfo = {
				id : counselorIdName.split("_")[0] ,
				name : counselorIdName.split("_")[1] ,
			};


			var buttonDesc = $(e.currentTarget).attr("data-desc");
			// if(!Utils.isLoggedIn()){
			// 	EventBus.trigger("renderLogin", buttonDesc, "home", "message", JSON.stringify(counselorInfo)) ;
			// 	//EventBus.trigger("renderLogin", buttonDesc, "home", "message", counselorInfo) ;
			// }else{

			// 	if(!counselorIdName || counselorIdName == undefined || counselorIdName == null ){
			// 		this.leaveMessage.render() ;
			// 	}else{
			// 		this.leaveMessage.render( counselorInfo ) ;
			// 	}

			// }
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "quickMessage", counselorInfo ) ;
			}else{
				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorInfo.id
					}
				});
			}

		},
		SubscribeArticles : function(email){

			$.ajax({
	          method: "POST",
	          url: Utils.contextPath()+'/subscribe',
	          data : email
		    }).done(function(response){

		        $(".home-subscribe-submit").hide() ;
		        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.track('SUBSCRIBE ARTICLES SECTION', {'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : 'subscribe articles section', 'itemMedium' : 'NORMAL'  });
				}
		        //$(".home-subscribe-submit span").html("SUBSCRIBE")
		        $(".subscribe-input-div").find(".subscribe-img").addClass("hide");
		        $(".home-subscribe-email").hide() ;
		        $(".home-subscribe-submit-error").removeClass("hide") ;
		        $(".home-subscribe-submit-error").html("<p class='teal-text'>Got it! You'll start receiving our newsletters soon</p>") ;

		    }).fail(function(error){
		    	//$(".home-subscribe-submit span").html("SUBSCRIBE")
		      	$(".subscribe-input-div").find(".subscribe-img").addClass("hide");
		        console.log(error);
		    });

		},
		takeToplayStore : function(){

	        var macos = navigator.userAgent.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;
	        var url = "http://m.onelink.me/7dc14b6";
/*	        if(!macos){

	          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){


	            mixpanel.track('APP BANNER', {'itemType':'ANDROID', 'medium' : 'website' });
	          }
	          url = 'https://play.google.com/store/apps/details?id=co.yourdost.app&hl=en';
	        }else{

	          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

	            mixpanel.track('APP BANNER', {'itemType':'MACOS', 'medium' : 'website' });
	          }
	          url = 'https://geo.itunes.apple.com/us/app/yourdost/id1053917659?mt=8';
	        }
*/
	        window.open(url , "_blank");
	    },
		homeSubscribeEmail : function(e){

	      var email = $(".home-subscribe-email").val();
	      var isValidEmail = Utils.formEmailCheck($(".home-subscribe-email").val()) ;
	      $(".subscribe-input-div").find(".subscribe-img").removeClass("hide");
	      //$(".home-subscribe-submit span").html("SUBSCRIBE...")
	      if(!isValidEmail){
	      	$(".subscribe-input-div").find(".subscribe-img").addClass("hide");
	        $(".home-subscribe-submit-error").html("Please enter valid email id");
	        $(".home-subscribe-submit-error").removeClass("hide") ;
	        return false ;
	      }
	      this.SubscribeArticles(email);

	    },
		chatCounselor : function(e){

			var chatURL = $(e.currentTarget).attr("data-href") ;
			var buttonDesc = $(e.currentTarget).attr("data-desc");

			var divID = $(e.currentTarget).attr("id");
			var counselorID = divID.split(/-/)[2];

			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL + "BREAKBREAK" + counselorID ) ;
				//EventBus.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL ) ;
			}else{

				//if ( !$(e.currentTarget).hasClass("disabled") ) {
					//$(e.currentTarget).html('<img src="https://d1hny4jmju3rds.cloudfront.net/talkItOut/ellipsis.gif" style="vertical-align: middle;">');
					EventBus.trigger('chatQuickCheck', 'direct', counselorID, chatURL, "", "home" );
					$(e.currentTarget).addClass("disabled");
				//}

/*				if ( !$(e.currentTarget).hasClass("disabled") ) {

					var username =  this.userModel.getUserName() ;
					if(chatURL.search("start") > 1){
						chatURL = chatURL.replace(/\/chat\//, "/chatSession/");
						chatURL = chatURL.replace(/\/start/, '/');
					}else{
						chatURL = chatURL.replace(/\/chat\//, "/chatSession/");
						chatURL = chatURL;
					}
					location.href = chatURL + "&username=" + username;
					$(e.currentTarget).addClass("disabled");

				}
*/


			}
		},

    	goToTestimonials: function(e){
			//location.href = "/testimonials";
			Backbone.history.navigate("/testimonials", {trigger: true});
			return true;
		},
    	showBecomeVolunteerForm : function(e){
    		// this.becomeVolunteer.render() ;
    		// $('select').not('.disabled').material_select();
    		Backbone.history.navigate("/become-an-expert", {trigger: true});
    	},
    	showShareExperienceForm : function (e) {
    		this.shareExperienceView.render();
    	},
    	showBeSaviorForm : function (e) {
    		this.beSaviorView.render() ;
    	},
		template: JST['app/templates/homeNew/layout.hbs'],
		ebookDownloadPopUpLayout: JST['app/templates/homeNew/ebookDownload.hbs'],

		renderVariant: function (variation) {
			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){
                mixpanel.track('homePageVariant', { 'version' : variation});
            }
			var macos = navigator.userAgent.match(/(Mac|iPhone|iPod|iPad)/i) ? "macos" : "android";
			var self = this;
			if (variation == 'current') {
				this.$el.html(this.template({isMobileDevice : Utils.isMobileDevice(), macos : macos, package:self.packageShow}));

				this.mainBannerView.render();

				//anonymous user view rendering
				this.expertsView.render();

				this.testimonialsView.render();

				$.ajax({
					method : "GET",
					url: "/scripts/json/ebooksForPopup.json"
				}).done(function( response ) {
					// console.log( "hello world" );
					console.log( response.posts );
					self.$el.find(".ebook-download-div").html( self.ebookDownloadPopUpLayout( {ebooks: response.posts} ) );
					self.swiper = new Swiper ('.ebook-slides', {
	              		spaceBetween: 300,
	              		loop: true,
	              		// pagination: '.swiper-pagination',
	              		paginationClickable: true,
	        			nextButton: '.swiper-button-next',
	        			prevButton: '.swiper-button-prev',
	              		autoplay: 4000,
	              		autoplayDisableOnInteraction: false
		          	});
		          	// self.swiper = mySwiper;
		          	console.log( "self swiper in ajax" );
		          	console.log( self.swiper );
				});
				console.log( "self swiper" );
				console.log( self.swiper );
				$.ajax({
					method : "GET",
					url : '/scripts/json/statistics.json',
				}).done(function(response){

					//response = JSON.parse(response);

					$.each(response, function(index){

						if(response[index].no_of_people){

							$(".home-ban-extra-txt strong").html(response[index].no_of_people);
						}

						if(response[index].no_of_experts){

							$(".yourdost-always-content .experts strong").html(response[index].no_of_expers);
						}
					})
				}).error(function(error){

					console.log("Error: "+ error);
				})

				this.ebooksView.render();

				this.articlesView.render();

				this.featuredInView.render();

				this.surveyView.render();

				var self = this;

		      	if( self.iInterval ){
		      		self.iInterval = null;
		      		self.iStart = 0;
		      		window.clearInterval(self.iInterval);
		      	}

		      	var tickerArr = ["BUILD HEALTHY PERSONAL RELATIONSHIPS?", "HAVE A MORE PRODUCTIVE WORK LIFE?", "WORK TOWARDS YOUR GOAL WITH ENTHUSIASM?", "BUILD A MORE CONFIDENT SELF?", "FIGHT SOCIETAL PRESSURE?", "IMPROVE YOUR INNER SELF?", "LEAD FROM WITHIN?", "SHARE YOUR GRIEF?"];

		      	$.ajax({
					method : "GET",
					url : '/scripts/json/text_carousel.json',
				}).done(function(response){

					var html ="";
					self.iInterval = window.setInterval(function(){

			      		self.iStart++;
			      		var html = '<a href="/talkItOut?category='+ response[self.iStart].category +'" class="ban-header-link" >'+response[self.iStart].text+'</a>';


						$('.home-carousel .home-ban-change-txt').animate({top:"-1rem", opacity:0}, 1000, function(){
							$('.home-carousel .home-ban-change-txt').css("top", "1rem");

			 				$('.home-carousel .home-ban-change-txt').html(html);
			 				$('.home-carousel .home-ban-change-txt').animate({top:0,opacity:1},'slow');
						});


			      		if( response.length-1 == self.iStart){
			      			self.iStart = 0;
			      		}
			      	},3000);

				}).error(function(error){
					console.log(error);
				});
				$.ajax({

	          		url: Utils.scriptPath() + "/banner.json",
	        		cache: false
	        	}).done( function( data ) {

	            	if ( data.visibility == "on") {
	            		$(".page-title").css("margin-bottom", "0px !important");
	            		$(".banner-high-traffic-row").removeClass("hide");
	            	}

	        	}).error(function(error){

	          		console.log(error)

	        	});
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){
		            mixpanel.track('Home-Page VISIT', { 'mediumSource' : 'website'});
				}
			} else if(variation == 'latest'){
				this.homeLatestView.render();	
			}
			else {
				this.packageView.render()
				//this.homeVariationView.render({variation: variation});
			}
		},
		render: function() {
				if (Utils.isLoggedIn()) {
					Backbone.history.navigate('/dashboard', {"trigger": true});
					return;
				}


				document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
				$('meta[name=description]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
				$('meta[name=title]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
				$('meta[property="og:description"]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
				$('meta[property="og:title"]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
				$('link[rel="canonical"]').attr('href', 'https://yourdost.com/');
			var self = this;
			// $( ".smoothscroll" ).addClass( "hide" );

			/*for randomising date wise
			var now = new Date();
			var start = new Date(now.getFullYear(), 0, 0);
			var diff = now - start;
			var oneDay = 1000 * 60 * 60 * 24;
			var day = Math.floor(diff / oneDay);
			var package = day % 7*/

				var package =Math.floor(Math.random() * 7);
				self.packageShow = package;
			self.renderVariant('latest');
			//use A/B testing library to decide variation
			// Utils.getVariantType({
			// 	'name': 'HomePageLatestExperiment',
			// 	'alternatives': ['current','latest']
			// })
			// .then(function (success) {
			// 	self.renderVariant(success);
			// }, function (err) {
			// 	self.renderVariant('current');
			// });
		},
    	smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -70}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
	    goDown: function(e){
	      $('html, body').stop().animate({
	      scrollTop: $("#testimonials-column").offset().top -70}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    }
	});

	HomePage.prototype.remove = function() {
		window.clearInterval(this.iInterval);
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.undelegateEvents();
    	//this.stopListening();
	};

	HomePage.prototype.clean = function() {
		window.clearInterval(this.iInterval);
		this.remove() ;
	};

	return HomePage;
});
