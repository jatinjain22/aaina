define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousel'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) {

	var StartChatView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		events: {
			'click #home2-scroll-down' : 'scrollToFeaturedExperts'
		},
		scrollToFeaturedExperts : function(e){
			$('html,body').animate({
        		scrollTop: $("#home2-featured-block").offset().top},
        	'slow');
		},
		StartChatViewLayout: JST['app/templates/homeNew/main_banner.hbs'],
		render: function() {
			var self = this;
			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}
			$(".start-chat-block").html(this.StartChatViewLayout({ "isLoggedIn" : Utils.isLoggedIn(), userType : userType, isMobileDevice:Utils.isMobileDevice() }));
			$.ajax({
				method: 'GET',
				dataType: 'JSON',
				url: Utils.contextPath() + '/v1/dashboard/ongoingCnt'
			}).done(function(response){
				var noOfPeopleOnline = parseInt(response) + 20;
				$('.home-chat-app-btns .talkItOutV2-noOfPeopleOnline-text .talkItOutV2-noOfPeopleOnline').text(noOfPeopleOnline);
			});

			// $.ajax({
			// 	method : "GET",
			// 	url : '/scripts/json/statistics.json',
			// }).done(function(response){

			// 	console.log(response);
			// 	$.each(response, function(index){

			// 		if('main_banner' in response[index]){

			// 			$(".start-chat-block").find(".parallax img").attr("src", response[index].main_banner);
			// 		}
			// 		if('no_of_people' in response[index]){

			// 			$(".home-ban-extra-txt strong").html(response[index].no_of_people);
			// 		}
			// 	})
			// }).error(function(error){

			// 	console.log("Error: "+ error);
			// })

		}
	});

	StartChatView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	StartChatView.prototype.clean = function() {
		this.remove() ;
	};

	return StartChatView;
});
