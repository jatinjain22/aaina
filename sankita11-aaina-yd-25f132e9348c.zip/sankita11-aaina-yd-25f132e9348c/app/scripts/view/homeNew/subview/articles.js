define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'jcarousellite',
	'config',
	'Swiper'
	//'jquery-swipe'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var ArticlesView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {},
		events: {
			'click .home-articles' : 'redirectToBlog' ,
			'click .article-cat-title a' : 'stopParentClick',
			'click .article-author a' : 'stopParentClick',
		},
		stopParentClick : function(e){
			e.stopPropagation();
		},
		redirectToBlog : function(e){
			e.preventDefault();
			e.stopPropagation();
			var url = $(e.currentTarget).attr("data-href");
			window.open(url, "_self");
		},	
		ArticlesViewLayout: JST['app/templates/homeNew/articles.hbs'],
		render: function() {

			var self = this ;

			var callSwiper = function(space){

				var mySwiper = new Swiper ('.articles-slider', {
						    
				    loop: true,
				    slidesPerView: 3,
				    nextButton: '.articles-direction-left',
				    prevButton: '.articles-direction-right',
				
				    spaceBetween: space,
				    centeredSlides: true,
				    autoplay: 3000,
				    breakpoints: {
					    // when window width is <= 320px
					    320: {
					      slidesPerView: 'auto',
					      spaceBetweenSlides: 5
					    },
					    // when window width is <= 480px
					    480: {
					      slidesPerView: 'auto',
					      spaceBetweenSlides: 5
					    },
					    // when window width is <= 640px
					    640: {
					      slidesPerView: 'auto',
					      spaceBetweenSlides: 10
					    },
					    768: {
					      slidesPerView: 'auto',
					      spaceBetweenSlides: 20
					    },
					    992: {
					      slidesPerView: 3,
					      spaceBetweenSlides: 20
					    },
					    1024: {
					      slidesPerView: 3,
					      spaceBetweenSlides: 20
					    }
					}
				})  
			}

			// $.ajax({
			// 	method : "GET",
			// 	dataType: 'jsonp',
			// 	url : Utils.bloghomeJson()//'/scripts/json/blog.json'//Utils.blogJson()//'/scripts/json/blog.json'// 
			// }).done(function(response){

			// 	if(response.posts.length > 3){

			// 		$(".articles-block").html(self.ArticlesViewLayout({ post : response.posts }));
			// 			var space = 30;
			// 			if(Utils.isMobileDevice()){

			// 				space = 5
			// 			}
						
			// 			callSwiper(space);	
			// 	}else{

					$.ajax({
						method : "GET",
						dataType: 'jsonp',
						url : Utils.blogJson()//'/scripts/json/blog.json'//Utils.blogJson()//'/scripts/json/blog.json'// 
					}).done(function(response){
						console.log(response.posts);

						$(".articles-block").html(self.ArticlesViewLayout({ post : response.posts }));
						var space = 30;
						if(Utils.isMobileDevice()){

							space = 5
						}
						
						callSwiper(space);   
					}).error(function(error){
							
						console.log(error);
					});
			// 	}
			// }).error(function(error){

			// 	console.log(error);
			// });	

		}
	});	

	ArticlesView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	ArticlesView.prototype.clean = function() {
		this.remove() ;
	};

	return ArticlesView;
});
