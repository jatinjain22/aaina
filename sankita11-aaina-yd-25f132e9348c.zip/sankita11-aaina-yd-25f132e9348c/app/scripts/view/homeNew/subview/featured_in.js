define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var FeaturedInView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {},
		events: {
			'mouseenter .media-img' : 'changeImg',
			'mouseleave .media-img' : 'changeImgBack'
		},
		FeaturedInViewLayout: JST['app/templates/homeNew/featured_in.hbs'],

		changeImg : function(e){

			var that = $(e.currentTarget).parents(".featuredin-img");

			that.find('.red-img').removeClass('hide');
			that.find('.grey-img').addClass('hide');

		},
		changeImgBack : function(e){

			var that = $(e.currentTarget).parents(".featuredin-img");

			that.find('.red-img').addClass('hide');
			that.find('.grey-img').removeClass('hide');

		},
		render: function(element) {
			var self = this ;
			$.ajax({
				url : "https://d3dlm19tttbkds.cloudfront.net/featured_in.json",
			}).done(function(response){
				if (element) {
					$(element).html(self.FeaturedInViewLayout( {featuredIn : response.featuredIn}));
					return;
				} 
				$(".featured-in-block").html(self.FeaturedInViewLayout( {featuredIn : response.featuredIn}));
			}).error(function(error){
				console.log(error) ;
			});

		}
	});

	FeaturedInView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	FeaturedInView.prototype.clean = function() {
		this.remove() ;
	};

	return FeaturedInView;
});
