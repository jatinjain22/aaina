define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousellite'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) {

	var FeaturedExpertsView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		events: {

		},
		renderReviews:function(counselorToPrint){


			_.each(counselorToPrint, function(value, key){

					$.ajax({
						url : Utils.contextPath() + "/v1/counselor/"+ value.id +"/ratingFavoriteCnt",
					}).done(function(response){

						if(response.rating == 0){
							$(".expert-rating-cnt-"+ value.id).html('');
						}else{
							$(".expert-rating-cnt-"+ value.id + " span").html( response.rating + ' reviews');
						}


						self.favouriteCnt = response.favorite;

						var peopleStr = "people"
						if((self.favouriteCnt ) <= 1){
							peopleStr = "person" ;
						}
						$(".favorite-cnt").html( response.favorite + ' ' + peopleStr);


					}).error(function(error){
						console.log(error);
					});
				});
		},
		renderFeaturedExperts : function(){

			var self = this ;

			var params = '';
			if(Utils.isLoggedIn()){
				params = "&user=" + self.userModel.getUserID();
			}

			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/?page_number=1"
			}).done(function(response){

				var counselorToPrint  =  response.slice(0,3) ;
				if(Utils.isMobileDevice() && !Utils.isIpadDevice() && window.innerWidth < 640){

					counselorToPrint  =  response.slice(0,2) ;
				}
				_.each(counselorToPrint, function(item){
					var hyphenatedName = item.name.replace(/\s/g , "-");
					var counselorProfileIdentifier = hyphenatedName + '-'+item.id;
					item["identifier"] = counselorProfileIdentifier
				})
				var header = "FEATURED EXPERTS";
				$(".home-experts-column").html(self.FeaturedExpertsViewLayout({ counselor : counselorToPrint , header : header}));


 				$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){

					_.each(response, function(value, key){

						if( value.status == "true" && $("#chat-home2-" + key).length ){
							$("#chat-home2-" + key).removeClass("hide");
							$("#chat-home2-" + key).attr("data-href", value.url);

						}
					});
					self.renderReviews(counselorToPrint);
				}).error(function(error){

				});


			}).error(function(error){
				console.log(error);
			});


		},

		FeaturedExpertsViewLayout: JST['app/templates/homeNew/experts.hbs'],
		render: function() {

			var self = this ;

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			if(Utils.isLoggedIn() && userType != 'OPERATOR'){
				$.ajax({
					method : "GET",
					url : Utils.contextPath() + "/v1/counselor/?familiar=true&user=" + self.userModel.getUserID()
				}).done(function(response){

					if(response.length > 0){
						var counselorToPrint  =  response.slice(0,3) ;
						if(Utils.isMobileDevice()){
							counselorToPrint  =  response.slice(0,2) ;
						}
						_.each(counselorToPrint, function(item){
							var hyphenatedName = item.name.replace(/\s/g , "-");
							var counselorProfileIdentifier = hyphenatedName + '-'+item.id;
							item["identifier"] = counselorProfileIdentifier
						})

						var header = "MY EXPERTS";
						$(".home-experts-column").html(self.FeaturedExpertsViewLayout({ counselor : counselorToPrint , header : header}));

		 				$.ajax({
							url : Utils.contextPath() + '/v1/counselor/status' ,
						}).done(function(response){
							_.each(response, function(value, key){
								if( value.status == "true" && $("#chat-home2-" + key).length ){
									$("#chat-home2-" + key).removeClass("hide");
									$("#chat-home2-" + key).attr("data-href", value.url);

								}
							});
						}).error(function(error){

						});

					}else{
						self.renderFeaturedExperts();
					}

					var counselorToPrint  =  response.slice(0,3) ;
					self.renderReviews(counselorToPrint);

				}).error(function(error){
					console.log(error);
				});
			}else{
				self.renderFeaturedExperts();
			}

/*			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/?page_number=1"
			}).done(function(response){

				var counselorToPrint  =  response.slice(0,3) ;
				if(Utils.isMobileDevice()){

					counselorToPrint  =  response.slice(0,2) ;
				}
				var header = "Featured Experts";
				$(".home-experts-column").html(self.FeaturedExpertsViewLayout({ counselor : counselorToPrint , header : header}));


 				$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){

					_.each(response, function(value, key){

						if( value.status == "true" && $("#chat-home2-" + key).length ){
							$("#chat-home2-" + key).removeClass("hide");
							$("#chat-home2-" + key).attr("data-href", value.url);

						}
					});
				}).error(function(error){

				});
				}).error(function(error){
				console.log(error);
			});
*/
		}
	});

	FeaturedExpertsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	FeaturedExpertsView.prototype.clean = function() {
		this.remove() ;
	};

	return FeaturedExpertsView;
});
