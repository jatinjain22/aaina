define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/testimonials',
	'Swiper'
], function($,_, Backbone, JST, TestimonialModel ) {

	var UserReviewView = Backbone.View.extend({

		el: "#user-review-block",
		initialize: function() {
			this.model = new TestimonialModel();

			this.globalSwiper = "";
		},
		events: {
			"mouseenter .swiper-slide" : "stopSwiper",
			"mouseleave .swiper-slide" : "startSwiper",

		},

		stopSwiper : function(e){

		    this.globalSwiper.params["autoplay"] = 99999;

		},
		startSwiper : function(e){

		    this.globalSwiper.params["autoplay"] = 15000;

		},
		UserReviewViewLayout:JST['app/templates/homeNew/user_reviews.hbs'],
		render: function() {

			var self = this;			

			$.ajax({
				method : "GET",
				url : '/scripts/json/user_reviews.json',
				contentType: 'text/plain',
			}).done(function(response){
				console.log(response);
				$("#user-review-block").html(self.UserReviewViewLayout({testimonials : response}));
				var mySwiper = new Swiper ('.home-testimonials', {
				    
				   	pagination: '.testimonials-pagination',
	        		paginationClickable: true,
	        		autoplay: 15000,
				});

				self.globalSwiper = mySwiper ;
				
				$(".swiper-slide")
					.mouseenter(function(){

						self.stopSwiper();
					})
					.mouseleave(function(){

						self.startSwiper();
				});

			}).error(function(error){
				console.log(error);
			});

			     
					
		}
	});

	UserReviewView.prototype.remove = function() {

	};

	UserReviewView.prototype.clean = function() {

	};

	return UserReviewView;
});
