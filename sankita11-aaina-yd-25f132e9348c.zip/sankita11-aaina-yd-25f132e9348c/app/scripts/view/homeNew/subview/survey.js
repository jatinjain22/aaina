define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function($,_, Backbone, JST, Utils) {

	var SurveyView = Backbone.View.extend({

		el : 'main' ,

		initialize: function() {

		},

		events: {

			"click .valentines-campaign .close-pop": "surveyDisappear",
			"click .survey-mark" : "registerMixpanel"
		},

		surveyDisappear :function(e){

     		$(e.currentTarget).parents(".valentines-campaign").addClass("hide");
			date = new Date()
            date.setTime(date.getTime()+(60*60*1000))
		 	$.cookie("campaign-closed", "yes", { path: '/', expires:date })

		 	if ( typeof mixpanel != 'undefined' && typeof mixpanel.track === "function" ){ 

	           mixpanel.track('Button Click', { 'itemName':'LetsTalk Campaign Closed'});
	        }
    	},

    	registerMixpanel : function(){

    		if ( typeof mixpanel != 'undefined' && typeof mixpanel.track === "function" ){ 

	           mixpanel.track('Button Click', { 'itemName':'LetsTalk Campaign'});
	        }
    	},

		SurveyViewLayout: JST['app/templates/homeNew/survey.hbs'],

		render: function() {

			this.$el.append(this.SurveyViewLayout());

			if(typeof jQuery.cookie('campaign-closed') != 'undefined' && jQuery.cookie("campaign-closed") == "yes"){
				
				$(".valentines-campaign").addClass("hide")
			}else{
				
			 	// $(".valentines-campaign").removeClass("hide")
			}
		}
	});

	SurveyView.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	SurveyView.prototype.clean = function() {

		this.remove() ;
	};

	return SurveyView;
});
