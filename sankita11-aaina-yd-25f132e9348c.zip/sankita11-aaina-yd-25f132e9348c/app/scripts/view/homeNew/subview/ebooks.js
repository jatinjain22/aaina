define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousellite',
	'config',
	'Swiper'
	//'jquery-swipe'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel) {

	var EbooksView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.ebooksResponse = {};
			this.userModel       = new UserModel();
			this.swiper = null;
		},
		events: {
			"mouseover .home-page-ebook-card": "showDescription",
			"mouseout .home-page-ebook-card": "hideDescription", 
			"click .home-page-ebook-card": "downloadEbook"	

		},
			
		EbooksViewLayout: JST['app/templates/homeNew/ebooks.hbs'],

		downloadEbookCall: function( postId, categoryId, successMsg, email ) {
    		
    		var self = this;

			var emailJSON = {
				"email": email
			}
		
			$.ajax({
		
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)

			}).done(function( data ) {
		
				console.log( data );
				
				if (categoryId == 100) {

	    				Backbone.history.navigate("/talkItOut?from=showAllExperts",{trigger:true});	
	    		}
	    		else {
	    				Backbone.history.navigate("/talkItOut?from=showAllExperts&category=" + categoryId,{trigger:true});
	    		}
	    		
	    		console.log( successMsg );
				Utils.displaySuccessMsgWithDelay( successMsg, 8000 );
			});
    	},

		downloadEbook: function(e) {
    		
    		var self = this;
    		e.preventDefault();
    		var email;
    		var target = $(e.currentTarget);
    		var postId = target.find('.home-page-ebook-card-reveal-download').attr('data-postid');
    		console.log("postid "+ postId);
    		var categoryId = self.ebooksResponse[postId]['categoryId'];
    		var successMsg = self.ebooksResponse[postId]['successMsg'];
    		var downloadEbookTitle = self.ebooksResponse[postId]['title'];


    		console.log( 'categoryId '+ categoryId );
    		var extraParams = [postId, categoryId, successMsg]; 
    		

    		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){ 

	            mixpanel.track('PDF DOWNLOADS', { 'medium' : 'website',  'itemName' : "Downloadprompt_download", 'desc' : downloadEbookTitle});

			}

    		if ( !Utils.isLoggedIn() ) {
         
         		Dispatcher.trigger("renderLogin", "Download Free Ebook", "home_page_download_eBook_popup", "download_free_ebook", extraParams ) ;          

        	}
        	else {

        		email = self.userModel.getUserEmail();
        		if (!email) {
        			// email = Utils.openPopup('download-ebook-modal');
        			if (categoryId == 0) {

        				Backbone.history.navigate("/talkItOut?from=showAllExperts&fromPage=EbookPrompt&postId="+postId,{trigger:true});	
        			}
        			else {
        				Backbone.history.navigate("/talkItOut?from=showAllExperts&category="+ categoryId +"&fromPage=EbookPrompt&postId="+postId,{trigger:true});
        			}

        		}
        		else {
        			self.downloadEbookCall(  postId, categoryId, successMsg, email);	
        		}
        		
				
			}
		},	

		hideDescription: function(e) {
			
			var self = this;
			self.swiper.startAutoplay();
			$(e.currentTarget).find('.card-reveal').velocity(
            {translateY: 0}, {
              duration: 225,
              queue: false,
              easing: 'easeInOutQuad',
              complete: function() { $(this).css({ display: 'none'}); }
            }
          );
			$(e.currentTarget).find('.home-page-ebook-card-reveal-download-div').removeClass("changeButton");
		},

		showDescription: function(e) {

			var self = this;
			self.swiper.stopAutoplay();
			console.log( $(e.currentTarget) );
			console.log( "hello");
			console.log( "hello1");
			$(e.currentTarget).closest('.card').css('overflow', 'hidden');
			$(e.currentTarget).find('.home-page-ebook-card-reveal-download-div').addClass("changeButton");
			$(e.currentTarget).find('.card-reveal').css({ display: 'block'}).velocity("stop", false).velocity(
          		{translateY: '-100%'}, 
          		{duration: 300, 
          		queue: false, 
          		easing: 'easeInOutQuad'});

		},
		render: function() {

			var self = this ;
			$.ajax({
				method : "GET",
				url : Utils.scriptPath() + "/ebooksOnHomePage.json",
				cache: false
			}).done(function(response){
				
				self.ebooksResponse = response;
				console.log(response);
				console.log( $(".home-page-ebooks") );
				$(".home-page-ebooks").html( self.EbooksViewLayout({ post : response}) );
				
				self.swiper = new Swiper ('.home-page-ebooks-slider', {
				    
				    loop: true,
				    slidesPerView: 4,
				    nextButton: '.home-page-ebook-direction-right',
				    prevButton: '.home-page-ebook-direction-left',
				    spaceBetween: 5,
				    centeredSlides: false,
				    autoplay: 3000,
				    preloadImages: true
				    
				});

			}).error(function(error){
					console.log(error);
			});

		}
	});	

	EbooksView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	EbooksView.prototype.clean = function() {
		this.remove() ;
	};

	return EbooksView;
});
