define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'Swiper',
	'event/dispatcher',
	'purl'

] , function( $, _, Backbone, Utils, JST, Swiper, Dispatcher ) {

	var valentinePage = Backbone.View.extend({

		el: "main",

		initialize : function(){

			var l = window.location.pathname.split("/").length-1;

			this.category = window.location.pathname.split("/")[l];
		},

		events : {

			'click .vchat-btn' : 'redirectToChat',
			'click .vyd-logo img' : 'mixpanelEvents'
		},

		redirectToChat : function(){

			this.registerMixpanelEvents("Button Click", "Valentines Landing Page"+this.category, "Valentines "+this.category);

			if(!Utils.isLoggedIn()){
				
				Dispatcher.trigger("renderLogin",  "Valentines Landing Page"+this.category, "home", "home_chat") ;
			}else{
	
				Dispatcher.trigger('chatQuickCheck', 'demo', 0);
			}
		},

		mixpanelEvents : function( ){

			this.registerMixpanelEvents("Button Click", "Valentines Landing Page"+this.category, "Valentines "+this.category);
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		getContent : function( category ){

			var defer = $.Deferred();

			$.ajax({

				method : 'GET',
				url : Utils.scriptPath() + '/valentine.json'

			}).done( function( response ){

				defer.resolve( response[category]);

			}).error( function( error ){

				defer.reject(error);
			})

			return defer.promise();
		},

		mainLayout : JST['app/templates/valentine/layout.hbs'],
		contentLayout : JST['app/templates/valentine/content.hbs'],

		setMetaData : function( data ){

			document.title= data.title;
			
			$('meta[name=description]').attr('content', data.description);
			$('meta[name=title]').attr('content', data.title);
			
			$('meta[property="og:description"]').attr('content', data.description);
			$('meta[property="og:title"]').attr('content',data.title);
			$('meta[property="og:image"]').attr('content',data.imageUrl);
			
			$('link[rel="canonical"]').attr('href', location.href);
		},

		render : function(){

			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			$(".dost-main").css({"min-height" : "100vh"})
			$('body').css("overflow","hidden");
			this.$el.html(this.mainLayout());

			var self = this;

			this.registerMixpanelEvents("Landing Page Served", "Valentines Landing Page"+this.category, "Valentines "+this.category);

			this.getContent( this.category )
			.then( function( content ){

				$(".v-container-inner").html( self.contentLayout( { content : content } ) )
				self.setMetaData(content.metaData)

			}, function( error ){

				console.log("Error ", error);
			})
		}
		
	});

	valentinePage.prototype.remove = function() {

		$("#main-header").show();
		$(".dost-main").css({"min-height" : "93vh"})
		$(".feedback-form-btn").removeClass("hide")
		$('body').css("overflow","auto");
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	valentinePage.prototype.clean = function() {

		this.remove() ;
	};

	return valentinePage;
});
