define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates'
], function($, _, Backbone, JST ) {
	
	var PrivacyPolicyPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
		},
		events: {},
		PrivacyPolicyLayout : JST['app/templates/privacyPolicy/layout.hbs'],
		render: function() {

	        document.title="Privacy Policy | YourDOST";
	        $('meta[name=description]').attr('content', "By using our Service you understand and accept this privacy policy along with any amendments or modifications as may be made from time to time");
	        $('meta[name=title]').attr('content',"Privacy Policy | YourDOST");
	        $('meta[property="og:description"]').attr('content', "By using our Service you understand and accept this privacy policy along with any amendments or modifications as may be made from time to time");
	        $('meta[property="og:title"]').attr('content',"Privacy Policy | YourDOST");
	        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/privacyPolicy');
                  
			this.$el.html(this.PrivacyPolicyLayout({}));
		}
	});

	PrivacyPolicyPage.prototype.remove = function() {};

	PrivacyPolicyPage.prototype.clean = function() {};

	return PrivacyPolicyPage;
});