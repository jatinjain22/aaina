define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'model/users',
	'view/paymentPending/payment_pending',
	'ajax-chosen',
	'utils',
], function($,  _, Backbone, JST, UserModel,PaymentPendingView, ajax_chosen, Utils) {
	var user_group = [];
	var img_src = "";
	var UserProfilePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			//$("input.cloudinary-fileupload[type=file]").cloudinary_fileupload();
			this.userModel     = new UserModel() ;
			this.userID        = this.userModel.getUserID() ;
			this.userInfo      = {} ;
			this.community     = {} ;
			this.userCommunity = {} ;
			this.paymentPendingView = new PaymentPendingView() ;
			this.selectedCommunity = new Array();
		},
		events: {
			'click .edit-details' : 'editDetails' ,
			'click .cancel-btn'   : 'cancelEdit'  ,
			'click .save-btn'     : 'saveDetails' ,
			'click .addCat'       : 'editDetails' ,
			'click #edit-image'   : 'editImage'   ,
			'click .avatar-img-signup' : 'selectAvatar',
			'click #avatars-modal .mclose' : 'hideContainer',
			'click #edit-communities' : 'showAutoComplete' ,
			'click #switch-input' : 'updateClientHistoryConsent',
			'click .validateOrgId' : 'validateOrg'
		},
		validateOrg : function(evt){
			var self = this;
			var userId = self.userModel.getUserID() ;
			var refCode = $("#refCode").val()
			if(!refCode || refCode == "") return;
			$(".validate-error").hide()
			var dataToSend = {
				"referralCode": refCode
			}
			$.ajax({
				method : 'POST',
				url : Utils.contextPath() + '/v1/organization/validate',
				dataType : 'json',
				contentType : 'application/json',
				data : JSON.stringify(dataToSend)
			}).done(function(data){
				$(".validate-orgid").html("<div class='col s12'><span class='validate-tick'><i class='mdi mdi-check'></i></span>Your account has been successfully linked with your organization.</div>")
				window.userdata = data;
				self.userModel.save(data) ;
			}).error(function(err){
				$(".validate-error").show()
			})
		},
		showAutoComplete : function(e){
			if(Utils.isMobileDevice())
				$("#edit-communities").autocomplete('search', "");
		},
		fileSelectHandler : function(e){

			alert("hello", e);
		    // get selected file
		    var oFile = $('#counselorImg')[0].files[0];

		    // hide all errors
		    $('.error').hide();

		    // check for image type (jpg and png are allowed)
		    var rFilter = /^(image\/jpeg|image\/png)$/i;
		    if (! rFilter.test(oFile.type)) {
		        $('.error').html('Please select a valid image file (jpg and png are allowed)').show();
		        return;
		    }

		    // check for file size
		    if (oFile.size > 250 * 1024) {
		        $('.error').html('You have selected too big file, please select a one smaller image file').show();
		        return;
		    }

		    //Utils.openPopup('login-modal') ;

		    // preview element
		    var oImage = document.getElementById('preview');

			alert('pv');
		},
		hideContainer : function(e){
			Utils.closePopup('avatars-modal');
		},
		selectAvatar : function(e){
			var avatarID = $(e.currentTarget).attr("id") ;
			$(".avatar-img-signup").removeClass("avatar-selected") ;
			$("#" + avatarID).addClass("avatar-selected") ;
			$("#selected-avatar-id").val(avatarID) ;

			var imgUrl = Utils.avatarToImage(avatarID);

			$(".user-profile-img").attr('src', imgUrl);
			this.hideContainer() ;
		},
		editImage : function(e){
			Utils.openPopup('avatars-modal') ;
		},
		addCategory : function(e){

			$("#edit_communities_chosen").removeClass("hide") ;
			$("#edit-communities").removeClass("hide")        ;
			this.editCategory();

			$(".profile-cat-list .non-editable").addClass("hide") ;
			$(".addCat").addClass("hide") ;

			$(".profile-info-cancel-save").removeClass("hide");
			$("#profile-info .edit-details").addClass("hide");
		},
		editDetails : function(e){

			var dataAttr = $(e.currentTarget).attr("data-attr") ;

			$("#" + dataAttr + " .non-editable" ).addClass("hide");
			$("#" + dataAttr + " .editable-input" ).removeClass("hide");

			if(dataAttr == "profile-info"){
				$("#" + dataAttr ).removeClass("yellow lighten-1");
				$("#" + dataAttr ).addClass("white");
				$("#edit_communities_chosen").removeClass("hide") ;
				$("#edit-image").removeClass("hide") ;
				//this.editCategory();
			}

			$("." + dataAttr + "-cancel-save").removeClass("hide");
			$("#" + dataAttr + " .edit-details").addClass("hide");

		},

		cancelEdit : function(e){

			var dataAttr = $(e.currentTarget).attr("data-attr") ;

			$("#" + dataAttr + " .non-editable" ).removeClass("hide");
			$("#" + dataAttr + " .editable-input" ).addClass("hide");

			if(dataAttr == "profile-info"){
				$("#" + dataAttr ).addClass("yellow lighten-1");
				$("#" + dataAttr ).removeClass("white");
				$("#form-error-pemail").html("") ;
				$("#email-input").val("") ;
				$("#edit-image").addClass("hide") ;
				$(".profile-info-cancel-save .save-btn").removeClass("grey-text") ;

/*				$("#edit_communities_chosen").addClass("hide") ;
				if(Utils.isMobileDevice()){
					$("#edit-communities").val() ;
				}else{
					$("#edit-communities").html("");
					setTimeout( function(){
						$("#edit-communities").chosen({
							width: "100%"
						});
						$("#edit-communities").trigger("chosen:updated");
					},100);
				}
*/
			}
			$("." + dataAttr + "-cancel-save").addClass("hide");
			$("#" + dataAttr + " .edit-details").removeClass("hide");

		},
		saveDetails : function(e){

			var self = this ;

			var emailError = $("#form-error-pemail").html() ;
			if(emailError.length > 0 ){
				return 0 ;
			}

			var dataAttr      = $(e.currentTarget).attr("data-attr") ;
			if(dataAttr == "profile-info"){
				$("#" + dataAttr ).addClass("yellow lighten-1");
				$("#" + dataAttr ).removeClass("white");
				$("#edit-image").addClass("hide") ;
			}

			var editableInput = $("#" + dataAttr + " .editable-input" ) ;
				console.log(self.userInfo);
			var infoToEdit = this.userInfo ;
			_.each(editableInput, function(elem){

				var editedVal = $(elem).val() ;
				var dataProp  = $(elem).attr("data-property");

				if($(elem).attr("parent-property") == "customProperties"){


					if($(elem).attr("name") == "gender"){
						var genderSelected = $("input[name='gender']:checked").val() ;
						if(genderSelected == undefined)
							editedVal = "" ;
						else
							editedVal = genderSelected ;
					}

					infoToEdit["customProperties"][dataProp] = [editedVal] ;
					if(editedVal.length <= 0 ){
						$("#" + dataProp).html('N/A') ;
						$(elem).val('') ;
					}else{
						$("#" + dataProp).html(editedVal) ;
						$(elem).val(editedVal) ;
					}

				}/*else if( $(elem).attr("id") != undefined && $(elem).attr("id") == "edit-communities"){
					var editedCat = $("#edit-communities").val();

					var communityArr = editedCat ;
					if(Utils.isMobileDevice()){
						communityArr = new Array() ;
						var communitiesSelected = editedCat.split(", ");
						_.each(communitiesSelected, function(elem){
							if(!elem.trim()){
								return false ;
							}
							communityArr.push(elem.trim()) ;
						});

						editedCat = communityArr ;
					}

					self.userCommunity = editedCat ;

					$(".profile-cat-list").html("") ;
					if(editedCat != null ){
						$.each(editedCat, function(eachID, val){
							$(".profile-cat-list").append('<div class="profile-category yellow darken-1 non-editable" data-value="'+val+'">'+val+'</div>') ;
						});
					}

					infoToEdit['userCommunities'] = editedCat;

				}*/else{
					infoToEdit[dataProp] = editedVal ;
					if(dataProp == "email" && editedVal.length <= 0 ){
						$("#" + dataProp ).html("No email Provided");
					}else{
						$("#" + dataProp ).html(editedVal);
					}

					$(elem).val(editedVal) ;
				}

			});

			self.userInfo = infoToEdit ;

			var self = this ;
			$.ajax({
				url : Utils.contextPath() + "/v2/users/"+self.userID +"/modify/profile",
				method : "POST" ,
				dataType : "json" ,
				xhrFields: {
     				 withCredentials: true
			    },
				contentType: "application/json",
				data : JSON.stringify(infoToEdit)
			}).done(function(response){
	 	        localStorage.removeItem("user");
				self.cancelEdit(e) ;
			}).error(function(error){
				console.log("error") ;
				console.log(error) ;
			});
		},
		checkForEmail : function(e){
			var email = $("#email-input").val() ;
			console.log("hh") ;
			console.log(email) ;

			if(!email.match(/^(((([a-z\d][\.\-\+_]?)*)[a-z0-9])+)\@(((([a-z\d][\.\-_]?){0,62})[a-z\d])+)\.([a-z\d]{2,6})$|^$/i)){
				$("#form-error-pemail").html("Please enter valid email id");
				$("#form-error-pemail").removeClass("hide") ;
				$(".profile-info-cancel-save .save-btn").addClass("grey-text") ;
				return 0 ;
			}

			if(email.length == 0){
				$("#form-error-pemail").html("");
				$("#form-error-pemail").addClass("hide") ;
				$(".profile-info-cancel-save .save-btn").removeClass("grey-text") ;
				return 1 ;
			}

			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
				statusCode:{
            		404 : function(){
						$("#form-error-pemail").html("");
						$("#form-error-pemail").addClass("hide") ;
						$(".profile-info-cancel-save .save-btn").removeClass("grey-text") ;
            		}
        		},

			}).done(function(response){
				if(response == true){
					$("#form-error-pemail").html("This email already exists");
					$(".profile-info-cancel-save .save-btn").addClass("grey-text") ;
				}
			}).error(function(error){
				console.log(error) ;
			});



		},
		updateClientHistoryConsent : function(e) {
			e.stopPropagation();
			console.log("hello world");
			console.log($(e.currentTarget));
			var switchValue = $("#switch-input").is(":checked");
			var self = this;
			if(switchValue) {
				console.log(self.$el.find("#user-consent-false-para").text());
				$("#user-consent-false-para").addClass("hide");
				$("#user-consent-true-para").addClass("hide");
				$("#user-consent-false-title").addClass("hide");
				$("#user-consent-true-title").addClass("hide");
				$("#user-consent-common-title").html("History can be seen by all experts");
				$("#user-consent-common-para").html("Experts you contact with can see your conversation history, to understand your problems quickly and provide better solutions");
				$("#user-consent-common-para").removeClass("hide");
				$("#user-consent-common-title").removeClass("hide");
			}
			else {
				console.log(self.$el.find("#user-consent-true-para").text());
				$("#user-consent-false-para").addClass("hide");
				$("#user-consent-true-para").addClass("hide");
				$("#user-consent-false-title").addClass("hide");
				$("#user-consent-true-title").addClass("hide");
				$("#user-consent-common-title").html("History can not be seen by all experts");
				$("#user-consent-common-para").html("Turn on if you want experts to be able to see your conversation history so that they can understand your problems quickly and provide better solutions");
				$("#user-consent-common-para").removeClass("hide");
				$("#user-consent-common-title").removeClass("hide");
			}
			console.log("user consent " + self.userModel.getUserConsent());
			$.ajax({
				method: "POST",
				url: Utils.contextPath() + '/v2/users/user/'+ self.userModel.getUserID() +'/clientHistoryConsentUpdate/'+ switchValue
			}).done(function(response){
				console.log(response);
				localStorage.removeItem("user");
				//self.editCategory() ;
			}).fail(function(error){});

		},
		editCategory : function(){
			var categories = this.community;
			var userCommunity = this.userCommunity  ;

			var userCommunityMap = {};

			userCommunity.map(function(obj){
				userCommunityMap[obj] = 1 ;
				return userCommunityMap ;
			});

			var selectedCommunity = new Array() ;

			if(Utils.isMobileDevice()){

				if(userCommunity.length > 0 ){
					$( "#edit-communities" ).val(userCommunity.join(", ")) ;
				}

				$( "#edit-communities" )
					.bind( "keydown", function( event ) {
						if ( event.keyCode === $.ui.keyCode.TAB &&
						    $( this ).autocomplete( "instance" ).menu.active ) {
						  event.preventDefault();
						}
					})
					.autocomplete({
						minLength: 0,
						source: function( request, response ) {
						  response( $.ui.autocomplete.filter(
						    categories, Utils.JUIextractLast( request.term ) ) );
						},
						focus: function() {
						  return false;
						},
						select: function( event, ui ) {
						  var terms = Utils.JUIsplit( this.value );
						  selectedCommunity.push(ui.item.value) ;
						  self.selectedCommunity = selectedCommunity ;
						  terms.pop();
						  terms.push( ui.item.value );
						  terms.push( "" );
						  this.value = terms.join( ", " );
						 // categories.splice($.inArray(ui.item.value, categories), 1);
						  return false;
						}
					});

			}else{

				$.each(categories, function(key, value){
					if( userCommunityMap[value] )
						var option = "<option value='"+value+"' selected>"+value+"</option>";
					else
						var option = "<option value='"+value+"'>"+value+"</option>";
					$("#edit-communities").append( option );

				});
				setTimeout( function(){
					$("#edit-communities").chosen({
						width: "100%"
					});
					$("#edit-communities").trigger("chosen:updated");
				},100);

			}

		} ,
		updateProfileLayout : JST["app/templates/profile/layout.hbs"]     ,
 		ActivityLayout      : JST['app/templates/profile/activities.hbs'] ,
 		LoaderLayout        : JST['app/templates/loader.hbs']             ,
		render: function() {
			var self = this ;
			var user_id = self.userModel.getUserID() ;
			var url = window.location.search;
			self.$el.html( self.LoaderLayout );
			$.ajax({
				method : "GET",
				url : Utils.contextPath()+"/v2/users/"+ user_id +"/profile",
			}).done(function(response){

				var user = response;
				console.log(JSON.stringify(response));
				self.userInfo = response ;
				console.log(self.userInfo);
				self.userCommunity = user.userCommunities ;

				if(self.userCommunity == null)
					self.userCommunity = [] ;

			$.ajax({
				method: "GET",
				url: Utils.contextPath() + '/community'
			}).done(function(response){
				var category = {} ;
				$.each(response,function(i, cat){
					category[i] = cat;
				});
				self.community = response ;
				//self.editCategory() ;
			}).fail(function(error){});

				var customfields = user.customProperties            ;
				var gender       = customfields.gender     || "N/A" ;
				var occupation   = customfields.occupation || "N/A" ;
				var age          = customfields.age        || "N/A" ;
				var imgUrl         = Utils.avatarToImage(user.avatar);
				var userCF ={ } ;
				userCF["age"]        = age        ;
				userCF["gender"]     = gender     ;
				userCF["occupation"] = occupation ;
				var showOrgId = false
				if(JSON.parse(localStorage.getItem("user")).loggableUser["orgId"] == -1) showOrgId = true
				self.$el.html( self.updateProfileLayout({showOrgId : showOrgId, cf : userCF, email : user.email, profile : user, imgUrl : imgUrl, userConsent : user.userConsent,userType : "VICTIM", isMobileDevice: Utils.isMobileDevice() }) );
				if(url != ""){
					Utils.scrollTo("#validateOrg", -60);
					$("#validateOrg #refCode").focus();
				}
				$("#" + user.avatar).addClass("avatar-selected") ;

				$('.datepicker').pickadate({
				    selectMonths: true, // Creates a dropdown to control month
				    selectYears: 90, // Creates a dropdown of 15 years to control year
					//min: new Date("1900/1/1"),
  					max: new Date(),
  					onClose: function() {
 					   $('.datepicker').blur();
					}
  				});

  				if(Utils.isLoggedIn()){

					self.paymentPendingView.render() ;
				}

				$("#email-input").keystop( function(event){
					self.checkForEmail(event) ;
				}, 500 ) ;

				$.ajax({
					method : "GET",
					url : Utils.contextPath() + "/v2/users/" + user_id + "/activities"
				}).done(function(response){

					var activities = response ;

					activities.answered = activities.answered || 0 ;
					activities.liked = activities.liked || 0 ;
					activities.bookmarked = activities.bookmarked || 0 ;

					self.$el.find("#activity-container").html( self.ActivityLayout({activities: activities }) );

				}).error(function(error){
					console.log(error)
				});


			}).fail(function(error){
				console.log(error)
			})

		}
	});
	UserProfilePage.prototype.remove = function() {};

	UserProfilePage.prototype.clean = function() {};

	return UserProfilePage;
});
