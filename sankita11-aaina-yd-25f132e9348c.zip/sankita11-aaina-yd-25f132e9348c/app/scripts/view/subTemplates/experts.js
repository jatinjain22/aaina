define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher'
] , function( $, _, Backbone, Utils, JST, Dispatcher ) {
	var ExpertsPage = Backbone.View.extend({
		el: "main",
		initialize : function(){},
    expertsLayout : JST['app/templates/subTemplates/experts.hbs'],
    loaderLayout : JST['app/templates/subTemplates/loader.hbs'],
    events : {
			'click .subtemplates-experts #direct-appointment' : 'bookAppointmentWithExpert',
			'click .subtemplates-experts #direct-message' : 'messageExpert',
			'click .subtemplates-experts #direct-chat': 'chatWithExpert',
			'click .subtemplates-experts .browse': 'browseAllExperts',
			'click .subtemplates-experts .expert-card': 'openExpertProfile',
		},
		openExpertProfile: function (evt) {
			var id = evt.currentTarget.getAttribute("data-id");
			window.location.href = "/counselor/" + id;
		},
		browseAllExperts: function () {
			Backbone.history.navigate('/talkItOut?from=showAllExperts', {'trigger': true});
		},
		scrollToForm : function( ){
			Utils.scrollTo("#MPBSE-signup-section");
		},
		chatWithExpert: function (evt) {
			var chatUrl = evt.currentTarget.getAttribute('data-url');
			if (!Utils.isLoggedIn()){
				this.scrollToForm()
			} else {
				this.redirectToUrl({
					'url': chatUrl
				});
			}
		},
		redirectToUrl: function (options) {
			window.location.href = options.url;
		},
		bookAppointmentWithExpert: function (evt) {
			var expertId = evt.currentTarget.getAttribute('data-id');
			Backbone.history.navigate("/bookAppointment?from=counselor&conID=" + expertId +"&catID=Others", {trigger: true});
		},
		messageExpert: function (evt) {
			var expertId = evt.currentTarget.getAttribute('data-id');
			if (!Utils.isLoggedIn()){
				this.scrollToForm()
			} else {
				this.message({
					'id': expertId
				});
			}
		},
    sendRequest : function(options){
      var deferred = $.Deferred();
			$.ajax(options).done(function (response) {
				deferred.resolve(response);
			}).fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
    },
    renderStats: function () {
			var self = this;
			this.sendRequest({method:"GET", url : "/scripts/json/statistics.json"})
			.then(function (res) {
				self.expertsCount = res[1].no_of_experts;
			});
    },
    render : function(conatinerId){
      this.renderStats()
      $('#'+conatinerId).html(this.loaderLayout())
      var self = this;
      var expertsPromise = this.sendRequest({method: "GET", url : Utils.contextPath() + "/v1/counselor?page_number=1"});
			var statusPromise = this.sendRequest({methos: "GET", url : Utils.contextPath() + "/v1/counselor/status"});
			$.when(expertsPromise, statusPromise)
			.then(function (experts, status) {
				var expert1 = experts[0];
				expert1.status = status[expert1.id]['status'] == 'true' ? true : false;
				expert1.chatUrl = status[expert1.id]['url'];
				var expert1rating = self.sendRequest({method : "GET", url : Utils.contextPath() + "/v1/counselor/" + expert1.id + '/ratingFavoriteCnt'});
				var expert2 = experts[1];
				expert2.status = status[expert2.id]['status'] == 'true' ? true : false;
				expert2.chatUrl = status[expert1.id]['url'];
				var expert2rating = self.sendRequest({method : "GET", url : Utils.contextPath() + "/v1/counselor/" + expert2.id + '/ratingFavoriteCnt'});
				var expert3 = experts[2];
				expert3.status = status[expert3.id]['status'] == 'true' ? true : false;
				expert3.chatUrl = status[expert1.id]['url'];
				var expert3rating = self.sendRequest({method : "GET", url : Utils.contextPath() + "/v1/counselor/" + expert3.id + '/ratingFavoriteCnt'});
				$.when(expert1rating, expert2rating, expert3rating)
				.then(function (rating1, rating2, rating3) {
					expert1.reviewCount = rating1.rating;
					expert2.reviewCount = rating2.rating;
					expert3.reviewCount = rating3.rating;
					var counselorDetails = [];
					counselorDetails.push(expert1);
					counselorDetails.push(expert2);
					counselorDetails.push(expert3);
					$('#'+conatinerId).html(self.expertsLayout({'details': counselorDetails, 'number': self.expertsCount, 'mobile': self.isMobile}));
				});
			});
		}
  });
  ExpertsPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.stopListening();
  };
  ExpertsPage.prototype.clean = function() {
    this.remove();
  };
  return ExpertsPage;
})
