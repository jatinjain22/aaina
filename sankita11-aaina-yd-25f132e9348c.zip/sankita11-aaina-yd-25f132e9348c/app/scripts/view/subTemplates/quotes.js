define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
], function( $, _, Backbone, JST, Utils, Dispatcher) {
	var quotesPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
		},
    quotesLayout : JST['app/templates/subTemplates/quotes.hbs'],
    loaderLayout : JST['app/templates/subTemplates/loader.hbs'],
    loadSwiper : function(container, next, prev){
      var space = 20, time = 15000
      if(Utils.isMobileDevice()) {
        space = 5
        time = 2000
      }
      var mySwiper = new Swiper ('.'+container, {
        autoplay: time,
        keyboardControl: true,
        slidesPerView: '3',
        nextButton: next,
        prevButton: prev,
        loop:true,
        spaceBetween: space,
        centeredSlides: true,
        breakpoints: {
            640: {
                slidesPerView: 'auto',
                spaceBetweenSlides: 10
            }
        },
      });
    },
    sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				})
				.fail(function (error) {
					deferred.reject(error);
				})
				return deferred.promise();
		},
    render : function(containerId){
      var self = this;
      $('#'+containerId).html(this.loaderLayout())
      this.sendRequest({method : 'GET', url : Utils.scriptPath()+'/subTemplates/quotes.json'})
      .then(function(res){
        $("#"+containerId).html(self.quotesLayout({header: res.header,images : res.images}))
        if(!Utils.isMobileDevice()) {
          self.loadSwiper('cm-common-gallery-inner-container', '.cm-gallery-next', '.cm-gallery-prev')
        }else{
          self.loadSwiper('cm-common-gallery-inner-container', '', '')
        }
      })
    }
  });
  quotesPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.stopListening();
  };
  quotesPage.prototype.clean = function() {
    this.remove();
  };
  return quotesPage;
})
