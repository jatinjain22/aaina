define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
  'event/dispatcher',
  'model/users',
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel) {
	var signupPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
      this.model = new UserModel();
      this.validateJSON = {
				"fields" : {
					"signupUsername" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z][a-zA-Z0-9-]+$",
						"minLength" : 6 ,
						"messages" : {
							"required" : "Please enter a valid username" ,
							"regexp"   : "Username must start with an alphabet. Special characters are not allowed",
							"minLength": "Username must be minimum 6 characters"
						}
					},
					"postSignupUsername" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z][a-zA-Z0-9]+$",
						"minLength" : 4 ,
						"messages" : {
							"required" : "Please enter a valid username" ,
							"regexp"   : "Username must start with an alphabet. Special characters are not allowed",
							"minLength": "Username must be minimum 4 characters"
						}
					},
					"signupEmail" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z0-9-_+.]+@[a-zA-Z0-9-_.]+\\.[a-zA-Z]+$",
						"messages" : {
							"required" : "Please enter a valid email id" ,
							"regexp"   : "Please enter a valid email id"
						}
					},
					"signupPassword" : {
						"required" : true ,
						"minLength" : 6,
						"regexp":"/\s/g",
						"messages" : {
							"required"    : "Please enter a valid password" ,
							"regexp"      : "Password should not have whitespaces in between",
							"minLength": "Password must be minimum 6 characters"
						}

					},
					"signupSchool" : {
						"required" : true,
            "validCode" : true,
						"messages" : {
							"required"    : "Please enter the school reference code.",
              "validCode"   : "Please enter a valid reference code."
						}
					}
				}
			}
    },
		events: {
      'focusout #mp-signupEmail' : 'checkForEmail',
			'click #mp-signup-btn' : 'mpbseSignup',
			'change #mp-tos-agree' : 'checkForTerms',
		},
    signupLayout : JST['app/templates/MPBSE/signup.hbs'],
    loaderLayout : JST['app/templates/subTemplates/loader.hbs'],
    sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				})
				.fail(function (error) {
					deferred.reject(error);
				})
				return deferred.promise();
		},
    enableSubmit : function(targetName){
			$("#modal-validate-" + targetName).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-check green-text prefix'></i>")
    	$("input[name='"+ targetName +"']").removeClass("invalid").addClass("valid") ;
			$("#form-error-"+ targetName).html("") ;
			$("#form-error-"+ targetName).hide() ;
			var allFieldsValid = this.checkForAllFields();
			if(!allFieldsValid){
				$("#mp-signup-btn").addClass("disabled") ;
				$("#mp-signup-btn").attr("disabled", true) ;
				return 0 ;
			}
			if($(".form-valid i").hasClass("mdi-navigation-close")){
				$("#mp-signup-btn").addClass("disabled") ;
				$("#mp-signup-btn").attr("disabled", true) ;
			}else{
				$("#mp-signup-btn").removeClass("disabled") ;
				$("#mp-signup-btn").attr("disabled", false) ;
			}
			return 1 ;
		},
		disableSubmit : function(targetName){
			$("#modal-validate-" + targetName ).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-close red-text prefix'></i>")
    	$("input[name='"+ targetName +"']").removeClass("valid").addClass("invalid") ;
			$("#mp-signup-btn").addClass("disabled") ;
			$("#mp-signup-btn").attr("disabled", true) ;
			$("#form-error-"+ targetName).show() ;
		},
		checkForPassword : function(e){
			var self = this;
			var targetName = $(e.currentTarget).attr("name") ;
			var validPassword = this.validateText( $(e.currentTarget).attr("name")) ;
			if(validPassword == 0){
				this.disableSubmit( $(e.currentTarget).attr("name")) ;
			}else{
				this.enableSubmit( $(e.currentTarget).attr("name")) ;
			}
		} ,
		checkForUsername : function(e){
			var self = this ;
			var username = $("#mp-signupUsername").val() ;
			var usernameValid = this.validateText("signupUsername");
			if(usernameValid == 0 ){
				this.disableSubmit("signupUsername") ;
				return 0 ;
			}
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=username&item=" + username,
				statusCode:{
            404 : function(){
						      $("#validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
						      $("#form-error-signupUsername" ).hide() ;
            			self.enableSubmit("signupUsername") ;
            		}
        		},
				}).done(function(response){
          $("#form-error-signupUsername").hide() ;
          self.usernameExists = true
					// if(response == true ){
					// 	if($("#form-error-signupUsername" ).length == 0){
					// 		$("#mp-signupUsername").after("<div id='form-error-signupUsername'  class='red-text'></div>");
					// 	}
					// 	$("#modal-validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
					// 	$("#form-error-signupUsername" ).html("This username already exists") ;
					// 	$("#mp-signupUsername").removeClass("valid").addClass("invalid") ;
					// 	$("#modal-signup-btn").addClass("disabled") ;
					// 	$("#modal-signup-btn").attr("disabled", true) ;
					// 	$("#form-error-signupUsername").show() ;
					// }
				}).error(function(){});
		},
		checkForEmail : function(e){
			var self = this ;
			var email = $("#mp-signupEmail").val() ;
			var emailValid = this.validateText("signupEmail");
			if( emailValid == 0 || email.trim().length==0 ) {
				this.disableSubmit( "signupEmail" );
				return 0;
			}
			if(email.trim().length == 0){
			}
			if($('input[name="user_identity"]:checked').attr("id") != "email-option" ){
			}
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
				statusCode:{
            		404 : function(){
						$("#modal-validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
            			self.enableSubmit("signupEmail") ;
            		}
        		},
				}).done(function(response){
					if(response == true ){
						if($("#form-error-signupEmail" ).length == 0){
							$("#mp-signupEmail").after("<div id='form-error-signupEmail'  class='red-text'></div>");
						}
						$("#modal-validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
						$("#form-error-signupEmail" ).html("This email already exists") ;
						$("#validate-icon-signupEmail" ).removeClass('mdi-navigation-check green-text').addClass('mdi-navigation-close red-text');
						$("#mp-signupEmail").removeClass("valid").addClass("invalid") ;
						$("#mp-signup-btn").addClass("disabled") ;
						$("#mp-signup-btn").attr("disabled", true) ;
						$("#form-error-signupEmail").show() ;
					}
				}).error(function(){
				});
		},
		checkForTerms : function(e){
    		if($("#mp-tos-agree").is(":checked")){
    			this.enableSubmit("mp-tos-agree")
    		}else{
    			this.disableSubmit("mp-tos-agree")
    			this.checkForAllFields();
    		}
    	},
		checkForAllFields : function(){
			var self = this;
			var username = $("#mp-signupUsername").val();
			var password = $("#mp-signupPassword").val().trim();
			//var email = $("#mp-signupEmail").val();
      var schoolCode = $("#mp-schoolCode").val()
			if( username.length <= 0 || password.length <= 0 || schoolCode.length <= 0 ){
				return 0 ;
			}
      if(Object.keys(this.schoolCodes).indexOf(schoolCode.toUpperCase()) == -1 ){
        return 0;
      }
			if(!$("#mp-tos-agree").is(":checked")){
				return 0 ;
			}
			if($('input[name="user_identity"]:checked').attr("id") == "email-option"){
				var email = $("#mp-signupEmail").val();
				if(email.length <=0 ){
					return 0 ;
				}
				if ( self.fromAction == "download_free_ebook" || self.fromPage=="landingPage2Message" || self.fromPage=="landingPage2" ) {
					if( email.length <= 0 ){
						return 0 ;
					}
				}

			}
			return 1 ;
		},
		validateText :  function(targetName){
      var self = this;
			var fieldsToValidate = this.validateJSON["fields"][targetName] ;
			if($("#form-error-" + targetName ).length == 0){
				$("input[name='"+ targetName +"']").after("<div id='form-error-"+ targetName +"'  class='form-error red-text'></div>");
				$("#form-error-" + targetName ).hide() ;
			}
			var textValue = $("input[name='"+ targetName +"']").val() ;
			if(targetName == "signupSchool") {
				textValue = textValue.trim()
			}
			if(targetName == "signupUsername"){
				textValue = textValue.trim() ;
			}
			if(targetName != "signupUsername" && targetName != "signupSchool" && targetName != "signupEmail" && targetName != undefined && targetName != "postSignupUsername"){
				textValue = textValue.trim() ;
			}
			var isValid = 1 ;
			_.each( fieldsToValidate, function(value, key){
				if( key == "required" && textValue.length == 0 ){
					isValid = 0 ;
					$("#form-error-"+ targetName ).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "minLength" && textValue.length < value ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "equalsTo" &&  textValue != $("input[name='"+ value +"']").val() ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "validCode"){
            if( Object.keys(self.schoolCodes).indexOf(textValue.toUpperCase()) == -1){
              isValid = 0
              $("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
              return false;
            }
        }else if( key == "regexp" ){
					if (targetName == 'signupEmail') {
    				var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
						if( !pattern.test(textValue) ){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}
					} else if(targetName == 'signupPassword'){
						var pattern = /\s/g;
						if( pattern.test(textValue) ){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}
					}else{
						var regex = new RegExp(value, "i");
						if(!textValue.match(regex)){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}
					}
				}
			});
			return isValid ;
		},
    trackAquisition : function(){
			var cookieArr = document.cookie.split(";")
			var acParams = {}
			for(i = 0; i < cookieArr.length; i++){
				 if(cookieArr[i].indexOf("ac_source") > -1){
					 var cookieInfo = cookieArr[i].split("&")
					 for( var j =0 ;j < cookieInfo.length; j++){
						 var item = cookieInfo[j].trim().split('::')
						 if(item) acParams[item[0]] = item[1]
					 }
				 }
			}
			return acParams;
		},
    checkForSchoolCode : function(){
      var refCode = $("#mp-schoolCode").val()
      var validRefCode = this.validateText('signupSchool')
      if( validRefCode == 0 || refCode.trim().length==0  || Object.keys(this.schoolCodes).indexOf(refCode.toUpperCase()) == -1 ){
			      this.disableSubmit('signupSchool');
			      return 0;
			}
      if( Object.keys(this.schoolCodes).indexOf(refCode.toUpperCase()) > -1 ){
        this.enableSubmit('signupSchool');
        return 1
      }
    },
    callLogin : function(data){
      var self = this;
      var loginUrl = Utils.contextPath() + "/v2/users/login";
 			var source = "website";
      var url = window.location.href ;
    	url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso');
			if(sso != undefined ){
				loginUrl = loginUrl + "?sso=" + sso ;
				source = "FORUM";
			}else{
				loginUrl = loginUrl ;
			}
      $.ajax({
				type: "POST",
				dataType: "JSON",
        contentType: "application/json; charset=utf-8",
    		url: loginUrl ,
    		xhrFields: {
     				withCredentials: true
			  },
		    beforeSend :function(xhr){
		    	xhr.setRequestHeader( "Authorization", "Basic "+ btoa(data.username + ":" + data.password) );
		    },
		    statusCode:{
		    	401 : function(response){
            var responseText = response.responseText;
            var responseJson = JSON.parse(responseText) ;
            var errorMessage = responseJson.message ;
            var errorType    = responseJson.type ;
            if(errorType != "BLOCKED"){
              $(".mpbse-login-error").html("Either this username has already been taken or you have entered an incorrect password.");
              $("#mp-signup-btn").show();
         			$("#signup-progress").hide() ;
            }else{
              self.callSignup(data)
            }
		    	},
		    },
  			data:JSON.stringify({"shouldGenerateCookie": true, "ipSession": false})
			}).done(function( data, status, xhr ) {
				$(".login-error").addClass("hide") ;
				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
					mixpanel.register({
						userInfo : data ,
						orgId : data["loggableUser"]["orgId"]
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.identify(data.id);
					mixpanel.track('LOGIN', {'type' : 'NORMAL', 'mediumSource' : source, 'itemName' : self.buttonDesc, 'itemMedium' : 'NORMAL'  });
					mixpanel.people.set({
	    			'username': data.username,
	    			'name' : data.username ,
	    			'$email': data.email,
	    			'id' : data.id,
 	    			'userType' : data["loggableUser"]["userType"],
					  'orgId' : data["loggableUser"]["orgId"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}
				window.userdata = data;
				self.model.save(data) ;
        if( data.uri ){
					Backbone.history.navigate(data.uri, {trigger: true});
				}else {
					location.href = Utils.chatUrl() + data.username;
				}
      }).error(function(err){
      })
    },
    mpbseSignup : function(e){
			var self = this ;
			var isValidEmail    = 1//this.checkForEmail();
			var isValidUsername = this.validateText("signupUsername");
			var isValidSchool = this.checkForSchoolCode();
      $(".mpbse-login-error").html('')
			if(isValidUsername == 0 ){
				this.disableSubmit("signupUsername") ;
				return false ;
			}
			if( isValidEmail == 0 ){
				this.disableSubmit("signupEmail") ;
				return false ;
			}
			if(isValidSchool == 0) {
				this.disableSubmit('signupSchool') ;
				return false;
			}
			if($("#signup-btn").hasClass("disabled")){
				return false ;
			}
			var currentDateTime = new Date().toISOString() ;
			var currentDate     = currentDateTime.split("T")[0] ;
 			var dataToSend = {
					"password" : $("#mp-signupPassword").val().trim() ,
					"username" : $("#mp-signupUsername").val().trim() ,
    			"avatar"   : "avatar7"                               ,
				} ;
			dataToSend[ "email" ] = $("#mp-signupUsername").val().trim() + '@ydmpbse.com'//$("#mp-signupEmail").val();
			var refCode = $("#mp-schoolCode").val()
 			dataToSend[ "school" ] = this.schoolCodes[refCode.toUpperCase()];
 			dataToSend[ "organisationId" ] = 9;
 			$("#mp-signup-btn").hide();
 			$("#signup-progress").show() ;

      this.sendRequest({ url : Utils.contextPath() + "/v2/users/exists?type=username&item=" + dataToSend.username, method : 'GET'})
      .then(function(res){
        self.callLogin(dataToSend)
      }, function(err){
        self.callSignup(dataToSend)
      })
		},
    callSignup : function(dataToSend){
      var self = this;
      var loginUrl = Utils.contextPath() + "/v2/users/signup-cf";
 			var source = "website";
      var url = window.location.href ;
    	url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso');
			if(sso != undefined ){
				loginUrl = loginUrl + "?sso=" + sso ;
				source = "FORUM";
			}else{
				loginUrl = loginUrl ;
			}
      $.ajax({
				method : 'POST',
				url : loginUrl,
				dataType : "json" ,
				xhrFields: {
   				 withCredentials: true
		    },
				contentType: "application/json",
				data: JSON.stringify(dataToSend),
				statusCode:{
			    	417 : function(response){
  			    	var responseText = response.responseText;
  						var responseJson = JSON.parse(responseText) ;
  						var errorMessage = responseJson.message ;
  						var errorType    = responseJson.type ;
  						if ( errorType = 'EmailExists' ) {
  							$( "#form-error-signupEmail" ).css( "display", "block" );
  							$( "#form-error-signupEmail" ).html("This email already exists") ;
  						}
			    	},
			    },
			}).done(function(response, status, xhr){
				self.model.save(response) ;
				sessionStorage.setItem("firstTimeUser" , 1 ) ;
				window.userdata = response;
				Raygun.setUser( response.username, false, response.email, response.firstName, response.firstName, response.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
					mixpanel.register({
						userInfo : response,
						orgId : response["loggableUser"]["orgId"]
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.alias(response.id, distinct_id);
					mixpanel.track('SIGNUP', {'type' : 'NORMAL', 'mediumSource' : source,  'itemName' : self.buttonDesc, 'itemMedium' : 'NORMAL'  });
					if (  ( typeof fbq != 'undefined' ) ){
						fbq('track', 'CompleteRegistration');
					}
					if( typeof ga != 'undefined'){
						ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
					}
					var aquisitionParams = self.trackAquisition()
					mixpanel.people.set({
	    			'username': response.username,
	    			'name' : response.username ,
	    			'$email': response.email,
	    			'id' : response.id,
	    			'src' : 'NORMAL',
	    			'userType' : response["loggableUser"]["userType"],
					  'orgId' : response["loggableUser"]["orgId"],
					  'ac_medium' : aquisitionParams['ac_medium'],
					  'ac_source' : aquisitionParams['ac_source'],
					  'ac_content' : aquisitionParams['ac_content'],
					  'ac_campaign' : aquisitionParams['ac_campaign']
					});
					mixpanel.name_tag({
						nameTag: response.username
					});
				}
        window.userdata = response;
				self.model.save(response) ;
				if( response.uri ){
					Backbone.history.navigate(response.uri, {trigger: true});
				}else {
					location.href = Utils.chatUrl() + response.username;
				}

			}).fail(function(error){
        $("#mp-signup-btn").show();
   			$("#signup-progress").hide() ;
			});
    },
    render : function(containerId){
      var self = this;
      $('#'+containerId).html(this.loaderLayout())
      this.sendRequest({method : 'GET', url : Utils.scriptPath()+'/mpbse.json'})
      .then(function(res){
        self.schoolCodes = res
        $("#"+containerId).html(self.signupLayout())
        addListeners()
      })
      function addListeners(){
        $("#mp-signupUsername").keystop( function(event){
          self.checkForUsername(event) ;
        }, 1000 ) ;
        $("#mp-signupPassword").keystop( function(event){
          self.checkForPassword(event) ;
        }, 1000 ) ;
        $("#mp-signupEmail").keystop( function(event){
          self.checkForEmail(event) ;
        }, 1500 ) ;
        $("#mp-schoolCode").keystop( function(event){
          self.checkForSchoolCode(event) ;
        }, 1500 ) ;
      }
    }
  })
  signupPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.stopListening();
  };
  signupPage.prototype.clean = function() {
    this.remove();
  };
  return signupPage;
})
