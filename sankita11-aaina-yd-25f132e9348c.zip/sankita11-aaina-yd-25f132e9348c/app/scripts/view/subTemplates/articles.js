define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
], function( $, _, Backbone, JST, Utils, Dispatcher) {
	var articlesPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
      "click .subtemplates-articles .all-articles": "redirectToBlog",
			"click .subtemplates-articles .content": "redirectToArticle",
		},
    articlesLayout : JST['app/templates/subTemplates/articles.hbs'],
    loaderLayout : JST['app/templates/subTemplates/loader.hbs'],
    redirectToArticle: function (evt) {
			var url = evt.currentTarget.getAttribute("data-url");
			this.redirectToUrl({
				'url': url
			});
		},
    redirectToBlog: function () {
			this.redirectToUrl({
				'url': "http://yourdost.com/blog"
			});
		},
    redirectToUrl: function (options) {
			window.location.href = options.url;
		},
    sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				})
				.fail(function (error) {
					deferred.reject(error);
				})
				return deferred.promise();
		},
    render : function(containerId){
      var self = this;
      $('#'+containerId).html(this.loaderLayout())
      var self = this;
			this.sendRequest({ method : "GET", url : Utils.scriptPath()+'/subTemplates/articles.json' })
			.then(function (res) {
				$("#"+containerId).html(self.articlesLayout({'details': res.articles, 'header' : res.header, 'mobile': self.isMobile}));
			});
    }
  });
  articlesPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.stopListening();
  };
  articlesPage.prototype.clean = function() {
    this.remove();
  };
  return articlesPage;
})
