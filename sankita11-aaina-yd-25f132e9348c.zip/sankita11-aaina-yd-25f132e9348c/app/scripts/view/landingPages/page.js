define([
  'jquery',
  'underscore',
  'event/dispatcher',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'Swiper',
], function($,_, Dispatcher, Backbone, JST, Utils ) {

    var landingPageView = Backbone.View.extend({

      el: 'main',

      initialize: function() {
               
      },
      
      events: {
        'click .landingpage-chat-btn' : 'chatNow',
      },
      // checkforvalidEmail : function(e){

      //   var email = $("#landingpage-email").val();
      //   var isValidEmail = Utils.formEmailCheck(email);
        
      //   if(email != ""){
          
      //     if(isValidEmail){

      //       $(".landingpage-email-error").addClass("hide");
      //       $(".landingpage-email-error").html("")
      //       if(e.keyCode == 13){

      //         this.landingPageChatNow(email)
      //       }
      //     }else{

      //       $(".landingpage-email-error").removeClass("hide");
      //       $(".landingpage-email-error").html("Please enter a valid email")
      //     }
      //   }else{

      //     $(".landingpage-email-error").addClass("hide");
      //     $(".landingpage-email-error").html("")
      //   }        
      // },

      // landingPageChatNow : function(email){

      //   $('.landingpage-chat-btn').html("CHECKING...")
      //   $.ajax({

      //     method : "POST",
      //     url : '',
      //     contentType : 'json',
      //   }).done(function(response){

      //     $('.landingpage-chat-btn').html("CHAT NOW")
      //     location.href = Utils.chatUrl() + username;
      //   }).error(function(error){

      //     $('.landing-chat-error').removeClass("hide").html("Somethig went wrong. Please try again later.")
      //     setTimeout(function(){ 

      //       $('.landing-chat-error').fadeOut(2000);
      //     },3000)
          
      //     $('.landingpage-chat-btn').html("CHAT NOW")
      //     console.log(error);
      //   })
      // },

      chatNow : function(e){

        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){

          Dispatcher.trigger("renderLogin", buttonDesc, "landingpage", "landingpage consult now") ;
        }
      },

      LandingPageLayouttemplate : JST['app/templates/landingPages/layout.hbs'],

      render: function() {

        var self = this;

        $.ajax({
          method : "GET",
          url : '/scripts/json/user_reviews_counselors.json',
          contentType: 'text/plain',
        }).done(function(response){

          self.$el.html( self.LandingPageLayouttemplate({reviews : response}) );

          var mySwiper = new Swiper ('.careerpage-testimonials', {
            
              loop: true,
              pagination: '.careerpage-pagination',
              paginationClickable: true,
              autoplay: 10000,
          });

        }).error(function(error){

          console.log(error);
        });

        
        //this.$el.html( this.LandingPageLayouttemplate() );
        
        return this;
      }
    });

  landingPageView.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind(); 
	};

	landingPageView.prototype.clean = function() {

      this.remove();

	};

    return landingPageView;
});
