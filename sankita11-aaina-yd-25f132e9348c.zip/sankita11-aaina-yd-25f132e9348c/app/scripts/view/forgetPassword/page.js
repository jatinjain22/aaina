define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'keystop'
], function( $, _, Backbone, JST, Utils ) {

	var ForgetPasswordPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
			'change input[name="forget-pass-user_identity"]' : 'showHideOptions' ,
			'submit .step1-cointaner' : 'showStep2Message' ,
		},
		showStep2Message: function(e){

			$("#step1-progress").removeClass("hide");
			$("#step1-proceed").addClass("hide");

			if(true){

				var email = $("#email").val() ;
                var username = $("#username").val() ;

                var dataToSend = {};
                var identifierUsed = '';
                if(username.length > 0)  {
                     dataToSend.username = username;
                     identifierUsed = 'username';
                }
                else if(email.length > 0) {
                    dataToSend.email = email;
                    identifierUsed = 'email';
                }
				$.ajax({
					url : Utils.contextPath() + "/v2/users/forgotpassword",
					method : "POST",
					dataType : "json" ,
					contentType: "application/json",
					data : JSON.stringify(dataToSend),
					statusCode :{
						417 : function(response){

							var errorMessage = "Sorry! You can reset your password from here only if your email ID is registered with us. For further support, please email customersupport@yourdost.com";
							$("#" + identifierUsed + "-error").html(errorMessage);
                            $("#" + identifierUsed + "-error").removeClass("hide") ;
							$("#step1-progress").addClass("hide");
							$("#step1-proceed").removeClass("hide");
						},
						404 : function(response){

							var errorMessage = "Sorry! You can reset your password from here only if your email ID is registered with us. For further support, please email customersupport@yourdost.com";
                            $("#" + identifierUsed + "-error").html(errorMessage)
                            $("#" + identifierUsed + "-error").removeClass("hide") ;
							$("#step1-progress").addClass("hide");
							$("#step1-proceed").removeClass("hide");
						}
					}
 				}).done(function(response){
 					$("#email-reset").html( email.replace( /^(\w\w).*?\.(.*?)$/, "$1**.$2" ));
 					$(".step1-cointaner").addClass("hide") ;
 					$(".email-activation-msg").removeClass("hide") ;
 				}).error(function(error){
 					console.log(error) ;
 				});

			}
		},
		showHideOptions : function(e){
			var optionID = $(e.currentTarget).attr("id") ;

			if(optionID == "email-option"){
				$(".email-block").show() ;
				$(".security-block").hide() ;
			}else{
				$(".email-block").hide() ;
				$(".security-block").show() ;
			}
		},
		disableSubmit : function(){
			$("#step1-proceed").addClass("disabled");
			$("#step1-proceed").attr("disabled", true) ;
		},
		enableSubmit : function(){
			$("#step1-proceed").removeClass("disabled");
			$("#step1-proceed").attr("disabled", false) ;
		},
		checkForEmail : function(e){
			var email = $("#email").val() ;
			console.log("hh") ;
			console.log(email) ;
			if(email.length <= 0){
				$("#email-error").html("Please enter valid email id");
				$("#email-error").removeClass("hide") ;
				this.disableSubmit();
				return 0 ;
			}

			var regex = new RegExp("^[a-zA-Z0-9-_+.]+@[a-zA-Z0-9-_.]+\\.[a-zA-Z]+$", "i");
			if(!email.match(regex)){
				$("#email-error").html("Please enter valid email id");
				$("#email-error").removeClass("hide") ;
				this.disableSubmit();
				return 0 ;
			}

			this.enableSubmit();
			$("#email-error").addClass("hide") ;
			return 1 ;
		},
        checkForUsername: function (e) {
            var username = $("#username").val();
            console.log("hh");
            console.log(username);
            if (username.length <= 0) {
                $("#username-error").html("Please enter valid username");
                $("#username-error").removeClass("hide");
                this.disableSubmit();
                return 0;
            }

            var regex = /\s/g ;
            if (username.match(regex)) {
                $("#username-error").html("Please enter valid username");
                $("#username-error").removeClass("hide");
                this.disableSubmit();
                return 0;
            }

            this.enableSubmit();
            $("#username-error").addClass("hide");
            return 1;
        },
		hideLoginModal : function(e){

			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('login-modal');
			$('#login-modal').remove() ;
			console.log("Removed...")
		},
		ForgetPasswordLayout:JST['app/templates/forgetPassword/layout.hbs'],
		render: function() {

			var self = this ;

			$.ajax({
				url : Utils.contextPath() + "/question"
			}).done(function(response){
				self.$el.html(self.ForgetPasswordLayout({securityQuestion : response }));
				$('.parallax').parallax();
				$('select').not('.disabled').material_select();
				$("#email").focus();

				$("#email").keystop( function(event){
					self.checkForEmail(event) ;
				}, 1000 ) ;

                $("#username").keystop( function(event){
                    self.checkForUsername(event) ;
                }, 1000 ) ;

                $('#email').on('focusin click', function(event) {
                    $("#username").val('');
                    $("#username-error").addClass("hide") ;
                    self.checkForEmail(event) ;
                });

                $('#username').on('focusin click', function(event) {
                    $("#email").val('');
                    $("#email-error").addClass("hide") ;
                    self.checkForUsername(event)
                });

			}).error(function(error){

			});


		}
	});

	ForgetPasswordPage.prototype.remove = function() {
				this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	ForgetPasswordPage.prototype.clean = function() {
		this.remove();
	};

	return ForgetPasswordPage;
});
