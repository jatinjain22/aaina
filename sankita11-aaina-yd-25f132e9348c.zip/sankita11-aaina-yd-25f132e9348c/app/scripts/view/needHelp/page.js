define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
], function( $, _, Backbone, JST, Utils, Dispatcher) {
	var needHelpPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
      'click .nh-fixed-btn' : 'showContent',
      'click .nh-close' : 'showContent',
      'click .nh-submit' : 'submitQuery'
		},
    showContent : function(e){
      if($(".nh-main-content").hasClass("visible")){
        $(".nh-main-content").removeClass("visible")
        return;
      }
      $(".nh-main-content").addClass("visible")
      $(".nh-2").addClass("hide")
      $(".nh-1").removeClass("hide")
    },
    verifyName : function(data){
      if(!data || data.length == 0){
        $("#nh-name").parent(".input-field").append("<div class='nh-error'>Please enter your name</div>")
        return 0;
      }
      return 1;
    },
    verifyPhone : function(data){
      if( !data || data.length != 10 ||
        !(!isNaN(data) && parseInt(Number(data)) == data && !isNaN(parseInt(data, 10)))
      ){
        $("#nh-phone").parent(".input-field").append("<div class='nh-error'>please enter a valid phone no</div>")
        return 0;
      }
      return 1;
    },
    verifyEmail : function(data){
      var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;
      if(!data || !pattern.test(data)){
        $("#nh-email").parent(".input-field").append("<div class='nh-error'>please enter a valid email</div>")
        return 0;
      }
      return 1;
    },
    submitQuery : function(){
      var self = this;
      $(".nh-main-content").find(".nh-error").remove()
      var name = $(".nh-1").find("#nh-name").val()
      var phone = $(".nh-1").find("#nh-phone").val()
      var email = $(".nh-1").find("#nh-email").val()
      if( !this.verifyName(name) || !this.verifyPhone(phone) || !this.verifyEmail(email)){
        return;
      }
      var dataToSend = {
				"mailTo" : [83643,181967,-1],
				"mailFrom" : 101,
				"mailParams" : {
					"name" : name,
					"mobile" : phone,
					"email" : email,
					"from"  : self.location || ""
				},
				"mailTemplate" : "NEEDHELP_TEMPLATE"
			}
      	this.sendRequest({method : 'POST', url : Utils.contextPath()+"/sendMail", data : JSON.stringify(dataToSend),contentType : "application/json"})
      	.then(function(res){
        	$(".nh-1").addClass("hide")
        	$(".nh-2").removeClass("hide")
        	setTimeout(function(){self.showContent()},5000)
      	})
		var dataToSendDb = {
			"name" : name,
			"email" : email,
			"phoneNo" : phone,
			"context" : self.location || ""
		}
	  	this.sendRequest({method: 'POST', url : Utils.contextPath()+"/visitor-help-request", data : JSON.stringify(dataToSendDb),contentType : "application/json"})
	  	.then(function(res){

	  	})
    },
    mainLayout : JST['app/templates/needHelp/layout.hbs'],
    sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
			.done(function (response) {
				deferred.resolve(response);
			})
			.fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},
    render : function(loc, visible){
      var self = this;
			self.location = loc
			if(Utils.isMobileDevice() && !visible) return;
			this.$el.append(this.mainLayout())
    }
  });
  needHelpPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.stopListening();
  };
  needHelpPage.prototype.clean = function() {
    this.remove();
  };
  return needHelpPage;
})
