define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    'Jcrop', 
    'raygun' ,
    'purl'    
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, UserModel ) {

	var CounselorImageModalPage = Backbone.View.extend({
		el: "main",
		initialize: function() {	
			
			var url = window.location.href ;	
			this.userModel       = new UserModel();
			this.userInfo = {};
			this.fromAction = url.replace(/^.*?=/, "");
		},
		events: {
			
			'click #upload' : 'uploadImage' ,
			'click .upload-counselor-img-close' : 'closeUpdateImgModal'
		},
		closeUpdateImgModal : function(e){

			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('demo');
			$('#demo').remove() ;
			$("#counselorImg").attr("src", "");
		},
		uploadImage : function(e){

			$(".upload-error").addClass("hide");
			$("#uploadImage").html("UPLOADING ...");
			var self = this;
			var data = new FormData();
			data.append('file', $('#counselorImg').get(0).files[0] );
            data.append('x1', $('#x1').val());
            data.append('y1', $('#y1').val());
            data.append('x2', $('#x2').val());
            data.append('y2', $('#y2').val());
            data.append('x', $('#x').val());
            data.append('y', $('#y').val());


	    	$.ajax({

	    		url: Utils.contextPath() + '/file/upload',
	    		data: data,
	    		method: 'POST',
	            cache: false,
			    contentType: false,
			    processData: false
	        }).done(function(response){

	        	$('#counselorImg').val("");
	        	var imageUrl = response.imageUrl;

	        	$(".user-profile-img").attr('src', imageUrl)
				Utils.closePopup('demo');

				var infoToEdit = self.userInfo ;
				infoToEdit.picUrl = $(".user-profile-img").attr('src');

				$.ajax({
					url : Utils.contextPath() + "/v1/" + self.userInfo.id + "/modify/preview" ,
					method : "POST" ,
					dataType : "json" ,
					xhrFields: {
	     				 withCredentials: true
				    },
					contentType: "application/json",
					data : JSON.stringify(infoToEdit)
				}).done(function(response){
					console.log(response);
					self.cancelEdit(e) ;
				}).error(function(error){
					console.log("error") ;
					console.log(error) ;
					self.cancelEdit(e) ;
				});

	        }).error(function(error){

	        	$("#uploadImage").html("UPLOAD PHOTO");
	        	$(".upload-error").removeClass("hide");
	        	console.log(error);
	        })			
		},
	    counselorImageLayout : JST["app/templates/counselor/upload_image.hbs"],
		render: function( oFile, userInfo ) {

			var self = this ;
			self.userInfo = userInfo;			
			self.$el.append(self.counselorImageLayout());


			Utils.openPopup('demo');

			var oImage = document.getElementById('preview');

			var cImage = document.getElementById('crop-preview');

		    var oReader = new FileReader();
		    oReader.onload = function(e) {

		        // e.target.result contains the DataURL which we can use as a source of the image
		        oImage.src = e.target.result;

		        oImage.onload = function () { // onload event handler

		            // display step 2
		            $('.step2').fadeIn(500);

		            // display some basic image info
		            var sResultFileSize = Utils.bytesToSize(oFile.size);
		           

		            var modalWidth = $('.counselor-img-preview-div').width();
		            var imageHeight = (  modalWidth/oImage.naturalWidth ) * oImage.naturalHeight;
				    
				    $('#x').val(modalWidth);
				    $('#y').val(imageHeight);

		            $('#preview').css("width", modalWidth);
		            $('#preview').css("height", imageHeight);

		            // Create variables (in this scope) to hold the Jcrop API and image size
		            var jcrop_api, boundx, boundy;

		            // destroy Jcrop if it is existed
		            if (typeof jcrop_api != 'undefined') 
		                jcrop_api.destroy();

		            // initialize Jcrop
		            $('#preview').Jcrop({
		                minSize: [150, 150], // min crop size
		                aspectRatio : 1, // keep aspect ratio 1:1		            	
		                bgFade: true, // use fade effect
		                bgOpacity: .3, // fade opacity
		                setSelect:   [ 100, 100, 300, 300 ],
		                onChange: Utils.updateInfo,
		                onSelect: Utils.updateInfo,
		                onRelease: Utils.clearInfo
		            }, function(){

		                // use the Jcrop API to get the real image size
		                var bounds = this.getBounds();
		                boundx = bounds[0];
		                boundy = bounds[1];

		                // Store the Jcrop API in the jcrop_api variable
		                jcrop_api = this;
		            });
		        };
		    };

		    // read selected file as DataURL
		    oReader.readAsDataURL(oFile);			
		},

	});

	CounselorImageModalPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	CounselorImageModalPage.prototype.clean = function() {
		this.remove();
	};

	return CounselorImageModalPage;
});
