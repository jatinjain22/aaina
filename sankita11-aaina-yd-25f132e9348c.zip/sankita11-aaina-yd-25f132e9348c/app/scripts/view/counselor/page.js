define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'view/counselor/modal_page',
	'ajax-chosen'
], function($,_, Backbone, JST, Utils, UserModel, CounselorImg ) {
	var filterData = '';
	var categories ='', languages='', qualifications ='', locations = '';
	var t_categories = [], t_languages=[], t_qualifications = [], t_locations = [];
	var CounselorProfilePage = Backbone.View.extend({

		el: "main",
		initialize: function() {

			this.userModel  = new UserModel();
			this.counselorImg = new CounselorImg();

			this.userID     = this.userModel.getUserID() ;
			this.userInfo   = {} ;

			this.categories     = [] ;
			this.languages      = [] ;
			this.qualifications = [] ;
			this.locations      = [] ;

			this.selectedCategories = {} ;
		},
		events: {
			'click .edit-details' : 'editDetails' ,
			'click .cancel-btn'   : 'cancelEdit'  ,
			'click .save-btn'     : 'saveDetails' ,
			'click .addCat'       : 'editDetails' ,
			'change #counselorImg' : 'fileSelectHandler',
			'click #edit-categories' : 'showAutoComplete' ,
			'click .cat-show-more' : 'showMoreCat' ,
			'click .cat-show-less' : 'showLessCat' ,
			'click .add-option' : 'addCustomOptions',
			'click .cp-options-delete' : 'deleteCustomOption',
			"change #counselor-title-select" : 'showTitleOptions'
 		},

 		showTitleOptions : function(e){

 			var selectedTitle = $(e.currentTarget).val() ;

 			if(selectedTitle == "others"){
 				$("#other-title-text").removeClass("hide");
 			}else{
 				$("#other-title-text").addClass("hide");
 				$("#other-title-text").val("");
 			}

 		},

 		addCustomOptions : function(e){

 			var dataProp = $(e.currentTarget).attr("id");
 			var prodID = dataProp.match(/add-(.*?)$/)[1];

 			var inputVal = $("#edit-" + prodID).val();

 			if(inputVal.length > 0){
	 			$("#edit-" + prodID + "-Values").append('<li class="cp-options"> <span>' + inputVal + '</span><i class="mdi mdi-close right"></i> </li>');
 			}

 			$("#edit-" + prodID).val('');
 		},

 		deleteCustomOption : function(e){

 			$(e.currentTarget).parent().remove();
 		},

		fileSelectHandler : function(e){
			
		    // get selected file
		    var oFile = e.target.files[0];

		    console.log("hello", e, oFile);
		    // hide all errors
		    $('.ierror').addClass('hide');

		    // check for image type (jpg and png are allowed)
		    var rFilter = /^(image\/jpeg|image\/png)$/i;
		    if (! rFilter.test(oFile.type)) {
		    	$('#form-error-pimg').removeClass('hide');
		        return;
		    }

		    // check for file size
		    if (oFile.size > 250 * 1024) {
		        $('#form-error-pimg-size').removeClass('hide');
		        return;
		    }
		    
		    this.counselorImg.render( oFile, this.userInfo );
		   	
		},
 		showMoreCat : function(e){
 			$("#counselor-cat-list").css("overflow", "visible") ;
 			$(".cat-show-less").removeClass("hide") ;
 			$(".cat-show-more").addClass("hide") ;
 		},
 		showLessCat : function(e){
 			$("#counselor-cat-list").css("overflow", "hidden") ;
 			$(".cat-show-less").addClass("hide") ;
 			$(".cat-show-more").removeClass("hide") ;
 		},

		showAutoComplete : function(e){
			if(Utils.isMobileDevice())
				$("#edit-categories").autocomplete('search', "");
		},
		addCategory : function(e){

			$("#edit_categories_chosen").removeClass("hide") ;
			$("#edit-categories").removeClass("hide")        ;
			this.editCategory();

			$(".profile-cat-list .non-editable").addClass("hide") ;
			$(".addCat").addClass("hide") ;

			$(".profile-info-cancel-save").removeClass("hide");
			$("#profile-info .edit-details").addClass("hide");
		},

		editDetails : function(e){

			var dataAttr = $(e.currentTarget).attr("data-attr") ;

			$("#" + dataAttr + " .non-editable" ).addClass("hide");
			$("#" + dataAttr + " .editable-input" ).removeClass("hide");
			$(".profile-label").removeClass('hide');
			$(".cat-show-more").addClass("hide");
			$(".cat-show-less").addClass("hide");
			if(dataAttr == "profile-info"){
				$("#" + dataAttr ).removeClass("yellow lighten-1");
				$("#" + dataAttr ).addClass("white");
				$("#edit_categories_chosen").removeClass("hide") ;
				this.editCategory();

				var currentTitle = $("#title").html() ;

				if($("#counselor-title-select option[value='"+currentTitle+"']").length > 0){
					$("#counselor-title-select").val(currentTitle);
				}else{
					$("#other-title-text").removeClass("hide");
					$("#other-title-text").val(currentTitle) ;
					$("#counselor-title-select").val("others");
				}

			}

			if(dataAttr == "personal-details"){

				$(".editable-options").removeClass("hide");
				
				$("#edit_Language_chosen").removeClass("hide") ;
				this.editLanguage();

				$("#edit_Qualification_chosen").removeClass("hide") ;
				this.editQualification();

				$("#edit_Location_chosen").removeClass("hide") ;
				this.editLocation();

				$(".add-option").removeClass("hide");

			}

			if(dataAttr == "profile-desc"){
				if( !Utils.isMobileDevice() )
					CKEDITOR.replace( 'edit-description' );
			}

			$("." + dataAttr + "-cancel-save").removeClass("hide");
			$("#" + dataAttr + " .edit-details").addClass("hide");

		},

		cancelEdit : function(e){

			var dataAttr = $(e.currentTarget).attr("data-attr") ;

			$("#" + dataAttr + " .non-editable" ).removeClass("hide");
			$("#" + dataAttr + " .editable-input" ).addClass("hide");
			$('.profile-label').addClass('hide');
			$(".cat-show-more").removeClass("hide");

			if(dataAttr == "profile-info"){
				$("#" + dataAttr ).addClass("yellow lighten-1");
				$("#" + dataAttr ).removeClass("white");

				$("#other-title-text").addClass("hide");
				$("#edit_categories_chosen").addClass("hide") ;
				if(Utils.isMobileDevice()){
					$("#edit-categories").val() ;
				}else{
					$("#edit-categories").html("");
						setTimeout( function(){
							$("#edit-categories").chosen({
								width: "100%"
							});
							$("#edit-categories").trigger("chosen:updated");
					},100);
				}
			}

			if(dataAttr == "personal-details"){
				$("#edit_Language_chosen").addClass("hide") ;
				$("#edit_Qualification_chosen").addClass("hide") ;
				$("#edit_Location_chosen").addClass("hide") ;
				$(".editable-options").addClass("hide");
				$(".add-option").addClass("hide");
				$("#edit-Language").html("");
					setTimeout( function(){
						$("#edit-Language").chosen({
							width: "100%"
						});
						$("#edit-Language").trigger("chosen:updated");
				},100);
				$("#edit-Location").html("");
					setTimeout( function(){
						$("#edit-Location").chosen({
							width: "100%"
						});
						$("#edit-Location").trigger("chosen:updated");
				},100);
				$("#edit-Qualification").html("");
					setTimeout( function(){
						$("#edit-Qualification").chosen({
							width: "100%"
						});
						$("#edit-Qualification").trigger("chosen:updated");
				},100);
			}

			if(dataAttr == "profile-desc"){
				if( !Utils.isMobileDevice() ){
					var hEd = CKEDITOR.instances['edit-description'];
					if(hEd){
						hEd.destroy(true);
					}
				}
			}

			$("." + dataAttr + "-cancel-save").addClass("hide");
			$("#" + dataAttr + " .edit-details").removeClass("hide");

		},
		saveDetails : function(e){

			var self = this ;

			var dataAttr      = $(e.currentTarget).attr("data-attr") ;
			var editableInput = $("#" + dataAttr + " .editable-input" ) ;

			var infoToEdit = this.userInfo ;
			_.each(editableInput, function(elem){

				var editedVal = $(elem).val() ;
				var dataProp  = $(elem).attr("data-property");

				if($(elem).attr("id") != undefined && $(elem).attr("id") == "edit-description"){

					var desc = "" ;
					if( !Utils.isMobileDevice() ){
						desc = CKEDITOR.instances['edit-description'].getData();
					}else{
						desc = $("#edit-description").val();
					}

					infoToEdit["customProperties"]['ShortDescription'] = [desc] ;
					$("#" + dataProp ).html(desc);

					$(elem).val(desc) ;

				}else if($(elem).attr("id") != undefined && $(elem).attr("id") == "edit-YDMessage"){

					var desc = "" ;
					desc = $("#edit-YDMessage").val();

					infoToEdit["customProperties"]['YDMessage'] = [desc] ;
					$("#" + dataProp ).html(desc);

					$(elem).val(desc) ;


				}else if($(elem).attr("parent-property") == "customProperties"){


					if(dataProp == 'Education' || dataProp == 'Awards' || dataProp == 'Experience'){

						var valuesOptions = $("#edit-"+ dataProp +"-Values li") ;

						var editedValArr = [];
						$.each(valuesOptions, function(index,elem){
							var valueText = $(elem).find("span").html();
							editedValArr.push(valueText);
						});

						if(editedValArr.length > 0){
							infoToEdit["customProperties"][dataProp] = editedValArr ;							
						}
					}else{
						var editedValArr = $("#edit-" + dataProp).val();
						infoToEdit["customProperties"][dataProp] = editedValArr ;	
					}


					$("#" + dataProp).html("") ;

					if(editedValArr.length <= 0 ){
						$("#" + dataProp).html('<div class="left detail-info non-editable">N/A</div>') ;
						$(elem).val('') ;
					}else{
						_.each(editedValArr, function(prop){
							var label = prop ;
							var replacedStr = label.replace(/\(/g, "BRACKETO") 	;
								replacedStr = replacedStr.replace(/\)/g, "BRACKETC");
								replacedStr = replacedStr.replace(/\//g, "SLASH");
								replacedStr = replacedStr.replace(/\./g, "DOT");
							$("#" + dataProp).append('<div class="left detail-info hide non-editable" id="pcust-'+replacedStr+'">'+ prop +'</div>') ;
						});
						$(elem).val(editedValArr) ;
					}

				}else if( $(elem).attr("id") != undefined && $(elem).attr("id") == "edit-categories"){
					var editedCat = $("#edit-categories").val();
					if(Utils.isMobileDevice()){
						var categoryArr = editedCat ;
						categoryArr = new Array() ;
						var categorySelected = editedCat.split(",");
						_.each(categorySelected, function(elem){
							if(!elem.trim()){
								return false ;
							}
							categoryArr.push(self.selectedCategories[elem.trim()]) ;
						});
						editedCat = categoryArr ;
					}


					var selectedCatMap = {} ;
					editedCat.map(function(obj){
						selectedCatMap[obj] = 1 ;
						return selectedCatMap ;
					});

					$(".profile-cat-list").html("") ;
					$(".cat-show-more").addClass("hide");
					if(editedCat != null ){
						var newCat = [] ;
						var catStr = "" ;
						_.each(self.categories, function(eachID){
							if(selectedCatMap[eachID.id] == 1){
								newCat.push(eachID);
								$(".profile-cat-list").append('<div class="profile-category yellow darken-1 non-editable" id="pcat-'+eachID.id+'">'+eachID.name+'</div>') ;
								catStr += eachID.name + "";

								if(Utils.isMobileDevice()){
									if(catStr.length > 50){
										$(".cat-show-more").removeClass("hide") ;
									}
								}else{
									if(catStr.length > 150){
										$(".cat-show-more").removeClass("hide") ;
									}
								}

							}
						});

						infoToEdit["categories"] = newCat ;
					}

				}else{

					if(dataProp == "title"){
						if($("#counselor-title-select").val() == "others"){
							infoToEdit["title"] = $("#other-title-text").val() ;
							$("#" + dataProp ).html($("#other-title-text").val());
							$(elem).val($("#other-title-text").val()) ;
						}else{
							infoToEdit["title"] = $("#counselor-title-select").val();
							$("#" + dataProp ).html($("#counselor-title-select").val());
							$(elem).val($("#counselor-title-select").val()) ;
						}

					}else{
						infoToEdit[dataProp] = editedVal ;
						$("#" + dataProp ).html(editedVal);
						$(elem).val(editedVal) ;
					}
					
				}

			});

			self.userInfo = infoToEdit ;

			var self = this ;
			console.log( "contextPath " + Utils.contextPath() );
			$("#title-change-counselor").html("Title & Description changes are subject to admin review. Your update will be live after being approved.");	
			$("#description-change-counselor").html("Title & Decription changes are subject to admin review. Your update will be live after being approved.");	
			$.ajax({
				url : Utils.contextPath() + "/v1/" + self.userID + "/modify/preview" ,
				method : "POST" ,
				dataType : "json" ,
				xhrFields: {
     				 withCredentials: true
			    },
				contentType: "application/json",
				data : JSON.stringify(infoToEdit)
			}).done(function(response){
				console.log(response);
				self.cancelEdit(e) ;
			}).error(function(error){
				console.log("error") ;
				console.log(error) ;
				self.cancelEdit(e) ;
			});
		},
		editCategory : function(){
			var categories = this.categories ;

			self = this ;
			if(Utils.isMobileDevice()){
				var categoriesArr = new Array() ;
				var categoryInput = ""          ;
				$.each(categories,function(key,value){
					categoriesArr.push({
						"key" : value.id ,
						"value" : value.name
					}) ;

					if( $("#pcat-" + value.id ).length > 0 ){
						categoryInput += value.name + ", " ;
						self.selectedCategories[value.name] = value.id ;
					}

				});

				$("#edit-categories").val(categoryInput) ;
				$( "#edit-categories" )
					.bind( "keydown", function( event ) {
						if ( event.keyCode === $.ui.keyCode.TAB &&
						    $( this ).autocomplete( "instance" ).menu.active ) {
						  event.preventDefault();
						}
					})
					.autocomplete({
						minLength: 0,
						source: function( request, response ) {
						  	response( $.ui.autocomplete.filter(
						    categoriesArr, Utils.JUIextractLast( request.term ) ) );
						},
						focus: function() {
						  return false;
						},
						select: function( event, ui ) {
							self.selectedCategories[ui.item.value] = ui.item.key ;

							var terms = Utils.JUIsplit( this.value );
							terms.pop();
							terms.push( ui.item.value );
							terms.push( "" );
							this.value = terms.join( ", " );
							return false;
						}
					});

			}else{
				$.each(categories, function(key, value){
					if( $("#pcat-" + value.id ).length > 0 )
						var option = "<option value='"+value.id+"' selected>"+value.name+"</option>";
					else
						var option = "<option value='"+value.id+"'>"+value.name+"</option>";
					$("#edit-categories").append( option );
				});
				setTimeout( function(){
					$("#edit-categories").chosen({
						width: "100%"
					});
					$("#edit-categories").trigger("chosen:updated");
				},100);

			}

		} ,
		editLanguage : function(e){
			$.each(this.languages, function(i, elem){
				if( $("#pcust-" + elem.label).length > 0 )
					var option = "<option value='"+elem.label+"' selected>"+elem.label+"</option>";
				else
					var option = "<option value='"+elem.label+"'>"+elem.label+"</option>";
				$("#edit-Language").append( option );
			});
			setTimeout( function(){
				$("#edit-Language").chosen({
					width: "100%"
				});
				$("#edit-Language").trigger("chosen:updated");
			},100);
		},
		editQualification : function(e){
			$.each(this.qualifications, function(i, elem){
				var label = elem.label ;
				var replacedStr = label.replace(/\(/g, "BRACKETO") 	;
					replacedStr = replacedStr.replace(/\)/g, "BRACKETC");
					replacedStr = replacedStr.replace(/\//g, "SLASH");
				if( $("#pcust-" + replacedStr).length > 0 )
					var option = "<option value='"+elem.label+"' selected>"+elem.label+"</option>";
				else
					var option = "<option value='"+elem.label+"'>"+elem.label+"</option>";
				$("#edit-Qualification").append( option );
			});
			setTimeout( function(){
				$("#edit-Qualification").chosen({
					width: "100%"
				});
				$("#edit-Qualification").trigger("chosen:updated");
			},100);
		},
		editLocation : function(e){
			$.each(this.locations, function(i, elem){
				if( $("#pcust-" + elem.label).length > 0 )
					var option = "<option value='"+elem.label+"' selected>"+elem.label+"</option>";
				else
					var option = "<option value='"+elem.label+"'>"+elem.label+"</option>";
				$("#edit-Location").append( option );
			});
			setTimeout( function(){
				$("#edit-Location").chosen({
					width: "100%"
				});
				$("#edit-Location").trigger("chosen:updated");
			},100);
		},
		CounselorProfilePageLayout : JST["app/templates/profile/layout.hbs"],
 		ActivityLayout      : JST['app/templates/profile/activities.hbs'] ,
	 	LoaderLayout: JST['app/templates/loader.hbs'],

		render: function() {

			var self = this ;
			var user_id = this.userModel.getUserID() ;
			var email = this.userModel.getUserEmail() ;
			self.$el.html( self.LoaderLayout );
			
			//call to get counselor staging data
			var staging_response;
			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/staging/get/counselor/" + user_id
			}).done(function(stag_resp){
				
				console.log(JSON.stringify(stag_resp));
				staging_response = stag_resp;
				console.log( "first staging response "+ JSON.stringify(staging_response) );

			}).fail(function(error){
				console.log(error);
			})
			console.log( "staging response " + JSON.stringify(staging_response) );
			//end call


			$.ajax({
				method : "GET",
				url : Utils.contextPath()+ "/v1/counselor/"+ user_id
			}).done(function(response){
				
				var lastActive = response.lastActive ;
				var formattedLastActive = "Never" ;
				if( lastActive != 0 ){
					formattedLastActive     = Utils.getDateDiff(new Date( lastActive * 1000 ).toISOString(), 0) ;
				}

				if (staging_response) {
					
					if (staging_response.title) {
						response.title = staging_response.title;
						//$("#title-change-counselor").html("Title changes are subject to admin review. Your update will be live after being approved.");	

					}
					if (staging_response.description) {
						response.description = staging_response.description;	
						//$("#description-change-counselor").html("Description changes are subject to admin review. Your update will be live after being approved.");
					}

					if(staging_response.customProperties != null){
						$.each(staging_response.customProperties, function(key, value){
							response.customProperties[key] = staging_response.customProperties[key];
						})
					}
				}

        if(response.numOfConversation < 40){
					formattedLastActive = "N/A" ;
				}

				var profileDetails = response ;

				var userCategories = profileDetails.categories ;

				var catStr = "" ;
				_.each(userCategories, function(eachCat){
					catStr += eachCat.name + "" ;
				})

				
				self.userInfo = response ;
				console.log( "Counselor Json " + JSON.stringify( response ) ) ;
				self.$el.html( self.CounselorProfilePageLayout({ email: email,  userType : "OPERATOR", imgUrl : profileDetails.picUrl,  profile : profileDetails, formattedLastActive: formattedLastActive, isMobileDevice: Utils.isMobileDevice() }) );
				
				if (staging_response) {
					
					if (staging_response.title) {
						
						$("#title-change-counselor").html("Title changes are subject to admin review. Your update will be live after being approved.");	

					}
					if (staging_response.description) {
							
						$("#description-change-counselor").html("Description changes are subject to admin review. Your update will be live after being approved.");
					}
				}

				if(Utils.isMobileDevice()){
					$(".edit-details").addClass("hide") ;
					if(catStr.length > 50){
						$(".cat-show-more").removeClass("hide") ;
					}
				}else{
					if(catStr.length > 150){
						$(".cat-show-more").removeClass("hide") ;
					}
				}

				$.ajax({
					method : "GET",
					url : Utils.contextPath() + "/v2/users/" + user_id + "/activities"
				}).done(function(response){
					var activities = response ;

					activities.answered = activities.answered || 0 ;
					activities.liked = activities.liked || 0 ;
					activities.bookmarked = activities.bookmarked || 0 ;

					self.$el.find("#activity-container").html( self.ActivityLayout({userType : "OPERATOR", activities: activities }) );
				}).error(function(error){
					console.log(error)
				});

			}).fail(function(error){
				console.log(error) ;
			});

        	var category = {};
        	$.ajax({
            	method: "GET",
            	url: Utils.contextPath()+'/category?include_faq=false'
        	}).done(function(response){
        		console.log(response) ;
        		self.categories = response ;
        	}).fail(function(error){});

        	$.ajax({
            	method: "GET",
            	url: Utils.contextPath() + '/v1/counselor/filters'
        	}).done(function(response){
        		console.log(response) ;
        		$.each(response, function(i, elem){
        			if(elem.name == "language"){
        				self.languages = elem.filters ;
        			}
        			if(elem.name == "qualification"){
        				self.qualifications = elem.filters ;
        			}
        			if(elem.name == "location"){
        				self.locations = elem.filters ;
        			}
        		});
        	}).fail(function(error){});

		}
	});

	CounselorProfilePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	CounselorProfilePage.prototype.clean = function() {
      	this.remove();

	};

	return CounselorProfilePage;
});
