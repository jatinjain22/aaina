define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/leaveMessage/page' ,
	'model/counselors_list',
	'view/paymentPending/payment_pending',
	'utils',
	'model/users',
	'event/dispatcher',
], function($,_, Backbone, JST, LeaveMessageView, CounselorsListModel, PaymentPendingView, Utils, UserModel, Dispatcher) {

	var CounselorSinglePage = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.counselorListModel = new CounselorsListModel() ;
			this.userModel          = new UserModel()           ;
			this.leaveMessage       = new LeaveMessageView()    ;
			this.paymentPendingView = new PaymentPendingView()  ;
			this.reviews            = ''; 
			this.counselorPicUrl	= '';
		},
		events: {
			'click .favorite-section'  : 'favoriteUser',
			'click .chat-counselor'    : 'chatCounselor',
			'click .message-counselor'  : 'messageCounselor',
			'click .view-more-review':    'viewMoreReview', 
			'click .view-less-review': 'viewLessReview',
			'click .reviewer-text-reply a': 'giveReplytoReview',
			'click .edit-review-reply': 'editReviewReply',
			'click .delete-review-reply': 'deleteReviewReply',
			'click .update-review-reply': 'updateReviewReply',
			'click .save-review-reply': 'saveReviewReply'
		},
		CounselorMoreReviewPageLayout : JST["app/templates/counselor/morereviews.hbs"],
		CounselorReviewReplyFormPageLayout: JST["app/templates/counselor/replyForm.hbs"],
		CounselorEditDeleteFormPageLayout: JST["app/templates/counselor/editDeleteForm.hbs"],
		giveReplytoReview: function(e) {
		
			var self = this;
			var currentTarget = $(e.currentTarget);
			console.log( currentTarget.parent() );

			$( e.currentTarget ).replaceWith( self.CounselorReviewReplyFormPageLayout() );
		
		},
		updateReviewReply: function(e) {

			var self = this;
			var currentTarget = $( e.currentTarget );
			var updateForm = currentTarget.parents( '.update-review-reply-form' );
			console.log( updateForm );
			var updateVal = updateForm.find('#review-reply-input').val();
			console.log( 'update Val ' + updateVal );
			updateForm.parent().replaceWith( self.CounselorEditDeleteFormPageLayout({val: updateVal}) );
		
		},
		saveReviewReply: function(e) {
		
			var self = this;
			var currentTarget = $( e.currentTarget );
			var saveForm = currentTarget.parents( '.save-review-reply-form' );
			var saveVal = saveForm.find('#review-reply-input').val();
			console.log( 'save val '+ saveVal );
			saveForm.parent().replaceWith( self.CounselorEditDeleteFormPageLayout({val: saveVal}) );
		
		},
		editReviewReply: function(e) {
		
			var self = this;
			var currentTarget = $(e.currentTarget);
			console.log( currentTarget.parent() );
			var ID = currentTarget.parents( '.reviewer-text-reply' ).data('reviewid');
			console.log( 'id '+ ID );
			var inputValue = currentTarget.parents( '.reviewer-text-reply' ).find('.reply-description').text();
			console.log( 'inputValue '+ inputValue );
			$( e.currentTarget ).parents('.reviewer-text-reply').html( self.CounselorReviewReplyFormPageLayout( {value:inputValue}) );
		
		},
		deleteReviewReply: function(e) {
		
			var self = this;
			var currentTarget = $(e.currentTarget);
			var ID = currentTarget.parents( '.reviewer-text-reply' ).data('reviewid');
			console.log( 'id '+ ID );
			$( e.currentTarget ).parents('.reviewer-text-reply').html('<a>Post Reply</a>');
		
		},
		
		viewMoreReview: function(e) {
			var self = this;
			
			var userId;
			var userType;
			if ( Utils.isLoggedIn() ) {
				userId = self.userModel.getUserID();
				userType = self.userModel.getUserType();
			}
			else {
				userId = -1;
				userType = '';
			}
			console.log( 'userType '+ userType );
			console.log( 'userId '+ userId );
			$('.view-more-review').addClass('hide');
			console.log('reviews ' + JSON.stringify(self.reviews.slice(5)) );
			var reviews = self.reviews.slice(5);
			self.$el.find('.counselor-desc').append( self.CounselorMoreReviewPageLayout({reviews:reviews, userId: userId, userType: userType, isLoggedIn: Utils.isLoggedIn(), picUrl: self.counselorPicUrl }) );
			self.$el.find('.counselor-desc').append('<div class="view-less" ><a class="view-less-review">View Less Reviews</a></div>');
			$("html, body").stop().animate({
	      		scrollTop: $(".view-less").offset().top}, 1000,"easeInOutExpo");

		},
		viewLessReview: function(e) {
			var self = this;
			$('.view-less-review').addClass('hide');
			$('.more-review-text').remove();
			$('.view-more-review').removeClass('hide');
			//$.scrollTo('.counselor-desc');
			$("html, body").stop().animate({
	      		scrollTop: $(".counselor-desc").offset().top}, 1000,"easeInOutExpo");
		},
		messageCounselor : function(e){

			var counselorInfo = {
				id : this.id ,
				name : $("#counselor-name").html().trim(),
			}
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "counselorPage", "message", JSON.stringify(counselorInfo) ) ;
			}else{
				this.leaveMessage.render( counselorInfo ) ;	
			}

		},
		chatCounselor : function(e){
			var chatURL = $(e.currentTarget).attr("data-href") ;
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "counselorPage", "counselorChat", chatURL ) ;
			}else{
				var username =  this.userModel.getUserName() ;
				location.href = chatURL + "&username=" + username;
			}
		},

		favoriteUser : function(e){
			e.stopPropagation();
			
			var currentObj = $(e.currentTarget);

			if( currentObj.children().attr("class").match("mdi-action-favorite-outline") ){
				currentObj.children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
				currentObj.children().removeClass('grey-text').addClass('red-text') ;
			}else{
				currentObj.children().removeClass('mdi-action-favorite').addClass('mdi-action-favorite-outline') ;				
				currentObj.children().removeClass('red-text').addClass('grey-text') ;
			}

			var userID      = this.userModel.getUserID() ;
			var counselorID = this.id                    ;
			$.ajax({
				method : "POST" ,
				url    : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/'+ counselorID +'/favourite' ,
				statusCode:{
    		        401 : function(){
                		//location.href = "/logout?r=talkItOut";
                		Backbone.history.navigate("/logout?r=talkItOut", {trigger: true});
	            	},
	        	},
 
			}).done(function(response){
				console.log(response) ;
			}).error(function(error){
				console.log("Error") ;
			});

			return false ;
		},
		CounselorSinglePageLayout : JST["app/templates/counselor/singlepage.hbs"],
		LoaderLayout : JST["app/templates/loader.hbs"],
		render: function() {

			var self = this ;
			//var user_id = self.userModel.getUserID() ;
			this.$el.html(this.LoaderLayout()) ;
			

			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/" + self.id
			}).done(function(response){
				
				$.ajax({
					url : Utils.contextPath() + '/v1/counselor/rating/' + self.id ,
				}).done(function(response){
					self.reviews = response;
					console.log('hello1');
					console.log( "reviews json " + JSON.stringify(response) );		
					if ( response.length > 5) {
						$('.view-more-review').removeClass('hide');
					}
				}).error(function(error){
					console.log('Error');
					console.log(error);
				});
				

				var ratingHTML = "" ;
				for(index = 0; index < response.rating; index ++ ){
					ratingHTML += '<i class="mdi-action-grade teal-text rating"></i>' ;
				}
				for(index = response.rating; index < 5; index++){
					ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
				}

				var lastActive = response.lastActive ;
				var formattedLastActive = "Never" ; 
				if( lastActive != 0 ){
					formattedLastActive     = Utils.getDateDiff(new Date( lastActive * 1000 ).toISOString(), 0) ;
				}
	
				if(response.numOfConversation < 40){
					formattedLastActive = "N/A" ;
				}


				$(".counselor-name-header").html(response.name) ;

				var colorArr = Utils.backgroundColorArr() ;
				var thisCounselorColor = colorArr[ response.id % 7 ] ;

				var userId;
				var userType;
				if ( Utils.isLoggedIn() ) {
					userId = self.userModel.getUserID();
					userType = self.userModel.getUserType();
				}
				else {
					userId = -1;
					userType = '';
				}

				console.log( ' user type: '+ userType );
				console.log( ' userId: ' + userId );
				self.counselorPicUrl = response.picUrl;
				//self.reviews and response.review are different
				//console.log('hello2');
				// console.log("review length " + self.reviews.length);
				// if (self.reviews.length > 5) {
				// 	response.reviews.readMore = 1;
				// } 
				// else {
				// 	response.reviews.readMore = 0;
				// }

				console.log( "response " + JSON.stringify(response) );

				self.$el.html( self.CounselorSinglePageLayout({ counselor : response, ratingHTML: ratingHTML, formattedLastActive:formattedLastActive, counselorColor : thisCounselorColor, isLoggedIn : Utils.isLoggedIn(), userType: userType, userId: userId }) );	
				$("#couselor-rating-" + response.id ).html(ratingHTML) ;

				if(Utils.isLoggedIn()){			
					var userID = self.userModel.getUserID() ;
					$.ajax({
						url : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/favourite' ,
						statusCode:{
    		        		401 : function(){
                				//location.href = "/logout?r=talkItOut"  ;
                				Backbone.history.navigate("/logout?r=talkItOut", {trigger: true});
	            			},
	        			},

					}).done(function(response){
						console.log(response) ;
						_.each(response, function(eachElem){
							console.log(eachElem) ;
							if(eachElem == self.id){
								$(".favorite-section" ).children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
								$(".favorite-section"  ).children().removeClass('grey-text').addClass('red-text') ;
							}
						});
					}).error(function(error){
						console.log("Error");
						console.log(error) ;
					});
				}
				if(Utils.isLoggedIn()){

					self.paymentPendingView.render() ;
				}


					$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
					}).done(function(response){
						
						_.each(response, function(value, key){
							
							if( value.status == "true" ){
								$("#chat-counselor-" + key).removeClass("hide");

								$("#chat-counselor-" + key).attr("data-href", value.url);

							}
						});
					}).error(function(error){

					});


			}).fail(function(error){
				console.log(error) ;
			});

		}
	});

	CounselorSinglePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	CounselorSinglePage.prototype.clean = function() {
      	this.remove();
	};

	return CounselorSinglePage;
});