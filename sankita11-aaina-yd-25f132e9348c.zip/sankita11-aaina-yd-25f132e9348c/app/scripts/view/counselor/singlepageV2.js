define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/leaveMessage/page' ,
	'model/counselors_list',
	'view/paymentPending/payment_pending',
	'utils',
	'model/users',
	'event/dispatcher',
], function($,_, Backbone, JST, LeaveMessageView, CounselorsListModel, PaymentPendingView, Utils, UserModel, Dispatcher) {

	var CounselorSinglePage = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.counselorListModel = new CounselorsListModel() ;
			this.userModel          = new UserModel()           ;
			this.leaveMessage       = new LeaveMessageView()    ;
			this.paymentPendingView = new PaymentPendingView()  ;
			this.reviews            = '';
			this.counselorPicUrl	= '';
			this.favouriteCnt       = 0 ;
			this.statusInterval		= 0 ;
		},
		events: {
			'click .expert-page-app-btn' : 'redirectToAppointment',
			'click .similiar-experts-app-btn' : 'redirectToAppointment',
			'click .expert-page-msg-btn' : 'openCompose',
			'click .expert-page-chat-btn' : 'redirectToChat',
			'click .similiar-experts-app-btn' : 'redirectToAppointment',
			'click .similiar-experts-msg-btn' : 'openCompose',
			'click .similiar-experts-chat-btn' : 'redirectToChat',
			'click .favourite-counselor-icon' : 'favoriteCounselor',
			'click .expert-rating-cnt span' : 'scrollToReviews',
			'click .cp-category-show-more' : 'showFullList',
			'click .cp-category-show-less' : 'showLessList',
			'click .review-view-more' : 'viewMoreReview',
			'click .review-view-less' : 'viewLessReview',
			'click .cp-back-to-experts' : 'redirectToExperts',
			'click .smiliar-experts-container' : 'rediretToProfile',
			"click .expert-share-profile a":"trackMixpanelForShare",
		},
		CounselorSinglePageLayout : JST["app/templates/counselor/singlepageV2.hbs"],
		LoaderLayout : JST["app/templates/loader.hbs"],
		CounselorMoreReviewPageLayout : JST["app/templates/counselor/moreReviewsV2.hbs"],
		trackMixpanelForShare:function(e){
			var name = $(e.currentTarget).attr('title');
			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

			           mixpanel.track('Button Click', { 'itemname' : "Expert Profile shared through "+name});
			       }
		},
		rediretToProfile : function(e){

			var expertName = $(e.currentTarget).attr("cName");
			var expertID = $(e.currentTarget).attr("cID");

			expertName = expertName.replace(/\s/g, "-");

			var profileURL = "/counselor/" + expertName + "-" + expertID ;

			Backbone.history.navigate(profileURL, {trigger: true});

		},

		redirectToExperts : function(e){
			sessionStorage.setItem('restoreCounselorListView','true');
			Backbone.history.navigate("/talkItOut?from=showAllExperts", {trigger: true});

		},

		showFullList : function(e){

			$(".counselor-category-info").css("height", "auto");
			$(".extra-category").removeClass("hide");
			$(".cp-category-show-more").addClass("hide");
			$(".cp-category-show-less").removeClass("hide");
		},

		showLessList : function(e){

			$(".counselor-category-info").css("height", "97px");
			$(".extra-category").addClass("hide");
			$(".cp-category-show-less").addClass("hide");
			$(".cp-category-show-more").removeClass("hide");
		},

		scrollToReviews : function(e){

			if($(".review-section").is(":visible")){
				$('html, body').animate({
	       		 scrollTop: $(".review-section").offset().top
	    		}, 2000);
			}else{
				$('html, body').animate({
	       		 scrollTop: $(".review-section-mobile").offset().top
	    		}, 2000);

			}


		},


		viewMoreReview: function(e) {
			var self = this;

			$("html, body").stop().animate({
	      		scrollTop: $(".cp-more-reviews").offset().top}, 1000,"easeInOutExpo");

			$('.review-view-more').addClass('hide');
			console.log('reviews ' + JSON.stringify(self.reviews.slice(5)) );
			var reviews = self.reviews.slice(5);
			$('.cp-more-reviews').append( self.CounselorMoreReviewPageLayout({reviews:reviews}) );

			$('.review-view-less').removeClass('hide');
		},


		viewLessReview: function(e) {
			var self = this;
			$('.review-view-less').addClass('hide');
			$('.cp-more-reviews').html('');
			$('.review-view-more').removeClass('hide');
			//$.scrollTo('.counselor-desc');
			if($(".review-section").is(":visible")){
				$("html, body").stop().animate({
		      		scrollTop: $(".review-section").offset().top}, 1000,"easeInOutExpo");

			}else{
				$("html, body").stop().animate({
			      	scrollTop: $(".review-section-mobile").offset().top}, 1000,"easeInOutExpo");

			}
		},
		favoriteCounselor : function(e){
			e.stopPropagation();

			var self = this ;

			var currentObj = $(e.currentTarget);

			var favoriteStr = '';
			if(self.favouriteCnt <= 1){
				favoriteStr = self.favouriteCnt  + ' person';
			}else if( self.favouriteCnt > 1 ){
				favoriteStr = self.favouriteCnt  + ' people';
			}

			if( currentObj.attr("class").match("mdi-heart-outline") ){
				currentObj.removeClass('mdi-heart-outline').addClass('mdi-heart') ;
				var strToAppend = 'by you ';
				if(self.favouriteCnt >= 1){
					 strToAppend += 'and ' + favoriteStr;
				}

				$(".expert-favorite-cnt-text").html( strToAppend ) ;
			}else{
				currentObj.removeClass('mdi-heart').addClass('mdi-heart-outline') ;
				$(".expert-favorite-cnt-text").html( favoriteStr);
			}

			var userID      = this.userModel.getUserID() ;
			var counselorID = self.counselorID ;
			$.ajax({
				method : "POST" ,
				url    : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/'+ counselorID +'/favourite'  ,
				statusCode:{
            		401 : function(){
                		Backbone.history.navigate("/logout?r=talkItOut", {trigger: true});
            		},
	        	},

			}).done(function(response){
				//console.log(response) ;
			}).error(function(error){
				console.log("Error") ;
			});

			return false ;
		},

		redirectToChat : function(e){
			e.stopPropagation();
			var divID = $(e.currentTarget).attr("id");
			var counselorID = divID.split(/-/)[2];

			var chatURL = $(e.currentTarget).attr("data-href") ;
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "counselorPage", "counselorChat", chatURL + "BREAKBREAK" + counselorID ) ;
			}else{
				Dispatcher.trigger('chatQuickCheck', 'direct', counselorID, chatURL, "counselorPage", "counselorPage" );
			}

		},

		openCompose : function(e){

			e.stopPropagation();
			var counselorInfo = {
				id : $(e.currentTarget).attr('cID') ,
				name : $(e.currentTarget).attr('cName')  ,
			};

			var buttonDesc = $(e.currentTarget).attr("data-desc");

			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "quickMessage", counselorInfo ) ;
			}else{
				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorInfo.id
					}
				});
			}

		},

		redirectToAppointment : function(e){

			e.stopPropagation();

			var counselorID = $(e.currentTarget).attr("cID");
			var counselorName = $(e.currentTarget).attr("cName");

			counselorName = counselorName.replace(/\s/g, '-');

			location.href = "/bookAppointment?from=counselor&conID="+ counselorID +"&catID=Others&conName=" + counselorName;

		},

		renderSimiliarExperts : function(category){

			var self = this ;

			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/?page_number=1&category=" + category.id
			}).done(function(response){

				$(".similiar-experts-loader").addClass("hide");

				var counselorsParsed = 0 ;
				$.each(response, function(index, elem){

					if(elem.id == 101){
						return true ;
					}

					if(counselorsParsed >= 3){
						return false ;
					}

					if(self.counselorID == elem.id){
						return true ;
					}

					var similiarExperts = $(".smiliar-experts-container-back").clone();

					similiarExperts.addClass("smiliar-experts-container").removeClass("smiliar-experts-container-back");
					similiarExperts.removeClass("hide");

					similiarExperts.attr("cID", elem.id);
					similiarExperts.attr("cName", elem.name);

					similiarExperts.find(".smiliar-experts-img").attr("src", elem.picUrl);

					var ratingHTML = "" ;
					for(index = 0; index < elem.rating; index ++ ){
						ratingHTML += '<i class="mdi-action-grade teal-text rating"></i>' ;
					}
					for(index = elem.rating; index < 5; index++){
						ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
					}

					similiarExperts.find(".similiar-experts-name").html(elem.name);
					similiarExperts.find(".similiar-experts-title").html(elem.title);
					similiarExperts.find(".similiar-experts-conversations").html('<span> Conversation : </span> ' + elem.numOfConversation);

					similiarExperts.find(".similiar-experts-rating").html(ratingHTML);

					similiarExperts.find(".similiar-experts-app-btn").attr("cID", elem.id);
					similiarExperts.find(".similiar-experts-app-btn").attr("cName", elem.name);

					similiarExperts.find(".similiar-experts-msg-btn").attr("cID", elem.id);
					similiarExperts.find(".similiar-experts-msg-btn").attr("cName", elem.name);

					similiarExperts.find(".similiar-experts-chat-btn").attr("id", "similiar-chat-btn-" + elem.id);

					similiarExperts.appendTo(".similiar-experts");


					counselorsParsed += 1 ;

				});

				$.ajax({
					url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){

					_.each(response, function(value, key){

						if( value.status == "true" ){
							$("#similiar-chat-btn-" + key).removeClass("hide");

							$("#similiar-chat-btn-" + key).attr("data-href", value.url);

						}
					});
				}).error(function(error){

				});

				//On the fly experts availability status check for every 10 seconds.
	            self.statusInterval = setInterval(function () {
	                $.ajax({
	                    url: Utils.contextPath() + '/v1/counselor/status',
	                }).done(function (response) {
	                    _.each(response, function (value, key) {
	                    	if(self.counselorID == key) {
	                    		if (value.status == "true") {//$("#chat-btn-" + key).hasClass("hide")) {
	                                $("#chat-btn-" + key).removeClass("hide");
	                    		}
	                    		else {
	                                $("#chat-btn-" + key).addClass("hide");
	                    		}
	                    	}
	                        else if (value.status == "true") {
	                            if ($("#similiar-chat-btn-" + key).hasClass("hide")) {
	                                $("#similiar-chat-btn-" + key).removeClass("hide");
	                                $("#similiar-chat-btn-" + key).attr("data-href", value.url);
	                            } else if ($("#similiar-chat-btn-" + key + " span").text() == "OFFLINE") {
	                                $("#similiar-chat-btn-" + key + " span").fadeOut(function () {
	                                    $(this).text("CHAT")
	                                }).fadeIn();
	                                $("#similiar-chat-btn-" + key).attr("data-href", value.url);
	                            }
	                        } else if (value.status == "false") {
	                            $("#similiar-chat-btn-" + key).addClass("hide")
	                        }
	                    });
	                });
	            }, 60 * 1000);

			}).error(function(error){

			});


		},
		setMetaData : function(data){
			var cName = data.name.replace(/\s/, '-');
			$('meta[property="og:description"]').attr('content', "Have a roadblock? Looking for guidance to kick that off? This expert on YourDOST could help you.");
			$('meta[property="og:title"]').attr('content',data.name + " - A YourDOST expert");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/counselor/' + cName + '-' + data.id);
			document.title= data.name + " - A YourDOST expert";
    	$('meta[name=description]').attr('content', "Have a roadblock? Looking for guidance to kick that off? This expert on YourDOST could help you.");
    	$('meta[name=title]').attr('content',data.name + " - A YourDOST expert");
    	$('meta[property="og:url"]').attr('content','https://yourdost.com/counselor/' + cName + '-' + data.id);
    	$('meta[property="og:image"]').attr('content',data.picUrl);
    	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/counselor/' + cName + '-' + data.id);
		},
		render: function() {

			var self = this ;
			this.$el.html(this.LoaderLayout()) ;

			var counselorParamStr = self.id ;
			var counselorParamInfo = counselorParamStr.split(/-/);

			self.counselorID = counselorParamInfo[counselorParamInfo.length - 1] ;

			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/" + self.counselorID
			}).done(function(response){
				self.setMetaData(response)
				$.ajax({
					url : Utils.contextPath() + '/v1/counselor/rating/' + self.counselorID
				}).done(function(reviews){
					self.reviews = reviews;
					if(reviews.length > 5){
						$(".review-view-more").removeClass("hide");
					}

				}).error(function(error){
					console.log(error);
				})

				var ratingHTML = "" ;
				for(index = 0; index < response.rating; index ++ ){
					ratingHTML += '<i class="mdi-action-grade yellow-rating rating"></i>' ;
				}
				for(index = response.rating; index < 5; index++){
					ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
				}



				var lastActive = response.lastActive ;
				var formattedLastActive = "Never" ;
				if( lastActive != 0 ){
					formattedLastActive     = Utils.getDateDiff(new Date( lastActive * 1000 ).toISOString(), 0) ;
				}

				if(response.numOfConversation < 40){
					formattedLastActive = "N/A" ;
				}


				var userId;
				var userType;
				if ( Utils.isLoggedIn() ) {
					userId = self.userModel.getUserID();
					userType = self.userModel.getUserType();
				}
				else {
					userId = -1;
					userType = '';
				}

				console.log( ' user type: '+ userType );
				console.log( ' userId: ' + userId );
				self.counselorPicUrl = response.picUrl;

				console.log( "response " + JSON.stringify(response) );

				var educationExist = 0 ;
				if(response.customProperties.Masters != undefined || response.customProperties.Bachelors != undefined ){
					educationExist = 1 ;
				}

				var nameForURL = response.name.replace(/\s/, '-');

				var counselorUrl = Utils.socialShareUrl() + "counselor/" + nameForURL + "-" + response.id ;

				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

			           mixpanel.track('Expert Profile Page', { 'itemname' : response.name});
			       }
				self.$el.html( self.CounselorSinglePageLayout({ counselorUrl: counselorUrl, counselor : response, ratingHTML: ratingHTML, formattedLastActive:formattedLastActive,  isLoggedIn : Utils.isLoggedIn(), userType: userType, userId: userId, educationExist : educationExist }) );
				$("#couselor-rating-" + response.id ).html(ratingHTML) ;

				var categories_parsed = 0 ;
				$.each(response.categories, function(index, elem){

					var classToAdd = "" ;
					if(categories_parsed >= 11){
						classToAdd = "hide extra-category";
						$(".cp-category-show-more").removeClass("hide");
					}

					$(".counselor-category-info").append('<a href="/talkItOut?category='+elem.id+'" class="'+classToAdd+' col cp-category">'+elem.name+'</a>');
					categories_parsed += 1 ;

				});

				/*var catNames = response.categories.map(function(catElem){
    								return catElem.name;
								}).join("");


				if(catNames.length > 150){
					$(".cp-category-show-more").removeClass("hide");
				}*/

				setTimeout(function(){
					addthis.toolbox('.addthis_toolbox');
				}, 2000)
				//addthis.button('.addthis_button_facebook_like');

				self.renderSimiliarExperts(response.categories[0]);

				 $('ul.tabs').tabs();
				$.ajax({
					url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){

					_.each(response, function(value, key){

						if( value.status == "true" ){
							$("#chat-btn-" + key).removeClass("hide");
							$("#chat-btn-" + key).attr("data-href", value.url);

							$("#mobile-chat-btn-" + key).removeClass("hide");
							$("#mobile-chat-btn-" + key).attr("data-href", value.url);

						}
					});
				}).error(function(error){

				});


				$.ajax({
					url : Utils.contextPath() + "/v1/counselor/"+ response.id +"/ratingFavoriteCnt",
				}).done(function(response){
					console.log(response);

					if(response.rating == 0){
						$(".expert-rating-cnt").html( '');
					}else{
						$(".expert-rating-cnt span").html( response.rating + ' reviews');
						$(".review-heading span").html( response.rating );
					}


					self.favouriteCnt = response.favorite;

					var peopleStr = "people"
					if((self.favouriteCnt ) <= 1){
						peopleStr = "person" ;
					}
					$(".favorite-cnt").html( response.favorite + ' ' + peopleStr);


					if(Utils.isLoggedIn()){
						var userID = self.userModel.getUserID() ;
						$.ajax({
							url : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/favourite' ,
							statusCode:{
	    		        		401 : function(){
	                				//location.href = "/logout?r=talkItOut"  ;
	                				Backbone.history.navigate("/logout?r=talkItOut", {trigger: true});
		            			},
		        			},

						}).done(function(response){
							console.log(response) ;
							_.each(response, function(eachElem){
								console.log(eachElem) ;
								if(eachElem == self.counselorID){
									$(".favourite-counselor-icon" ).removeClass('mdi-heart-outline').addClass('mdi-heart') ;
									$(".my-fav-expert-text").html('by you and ');

									if( (self.favouriteCnt - 1) > 0){

										var peopleStr = "people"
										if((self.favouriteCnt - 1) == 1){
											peopleStr = "person" ;
										}

										$(".favorite-cnt").html( (self.favouriteCnt - 1) + ' ' + peopleStr);
									}

								}
							});
						}).error(function(error){
							console.log("Error");
							console.log(error) ;
						});
					}


				}).error(function(error){
					console.log(error);
				});


/*				$.ajax({
					url : Utils.contextPath()+'/discussion/top?limit=5',
				}).done(function(response){

					console.log(response);

					$.each(response, function(index, elem){

						var postTime = Utils.getDateString(elem.lastPostedAt, 'shortdate');

						var discussionLine = $(".discussion-line-item-back").clone();

						discussionLine.removeClass("hide");
						discussionLine.removeClass("discussion-line-item-back").addClass("discussion-line-item");

						discussionLine.find(".cp-discussion-text").html(elem.fancyTitle);
						discussionLine.find(".cp-discussion-info").html(elem.lastPosterUsername + ", " + postTime);

						discussionLine.appendTo( ".discussions-container ul" );

					});


				}).error(function(error){
					console.log(error);
				});
*/

				var firstName = response.name.replace(/\s.*?$/, "");

				$.ajax({
					method : "GET",
					dataType: 'jsonp',
					url : "https://yourdost.com/blog/api/get_author_posts?author_slug=" + firstName.toLowerCase()
				}).done(function(response){

					var posts = response.posts ;

					console.log(posts);

					if(posts == undefined){
						$(".article-main-container").addClass("hide");
						return true ;
					}
					$(".articles-loader").addClass("hide");

					var articlesParsed = 0 ;
					$.each(posts, function(index, elem){

						var postTime = Utils.getDateString(elem.date, 'shortdate');

						var articleLine = $(".article-line-item-back").clone();

						articleLine.removeClass("hide");
						articleLine.removeClass("article-line-item-back").addClass("article-line-item");

						articleLine.find(".article-thumbnail").attr('src', elem.thumbnail);
						articleLine.find(".blog-title").html(elem.title);
						articleLine.find(".blog-title").attr("href",elem.url);
						articleLine.find(".blog-title").attr("target","_blank");
						articleLine.find(".article-post-date").html(postTime);

						articleLine.appendTo( ".articles-container ul" );

						articlesParsed += 1 ;

						if(articlesParsed >= 5){
							return false;
						}

					});

				}).error(function(error){
					$('.article-main-container').addClass('hide');
					console.log(error);
				})

			}).fail(function(error){
				$('.article-main-container').addClass('hide');
				console.log(error) ;
			});

		}
	});

	CounselorSinglePage.prototype.remove = function() {
    	clearInterval(this.statusInterval);
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	CounselorSinglePage.prototype.clean = function() {
      	this.remove();
	};

	return CounselorSinglePage;
});
