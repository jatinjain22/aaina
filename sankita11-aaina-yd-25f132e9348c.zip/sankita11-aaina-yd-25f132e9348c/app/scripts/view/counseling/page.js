define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
], function($, _, Backbone, Utils, JST ) {

	var CounselingPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {},
		template: JST['app/templates/counseling/layout.hbs'],
		
		render: function() {

			this.$el.html(this.template());
		},
	});

	CounselingPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	CounselingPage.prototype.clean = function() {

    	this.remove();

	};

	return CounselingPage;
});
