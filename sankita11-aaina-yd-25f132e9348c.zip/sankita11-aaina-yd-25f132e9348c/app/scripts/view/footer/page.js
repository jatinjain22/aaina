define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'event/dispatcher',
  'utils',
  'purl',
  'keystop'
], function($, _, Backbone, JST, Dispatcher, Utils){

  var FooterView = Backbone.View.extend({
    el: 'footer',
    initialize: function () {
      var self = this;
      var url = window.location.href ;
      if(window.location.pathname.indexOf('relationshipCounselor') > -1
          ||
        window.location.pathname.indexOf("careerCounselor") > -1){

        self.MarketingPage = true;
      }else{

        self.MarketingPage = false
      }
    },
    events: {
        "click #subscribe-button" : "subscribeEmail",
        "click #subscribe-email" : "showSubscribe",
        "click #discussion-url-footer" : "redirectToDiscussion" ,
        'keyup #subscribe-email' : 'checkForSubscribeFooterEmail',
        'click .footer-track-link' : 'trackFooterLink',
        'click .hub-spoke-footer-link' : 'trackFooterLink',
        "click .footer-android-app-redirect":"redirecttoAndroid",
        "click .footer-ios-app-redirect":"redirecttoIOS",
        "click .cat-index" : "trackEvents",
        "click .cit-index" : "trackEvents",
        "click .business-offerings" : "loadUrl",
        "click .link-header": "showLinks"
    },

    tosModalBody: JST['app/templates/footer/tos.hbs'],
    template: JST['app/templates/footer/layoutNew.hbs'],

    loadUrl: function(e){

      e.preventDefault()
      window.open("/business-offerings", "_self")
    },
    showLinks: function (evt) {
      $(".active-links").removeClass("active-links");
      $(".dripicons-chevron-down").removeClass("dripicons-chevron-down").addClass("dripicons-chevron-right");
      var className = evt.currentTarget.getAttribute("data-desc");
      $(evt.target).find(".icon").removeClass("dripicons-chevron-right").addClass("dripicons-chevron-down");
      $("." + className).addClass("active-links");
    },
    redirecttoAndroid:function(){
        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

                     mixpanel.track('Button Click', { 'itemname' : ' Footer_App_Android'});
                 }

      },
      redirecttoIOS:function(){
        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

                     mixpanel.track('Button Click', { 'itemname' : ' Footer_App_iOS'});
                 }

      },
    redirectToDiscussion : function(e) {
      if( Utils.isLoggedIn() && ( $.cookie("_t") == "" || !$.cookie("_t") || $.cookie("_t") == undefined) ) {
       location.href = Utils.discussionUrl() + "/session/sso?return_path=%2F";
      }else{
       location.href = Utils.discussionUrl() ;
      }
    },
     trackFooterLink : function(e){
            var href = $(e.currentTarget).attr('href');
              var url = href.replace(/^\//,'').replace('\#\!\/','');
              console.log('footer link>>>>',url);
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

              mixpanel.track('Footer', {'itemName': url, 'mediumSource' : 'website' });


      }
      },
    trackEvents : function( evt ){

      var item = "footer_CityIndex_listpage"

      if($(evt.currentTarget).hasClass("cat-index")) item = "footer_CatIndex_listpage"

      if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

        mixpanel.track('Button Click', {'itemName': item, 'mediumSource' : 'website' });
      }
    },

    checkForSubscribeFooterEmail : function(e){

      var email = $("#subscribe-email").val();
      var isValidEmail = Utils.formEmailCheck($("#subscribe-email").val()) ;
      if(email != ""){
        if(!isValidEmail){

          $(".subscribe-footer-img").addClass("hide");
          $("#subscribe-email-error").html("Please enter valid email id");
          $("#subscribe-email-error").removeClass("hide") ;
          return false ;
        }else{

          $("#subscribe-email-error").html("");
          $("#subscribe-email-error").addClass("hide") ;
        }

        if(e.keyCode == 13 && isValidEmail){
          $(".subscribe-footer-img").removeClass("hide");

          this.footerSubscribeEmail(email);
        }
      }else{

        $("#subscribe-email-error").html("");
        $("#subscribe-email-error").addClass("hide") ;
      }
    },
    footerSubscribeEmail : function(email){

      $.ajax({
          method: "POST",
          url: Utils.contextPath()+'/subscribe',
          data : email
      }).done(function(response){
        $("#subscribe-button").hide() ;
        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

          mixpanel.track('SUBSCRIBE ARTICLES SECTION', {'email': email, 'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : 'subscribe footer section', 'itemMedium' : 'NORMAL'  });
          mixpanel.people.set({
              'email': email,
              'name':'Subscriber'
          });
          mixpanel.identify( Math.floor(Math.random()*10000000) )
        }
        $(".subscribe-footer-img").addClass("hide");
        $("#subscribe-container").html("<p class='teal-text'>Got it! You'll start receiving our newsletters soon</p>") ;

      }).fail(function(error){
        console.log(error);
      });

    },
    subscribeEmail : function(e){

      $("#subscribe-button").removeClass("hide");
      var email = $("#subscribe-email").val();
      $(".subscribe-footer-img").removeClass("hide");
      var isValidEmail = Utils.formEmailCheck($("#subscribe-email").val()) ;
      if(!isValidEmail){
        $("#subscribe-email-error").html("Please enter valid email id");
        $("#subscribe-email-error").removeClass("hide") ;
        $(".subscribe-footer-img").addClass("hide");
        return false ;
      }
      this.footerSubscribeEmail(email);

    },

    checkForEmail : function(e){
      var isValidEmail = Utils.formEmailCheck($("#subscribe-email").val()) ;
      if(!isValidEmail){
        $("#subscribe-email-error").html("Please enter valid email id");
        $("#subscribe-email-error").removeClass("hide") ;
      }else{
        $("#subscribe-email-error").addClass("hide") ;
      }
    },
    render: function () {

      var MarketingPage = this.MarketingPage;

	  	this.$el.html(this.template({discussionURL:Utils.discussionUrl(), MarketingPage : MarketingPage, blogOrigin : blogURLFooter, mobile: Utils.isMobileDevice()}));
      //isLoggedIn : Utils.isLoggedIn()
      var self = this ;
      if( !Utils.isLoggedIn() ){
        $("#subscribe-email").keystop( function(event){
          self.checkForEmail(event) ;
        }, 1000 ) ;


        $(".page-footer").removeClass("floggedin");

       /*setTimeout(function(){$("#subscribe-button").addClass("hide");},10);

         $(document).mouseup(function (e){

             var container = $("#subscribe-email");

            if ( container.length != 0 && !container.is(e.target) // if the target of the click isn't the container...
                && container.has(e.target).length === 0 && $("#subscribe-email").val().trim() == "" ) // ... nor a descendant of the container
              {
                $("#subscribe-button").addClass("hide");
              }
        });  */


      }else{
        $(".page-footer").addClass("floggedin");
      }

      //Utils.trackFooterLinks();

      return this;
    },
    showSubscribe: function(e){
      $("#subscribe-button").removeClass("hide");
    },

  });

  FooterView.prototype.clean = function(){
	  //Dispatcher.off("footer:showTos");
  };

  return FooterView;
});
