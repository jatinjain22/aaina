define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'model/users',
    'purl'
], function( $, _, Backbone, JST, Utils,UserModel ) {
	var ssoLoginPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
            this.userModel = new UserModel()
        },
		events: {},
		ssoLoginLayout : JST['app/templates/ssoLogin/layout.hbs'],
        showError : function(error){
			$(".sso-login-layout .card-preloader").addClass("hide")
			var errObj = JSON.parse(error.responseText)
            if(error.status == 500){
                $(".sso-login-error").removeClass("hide").html(errObj.type)
            }else if (error.status == 400) {
				$(".sso-login-error").removeClass("hide").html(errObj.type)
            }else{
				$(".sso-login-error").removeClass("hide").html("Something went wrong. Please try again after sometime.")
			}
        },
		render: function() {
            $("#main-header").hide()
            var self = this;
            $(".feedback-form-btn").addClass("hide")
            var url = window.location.href;
            var token =  $.url( url ).param('token') ;
            $.ajax({
                method : 'GET',
                url : Utils.contextPath()+'/v2/users/login/sso?token='+token,
                xhrFields: {
     				withCredentials: true
			    },
            }).done(function(res){
                console.log("Response: ",res)
                self.userModel.save(res.user)
                location.href =  ( !("redirect_url" in res) || res.redirect_url === '' || res.redirect_url === null) ? Utils.chatUrl()+res.user.username : location.origin + res.redirect_url;
            }).error(function(err){
                console.log("Error: ",err)
                self.showError(err)
            })
            this.$el.html(this.ssoLoginLayout());
		}
	});
	ssoLoginPage.prototype.remove = function() {
        $("#main-header").show()
        $(".feedback-form-btn").removeClass("hide")
    };
	ssoLoginPage.prototype.clean = function() {
        this.remove()
    };
	return ssoLoginPage;
});
