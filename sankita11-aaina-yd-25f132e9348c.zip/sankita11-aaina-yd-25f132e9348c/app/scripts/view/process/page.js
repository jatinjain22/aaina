define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'purl'
], function($, _, Backbone, Utils, JST ) {

	var Error403Page = Backbone.View.extend({
		el: "main",
		initialize: function() {
			
		},
		events: {
		},
		LoaderLayout: JST['app/templates/loader.hbs'],
		render: function() {

			this.$el.html(this.LoaderLayout()) ;
			var self = this;
			
			var url = window.location.href ;
    		//url = url.replace("/process", "" );
			//var id = $.url( url ).param('id') ;
			var id = location.search.split('?id=')[1]

			if(isNaN(id)){

				id = id.replace(/%22/g, '');

				$.ajax({
					url : Utils.contextPath() + '/v1/user/transaction/process/extra?extra=' + id,
				}).done(function(response){
					if(response.error) {
						self.$el.html("<div style='display: flex; justify-content: center; align-items: center; height: 40vh; font-size: 18px;'>This payment link is not valid anymore. For any outstanding payments please contact customersupport@yourdost.com</div>") ;
					}
					else {
						var redirectURI = response.uri ;
						window.location = redirectURI ;
					}
				}).error(function(error){
					console.log(error);
				})

			}else{

				$.ajax({
					url : Utils.contextPath() + '/v1/user/transaction/process/' + parseInt(id),
				}).done(function(response){
					if(response.error) {
						self.$el.html("<div style='display: flex; justify-content: center; align-items: center; height: 40vh; font-size: 18px;'>This payment link is not valid anymore. For any outstanding payments please contact customersupport@yourdost.com</div>") ;
					}
					else {
						var redirectURI = response.uri ;
						window.location = redirectURI ;
					}
				}).error(function(error){
					console.log(error);
				})
			}
		},
	});

	Error403Page.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	Error403Page.prototype.clean = function() {

    	this.remove();

	};

	return Error403Page;
});