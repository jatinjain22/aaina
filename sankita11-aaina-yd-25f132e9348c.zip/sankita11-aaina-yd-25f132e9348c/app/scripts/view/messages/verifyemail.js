define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var VerifyEmailPage = Backbone.View.extend({
		el: "main",
		initialize: function() {	

			this.userModel = new UserModel();
			this.cName = '';
			this.cType = '';
		},
		VerifyEmailPageLayout : JST['app/templates/messages/verify_email.hbs'], 
		
		events: {
			
		},
		
		redirectToChat : function(){

			if(!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "From Verify Email Page", "verifyEmail", "home_chat" ) ;
			
			}else{

				var username     = this.userModel.getUserName() ;
				var chatStartUrl = Utils.chatUrl() + username   ;
				
				if( this.cType == "SIGNUP"){

					chatStartUrl = Utils.socialShareUrl+"/talkItOut";

				}else{

					if(typeof this.cName !='undefined' && this.cName != '' && this.cName != 'demo'){

						chatStartUrl = Utils.justChatUrl()+"/?workgroup="+this.cName+'__yd@'+Utils.chatDemoWorkgroup().split('@')[1] +"&noUI=true&username="+username;
						

					}else{

						chatStartUrl =  chatStartUrl ;
					}
				}

				location.href = chatStartUrl;
			}
		},

		render: function() {
			
			var url = window.location.href;
			url = url.replace("/verifyemail", "" );
			var vCode = $.url( url ).param('_v') ;
			var token = $.url( url ).param('_c') ;

			var type  = $.url( url ).param("type");

			this.cType = type;

			var appID = $.url( url ).param("id");

			this.cName = $.url( url ).param("cName");


			var param = "";
			if(type){
				param = '&type=' + type + '&id=' + appID ;
			};


			var self = this;
			var success = '';
			$.ajax({
	            method: "POST",
	            url: Utils.contextPath()+'/v2/users/email/validate?_v='+vCode+ param ,
	            contentType: "application/json",
	            headers :{
					"X-DOST-ZION-AUTH" :  token,
				},
				statusCode:{
			    	417 : function(response){
			    		success = 'no';
			    		self.$el.html.find(".verify_text").html('<span style="color:red">Sorry couldn\'t verify your email.</span>');

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ; 
						var errorType    = responseJson.type ;

						if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
							mixpanel.track('Email Verified Error', {'mediumSource' : 'website', 'error' : errorMessage});
						} 

			    	},
			    	400 : function(response){
			    		success = 'no';
			    		self.$el.find(".verify_text").html('<span style="color:red">Sorry couldn\'t verify your email.</span>');

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ; 
						var errorType    = responseJson.type ;

						if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
							mixpanel.track('Email Verified Error', {'mediumSource' : 'website', 'error' : errorMessage});
						} 

			    	},
			    	401 : function(response){
			    		success = 'no';
			    		self.$el.find(".verify_text").html('<span style="color:red">Sorry couldn\'t verify your email.</span>');

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ; 
						var errorType    = responseJson.type ;

						if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
							mixpanel.track('Email Verified Error', {'mediumSource' : 'website', 'error' : errorMessage});
						} 

			    	},
			    },
          	}).done(function(response){
          		console.log("successfully verified");
          		success = 'yes';
          		self.$el.find(".verify_text").html('<span style="color:teal">Your Email has been successfully verified.</span>');

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            		console.log( 'inside mixpanel' );
            		mixpanel.track('Email Verified', {'mediumSource' : 'website'});
          		} 

          		setTimeout(function(){

          			self.redirectToChat();

          		}, 2000)

          	}).error(function(error){
          		console.log("something went wrong"+ error);
          	    success = 'no';
          	    self.$el.find(".verify_text").html('<span style="color:red">Sorry couldn\'t verify your email.</span>');
          	})

			
          	this.$el.html( this.VerifyEmailPageLayout() );
			
			return this;
			
		},
		
	});

	VerifyEmailPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	VerifyEmailPage.prototype.clean = function() {
		this.remove();
	};

	return VerifyEmailPage;
});
