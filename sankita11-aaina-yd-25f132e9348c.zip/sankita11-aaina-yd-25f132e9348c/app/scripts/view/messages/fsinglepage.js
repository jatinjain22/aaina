define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/FriendMsgModel',
	'view/leaveMessage/page',
	'ajax-chosen',
	'smooth-scroll'
], function($,_, Backbone, JST, Utils, EventBus, FriendMsgModel, LeaveMessageView) {

	var FriendSingleMessagePage = Backbone.View.extend({
		el: "main",
		initialize: function(options) {

			console.log(location.pathname) ;
			if(!Utils.isLoggedIn()){
				var hash = location.pathname ;
				hash = hash.replace("/", "") ;
				//location.href = "/login?r=" + hash ;
				Backbone.history.navigate("/login?r=" + hash, {trigger: true});
				return ;
			}

			this.leaveMessageView = new LeaveMessageView();
			this.model = new FriendMsgModel;
			this.model.set("threadId",Utils.decodeString(this.id));
			this.direct = false;
			this.selectedSentBy = {} ;
			this.attachmentIds = [];

			this.userChats = "" ;

			window.prevType = window.msgType;
			window.iprevType = window.imsgType;

			if( typeof window.imsgType == 'undefined' )
				window.iprevType = 'MAIL';

			if( options.type ){
				if( options.type.toLowerCase() == "inbox" ){
					window.msgType = "MAIL";
					window.imsgType = "MAIL";
					this.direct = true;
				}else if( options.type.toLowerCase() == "chat" ){
					window.msgType = "CHAT";
					window.imsgType = "CHAT";
					this.direct = true;
				}
				else{
					window.msgType = false;
					window.imsgType = false;
				}
			}

			if( !window.msgType ){
				//location.href = "/friend/messages";
				Backbone.history.navigate("/friend/messages", {trigger: true});
				return this;
			}
			this.initSetup();
			EventBus.trigger("msg:updateUnreadCount");
			this.selectedUsers = {} ;
			this.timeoutId = -1;
			this.threadID = 0;
			this.messageID = 0;
		},
		events: {
			"click #add-notes": "openNotes",
			"click #close-notes": "closeNotes",
			"click #msg-add-note": "openNotes",
			"click #open-ireply": "openPostReply",
			"click #open-reply": "singleMsgReply",
			"click #post-reply": "postReply",
			"click #delete-reply": "deleteReply",
			"click .fmsgtype": "fetchList",
			"click .msg-severity": "markImportant",
			"click #add_tag": "addTag",
			"click #close_tag": "closeTag",
			"click .tag-delete": "removeTag",
			"click #save-note": "addNotes",
			"keyup #add-user-note": "addNotesByEnter",
			"click #fsmsg-delete": "deleteMsg",
			"click #fsmsg-block": "blockMsg",
			"click #compose-send-btn": "forwardMsg",
			"click .ftag": "tagFilter",
			"click #fsmsg-close" : "CloseThread",
			"click #fsmsg-open" : "OpenThread",
			"click .msg-back": "backToList",
			"click #fsmsg-forward": "openFMsg",
            "click #msg-search-btn": "searchMessage",
            "keypress #msg-search-txt": "searchMessageByEnter",
            "click .dost-msg-item": "removeCollapsed",
            'click .smoothscroll': 'smoothScroll',
            "click #compose .mclose" : "hideCompose",
            'click .msg-single-reply' : 'singleMsgReply',
            'keyup #message' : 'addEnterInMsg',
            'click #chat-compose-btn' : 'openChatMsg',
            'click #msg-follow' : 'followThread',
            'click #msg-unfollow' : 'unfollowThread',
            'click #fsmsg-join' : 'populateSenderForJoin',
            'click #join-conversation' : 'joinConversation',
            "keyup #reply_message": "isMessage",
            "change #freply-file-attachment" : "uploadFileInFReply",
            "click .freply-remove-attached-file" : "uploadNewFileInF",
            "click .friend-download-attachment" : "downloadFriendAttachment",
            // "click .go-to-client" : "goToClientHistory"
		},

		// goToClientHistory : function(e){

		// 	e.preventDefault()
		// 	e.stopPropagation()

		// 	var client_id = $(e.currentTarget).attr("data-fromid")

		// 	var username = $(e.currentTarget).attr("data-username")

		// 	if(client_id){

		// 		if(client_id == userModel.getUserID()){

		// 			return
		// 		}
		// 		Backbone.history.navigate("/client/"+client_id+"/"+username, {trigger: true});
		// 	}
		// },
		
		autoSaveMessage: function(msg) {

			console.log( 'Autosave!' );
            if(window.pendingDraftsaveRequest)
                return;
        	$(".email-draft-bar").removeClass( "hide" );
	        $( ".email-draft-saving-msg" ).removeClass( "hide" );
	        $( ".email-draft-saved-msg" ).addClass("hide");

			var subject = $("#subject").val() || null;

			var sendTo = $(".user-friend").hasClass("hide") ? $("#send-to").val() : null;
			// var sendCategory = $("#send-category").val();

			var self = this ;
			// var categoryArr = sendCategory ;



			var userArr = sendTo ;
			if(Utils.isMobileDevice() && userArr != null){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){

				if ( CKEDITOR.instances.message == undefined ) {
					var body = encodeURI(CKEDITOR.instances.reply_message.getData()) || null;
					self.threadID = $("#single-msg-block").attr("data-msgid");

				} else {
					var body = encodeURI(CKEDITOR.instances.message.getData()) || null;

				}


			}else{
				var body = encodeURI($("#reply_message").val().trim()) || null;
				if ( $("#single-msg-block").attr("data-msgid") ) {
					self.threadID = $("#single-msg-block").attr("data-msgid");
				}
			}
			console.log( "subject", subject );
			console.log( "userArr", userArr );
			console.log( "categoryArr", categoryArr );
			console.log( "body", body );

			var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"recipients":userArr,
					"status":"DRAFT"

			};

			console.log( "threadID", self.threadID );


			console.log( "msgJSON", msgJSON );
            window.pendingDraftsaveRequest = true;
			$.ajax({
        		method: "POST",
        		url: Utils.contextPath()+'/v1/users/'+ this.model.get("userID")+'/messages',
        		data: JSON.stringify(msgJSON),
       			contentType: "application/json"
      		}).done(function(response){
                window.pendingDraftsaveRequest = false;
      			console.log( response );
      			self.threadID = response.conversationDetail.threadID;
      			var userMessages = response.conversationDetail.userMessage;
      			var lastMsg = userMessages[userMessages.length - 1];
      			self.messageID = lastMsg.msgID;
      			// messageID = 13340;
      			if (msg == "saveDraft") {
      				Utils.displaySuccessMsg("Your draft has been saved");
      			}
	        	$( ".email-draft-saving-msg" ).addClass( "hide" );
	        	$( ".email-draft-saved-msg" ).removeClass("hide");
	        	return true;
			}).error(function(error){
                window.pendingDraftsaveRequest = false;
				console.log(error);
			});
		},
		isMessage: function(e) {

			//console.log("hello");
			//console.log(e.currentTarget);
			var self = this;

			clearTimeout(self.timeoutId);
    		self.timeoutId = setTimeout(function() {
        		// Runs 1 second (1000 ms) after the last change

        		//self.autoSaveMessage();

    		}, 500);

			console.log("one who knocks");

			if ( $(".imessage").parent().hasClass('error') ) {


				$(".imessage").hide();
				$(".imessageCnt").hide();
				$(".imessage").parent().removeClass('error');


			}

		},

		uploadNewFileInF : function(e){

			$(".file-name-attached-freply").addClass("hide");
			$(".file-attachment-freply-send").removeClass("hide");
			this.attachmentIds = []
		},

		uploadFileInFReply : function(e){

			var file = e.target.files[0];
			var data = new FormData();
			var self =  this;
			$(".freply-upload-error").addClass("hide")
			if(file.type == "application/x-ms-dos-executable"){

				$(".freply-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			$(".file-name-attached-freply").removeClass("hide");
			$(".file-attachment-freply-send").addClass("hide");
			$(".freply-file-name-attached").html("Uploading ...");

			data.append('file', $('#freply-file-attachment').get(0).files[0] );
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){

				console.log("Response: "+response)
				$(".freply-file-name-attached").html(file.name);
				self.attachmentIds.push(response.fileID);

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	        	    mixpanel.track('File Attached', {'mediumSource' : 'website', 'itemName': 'File Attached in Post Reply Counselor'});

	        	}

			}).error(function(error){

				$(".file-name-attached-freply").addClass("hide");
				$(".file-attachment-freply-send").removeClass("hide");
				$(".freply-upload-error").removeClass("hide").html("Upload Error");
				console.log("Error: "+error);
			})
		},
		downloadFriendAttachment : function(e){

			e.stopPropagation();
			e.preventDefault();
			var fileID = $(e.currentTarget).attr("data-fileid");
			location.href = Utils.contextPath()+'/file/download/'+fileID;
			// $(e.currentTarget).parents(".msg-content").find(".download-error").addClass("hide");
			// $(e.currentTarget).parents(".msg-content").find(".downloading-text").removeClass("hide");
			// $(e.currentTarget).addClass("hide");
			// $.ajax({

			// 	method: "GET",
			// 	url : Utils.contextPath()+'/file/download/'+fileID,
			// }).done(function(response){

			// 	console.log("Response: "+response);
			// 	$(e.currentTarget).parents(".msg-content").find(".downloading-text").addClass("hide");
			// 	$(e.currentTarget).removeClass("hide");

			// }).error(function(error){

			// 	console.log("Error: "+error)
			// 	$(e.currentTarget).parents(".msg-content").find(".download-error").removeClass("hide");
			// 	$(e.currentTarget).parents(".msg-content").find(".downloading-text").addClass("hide");
			// 	$(e.currentTarget).removeClass("hide");

			// 	setTimeout(function(){

			// 		$(e.currentTarget).parents(".msg-content").find(".download-error").addClass("hide");
			// 	}, 3000)
			// })

		},
		addNotesByEnter: function(e) {
			var self = this;
			if(event.keyCode == 13){
        		self.addNotes();
    		}
		},
		openChatMsg : function(e){

			var userChats = this.userChats ;

			var userInfo = {};
			_.each(userChats, function(elem){
				var userType = elem.user.loggableUser.userType ;
				if(userType == 'VICTIM'){
					userInfo["id"] = elem.user.id ;
					userInfo["name"] = elem.user.username ;
					return false ;
				}

			});

			this.leaveMessageView.render(userInfo);

		},

		addEnterInMsg : function(e){

			if(Utils.isMobileDevice()){
				var code = e.keyCode || e.which;
	 			if(code == 13) {
	   				var msgText = $("#message").val() ;
	   				$("#message").val( msgText + "\n" ) ;
	 			}
			}

		},
		populateSender : function(){

			var self = this ;
			var searchType = '/v2/users/list' ;

			if(Utils.isMobileDevice()){

				$( "#msg-send-to" )
			      // don't navigate away from the field on tab when selecting an item
			      .bind( "keydown", function( event ) {
			        if ( event.keyCode === $.ui.keyCode.TAB &&
			            $( this ).autocomplete( "instance" ).menu.active ) {
			          event.preventDefault();
			        }
		      })
		      .autocomplete({
		        source: function( request, response ) {

		        	$.ajax({
					method: 'GET',
					url: Utils.contextPath()+ searchType + '?name=' + Utils.JUIextractLast( request.term ),
					}).done(function (data) {
						var usersArr = new Array() ;

						$.each(data, function (i, val) {
						usersArr.push({
							"key" : val,
							"value" : i
						});
						});
						response( usersArr );
					});


		        },
		        search: function() {
		          // custom minLength
		          var term = Utils.JUIextractLast( this.value );
		          if ( term.length < 2 ) {
		            return false;
		          }
		        },
		        focus: function() {
		          // prevent value inserted on focus
		          return false;
		        },
		        select: function( event, ui ) {

		          self.selectedSentBy[ui.item.value] = ui.item.key ;
		          var terms = Utils.JUIsplit( this.value );
		          // remove the current input
		          terms.pop();
		          // add the selected item
		          terms.push( ui.item.value );
		          // add placeholder to get the comma-and-space at the end
		          terms.push( "" );
		          this.value = terms.join( ", " );
		          return false;
		        }
		      });
			}else{
				self.$el.find("#msg-send-to").ajaxChosen({
					type: 'GET',
					url: Utils.contextPath()+ searchType,
					dataType: 'json',
					jsonTermKey:"name",
					minTermLength:1
				}, function (data) {

					var terms = {};
					$.each(data, function (i, val) {
						terms[val] = i;
					});
					return terms;
				});
			}

		},
		singleMsgReply : function(e){

			this.openPostReply(e);
			var self = this ;
			var targetID = $(e.currentTarget).attr("id") ;
			var msgID    = targetID.split(/-/)[1] ;
			if(targetID == "open-reply"){
				var allMsgs = $(".dost-msg-item")           ;
				var lastMsg = allMsgs[ allMsgs.length - 1 ] ;

				var msgID = $(lastMsg).attr("id") ;
				msgID     = msgID.split(/-/)[1]   ;
			}
			var msgSentByID   = $("#msg-" + msgID).find(".msg-sent-by").attr("data-fromid") ;
			var msgSentByName = $("#msg-" + msgID).find(".msg-sent-by a").html()              ;
			if(msgSentByName == undefined){
				msgSentByName = $("#msg-" + msgID).find(".msg-sent-by").html()              ;
			}

			this.messageID = msgID;
			var userID = this.model.get("userID") ;

			var replyFrom = [] ;
			if(msgSentByID == userID){
				var msgSentTo = $("#msg-" + msgID).find(".msg-toids span");
				$.each(msgSentTo, function(index, elem){
					var userInfo = {
						"id"   : $(elem).attr("data-toids"),
						"name" : $(elem).html().trim()
					}

					replyFrom.push(userInfo) ;
				});
			}else{
				replyFrom = [{
					"id" : msgSentByID.trim() ,
					"name" : msgSentByName.trim() ,
				}];
			}
			if(Utils.isMobileDevice()){

				var replyFromStr = "" ;
				$.each(replyFrom, function(index, elem){
					console.log(elem.name) ;
					replyFromStr += elem.name + ", " ;
					self.selectedSentBy[elem.name] = elem.id ;
				});

				$("#msg-send-to").val(replyFromStr) ;
			}else{

				replyFromIDs = [] ;
				$.each(replyFrom, function(index, elem){
					$("#msg-send-to").append("<option value='"+ elem.id +"'>" + elem.name + "</option>") ;
					replyFromIDs.push(elem.id) ;
				});
				setTimeout( function(){
					$("#msg-send-to").val(replyFromIDs) ;
					$("#msg-send-to").chosen({
						width: "100%"
					});
					$("#msg-send-to").trigger("chosen:updated");
				},100);

				$("#msg-send-to").addClass("hide");
			}

			this.populateSender() ;

		},


		hideCompose : function(){
			Utils.closePopup('compose') ;
		},
		smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
		initSetup: function(){

			this.type = window.msgType;
			this.cid = window.cid;
			this.model.set("type",window.msgType);
			this.model.setMsgUrl();
			this.eMsgList = [];
			this.msgOrder = [];
			this.listenTo(this.model, 'change', function(model) {
        		model.fetch();
    		});
		},
		searchMessageByEnter: function(e){

			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#msg-search-btn").trigger("click");
 			}
		},
		searchMessage: function(e){

			var self = this;

			if( $("#msg-search-txt").val().trim() == "" )
				return false;

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			var search = "content_search="+$("#msg-search-txt").val();
			var params = {"search":search};
			localStorage.setItem( "msearch" , JSON.stringify( params ) );
			window.imsgType = "SEARCH";
			if( window.imsgType == "SEARCH" ){
				window.search = $("#msg-search-txt").val();
			}

			//location.href = "/friend/messages";
			Backbone.history.navigate("/friend/messages", {trigger: true});
			return this;
		},
		backToList: function(e){

			if( $(e.currentTarget).attr("cid") > 0 ){
				window.msgType = "TAGS";
				window.cid = $(e.currentTarget).attr("cid");
			}else{
				window.msgType = $(e.currentTarget).attr("data-type");
			}

			//location.href = "/friend/messages";
			Backbone.history.navigate("/friend/messages", {trigger: true});
			return this;
		},
		tagFilter: function(e){
			window.msgType = "TAGS";
			window.cid = $(e.currentTarget).attr("data-tagid");
			//location.href = "/friend/messages";
			Backbone.history.navigate("/friend/messages", {trigger: true});
			return this;
		},
		fetchList: function(e){

			window.msgType = $(e.currentTarget).attr("data-type");
			//location.href = "/friend/messages";
			Backbone.history.navigate("/friend/messages", {trigger: true});
			return this;
		},
		deleteReply: function(e){

			if( !Utils.isMobileDevice() ){

				if( CKEDITOR.instances.reply_message.getData() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}else{

				if( $("#reply_message").text().trim() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}
			//Utils.discardDraft( this.model.get("userID"), this.messageID );
			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$(".msg-single-reply").attr("clicked",false);
			this.uploadNewFileInF();
		},
		openPostReply: function(e){

			if( $(".msg-single-reply").attr("clicked") == "true" )
				return true;

			$(".msg-single-reply").attr("clicked",true);
			$("#open-reply").before( $(".reply-block").html() ).addClass("hide");

			if( !Utils.isMobileDevice() )
				Utils.addRTD('reply_message');
			else
				$("#reply_message").focus();

			Utils.scrollTo("#reply-form",-50);
		},
		postReply: function(e){

			$(".iauthentication-error").hide() ;

			var isError = false;
			var self = this;

			var sendTo = $("#msg-send-to").val();
			if(sendTo == null){
				$(".isend-to").show();//.parent().addClass("error");
				isError = true;
			}
			var sentByArr = sendTo ;
			console.log(self.selectedSentBy);
			if(Utils.isMobileDevice()){
				var senders = sentByArr;
				sendersArr = senders.split(",");
				console.log(sendersArr);
				sentByArr = [] ;
				$.each(sendersArr, function(index,elem){
					if(!elem.trim()){
						return false ;
					}
					sentByArr.push(self.selectedSentBy[elem.trim()])
				});
			}
/*			var sendTo = [];
			$(".msg-senders").each(function(){
				if( $(this).attr("data-fromid") != undefined ){
					if( sendTo.indexOf($(this).attr("data-fromid")) < 0
						&&
						( $(this).attr("data-fromid") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-fromid"));
					}
				}
			});

			$(".msg-toid").each(function(){
				if( $(this).attr("data-toids") != undefined ){
					if( sendTo.indexOf($(this).attr("data-toids")) < 0
						&&
						( $(this).attr("data-toids") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-toids"));
					}
				}
			});
*/
			var subject = $(".msg-header").text();
			if( !Utils.isMobileDevice() ){

				var body = encodeURI(CKEDITOR.instances.reply_message.getData());
				if( body == "" ){
					CKEDITOR.instances.reply_message.focus();
					$(".imessage").show();
					isError = true;
				}
			}else{

				var body = encodeURI($("#reply_message").val().trim());
				if( body == "" ){
					$("#reply_message").focus();
					$(".imessage").show();
					isError = true;
				}
			}
			console.log("reply");

			if( !isError ){
				if(Utils.isMobileDevice()){
					body = body.replace(/%0A/g, '<br />');
				}
				if(self.attachmentIds.length == 0){

					self.attachmentIds = [-1];
				}

				var msgJSON = {
					"threadID":$("#single-msg-block").attr("data-msgid"),
					"subject":subject,
					"content":body,
					"recipients":sentByArr,
					"status": "SENT",
					//"messageID": self.messageID,
					"attachmentIDs" : self.attachmentIds
				};

				$("#post-reply").addClass("disabled").html("Sending...");
				$("#delete-reply").addClass("disabled");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json",
	              statusCode : {
              		417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						$(".iauthentication-error").html(errorMessage);
						$(".iauthentication-error").show() ;

					},
              		500 : function(){
						$(".iauthentication-error").html("Something went wrong. Please try again");
						$(".iauthentication-error").show() ;
					},

	              }
	          	}).done(function(response){

	          		self.uploadNewFileInF();
	          		Utils.displaySuccessMsg("Your message has been sent.");
	          		self.addThreadAfterPostReply( response );
	          		$("#post-reply")
	          			.removeClass("disabled")
	          			.html( 'Reply<i class="mdi-content-send right"></i>' );
					$("#delete-reply").removeClass("disabled");
	          	}).fail(function(error){
	          		console.log(error);
	          		$("#post-reply")
	          			.removeClass("disabled")
	          			.html( 'Reply<i class="mdi-content-send right"></i>' );
					$("#delete-reply").removeClass("disabled");
	          	});
			}else{
				setTimeout(function(){$(".error-msg").hide();$(".input-field").removeClass("error");},3000);
				return false;
			}
		},
		closeNotes: function(e){
			$(".msg-notes-list").addClass("hide");
			$("#close-notes").addClass("hide");
			$(".feedback-form-btn").removeClass("hide");
			$(".msg-notes").width("55px");
			e.stopPropagation();
		},
		openNotes: function(e){
			$(".msg-notes-list").removeClass("hide");
			$(".feedback-form-btn").addClass("hide");
			$(".msg-notes").addClass("fadeInRightBig animated").width("300px");
			$("#close-notes").removeClass("hide");
			setTimeout(function(){$("#add-user-note").focus();},1100);
		},
		checkForAttachments : function(userMessagesObj){

			$.each(userMessagesObj, function(index){

				if(userMessagesObj[index].attachmentID > 0){

					var fileID = userMessagesObj[index].attachmentID;
					$.ajax({

						method : "GET",
						url : Utils.contextPath() + '/file/type/'+fileID,
						contentType: "application/json",
					}).done(function(response){

						if(response){

							console.log("Response: "+response)
							$("#msg-"+userMessagesObj[index].msgID).find(".msg-content").append('<div class="download-div"><i class="mdi mdi-attachment"></i><a class="friend-download-attachment" data-href="'+response.s3Url+'" href="'+Utils.contextPath()+'/file/download/'+fileID+'" data-fileid ="'+response.iD+'">'+response.fileName+'</a><span class="downloading-text hide">Downloading ...</span><span class="download-error hide">Download Error.</span></div>')
						}
					}).error(function(error){

						console.log("Error: "+error)
					})
				}
			})
		},
		FriendMessagePageLayout : JST['app/templates/messages/friend_layout.hbs'],
		ComposePageLayout : JST['app/templates/messages/compose.hbs'],
		SingleMsgLayout : JST['app/templates/messages/single_fmsg_layout.hbs'],
		FriendMsgSideMenuLayout : JST['app/templates/messages/fmsg_sidemenu.hbs'],

		renderDraftMessage: function( response ) {

			var self = this;
			var userMessages = response.attributes.conversationDetail.userMessage;
			var userMessagesLength = userMessages.length;
			var lastUserMessage = userMessages[userMessagesLength - 1];

			var allMsgs = $(".dost-msg-item")           ;
			var lastMsg = allMsgs[ allMsgs.length - 1 ] ;

			var msgID = $(lastMsg).attr("id") ;
			msgID     = msgID.split(/-/)[1]   ;

			var msgSentByID   = $("#msg-" + msgID).find(".msg-sent-by").attr("data-fromid") ;
			var msgSentByName = $("#msg-" + msgID).find(".msg-sent-by").html()              ;
			var content = $("#msg-" + msgID).find(".msg-content").html();
			self.openPostReply();

			console.log("content ", content);

			var userID = this.model.get("userID") ;

			var replyFrom = [] ;
			if(msgSentByID == userID){
				var msgSentTo = $("#msg-" + msgID).find(".msg-toids span");
				$.each(msgSentTo, function(index, elem){
					var userInfo = {
						"id"   : $(elem).attr("data-toids"),
						"name" : $(elem).html().trim()
					}

					replyFrom.push(userInfo) ;
				});
			}else{
				replyFrom = [{
					"id" : msgSentByID.trim() ,
					"name" : msgSentByName.trim() ,
				}];
			}
			if(Utils.isMobileDevice()){

				var replyFromStr = "" ;
				$.each(replyFrom, function(index, elem){
					console.log(elem.name) ;
					replyFromStr += elem.name + ", " ;
					self.selectedSentBy[elem.name] = elem.id ;
				});

				$("#msg-send-to").val(replyFromStr) ;
				$("#reply_message").val(content);

			}else{

				replyFromIDs = [] ;
				$.each(replyFrom, function(index, elem){
					$("#msg-send-to").append("<option value='"+ elem.id +"'>" + elem.name + "</option>") ;
					replyFromIDs.push(elem.id) ;
				});
				setTimeout( function(){
					$("#msg-send-to").val(replyFromIDs) ;
					$("#msg-send-to").chosen({
						width: "100%"
					});
					$("#msg-send-to").trigger("chosen:updated");
				},100);

				$("#msg-send-to").addClass("hide");
				CKEDITOR.instances.reply_message.setData( content );
			}
			$("#msg-" +msgID).remove();
			self.messageID = msgID;
		},
		render: function() {

			if(!Utils.isLoggedIn()){
				var hash = location.pathname ;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash ;
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}
			console.log(window.msgType);

			if( !window.msgType ){
				return this;
			}

			var self = this;
			self.$el.html(this.FriendMessagePageLayout());
			self.$el.find(".msg-list-bar .msg-page-search-bar").remove();
			self.$el.append(this.ComposePageLayout());

			self.model.addWait();

			self.model.fetch({
				success : function(response){

					response.attributes["isMobileDevice"] = Utils.isMobileDevice() ;
					var specialFriend = false;
					if( self.model.get("userID") == 101 ){
						specialFriend = true;
					}
					var userMessages = response.attributes.conversationDetail.userMessage;

					if(typeof userMessages != 'undefined'){

						self.checkForAttachments(userMessages);
					}

					response.attributes["specialFriend"] = specialFriend;
					self.$el.find(".msg-details-right").append(
						self.SingleMsgLayout(response.attributes)
					);
					var msgID = response.attributes["threadId"];
					var userID = response.attributes["userID"];
					console.log("Inside");
					console.log( response.attributes.conversationDetail );

					if ( response.attributes.conversationDetail.status == 'DRAFT' ) {
						self.renderDraftMessage(response);
					}

					console.log(response.changed.conversationDetail.following);
					if(response.changed.conversationDetail.following === true){
						$("#msg-follow").addClass("hide");
						$("#msg-unfollow").removeClass("hide");
					}else{
						$("#msg-follow").removeClass("hide");
						$("#msg-unfollow").addClass("hide");
					}
					$.ajax({
						method: 'GET',
						url: Utils.contextPath()+"/v1/users/"+userID+"/messages/"+msgID+"/closedstatus",
					}).done(function (data) {

					   if(data["status"]==true){
						    $("#fsmsg-open").removeClass("hide");
							$("#fsmsg-close").addClass("hide");
						}else{
							$("#fsmsg-open").addClass("hide");
							$("#fsmsg-close").removeClass("hide");
						}
						console.log(data)
					}).fail(function(error){
		          		console.log(error);
		          	});


					if( response.attributes.conversationDetail.categories )
						self.addTagsOption( response.attributes.conversationDetail.categories );

					if( self.type == "CHAT" ){
						self.$el.find(".msg-notes").addClass("hide");
						self.userChats = response.attributes.conversationDetail.userChats;
					}else{
						self.$el.find(".msg-notes").removeClass("hide");
					}

					setTimeout(function(){
						self.$el.find("#single-msg-block").attr("cid",self.cid);
						self.$el.find(".msg-back").attr("cid",self.cid);
						self.$el.find(".msg-back").attr("data-type",window.iprevType);

						if( self.type != "CHAT" ){

							self.$el.find(".msg-toids").each(function(){
								$(this).html( $(this).html().slice(0,-2) );
							});

							self.$el.find(".dost-msg-item:last-child").find(".msg-senders").removeClass("truncate");
							self.$el.find(".dost-msg-item:last-child").find(".msg-content").removeClass("hide");
						}

						if( Utils.isMobileDevice() ){
                			$("header").addClass("hide");
                			$(".mmsg-single-view-header").html(	$(".single-msg-btn-mbar").html() );
                			$(".mleft-menu").removeClass("hide");
            			}
					},10);

					Utils.adjustViewPortSize();

					self.model.removeWait();
				},
				error : function(error){
					self.model.removeWait();
					console.log(error);
				}
			});

			self.renderElements();
			EventBus.trigger('removeChatScroll');

			if( this.direct ){
				this.sideMenu( this.model );
			}else{
				EventBus.trigger("fmsg:renderSideMenu",this.model);
			}

			$(".fmsgtype").removeClass("active");
			$(".fmsgtype").each(function(){
				if( $(this).attr("data-type") == window.iprevType )
					$(this).addClass("active");
			});

			if( window.iprevType == "TAGS" ){

				$(".fmsgtype").removeClass("active");
				$(".msg-tags-list > li").removeClass("active");

				$(".msg-tags-list > li").each(function(){
					if( $(this).attr("data-tagid") == self.cid )
						$(this).addClass("active");
				});
			}


			if( window.imsgType == "SEARCH" ){
				$("#msg-search-txt").val( window.search );
			}

			//self.fillMobileSearch();

			$(window).unbind("scroll");

			$( window ).scroll(function() {
		        if( $(window).scrollTop() > 150 ){
		          $("#scroll-up-mbtn").removeClass("hide");
		        }
		        else{
		          $("#scroll-up-mbtn").addClass("hide");
		        }
		    });

			return this;
		},
		fillMobileSearch: function(){

			if( window.device == "mobile" ){

				setTimeout(function(){
					$("#search-bar").css("left", 0);
					$("#msg-search-txt").val( window.search );
					$("#search-msg-mobile").val( window.search );
				},10);
			}
		},
		deleteMsg: function(e){

			if( confirm("Are you sure you want to delete this message?") ){

				var msgID = $("#single-msg-block").attr("data-msgid");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/mark/deleted',
	              contentType: "application/json"
	          	}).done(function(response){
	          		Utils.displaySuccessMsg("Your message has been deleted.");
	          		//location.href = "/friend/messages";
	          		Backbone.history.navigate("/friend/messages", {trigger: true});
	          		return true;
	          	}).fail(function(error){
	          		console.log(error);
	          	});
			}
		},
		CloseThread : function(e){

			var msgID = $("#single-msg-block").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been closed.");
			    $("#fsmsg-open").removeClass("hide");
				$("#fsmsg-close").addClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		OpenThread : function(e){

			var msgID = $("#single-msg-block").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been opened.");
			    $("#fsmsg-open").addClass("hide");
				$("#fsmsg-close").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		forwardMsg: function(e){

			//TO-DO: remove this line when server side code will be fixed
			return true;

			var isError = false;

			var sendTo = $("#send-to").val();
			var subject = $("#subject").val();
			var self = this ;
			var userArr = sendTo;
			if(Utils.isMobileDevice()){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){
				var body = encodeURI(CKEDITOR.instances.message.getData());
			}else{
				var body = encodeURI($("#message").val());
			}
			console.log("compose");

			if( sendTo < 1 ){
				$(".isend-to").show().parent().addClass("error");
				isError = true;
			}

			if( subject == "" ){
				$(".isubject").show().parent().addClass("error");
				isError = true;
			}

			if( body == "" ){
				$(".imessage").show().parent().addClass("error");
				isError = true;
			}

			if( !isError ){

				if(self.attachmentIds.length == 0){

					self.attachmentIds = [-1];
				}
				var msgJSON = {
					"threadID":$("#single-msg-block").attr("data-msgid"),
					"subject":subject,
					"content":body,
					"recipients":userArr,
					"attachmentIDs" : self.attachmentIds
				};

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json"
	          	}).done(function(response){
	          		Utils.displaySuccessMsg("Your message has been sent.");
	          		$('#compose').closeModal();
	          		self.hideCompose();
	          		self.addThreadAfterPostReply( response );
	          	}).fail(function(error){
	          		console.log(error);
	          	});
			}else{
				setTimeout(function(){$(".error-msg").hide();$(".input-field").removeClass("error");},3000);
				return false;
			}
		},
		openFMsg: function(e){

			//TO-DO: remove this line when server side code will be fixed
			return true;

			var self = this;

			$("#compose").remove();

			self.$el.append(this.ComposePageLayout({isMobileDevice:Utils.isMobileDevice() }));

			$(".user-header").addClass("hide");
			$(".friend-header").removeClass("hide");

			$('body').css({'overflow-y' : 'hidden'});

			Utils.openPopup("compose");

			$("#subject").val( $(".msg-header").text() ).attr("readonly",true);

			if(Utils.isMobileDevice()){

				$( "#send-to" )
				    // don't navigate away from the field on tab when selecting an item
				    .bind( "keydown", function( event ) {
				    if ( event.keyCode === $.ui.keyCode.TAB &&
				        $( this ).autocomplete( "instance" ).menu.active ) {
				        event.preventDefault();
				    }
			    })
			    .autocomplete({
			        source: function( request, response ) {

			        	$.ajax({
						method: 'GET',
						url: Utils.contextPath()+'/v1/counselor/search?name=' + Utils.JUIextractLast( request.term ),
						}).done(function (data) {
							console.log(data) ;
							var usersArr = new Array() ;

							$.each(data, function (i, val) {
							usersArr.push({
								"key" : val,
								"value" : i
							});
							});
							console.log(usersArr) ;
							response( usersArr );
						});

			        },
			        search: function() {
			          // custom minLength
			          console.log(this) ;
			          var term = Utils.JUIextractLast( this.value );
			          if ( term.length < 2 ) {
			            return false;
			          }
			        },
			        focus: function() {
			          // prevent value inserted on focus
			          return false;
			        },
			        select: function( event, ui ) {
			        	console.log(ui.item) ;
			          self.selectedUsers[ui.item.value] = ui.item.key ;
			          console.log(self.selectedUsers) ;
			          var terms = Utils.JUIsplit( this.value );
			          // remove the current input
			          terms.pop();
			          // add the selected item
			          terms.push( ui.item.value );
			          // add placeholder to get the comma-and-space at the end
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
			        }
			      });
			}else{
					self.$el.find("#send-to").ajaxChosen({
						type: 'GET',
						url: Utils.contextPath()+'/v1/counselor/search',
						dataType: 'json',
						jsonTermKey:"name",
						minTermLength:1
					}, function (data) {

						var terms = {};
						$.each(data, function (i, val) {
							terms[val] = i;
						});
						return terms;
					},
					{
		    			// CHOSEN OPTIONS
		    			disable_search_threshold: -1
					});
			}

			if( !Utils.isMobileDevice() )
				CKEDITOR.replace( 'message' );

			setTimeout(function(){$("#send_to_chosen").find(".chosen-choices").trigger("click");},10);
		},
		blockMsg: function(e){

			var $this = $(e.currentTarget);

			if( confirm("Are you sure you want to mark this message spam?") ){

				var msgID = $("#single-msg-block").attr("data-msgid");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/mark/deleted',
	              contentType: "application/json"
	          	}).done(function(response){
	          		if( $this.hasClass("red-text") ){
						$this.attr("title","Report Spam");
						$this.removeClass("red-text");
					}else{
						$this.addClass("red-text");
						$this.attr("title","Unblock");
					}
					Utils.displaySuccessMsg("Your message has been marked as spam.");
					//location.href = "/friend/messages";
					Backbone.history.navigate("/friend/messages", {trigger: true});
					return true;
	          	}).fail(function(error){
	          		console.log(error);
	          	});
          	}
		},
		addTagsOption:function( categories ){

			var cats = [];
			$.each(categories,function(key,value){
				var tspan = '<span class="tag" data-id="'+value.id+'">'+value.name+'</span>';
				$(".left-tag-list").prepend( tspan );
				cats[value.id] = value.name;
			});

			var self = this;
			var category = localStorage.getItem("categories");
			setTimeout( function(){
				$.each(JSON.parse(category),function(key,value){
	              var option = "<option value='"+key+"' "+(cats[key] != undefined ? 'selected':'')+">"+value+"</option>";
	              $("#tag-list").append( option );
	            });
			},100);
		},
		renderElements: function(){

			$('html, body').stop().animate({
	      		scrollTop: $("body").offset().top}, 1000,'easeInOutExpo');

			this.$el.find("#msg-list-block").remove();
			this.$el.find("#single-msg-block").removeClass("hide");
			this.$el.find(".msg-compose").remove();
		},
		markImportant: function(e){

			var $this = $(e.currentTarget);
			var msgID = $(e.currentTarget).attr("data-msgid");

			if( $this.hasClass("high") ){
				$this.addClass("rotateOut");
				$this.attr("title","Mark Important");
			}
			else{
				$this.addClass("rotateIn");
				$this.attr("title","");
			}
			setTimeout(function(){$this.toggleClass("high");$this.removeClass("rotateIn rotateOut");},800);

			$.ajax({
              method: "POST",
              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/mark/important'
          	}).done(function(response){
          	}).fail(function(error){
          		console.log(error);
          	});
		},
		renderNotesInMsg: function(){
			//user_notes
		},
		addNotes: function(){

			var notes = $("#add-user-note").val();

			if( notes ){

				var msgID = $("#single-msg-block").attr("data-msgid");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/notes',
	              data: notes,
	              contentType: "application/json"
	          	}).done(function(response){
	          		$("#user_notes").find(".no-notes").remove();
	          		var note = '<li class="collection-item"><div class="note-text">'+notes+'</div><span class="note-time">'+Utils.getDateDiff(new Date().getTime())+'</span></li>';
					$("#user_notes").find(".notes-list").prepend( note );
					Utils.displaySuccessMsg("Your note has been added.");
					$("#add-user-note").val("").focus();
	          	}).fail(function(error){
	          		console.log(error);
	          	});
			}else{
				$("#add-user-note").focus();
				return false;
			}
		},
		addTag: function(){

			var msgID = $("#single-msg-block").attr("data-msgid");
			var category = localStorage.getItem("categories");
			var categories = JSON.parse(category);
			$(".right-tag-list").removeClass("hide");
			$(".left-tag-list").addClass("hide");
			$("#tag-list").chosen({
    			width: "94%"
  			});

			var self = this;

			$("#tag-list").on('change', function(evt, params) {

				if( params.selected != undefined ){

					$.ajax({
		              method: "POST",
		              url: Utils.contextPath()+'/v1/users/'+self.model.get("userID")+'/messages/'+msgID+'/categories',
		              data: JSON.stringify(params.selected),
		              contentType: "application/json"
		          	}).done(function(response){
		          		var tspan = '<span class="tag" data-id="'+params.selected+'">'+categories[params.selected]+'</span>';
						$(".left-tag-list").prepend( tspan );
		          	}).fail(function(error){
		          		console.log(error);
		          	});
				}


				if( params.deselected != undefined ){
					self.removeTagByCall( params.deselected );
				}
  			});
		},
		removeTagByCall: function( value ){

			var msgID = $("#single-msg-block").attr("data-msgid");

			$.ajax({
              method: "POST",
              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/categories',
              data: JSON.stringify(value),
              contentType: "application/json"
          	}).done(function(response){
				$(".left-tag-list").find(".tag").each(function(){
					if( $(this).attr("data-id") == value ){
						$(this).remove();
					}
				});
          	}).fail(function(error){
          		console.log(error);
          	});
		},
		closeTag: function(){

			$(".right-tag-list").addClass("hide");
			$(".left-tag-list").removeClass("hide");
			$("#tag-list").trigger('chosen:close');
			$("#tag-list").off('change');
		},
		removeTag: function(e){
			var value = $(e.currentTarget).parent().attr("data-id");
			$(e.currentTarget).parent().remove();
	        $("#tag-list option[value="+value+"]").prop("selected",false);
			//this.removeTagByCall( value );
		},
		removeCollapsed: function(e){

			var $this = $(e.currentTarget);
			// if($this.hasClass("friend-download-attachment")){

			// 	return false;
			// 	e.stopPropagation();
			// 	e.preventDefault();
			// }
			if( $this.attr("data-type") == "CHAT" )
				return true;

			if( $this.hasClass("mcollapsed") ){
				$this.removeClass("mcollapsed");
				$this.find(".bcollapsed").addClass("hide");
				$this.find(".msg-content").removeClass("hide");
				$this.find(".msg-senders").removeClass("truncate");
			}else{
				$this.addClass("mcollapsed");
				$this.find(".bcollapsed").removeClass("hide");
				$this.find(".msg-content").addClass("hide");
				$this.find(".msg-senders").addClass("truncate");
			}

			if( $this.is(":last-child") ){
				$this.find(".msg-content").removeClass("hide");
				$this.find(".msg-senders").removeClass("truncate");
			}
		},
		addBackButton: function(){
			this.$el.find(".msg-side-menu").before( this.$el.find(".desk-back-btn").html() );
		},
		addThreadAfterPostReply: function( response ){

			var cMsg = response.conversationDetail;

			var threadID = cMsg.threadID;
			var important = cMsg.important;
			var message = cMsg.userMessage[ cMsg.userMessage.length-1 ];
			var attachmentId = message.attachmentID;

			var body = message.body.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
			body = Utils.replaceUrls(body);

			var receivedTime = Utils.getDateDiff( message.receivedDate );
			var subject = message.subject;
			var read = message.read;
			var sender = message.fromRecipient.firstName != null ? message.fromRecipient.firstName : message.fromRecipient.username;

			if( message.fromRecipient.picUrl != undefined ){
				var fAvatar = message.fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+message.fromRecipient.avatar+'.png';
			}

			var tos = [];
            for( var i = 0 ; i < message.toRecipients.length ; i++ ){
            	var to = message.toRecipients[i];
            	var firstName = to.firstName != null ? to.firstName : to.username;
 				tos.push( '<span class="msg-toid" data-toids="'+to.id+'">'+firstName+'</span>' );
            }

			var item = '<li class="collection-item avatar dost-msg-item rhover expanded" id="msg-'+message.msgID+'" data-msgid="'+threadID+'" data-type="MAIL">'
              				+'<div class="msg-img-holder">'
                  				+'<img src="'+fAvatar+'" class="circle msg-avatar z-depth-1">'
              				+'</div>'
              				+'<p class="msg-senders msg-sent-by" data-fromid="'+message.fromRecipient.id+'">'+sender+'</p>'
              				+'<p class="msg-senders msg-toids">To: '+tos.join(", ")+'</p>'
                			+'<p class="bcollapsed truncate hide">'
                			+message.bodyCollapsed+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
              				+'</p>'
              				+'<p class="msg-content">'+body+'</p>'
              				+'<a class="secondary-content msg-time">'+receivedTime+'</a>'
                          	+'<i class="mdi mdi-reply smoothscroll msg-single-reply" id="reply-'+message.msgID+'" href="#reply-form" title="Reply"></i>'
						+'</li>';

			this.$el.find("#single-msg-block").find(".single-thread").append( item );
			var self = this;
			if(attachmentId > 0){

				$.ajax({

					method : "GET",
					url : Utils.contextPath() + '/file/type/'+attachmentId,
					contentType: "application/json",
				}).done(function(response){

					if(response){

						var attachment = '<div class="download-div"><i class="mdi mdi-attachment"></i><span class="friend-download-attachment" data-href="'+response.s3Url+'"  data-fileid ="'+response.iD+'">'+response.fileName+'</span><span class="download-error hide">Download Error.</span></div>';
						$("#msg-"+message.msgID).find(".msg-content").append(attachment);
					}
				}).error(function(error){

					console.log("Error: "+error)
				})
			}
			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$(".msg-single-reply").attr("clicked",false);
		},
		sideMenu: function( model ){

			var specialFriend = false;
			if( this.model.get("userID") == 101 ){
				specialFriend = true;
			}

			var sideMenuTemplate = this.FriendMsgSideMenuLayout({specialFriend : specialFriend });
			$("#msg-block").find(".msg-side-menu").html( sideMenuTemplate );

			model.setUnreadCount();

			$("#msg-block").find(".msg-tags-list").html("");
			$("#msg-list-mobile").find(".msg-tags-list").html("");

			var categories = localStorage.getItem("categories");

	        if( !categories ){

            	var category = {};
            	var categories = {};
            	$.ajax({
                	method: "GET",
                	url: Utils.contextPath()+'/category?include_faq=false'
            	}).done(function(response){
              		_.each(response,function(cat){
                		category[cat.id] = cat.name;
                		categories["c_" + cat.id] = cat.name;
                		var list = "<li class='collection-item aitem ftag' data-tagid='"+cat.id+"'>"+cat.name+"</li>";
	              		$("#msg-block").find(".msg-tags-list").append( list );
              		});
              		localStorage.setItem("categories",JSON.stringify(category));
              		localStorage.setItem("c_categories",JSON.stringify(categories));
              		setTimeout(function(){$("#msg-list-mobile").find(".msg-tags-list").html( $("#msg-block").find(".msg-tags-list").html() );},10);
            	}).fail(function(error){});
          	}else{

          		$.each(JSON.parse(categories),function(key,value){
	              	var list = "<li class='collection-item aitem ftag' data-tagid='"+key+"'>"+value+"</li>";
	              	$("#msg-block").find(".msg-tags-list").append( list );
	            });
	            setTimeout(function(){$("#msg-list-mobile").find(".msg-tags-list").html( $("#msg-block").find(".msg-tags-list").html() );},10);

          	}
		},
	    followThread : function( e ){
	    	e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $("#single-msg-block").attr("data-msgid");
			var userID = this.model.get("userID")
			console.log("msg id " + msgID + " userId " + userID);
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+userID+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been followed.");
			    $("#msg-follow").addClass("hide");
				$("#msg-unfollow").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
	    },
	  	unfollowThread : function( e ){
	    	e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $("#single-msg-block").attr("data-msgid");
			console.log("msg id " + msgID);
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("Not following this thread.");
			    $("#msg-unfollow").addClass("hide");
				$("#msg-follow").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
	    },

	    populateSenderForJoin : function(){

			var self = this ;
			var searchType = '/v1/counselor/search' ;

			if( document.getElementById("thread_join_to_chosen") == null){
				$('#thread-join-to').css("display","block");
			}
			$('#thread_join_to_chosen').css("display","block");
			$('#join-conversation').css("display","block");

			if(Utils.isMobileDevice()){

				$( "#thread-join-to" )
			      // don't navigate away from the field on tab when selecting an item
			      .bind( "keydown", function( event ) {
			        if ( event.keyCode === $.ui.keyCode.TAB &&
			            $( this ).autocomplete( "instance" ).menu.active ) {
			          event.preventDefault();
			        }
		      })
		      .autocomplete({
		        source: function( request, response ) {

		        	$.ajax({
					method: 'GET',
					url: Utils.contextPath()+ searchType + '?name=' + Utils.JUIextractLast( request.term ),
					}).done(function (data) {
						var usersArr = new Array() ;

						$.each(data, function (i, val) {
						usersArr.push({
							"key" : val,
							"value" : i
						});
						});
						response( usersArr );

					});


		        },
		        search: function() {
		          // custom minLength
		          var term = Utils.JUIextractLast( this.value );
		          if ( term.length < 2 ) {
		            return false;
		          }
		        },
		        focus: function() {
		          // prevent value inserted on focus
		          return false;
		        },
		        select: function( event, ui ) {

		          self.selectedSentBy[ui.item.value] = ui.item.key ;
		          var terms = Utils.JUIsplit( this.value );
		          // remove the current input
		          terms.pop();
		          // add the selected item
		          terms.push( ui.item.value );
		          // add placeholder to get the comma-and-space at the end
		          terms.push( "" );
		          this.value = terms.join( ", " );
		          return false;
		        }
		      });
			}else{
				self.$el.find("#thread-join-to").ajaxChosen({
					type: 'GET',
					url: Utils.contextPath()+ searchType,
					dataType: 'json',
					jsonTermKey:"name",
					minTermLength:1
				}, function (data) {

					var terms = {};
					$.each(data, function (i, val) {
						terms[val] = i;
					});
					return terms;
				});
			}

		},
		joinConversation : function(){
			var counselorId = $('#thread-join-to').val();

			if( counselorId == null ){
				Utils.displayErrorMsg("Add counselor to conversation");
				return;
			}

			if( counselorId.length > 1 ){
				Utils.displayErrorMsg("Only one counselor allowed to join conversation");
				return;
			}

			var threadId = $("#single-msg-block").attr("data-msgid");
			var counselor = $('#thread_join_to_chosen').find('.search-choice span').html();
			$.ajax({
					method: 'POST',
					url: Utils.contextPath()+ "/v1/users/messages/" + threadId + "/" + counselorId,
					data: {},
					}).done(function (data) {
						if(data == true){
							$('#thread-join-to').css("display","none");
							$('#join-conversation').css("display","none");
							$('#thread_join_to_chosen').css("display","none");
							$('#thread_join_to_chosen').find('.search-choice').remove();
							$('#thread-join-to').find(':selected').each(function() { $(this).removeAttr('selected') });
							Utils.displaySuccessMsg("This conversation has been joined with counselor " +  counselor );

						}else{
							alert("error");
						}
					});

		}
	});

	FriendSingleMessagePage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	$(window).unbind("scroll");
	};

	FriendSingleMessagePage.prototype.clean = function() {
 		this.remove();
 		$(window).unbind("scroll");
	};

	return FriendSingleMessagePage;
});
