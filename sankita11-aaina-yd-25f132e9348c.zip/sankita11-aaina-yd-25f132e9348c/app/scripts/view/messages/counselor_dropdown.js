define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'model/users',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function($, _, Dispatcher, UserModel,Backbone, JST, Utils) {
	
	var CounselorDropDownPage = Backbone.View.extend({
		
		el: "main",

		initialize: function() {

			this.userModel       = new UserModel();
			_.bindAll(this)                                                  ;
			this.listenTo(Dispatcher, 'renderCounselorDropDown', this.renderHTML) ;
			this.selectedCounselorObj = {};
		},
		events: {

			'keyup #searchCounselorList' : 'searchCounselorList',
			'click .counselor_dropdownlist_item' : 'selectCounselor',
			'click #searchCounselorList' : 'showDropDownList'
		},

		counselorDropDownLayout: JST['app/templates/messages/counselor_dropdown.hbs'],

		// renderHTML : function(container){

		// 	$(container).append(this.counselorDropDownLayout({}));
		// },

		selectCounselor : function(e){

			var self = this;
			var name = "";
			var id = "";

			if($(e.currentTarget).hasClass("selected")){

				$(e.currentTarget).removeClass("selected")
				$(".counselor_dropdownlist_item").removeClass("selected")
			}else{

				$(".counselor_dropdownlist_item").removeClass("selected")
				$(e.currentTarget).addClass("selected")
				id = $(e.currentTarget).attr("data-id")
				if(id == 101){

					name = "Send to best suitable Expert";
				}else{

					name = $(e.currentTarget).find("#counselor_dropdownlist_name").text();
				}
				$(".counselor_dropdownlist").addClass("hide");
			}
			self.selectedCounselorObj["id"] = id;
			self.selectedCounselorObj["name"] = name;
			$("#searchCounselorList").val(name);
			$("#searchCounselorList").attr("data-cId", id)
		},

		showDropDownList : function(){

			$(".counselor_dropdownlist").removeClass("hide");
		},

		searchCounselorList : function(){

			var self = this;

			$(".counselor_dropdownlist").removeClass("hide");

			$(".no_experts_found").addClass("hide");
			var term = $("#searchCounselorList").val();
			

			if(term == ""){

				$(".counselor_dropdownlist_item").removeClass("selected")
				$('.counselor_dropdownlist_item').each(function(){

			       	$(this).show();
			    });

			}else{

				$('.counselor_dropdownlist_item').hide();
				$(".counselor_dropdownlist_all").find(".counselor_dropdownlist_header").show();
	        	$(".counselor_dropdownlist_familiar").find(".counselor_dropdownlist_header").show();
	        	$('.counselor_dropdownlist_item').each(function(){


			        if($(this).find("#counselor_dropdownlist_name").text().toUpperCase().indexOf(term.toUpperCase()) != -1){
			           
			           	$(this).show();
			           	$(".counselor_dropdownlist_item_special").show();

			        	self.checkforCounselorSearch()
			        }else{

			        	$(".counselor_dropdownlist_item_special").show();
			        	self.checkforCounselorSearch()
			        }
			    });
			}
		},

		checkforCounselorSearch : function(){

			if(!$(".counselor_dropdownlist_all .counselor_dropdownlist_item").is(":visible")){

        		$(".counselor_dropdownlist_all").find(".counselor_dropdownlist_header").hide();
        	}else{

        		$(".counselor_dropdownlist_all").find(".counselor_dropdownlist_header").show();
        	}
        	if(!$(".counselor_dropdownlist_familiar .counselor_dropdownlist_item").is(":visible")){

        		$(".counselor_dropdownlist_familiar").find(".counselor_dropdownlist_header").hide();
        	}else{

        		$(".counselor_dropdownlist_familiar").find(".counselor_dropdownlist_header").show();
        	}
		},

		getFamiliarCounselors : function(container){

			var self = this;
			var arrayOfExperts = []
			var userId = self.userModel.getUserID();

			$.ajax({
	            method: "GET",
	            url: Utils.contextPath()+'/v1/counselor?user='+userId,
	            contentType: "application/json",
	        }).done(function(allExperts){

	        	$.ajax({
	            method: "GET",
	            url: Utils.contextPath()+'/v1/counselor?user='+userId+'&familiar='+true,
	            contentType: "application/json",
	       		}).done(function(familiarExperts){

	       			showFamiliarExperts = "false";

	       			if(familiarExperts.length > 0){

	       				showFamiliarExperts = "true"

	  					$.each(familiarExperts, function(j){

	  						for(var index=0;index < allExperts.length; index++){

	  							if(allExperts[index].id == familiarExperts[j].id){

	  								allExperts.splice(index, 1)
	  								break;
	  							}
	  						}
	  					})
		  			}

	       			self.$("."+container).append(self.counselorDropDownLayout({allExperts : allExperts, showFamiliarExperts : showFamiliarExperts, familiarExperts : familiarExperts}))
	       		}).error(function(error){

	       			console.log("Error ", error)
	       		})
				
			}).error(function(error){

				console.log("Error ", error)
			})

		},

		getAllCounseelors : function(container){

			var self = this;

			$.ajax({
	            method: "GET",
	            url: Utils.contextPath()+'/v1/counselor',
	            contentType: "application/json",
	        }).done(function(response){

				self.$("."+container).append(self.counselorDropDownLayout({allExperts : response, showFamiliarExperts: "false"}))

			}).error(function(error){

				console.log("Error ", error)
			})
		},

		renderHTML : function(container){

			var self = this;

			if(!Utils.isLoggedIn()){

				self.getAllCounseelors(container);
			}else{

				self.getFamiliarCounselors(container);
			}

			self.setElement($("main")).render();
		},

		render: function(container) {

			var self = this;
			
			 $(document).mouseup(function (e){

                var container = $(".counselor_dropdownlist_search");

                if (!container.is(e.target) 
                    && container.has(e.target).length === 0 ) 
                  {
                    $(".counselor_dropdownlist").addClass("hide")
                  }
            });
			return this;
		}
	});

	CounselorDropDownPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	CounselorDropDownPage.prototype.clean = function() {

		this.remove();
	};

	return CounselorDropDownPage;
});