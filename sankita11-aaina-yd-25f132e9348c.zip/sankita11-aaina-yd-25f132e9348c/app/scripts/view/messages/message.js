define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel',
	'model/users',
	//'view/messages/message_modal',
	'view/messages/user_profile_collection',
	'view/messages/user_profile',
	'ajax-chosen',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, Utils, EventBus, UserMsgModel, UserModel, UserProfileCollectionView, UserProfile) {

	var MessagePage = Backbone.View.extend({
		el: "main",
		template: JST['app/templates/messages/message_view_container.hbs'],
		initialize: function() {
			var self = this;

			$(document).on('keyup','#search-msg-mobile', function(evt) {
			   self.search(evt);
			});

			$(document).on('click','#back-to-conversations', function(evt) {
			   self.loadConversations();
			});

			$(document).on('click','.delete', function(evt) {
			   self.deleteThread();
			});			

			var url = window.location.href ;
    		url = url.replace("/user/messages", "" );
            
            var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo; 

            this.searchParam = $.url( url ).param( 's' );

			this.selectedCategories = {} ;
			this.selectedUsers = {} ;

			this.model = new UserMsgModel();
			this.createModelUrl();
			this.userModel = new UserModel();
			this.userProfileCollection = new UserProfileCollectionView();
			this.userProfile = new UserProfile();
			this.isMobile = Utils.isMobileDevice();
			this.statusInterval = 0;
		},
		events: {
			"click .message-item" : "fetchThreadMessages",
			"click .chat-list .circle" : "loadExpertProfile",
			"click .mail-list .circle" : "loadExpertProfile",
			"click .profile-details .header .close-expert-profile" : "closeExpertProfile",
			"click .profile-details .show-more" : "showMoreDetails",
			"click .profile-details .show-less" : "showLessDetails",
			"click .compose" : "openCompose",
			"click .edit-draft" : "editDraft",
			"click .delete" : "deleteThread",
			"click #call-thread" : "callFromThreadView",
			"click #call-expert" : "callFromExpertView",
			"click #msg-thread" : "messageFromThreadView",
			"click #msg-expert" : "messageFromExpertView",
			"click .reply-btn" : "reply",
			"keyup .search-box" : "search",
			"click .attachment .dripicons-download" : "trackFileDownload",
			"click .profile-details .dripicons-conversation" : "trackChat",
			"click .more-details-container .categories" : "trackFilter",
			"click .favourite": "favourite",
			"click .connect" : "connectToChat",
			"click .connect-expert .msg-connect" : "connectChat"
		},
		pageNumber: 1,
		counselorList: [],
		categoryList: [],
		loadConversations: function () {
			$(".mmsg-list-view-header").html(this.conversationHeader);
			this.$el.find(".thread-container").hide();
			this.$el.find(".list-container").show();
		},
		search: function (evt) {
			var self = this;
			var searchText = self.isMobile ? $("#search-msg-mobile").val() : $(".search-box input").val(); 
			if (evt.keyCode == "13") {
				var query = searchText;
				if (query.length > 0) {
					self.pageNumber = 1;
					self.fetchMessages({'search': "content_search=" + query});
				}
			} else if (searchText.length == 0 || !evt.keyCode) {
				self.pageNumber = 1;
				self.fetchMessages();
			}
		},
		scrolled: function (o) {
			if (this.loading) return;
			var bottomOffset = 20;
			o=o.currentTarget;
			if(o.offsetHeight + o.scrollTop > (o.scrollHeight - bottomOffset))
            {
                var searchText = this.isMobile ? $("#search-msg-mobile").val() : $(".search-box input").val();
                this.pageNumber += 1;
                if (searchText && searchText.length > 0) {
                	this.fetchMessages({'search': "content_search=" + searchText});	
                } else {
                	this.fetchMessages();
                }
                
            }
		},

		connectToChat: function(){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'Chat - specialfriend card' });
			EventBus.trigger('chatQuickCheck', 'demo', 0, "Special Friend Chat", " Message specialfriend card", "home");
		},
		connectChat: function(){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : ' Message - specialfriend footer CTA' });
			EventBus.trigger('chatQuickCheck', 'demo', 0, "Special Friend Chat", " Message specialfriend Mail", "home");
		},
		sendRequest: function (method, url) {
			var deferred = $.Deferred();
			$.ajax({
				method : method,
				url : url
			})
			.done(function (response) {
				deferred.resolve(response);
			})
			.fail(function (error) {
				deferred.reject(error);
			})
			return deferred.promise();
		},
		trackFileDownload: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("File Download", { "itemName" : 'From Message' });
		},
		trackChat: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : '#CHAT - expert module - messages' });
		},
		trackFilter: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'filter - expert module - messages' });
		},
		getTime: function (date) {
			var splittedDate = Utils.getDateDiff(date, undefined, false).split(" ");
			return splittedDate[3].concat(" ").concat(splittedDate[4]);
		},
		showMoreDetails: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'Expand Expert Card in Message' });	
			$(".show-more").hide();
			$('.more-details-container').show();
		},
		showLessDetails: function () {
			$(".show-more").show();
			$('.more-details-container').hide();
		},
		openUserProfileCollection: function () {
			this.userProfileCollection.render({});
			this.pageNumber = 1;
			this.fetchMessages();
		},
		openCompose: function () {
			if (!Utils.isLoggedIn()) {
				EventBus.trigger("renderLogin", undefined, 'messages', undefined, {}) ;
			} else {
				EventBus.trigger("openComposeMessage", {
					info: {}
				});
			}
		},
		reply: function () {
			var self = this;
			if (self.isMobile) {
				self.editDraft({status: 'SENT', mobile: "true"});
				return;
			}
			
			var messageText = $(".reply-text").val();
			if (messageText) {
				var url = self.model.url.split("messages")[0] + "messages";
				var params = {
					recipients: [],
					categoryIds: []
				};
				if (self.selectedConversation.userMessage[0].toRecipients[0].id == self.userModel.getUserID()) {
					params.recipients.push(self.selectedConversation.userMessage[0].fromRecipient.id);
				} else {
					params.recipients.push(self.selectedConversation.userMessage[0].toRecipients[0].id);
				}
				
				if (self.selectedConversation.categories[0]) params.categoryIds.push(self.selectedConversation.categories[0].id);
				params.status = 'SENT';
				params.subject = self.selectedConversation.userMessage[0].subject;
				params.content = messageText
				params.threadID = self.selectedConversation.threadID
				self.$el.find(".thread-container").html(self.loaderLayout()) ;
				$.ajax({
					method : 'POST',
					url : url,
					data : JSON.stringify(params),
					dataType: "JSON",
					contentType: "application/json; charset=utf-8",
				})
				.done(function (response) {
					self.replySuccess = true;
					self.selectedElement.click();
				})
				.fail(function (error) {
					
				});
			}
		},
		renderUserProfile: function () {
			this.userProfile.$el = this.$('#user-profile-widget');
			this.userProfile.render();
			this.userProfile.delegateEvents();
			this.replySuccess = false;
		},
		callFromThreadView: function () {
			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + this.expertId + '&catID=Others', {trigger: true});
		},
		callFromExpertView: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : '#APPOINTMENT - expert module - messages' });
			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + this.expertId + '&catID=Others', {trigger: true});
		},
		messageFromThreadView: function () {
			var details = {};
			details.recipientId  = this.expertId;
			EventBus.trigger("openComposeMessage", {
				info: details
			});
		},
		messageFromExpertView: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : '#MSG - expert module - messages' });
			var details = {};
			details.recipientId  = this.expertId;
			EventBus.trigger("openComposeMessage", {
				info: details
			});
		},
		editDraft: function (options) {
			var self = this;
			var savedDetails = {};
			savedDetails.recipientId  = this.selectedConversation.userMessage[0].toRecipients[0].id;
			savedDetails.subject = this.selectedConversation.userMessage[0].subject;
			savedDetails.categories = this.selectedConversation.categories;
			savedDetails.body = this.selectedConversation.userMessage[0].body;
			savedDetails.threadID = this.selectedConversation.threadID;
			savedDetails.messageID = this.selectedConversation.userMessage[0].msgID;
			if (options) {
				savedDetails.status = options.status;
				savedDetails.mobile = options.mobile;
				if (options.mobile) savedDetails.body = "";
			}
			this.getParsedAttachments(this.selectedConversation.userMessage)
			.then(function (response) {
				savedDetails.attachments = response;
				EventBus.trigger("openComposeMessage", {
					info: savedDetails
				});
			},function (error) {
				EventBus.trigger("openComposeMessage", {
					info: savedDetails
				});
			});
			
		},
		messageListLayout : JST['app/templates/messages/message_list.hbs'],
		messageThreadLayout : JST['app/templates/messages/message_thread.hbs'],
		expertProfileLayout : JST['app/templates/messages/expert_profile.hbs'],
		attachmentsLayout : JST['app/templates/messages/attachments.hbs'],
		//composeMessage: JST['app/scripts/view/messages/message_modal.js'],
		loaderLayout : JST['app/templates/loader.hbs'],
		mobileHeaderLayout: JST['app/templates/messages/mobile_thread_header.hbs'],

		getParsedMessages: function(messageList) {
			var parsedMessagesList = [];
			_.each(messageList, function(message){
				var type = message.type;
				message = message.conversationDetail;
				var messageHash = {};
				var messageDetails = {};
				messageHash['threadId'] = message.threadID;
				messageHash['msgType'] = type;
				if (type == 'CHAT') {
					messageDetails = message.userChats[0].chatGroupUsers[0];
					messageHash['desc'] = message.userChats[0].body;
					messageHash['elapsedTime'] = Utils.getDateDiff(message.userChats[0].sentDate).split("'")[0];
					messageHash['isChat'] = true;
				} else if (type == 'MAIL') {
					messageDetails = message.userMessage[0].messageType == 'SENT_MAIL' ? message.userMessage[0].toRecipients[0] : message.userMessage[0].fromRecipient;
					messageHash['isRead'] = message.userMessage[0].messageType == 'SENT_MAIL' || message.userMessage[0].read ? '' : 'unread';
					//messageHash['isDraft'] = message.status == 'DRAFT' ? true : false;
					messageHash['isDraft'] = false;
					messageHash['desc'] = message.userMessage[0].subject || '&nbsp;&nbsp;';
					messageHash['elapsedTime'] = Utils.getDateDiff(message.userMessage[0].receivedDate).split("'")[0];
				}
				messageHash['expertId'] = messageDetails.id;
				messageHash['senderName'] = messageDetails.firstName || messageDetails.username;
				messageHash['senderPic'] = Utils.getSecureUrl(messageDetails.picUrl) || '/images/avatar/'.concat(messageDetails.avatar).concat('.png');
				parsedMessagesList.push(messageHash);
			});
			return parsedMessagesList;
		},
		getParsedThreadMessages: function (options) {
			var self = this;
			var parsedMessagesList = [];
			if (options.chatType) {
				_.each(options.messageList, function (message, index) {
					var messageHash = {};

					messageHash['expertId'] = message.user.id;
					//self.expertId = messageHash['expertId'];
					messageHash['desc'] = message.body;
					messageHash['senderPic'] = Utils.getSecureUrl(message.user.picUrl) || '/images/avatar/'.concat(message.user.avatar).concat('.png');
					messageHash['time'] = self.getTime(message.sentDate);
					messageHash['isVictim'] = message.user.loggableUser.userType == 'VICTIM' ? true : false;
					/*
						-- checking for 0th index
						-- to add extra fields for first item
						-- required to populate the fixed header title
					*/
					if (!index) {
						messageHash['elapsedTime'] = Utils.getDateDiff(message.sentDate).split("'")[0];
						messageHash['expertName'] = self.selectedConversation.expertName;
						messageHash['expertPic'] = self.selectedConversation.expertPic;
					}
					parsedMessagesList.push(messageHash);
				});
			} else {
				var isDraft = options.isDraft;
				var msgLength = options.messageList.length
				var showCta = false;
				var ctaAdded = false;
				var expertIndex = 0;
				var indexExpertLastMsg = this.checkToCta(options.messageList);
				_.each(options.messageList, function (message, index) {
					var messageHash = {};

					//exporting expert id only for experts
					if (message.fromRecipient.loggableUser.userType !== 'VICTIM') messageHash['expertId'] = message.fromRecipient.id;

					messageHash['desc'] = message.body;

					if(message.fromRecipient.loggableUser.userType == 'OPERATOR'){

						expertIndex++;
					}
					if(indexExpertLastMsg == expertIndex && !ctaAdded){

						showCta = true;
						ctaAdded = true;
					}else{

						showCta = false
					}
					
					messageHash['showCta'] = showCta;
					//messageHash['isDraft'] = isDraft;
					messageHash['isDraft'] = false;
					messageHash['senderName'] = message.fromRecipient.firstName || message.fromRecipient.username;
					messageHash['senderPic'] = Utils.getSecureUrl(message.fromRecipient.picUrl) || '/images/avatar/'.concat(message.fromRecipient.avatar).concat('.png');
					messageHash['elapsedTime'] = Utils.getDateDiff(message.receivedDate).split("'")[0];
					messageHash['recipientName'] = message.toRecipients[0] && (message.toRecipients[0].firstName || message.toRecipients[0].username);
					parsedMessagesList.push(messageHash);
				});
			}
			return parsedMessagesList;
		},

		checkToCta: function( data ){

			var expertMsgList = []
			_.each(data, function(msg, index){

				if(msg.fromRecipient.loggableUser.userType == "OPERATOR"){

					expertMsgList.push(msg)
				}
			})

			return expertMsgList.length
		},
		getParsedReviews: function (reviews) {
			var self = this;
			var parsedReviews = [];
			_.each(reviews, function (review) {
				var reviewHash = {};
				reviewHash['desc'] = review.description;
				reviewHash['ratingArr'] = self.getRatingArray(review.rating);
				reviewHash['name'] = review.victim && (review.victim.firstName || review.victim.username);
				reviewHash['pic'] = 'https://d1hny4jmju3rds.cloudfront.net/avatar/avatar7.png';
				//reviewHash['pic'] = review.victim && (review.victim.picUrl || '/images/avatar/'.concat(review.victim.avatar).concat('.png'));
				parsedReviews.push(reviewHash);
			});
			return parsedReviews;
		},
		getParsedAttachments: function (list) {
			var self = this;
			var deferred = $.Deferred();
			var promiseList = [];
			var attachmentHashList = [];
			_.each(list, function (item) {
				if (item.attachmentID) {
					var attachmentHash = {};
					attachmentHash['downloadLink'] = Utils.contextPath() + '/file/download/' + item.attachmentID;
					attachmentHashList.push(attachmentHash);
					promiseList.push(self.sendRequest('GET', Utils.contextPath() + '/file/type/' + item.attachmentID));
				}
			});
			if (!promiseList.length) $(".profile-container .expert-profile-container").css("height", "100%");
			$.when.apply($, promiseList)
			.then(function () {
				var responseArr = Array.prototype.slice.call(arguments);
				var length = responseArr.length;
				for (var i=0; i<length; i++) {
					attachmentHashList[i]['name'] = responseArr[i]['fileName'];
				}
				deferred.resolve(attachmentHashList);
			}, function (error) {
				// body...
			});
			return deferred.promise();
		},
		getRatingArray: function (rating) {
			var ratingArr = [];
			for (var i=0; i<5; i++) {
				if (i < rating) {
					ratingArr.push("");
				} else {
					ratingArr.push("-outline");
				}
			}
			return ratingArr;
		},
		favourite: function () {
			self.isFavourite = !self.isFavourite;
			if (self.isFavourite) {
 				$(".favourite").removeClass("favourite-counselor");	
			} else {
				$(".favourite").addClass("favourite-counselor");
			}
			var userId = this.model.url.split("users/")[1].split("/messages")[0];
			var url = Utils.contextPath() + "/v2/users/" + userId + "/counselor/" + this.expertId + "/favourite";
			$.ajax({
				method : 'POST',
				url : url
			});	
		},
		loadExpertProfile: function (evt, profileIconNotClicked) {

			var expertId = evt.currentTarget.getAttribute('data-expert-id');
			this.expertId = expertId;
			if(!this.expertId){

				return;
			}
			if (this.isMobile && !profileIconNotClicked) {
				this.$el.find(".thread-container").hide();
				$(".mmsg-list-view-header").html(this.mobileHeaderLayout({
					isChat: false,
					expertName: ""
				}));
				this.$el.find(".profile-container").addClass("no-padding");
				this.$el.find(".profile-container").show();
			} else {

				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'expand - expert module - messages' });
				this.$el.find(".expert-profile-container").html(this.loaderLayout()) ;
				$(".thread-container").removeClass("l9").addClass("l6");
				$(".profile-container").show();
				$(".chat-list .title").css("width", "44%");	
			}
			if (this.pageNumber == 1 && this.messagesCount < 3) this.closeExpertProfile();
			var self = this;
			clearInterval(self.statusInterval);
			
			if (expertId != "101") {

				var detailsPromise = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/" + expertId);
				var reviewsPromise = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/rating/" + expertId);
				var statusPromise = self.sendRequest("GET", Utils.contextPath() + "/v1/counselor/status");
				$.when(detailsPromise, reviewsPromise, statusPromise)
				.then(function (details, reviews, status) {
					var statusDetails = status[expertId];
					if (statusDetails && statusDetails.status == "true") {
						details.isOnline = true;
						details.chatUrl = statusDetails.url;
					}
					details.ratingArr = self.getRatingArray(details.rating);
					details.reviews = self.getParsedReviews(reviews);
					details.reviewCount = reviews.length;
					details.showExpertCard = true
					details.lastActive = details.lastActive && self.getTime(details.lastActive);
					self.$el.find('.expert-profile-container').html(self.expertProfileLayout(details));
					if (self.isMobile) self.$el.find(".close-expert-profile").hide();
					$('.more-details-container').hide();
					// if (self.favouriteCounselors.indexOf(parseInt(self.expertId)) > -1) {
					// 	self.isFavourite = true;
 				// 		$(".favourite").addClass("favourite-counselor");
					// }
				})

				self.statusInterval = setInterval(function () {
	                $.ajax({
	                    url: Utils.contextPath() + '/v1/counselor/status',
	                }).done(function (response) {
	                	var statusDetails = response[expertId];
						if (statusDetails && statusDetails.status == "true") {
							$(".expert-profile-container .details #chat-btn").removeClass("offline").addClass("pointer").find("a").addClass("chat").attr("href", statusDetails.url);
						}
						else {
							$(".expert-profile-container .details #chat-btn").removeClass("pointer").addClass("offline").find("a").removeClass("chat").removeAttr("href");
						}
	                });
	            }, 60 * 1000);
			}
			if(expertId == "101"){

				var defaultDetails = {}
				defaultDetails.picUrl = 'https://d1hny4jmju3rds.cloudfront.net/cloudinary/yourdost-mascot.jpg'
				Utils.fetchCounselorList()
				.then(function (counselors) {

					defaultDetails.expertList = counselors.slice(3,7)
					self.$el.find('.expert-profile-container').html(self.expertProfileLayout(defaultDetails));
				});
				$.ajax({
					method: 'GET',
					dataType: 'JSON',
					url: Utils.contextPath() + '/v1/dashboard/ongoingCnt'
				}).done(function(response){
					
					var noOfPeopleOnline = parseInt(response) + 20;
					$('.online-count').text(noOfPeopleOnline);
				});
			}
		},
		closeExpertProfile: function (evt) {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : 'close - expert module - messages' });
			$(".profile-container").hide();
			$(".thread-container").removeClass("l6").addClass("l9");
			if($('.thread-container').find('.desc').width() < 500) {
				$('.thread-container').find(".mail-item .desc .dost-welcome-msg-table > tbody > tr > td").css("padding", "0px");
			}
			else {
				$('.thread-container').find(".mail-item .desc .dost-welcome-msg-table > tbody > tr > td").css("padding", "0px 47px");
			}
			$(".chat-list .title").css("width", "66%");
		},
		deleteThread: function () {
			var self = this;
			this.$el.find(".thread-container").html(this.loaderLayout()) ;
			this.sendRequest("POST", Utils.contextPath() + "/v1/users/" + this.userModel.getUserID() + "/messages/" + this.selectedConversation.threadID + "/mark/deleted")
			.then(function (response) {
				if (self.isMobile) self.loadConversations();
				self.pageNumber = 1;
				self.fetchMessages();
			}, function (error) {
				// body...
			});
		},

		fetchThreadMessages: function (evt) {
			$(".profile-container .expert-profile-container").css("height", "80%");
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : '.dost-msg-item' });
			if (this.isMobile) {
				this.conversationHeader = this.conversationHeader || $(".mmsg-list-view-header").html();
				this.$el.find(".list-container").hide();
				this.$el.find(".thread-container").show();	
			}
			this.$el.find(".thread-container").html(this.loaderLayout()) ;
			var self = this;
			//this is to handle highlight of selected message list item
			if (self.selectedElement) self.selectedElement.classList.remove('selected');
			self.selectedElement = evt.currentTarget;
			self.selectedElement.classList.add('selected');

			self.loadExpertProfile(evt, true);
			
			//decrement read messages counter of heaer
			if (self.selectedElement.className.indexOf("unread") > -1) {
				var unreadMessages = $(".iheader-msg-badge").html();
				$(".iheader-msg-badge").html(parseInt(unreadMessages) - 1);
				 sessionStorage.setItem("unread",parseInt(unreadMessages) - 1);
				 if(sessionStorage.getItem("unread")==0){
				 		sessionStorage.removeItem("unread");
				 }
				self.model.setUnreadCount();
			}

			self.selectedElement.classList.remove('unread'); 

			var threadId = self.selectedElement.getAttribute("data-thread-id");
			var msgType = self.selectedElement.getAttribute("data-msg-type");
			var chatExpertName = self.selectedElement.getAttribute("data-sender-name");
			var chatExpertPic = self.selectedElement.getAttribute("data-sender-pic");	

			this.model.setMsgUrl({
				threadId : threadId,
				type     : msgType
			});
			self.sendRequest("GET", self.model.url)
			.then(function (response) {
				var chatType = response.type == 'CHAT' ? true : false;
				if (self.isMobile) {
					$(".mmsg-list-view-header").html(self.mobileHeaderLayout({
						isChat: chatType,
						expertName: chatType && (response.conversationDetail.userChats[0].user.firstName || response.conversationDetail.userChats[0].user.username)
					}));	
				}
				self.selectedConversation = response.conversationDetail;
				self.selectedConversation.expertName = chatExpertName;
				self.selectedConversation.expertPic = chatExpertPic;
				self.$el.find('.thread-container').html(self.messageThreadLayout({
					messageList: self.getParsedThreadMessages({
						messageList : response.conversationDetail.userChats || response.conversationDetail.userMessage,
						chatType: chatType,
						//isDraft: response.conversationDetail.status == 'DRAFT' ? true : false
						isDraft: false
					}),
					chatType: chatType,
					//isDraft: response.conversationDetail.status == 'DRAFT' ? true : false
					isDraft: false
				}));
				if(self.$el.find('.thread-container').find('.desc').width() < 500) {
					self.$el.find('.thread-container').find(".mail-item .desc .dost-welcome-msg-table > tbody > tr > td").css("padding", "0px");
				}
				if (!chatType) { 
					self.getParsedAttachments(response.conversationDetail.userMessage)
					.then(function (response) {
						self.$el.find('.attachments-container').html(self.attachmentsLayout({
							attachments: response.length ? response: undefined
						}));
					}, function (error) {
						// body...
					});
				} else {
					$(".profile-container .expert-profile-container").css("height", "100%");
					self.$el.find('.attachments-container').html(self.attachmentsLayout({
						attachments: undefined
					}));
				}
				if (self.replySuccess) self.renderUserProfile();
			}, function (error) {
				// body...
			});
			self.model.setUnreadCount();
		},
		createModelUrl: function (params) {
			var params = params || '';
			this.model.setMsgTypeUrl(this.pageNumber, params);
		},
		fetchMessages: function (params) {
			var listContainer = this.$el.find(".messages");
			if (this.pageNumber == 1) listContainer.html(this.loaderLayout()) ;
			var self = this;
			self.createModelUrl(params);
			self.loading = true;
			self.sendRequest("GET", self.model.url)
			.then(function (response) {
				self.messagesCount = response.length;
				self.loading = false;
				if (self.pageNumber == 1) {
					listContainer.html('');
				}

          		listContainer.append(self.messageListLayout({
          			messageList: self.getParsedMessages(response),
          		}));
          		if (params) $(".search-box input").val(params['search'].split("=")[1]);
          		if (!self.isMobile) {
          			if (self.pageNumber == 1) $(".message-item").first().click();
          		}
          		if (!self.scrollHandlerRegistered) {
          			$('.messages').scroll(function(evt) {
          				self.scrolled.call(self, evt);
          			});
          			self.scrollHandlerRegistered = true;
          		}
			}, function (error) {
				self.loading = false;
			});
		},
		disableTabKey: function (evt) {
			if (evt.keyCode == '9') evt.preventDefault();
		},
		render: function() {
			$(".feedback-form-btn").addClass("hide");
			window.scrollTo(0,0);
			var self = this;
			//this is to prevent focus on page footer on tab key press
			$(document).bind('keydown', self.disableTabKey);	
			//disable scrolling
			$('body').css("overflow","hidden");
			var self = this;
			$(".modal").remove();

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) {
				mixpanel.track("Messages Page", {});
			}

			if(!Utils.isLoggedIn()){
				var hash = location.pathname;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{                        
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}
			var user_id = this.userModel.getUserID() ; 
			var userType = this.userModel.getUserType();
			self.model.setUnreadCount();
			var url = Utils.contextPath() + "/v2/users/" + user_id + "/counselor/favourite";
			$.ajax({
				method : 'GET',
				url : url
			})
			.then(function (res) {
				self.favouriteCounselors = res;
			});
			
			this.$el.html(this.template());
			this.fetchMessages();
			return this;
		}
	});

	MessagePage.prototype.remove = function() {
		var self = this;
		this.$el.empty();
    	this.$el.off();
		clearInterval(self.statusInterval);
    	this.stopListening();
    	$(document).unbind('keydown', self.disableTabKey);
    	$(".feedback-form-btn").removeClass("hide");

    	//restore scrolling on other views
    	$('body').css("overflow","scroll");
	};

	MessagePage.prototype.clean = function() {
		this.remove();
	};

	return MessagePage;
});
