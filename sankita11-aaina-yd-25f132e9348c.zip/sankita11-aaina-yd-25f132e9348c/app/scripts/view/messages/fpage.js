define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/FriendMsgModel',
	'ajax-chosen'
], function($,_, Backbone, JST, Utils, EventBus, FriendMsgModel) {

	var FriendMessagePage = Backbone.View.extend({
		el: "main",
		initialize: function() {

			if(!Utils.isLoggedIn()){
				var hash = location.pathname ;
				hash = hash.replace("/", "") ;
				//location.href = "/login?r=" + hash ;
				Backbone.history.navigate("/login?r=" + hash, {trigger: true});
				return ;
			}

			this.model = new FriendMsgModel;
			this.initSetup();
			EventBus.bind("msg:updateUnreadCount",this.updateUnreadCount);
			this.updateUnreadCount();
			this.selectedUsers = {} ;

			this.timeoutId = -1;
			this.threadID = 0;
			this.messageID = 0;
			this.subjectLine = "";
			this.messageBody = "";
			this.usersArrString = "";
			this.attachmentIds = [];

		},
		FriendMessagePageLayout : JST['app/templates/messages/friend_layout.hbs'],
		FriendMsgSideMenuLayout : JST['app/templates/messages/fmsg_sidemenu.hbs'],
		ComposePageLayout : JST['app/templates/messages/compose.hbs'],
		events: {
			"click .dost-msg-item": "openMessage",
			"click #compose .mclose" : "hideCompose" ,
			"click #compose-btn": "openCompose",
			"click #compose-send-btn": "composeMsg",
			"click .msg-msearch-ficon": "openMobileMenu",
			"click .fmsgtype": "fetchList",
			"click .msg-severity": "markImportant",
            "click #filter-close-btn" : "hideFilter",
            "click #msg-side-header-close": "closeMsgSideBar",
            "click .ftag": "tagFilter",
            "click #msg-search-btn": "searchMessage",
            "keyup #msg-search-txt": "searchMessageByEnter",
            "click #fsmsg-close" : "CloseThread",
			"click #fsmsg-open" : "OpenThread",
			"keyup #subject": "isSubject",
            "change #send-to": "isSendTo",
            "keyup #send-to": "isSendToInMobile",
            "keyup #message ": "isMessage",

            "change #send-category": "isCategory",
            "keyup #send-category": "isCategoryInMobile",
            "click #msg-follow" : "followThread",
            "click #msg-unfollow" : "unfollowThread",
            "click .confirm-save-draft-modal-dont-save": "discardDraft",
            "click .confirm-save-draft-modal-save": "saveDraft",
            "click .delete-draft": "hideCompose",
            "change #message-file-attachment" : "uploadFileInFMessageList",
            "click .remove-attached-file" : "uploadNewFileFMessageList"
		},
		discardDraft: function(e) {

			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();
        	Utils.discardDraft( this.model.get("userID"), this.messageID );
        	$("#compose").remove();
		},
		saveDraft: function(e) {

			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();

			$("#compose").remove();

		},

		uploadNewFileFMessageList : function(e){

			$(".file-name-attached-message").addClass("hide");
			$(".file-attachment-message-send").removeClass("hide");
		},
		uploadFileInFMessageList : function(e){

			var file = e.target.files[0];
			var data = new FormData();
			var self =  this;

			$(".message-upload-error").addClass("hide")
			if(file.type == "application/x-ms-dos-executable"){

				$(".message-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			$(".file-name-attached-message").removeClass("hide");
			$(".file-attachment-message-send").addClass("hide");
			$(".file-name-attached").html("Uploading ...");

			data.append('file', $('#message-file-attachment').get(0).files[0] );
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){

				console.log("Response: "+response)
				$(".file-name-attached-message").removeClass("hide");
				$(".file-attachment-message-send").addClass("hide");
				$(".file-name-attached").html(file.name);
				self.attachmentIds.push(response.fileID);

			}).error(function(error){

				$(".file-name-attached-message").addClass("hide");
				$(".file-attachment-message-send").removeClass("hide");
				$(".message-upload-error").removeClass("hide").html("Upload Error");
				console.log("Error: "+error);
			})
		},
		hideCompose : function(){
			Utils.closePopup('compose') ;

			console.log("hello2");
			//this.autoSaveMessage();
			//.openPopup( "confirm-save-draft" );
			$("div#lean-overlay:last").css({'display':'block', 'opacity':'0.5'});
		},
		tagFilter: function(e){

			var self = this;
			var catId = $(e.currentTarget).attr("data-tagid");

			$("#msg-list-block").attr("data-ctype","TAGS");

			this.clearSearch();

			if( $(e.currentTarget).parent().hasClass("mside") ){
				$('#filter-msg-nav-btn').sideNav("hide");
				$(".smsg-header").text( $(e.currentTarget).attr("data-text") );
			}

			$("#msg-list-block").find(".fmsg-TAGS-list").attr("cid",catId);

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			$("#msg-list-block").find(".fmsg-list").addClass("hide");
			$("#msg-list-block").find(".fmsg-TAGS-list").html("");
			$(".aitem").removeClass("active");
			$(e.currentTarget).addClass("active");
			var params = {"cid":catId};
			this.loadMsgs( 1 , params );
			self.bindScroll();
		},
		isCategory: function() {

			//console.log('hello');
			if ( $(".category-field").hasClass("error") ) {
				$(".isend-category").hide();
				$(".category-field").removeClass("error");
			}
		},
		isSubject: function() {
			//console.log("hello");
			if ( $(".isubject").parent().hasClass('error') ) {

				$(".isubject").hide();
				$(".isubject").parent().removeClass('error');
			}

		},
		isSendTo: function() {

			var sendTo = $("#send-to").val();

			if (sendTo != null) {
				var sendToLength = sendTo.length;
			}

			if ( sendToLength === 1 ) {
				if( $(".isend-to").parent().hasClass('error') ) {

					$(".isend-to").hide();
					$(".isend-to").parent().removeClass('error');
				}
			}
		},
		isSendToInMobile: function() {

			if (Utils.isMobileDevice) {

				var sendTo = $("#send-to").val();

				if (sendTo != null) {
					var sendToLength = sendTo.length;
				}

				if ( sendToLength === 1 ) {
					if( $(".isend-to").parent().hasClass('error') ) {

						$(".isend-to").hide();
						$(".isend-to").parent().removeClass('error');
					}
				}
			}
		},
		isMessage: function(e) {

			console.log("hello");
			//console.log(e.currentTarget);
			var self = this;

			clearTimeout(self.timeoutId);
    		self.timeoutId = setTimeout(function() {
        		// Runs 1 second (1000 ms) after the last change
        		//self.autoSaveMessage();

    		}, 500);

			var body = $("#message").val().trim();
			if ( $(".imessage").parent().hasClass('error') ) {

				if (body.trim().length < 100) {
					$(".imessage").hide();
					$(".imessage").parent().removeClass('error');
				}
				else {
					$(".imessageCnt").hide();
					$(".imessage").parent().removeClass('error');
				}
			}
		},
		isCategoryInMobile: function(e) {

			if (Utils.isMobileDevice) {

					if ( $(".category-field").hasClass("error") ) {
						$(".isend-category").hide();
						$(".category-field").removeClass("error");
				}

			}
		},
		fillMobileSearch: function(){

			if( window.device == "mobile" && window.search ){

				setTimeout(function(){
					$("#search-bar").css("left", 0);
					$("#msg-search-txt").val( window.search );
					$("#search-msg-mobile").val( window.search );
				},10);
			}
		},
		searchMessageByEnter: function(e){

			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#msg-search-btn").trigger("click");
 			}

 			if( $("#msg-search-txt").val().trim() == "" ){
				if( Utils.isMobileDevice() )
					$("#minbox").trigger("click");
				else
					$("#inbox").trigger("click");
 			}
		},
		searchMessage: function(e){

			var self = this;

			if( $("#msg-search-txt").val().trim() == "" )
				return false;

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			$("#msg-list-block").attr("data-ctype","SEARCH");

			$("#msg-list-block").find(".fmsg-list").addClass("hide");
			$("#msg-list-block").find(".fmsg-SEARCH-list").html("");
			$(".aitem").removeClass("active");
			var search = "content_search="+$("#msg-search-txt").val();
			var params = {"search":search};
			localStorage.setItem( "msearch" , JSON.stringify( params ) );
			self.bindScroll();
			this.loadMsgs( 1 , params );
		},
        closeMsgSideBar: function(e){
            $('#filter-msg-nav-btn').sideNav("hide");
        },
		hideFilter: function(e){
			$("#filter-mobile").animate({'top': '105%'}, "slow");
		},
		initSetup: function(){

			if( window.msgType ){
				this.type = window.msgType;
				this.cid = window.cid;
				this.model.set("type",this.type);
			}
			this.eMsgList = [];
			this.msgOrder = [];
			EventBus.bind("fmsg:renderSideMenu",this.renderSideMenu);

			this.listenTo(this.model, 'change', function(model) {
        		model.fetch();
    		});
		},
		CloseThread : function(e){
			e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $(e.currentTarget).parents(".collection-item").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been closed.");
			    $this.parents(".collection-item").find("#fsmsg-open").removeClass("hide");
				$this.parents(".collection-item").find("#fsmsg-close").addClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		OpenThread : function(e){
			e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $(e.currentTarget).parents(".collection-item").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been opened.");
			    $this.parents(".collection-item").find("#fsmsg-open").addClass("hide");
				$this.parents(".collection-item").find("#fsmsg-close").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		fetchList: function(e){

			var self = this;
			var type = $(e.currentTarget).attr("data-type");

			$("#msg-list-block").attr("data-ctype",type);

			this.clearSearch();

			self.bindScroll();

			if( $(e.currentTarget).hasClass("mside") ){
				$('#filter-msg-nav-btn').sideNav("hide");
				$(".smsg-header").text( $(e.currentTarget).attr("data-text") );
			}

			if( $("#msg-list-block").find(".fmsg-"+type+"-list").html() != "" ){
				$("#msg-list-block").find(".fmsg-list").addClass("hide");
				$("#msg-list-block").find(".fmsg-"+type+"-list").removeClass("hide");
				$("#msg-list-block").find(".fmsg-"+type+"-list").find(".dost-msg-item").removeClass("hide");
				$(".aitem").removeClass("active");
				$(e.currentTarget).addClass("active");
				self.removeNoMessage();
			}else{

				if( this.isLoading ){
					alert("Previous request is in progress...");
					return false;
				}

				$("#msg-list-block").find(".fmsg-list").addClass("hide");
				$("#msg-list-block").find(".fmsg-"+type+"-list").html("");
				$(".aitem").removeClass("active");
				$(e.currentTarget).addClass("active");
				this.loadMsgs(1);
			}
		},
		openMobileMenu: function(e){

			//$(".filter-container").addClass("wow bounceInUp animated").removeClass("hide");

		},
		openCompose: function(e){

			var self = this;
			this.draftCall = 0;
			this.timeoutId = -1;
			this.threadID = 0;
			$("#compose").remove();

			self.$el.append(this.ComposePageLayout({isMobileDevice:Utils.isMobileDevice() }));
			self.$el.append( this.ConfirmSaveDraftLayout() );
			$(".user-header").addClass("hide");
			$(".friend-header").removeClass("hide");

			$('body').css({'overflow-y' : 'hidden'});

			Utils.openPopup("compose");


				if(Utils.isMobileDevice()){

					$( "#send-to" )
				      // don't navigate away from the field on tab when selecting an item
				      .bind( "keydown", function( event ) {
				        if ( event.keyCode === $.ui.keyCode.TAB &&
				            $( this ).autocomplete( "instance" ).menu.active ) {
				          event.preventDefault();
				        }
			      })
			      .autocomplete({
			        source: function( request, response ) {

			        	$.ajax({
						method: 'GET',
						url: Utils.contextPath()+'/v2/users/list?name=' + Utils.JUIextractLast( request.term ),
						}).done(function (data) {
							var usersArr = new Array() ;

							$.each(data, function (i, val) {
							usersArr.push({
								"key" : val,
								"value" : i
							});
							});
							response( usersArr );
						});

			        },
			        search: function() {
			          // custom minLength
			          var term = Utils.JUIextractLast( this.value );
			          if ( term.length < 2 ) {
			            return false;
			          }
			        },
			        focus: function() {
			          // prevent value inserted on focus
			          return false;
			        },
			        select: function( event, ui ) {
			          self.selectedUsers[ui.item.value] = ui.item.key ;
			          var terms = Utils.JUIsplit( this.value );
			          // remove the current input
			          terms.pop();
			          // add the selected item
			          terms.push( ui.item.value );
			          // add placeholder to get the comma-and-space at the end
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
			        }
			      });



			}else{
					self.$el.find("#send-to").ajaxChosen({
						type: 'GET',
						url: Utils.contextPath()+'/v2/users/list',
						dataType: 'json',
						jsonTermKey:"name",
						minTermLength:1,

					}, function (data) {

						var terms = {};
						$.each(data, function (i, val) {
							terms[val] = i;
						});
						return terms;
					},
					{
		    			// CHOSEN OPTIONS
		    			disable_search_threshold: -1
					});
			}



			if( !Utils.isMobileDevice() )
				CKEDITOR.replace( 'message' );

			setTimeout(function(){$("#send_to_chosen").find(".chosen-choices").trigger("click");},10);
		},
		composeMsg: function(e){

			var isError = false;

			var sendTo = $("#send-to").val();
			var subject = $("#subject").val();
			var self = this ;
			var userArr = sendTo ;
			if(Utils.isMobileDevice()){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}


			if( !Utils.isMobileDevice() ){
				var body = encodeURI(CKEDITOR.instances.message.getData());
			}else{
				var body = encodeURI($("#message").val().trim());
			}
			console.log("compose");

			if( sendTo < 1 ){
				$(".isend-to").show().parent().addClass("error");
				isError = true;
			}

			if( subject == "" ){
				$(".isubject").show().parent().addClass("error");
				isError = true;
			}

			if( body == "" ){
				$(".imessage").show().parent().addClass("error");
				isError = true;
			}

			if( !isError ){

				if(Utils.isMobileDevice()){
					body = body.replace(/%0A/g, '<br />');
				}

				if(self.attachmentIds.length == 0){

					self.attachmentIds = [-1];
				}

				var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"recipients":userArr,
					"status": "SENT",
					//"messageID": self.messageID,
					"attachmentIDs" : self.attachmentIds
				};

				$("#compose-send-btn").addClass("disabled").html("Sending...");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json",
	              statusCode : {
              		417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						$(".iauthentication-error").html(errorMessage);
						$(".iauthentication-error").show() ;

					},
              		500 : function(){
						$(".iauthentication-error").html("Something went wrong. Please try again");
						$(".iauthentication-error").show() ;
					},

	              }
	          	}).done(function(response){
	          		Utils.displaySuccessMsg("Your message has been sent.");
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          		$('#compose').closeModal();
	          		self.hideCompose();
	          	}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
			}else{
				//setTimeout(function(){$(".error-msg").hide();
				//$(".input-field").removeClass("error");},3000);
				return false;
			}
		},
		openMessage: function(e){


			var msgId = $(e.currentTarget).attr("data-msgid");
			window.msgType = $(e.currentTarget).attr("dtype");
			window.imsgType = $("#msg-list-block").attr("data-ctype");
			window.cid = $(e.currentTarget).parents('.collection').attr("cid");

			if( $("#msg-list-block").attr("data-ctype") == "SEARCH" ){
				window.search = $("#msg-search-txt").val();
			}

			//location.href = "/friend/messages/"+Utils.encodeString(msgId);
			if( window.msgType == "CHAT" )
				Backbone.history.navigate("/friend/messages/"+Utils.encodeString(msgId), {trigger: true});

			return this;

			// var msgId = $(e.currentTarget).attr("data-msgid");
			// window.imsgType = $("#msg-block").attr("data-type");
			// window.msgType = $(e.currentTarget).attr("data-type");

			// if( $("#msg-block").attr("data-type") == "search" ){
			// 	window.search = $("#msg-search-txt").val();
			// }
			// location.href = "#user/messages/"+Utils.encodeString(msgId);
			// return this;
		},
		autoSaveMessage: function(msg) {
			console.log( 'Autosave!' );
            if(window.pendingDraftsaveRequest)
                return;
        	$(".email-draft-bar").removeClass( "hide" );
	        $( ".email-draft-saving-msg" ).removeClass( "hide" );
	        $( ".email-draft-saved-msg" ).addClass("hide");


			var subject = $("#subject").val() || null;

			var sendTo = $(".user-friend").hasClass("hide") ? $("#send-to").val() : null;
			// var sendCategory = $("#send-category").val();

			var self = this ;
			// var categoryArr = sendCategory ;
			// if(Utils.isMobileDevice()){
			// 	categoryArr = new Array() ;
			// 	var categorySelected = sendCategory.split(",");
			// 	_.each(categorySelected, function(elem){
			// 		if(!elem.trim()){
			// 			return false ;
			// 		}
			// 		categoryArr.push(self.selectedCategories[elem.trim()]) ;
			// 	});
			// }


			var userArr = sendTo ;
			if(Utils.isMobileDevice() && userArr != null){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){

				if ( CKEDITOR.instances.message == undefined ) {
					var body = encodeURI(CKEDITOR.instances.reply_message.getData()) || null;
					self.threadID = $("#single-msg-block").attr("data-msgid");

				} else {
					var body = encodeURI(CKEDITOR.instances.message.getData()) || null;

				}


			}else{
				var body = encodeURI($("#message").val().trim()) || null;
				if ( $("#single-msg-block").attr("data-msgid") ) {
					self.threadID = $("#single-msg-block").attr("data-msgid");
				}
			}
			console.log( "subject", subject );
			console.log( "userArr", userArr );
			// console.log( "categoryArr", categoryArr );
			console.log( "body", body );

			var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"recipients":userArr,
					"status":"DRAFT"

			};

			msgJSON["threadID"] = self.threadID;
			console.log( "threadID", self.threadID );

			console.log( "msgJSON", msgJSON );
			console.log( "call to AJAX");
            window.pendingDraftsaveRequest = true;
			$.ajax({
        		method: "POST",
        		url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
        		data: JSON.stringify(msgJSON),
       			contentType: "application/json"
      		}).done(function(response){
                window.pendingDraftsaveRequest = false;
      			console.log( response );
      			self.threadID = response.conversationDetail.threadID;
      			var userMessages = response.conversationDetail.userMessage;
      			var lastMsg = userMessages[userMessages.length - 1];
      			self.messageID = lastMsg.msgID;
      			// messageID = 13340;
      			if (msg == "saveDraft") {
      				Utils.displaySuccessMsg("Your draft has been saved");
      			}

	        	$( ".email-draft-saving-msg" ).addClass( "hide" );
	        	$( ".email-draft-saved-msg" ).removeClass("hide");
	        	return true;
			}).error(function(error){
                window.pendingDraftsaveRequest = false;
				console.log(error);
			});
		},
		ConfirmSaveDraftLayout: JST['app/templates/messages/confirmSaveDraft.hbs'],
		render: function() {

			if(!Utils.isLoggedIn()){
				var hash = location.pathname ;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname ;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash ;
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}

			var self = this;
			self.$el.html(this.FriendMessagePageLayout());
			self.renderSideMenu( this.model );
			self.$el.append(this.ComposePageLayout());

			self.type = this.model.get("type");

			self.$el.find("#msg-list-block").attr("data-ctype",self.type);

			if( window.search ){

          		var params = JSON.parse( localStorage.getItem("msearch") );
          		self.loadMsgs(1,params);
          		$("#msg-search-txt").val( window.search );
          	}else{

          		if( self.type == "TAGS" ){
					this.clearSearch();
	          		var params = {"cid":window.cid};
	          		self.loadMsgs(1,params);
	          	}else{
	          		this.clearSearch();
	          		self.loadMsgs(1);
	          	}
          	}


			$(".fmsgtype").removeClass("active");
			$(".fmsgtype").each(function(){
				if( $(this).attr("data-type") == self.type )
					$(this).addClass("active");
			});

			if( self.type == "TAGS" ){

				$(".fmsgtype").removeClass("active");
				$(".msg-tags-list > li").removeClass("active");

				$(".msg-tags-list > li").each(function(){
					if( $(this).attr("data-tagid") == window.cid )
						$(this).addClass("active");
				});
			}

			self.renderElements();
			EventBus.trigger('removeChatScroll');
			setTimeout(function(){$(".smsg-header").text( "Inbox" );},10);
			self.fillMobileSearch();


			CKEDITOR.on('instanceCreated', function(e) {
				var buffer = this.tools.eventsBuffer( 500, function() {

                	//self.autoSaveMessage();

            	});
            	e.removeListener('change', buffer.input);
			    e.editor.on('change', buffer.input);

			    e.editor.on('change', function (event) {
			        // change event in CKEditor 4.x
			        //console.log('hello');
			        var body = $("#message").val().trim();
					if ( $(".imessage").parent().hasClass('error') ) {
						$(".imessage").hide();
						$(".imessageCnt").hide();
						$(".imessage").parent().removeClass('error');

					}
			    });
			});
			return this;
		},
		bindScroll: function(){
			var self = this;
			$(window).scroll(function() {
		        self.checkScroll();
		    });
		},
		loadMsgs: function( pno , params ){

			var self = this;
			var type = $("#msg-list-block").attr("data-ctype");

			$("#msg-list-block").find(".fmsg-"+type+"-list").find(".dost-msg-item").removeClass("hide");

			self.model.addWait();

			if( $("#msg-list-block").find(".fmsg-"+type+"-list").html() != "" ){
				$(".main-loader").addClass("mmain-loader");
			}

			this.isLoading = true;

			//console.log(type, pno, params)
			self.model.setMsgTypeUrl( type , pno , params );

			console.log(self.model.url);
			$.ajax({
              method: "GET",
              url: self.model.url,
              dataType: 'json'
          	}).done(function(response){

          		if( response.length > 0 ){

          			self.removeNoMessage();
          			_.each(response, function(msg){
						self.checkTypeAndCleanupMsgList( msg );
					});

					self.renderMsgs( type );
					$("#msg-list-block").find(".fmsg-"+type+"-list").removeClass("hide");
					self.bindScroll();
          		}else{
          			if( $("#msg-list-block").find(".fmsg-"+type+"-list").html() == "" ){
          				self.renderNoMessage();
          			}
          			self.unbindScroll();
          		}

				Utils.adjustViewPortSize();
				self.model.removeWait();
				self.isLoading = false;
          	}).fail(function(error){
          		self.isLoading = false;
          		Utils.adjustViewPortSize();
          		self.model.removeWait();
				console.log(error);
          	});
		},
		unbindScroll: function(){
			$(window).unbind("scroll");
		},
	    checkScroll: function () {

	        var triggerPoint = 100; // 20px from the bottom
	        var type = $("#msg-list-block").attr("data-ctype");
	        if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {

	          var pno = $("#msg-list-block").find(".fmsg-"+type+"-list").attr("page_number");
	          var cid = $("#msg-list-block").find(".fmsg-"+type+"-list").attr("cid");
	          pno = parseInt(pno) + 1;

	          if( type == "TAGS" ){
	          	var params = {"cid":cid};
	          	this.loadMsgs(pno,params);
	          }else if( type == "SEARCH" ){
	          	var params = JSON.parse(localStorage.getItem("msearch"));
	          	this.loadMsgs(pno,params);
	          }else{
	          	this.loadMsgs(pno);
	          }
	          $("#msg-list-block").find(".fmsg-"+type+"-list").attr("page_number",pno);
	        }
	    },
	    clearSearch: function(){
	    	localStorage.removeItem( "msearch" );
	    	$("#msg-search-txt").val("");
	    	window.search = false;
	    	this.$el.find(".fmsg-SEARCH-list").html("");
	    	this.$el.find(".fmsg-SEARCH-list").attr("page_number",1);
	    },
		renderElements: function(){

			$("html, body").stop().animate({
	      		scrollTop: $("body").offset().top}, 1000,"easeInOutExpo");

			this.$el.find("#single-msg-block").addClass("hide");
			this.$el.find("#msg-list-block").removeClass("hide");
			this.$el.find(".msg-notes").addClass("hide");
			this.$el.find(".msg-compose").removeClass("hide");
		},
		checkTypeAndCleanupMsgList: function( msg ){

			if( msg.type == "MAIL" ){
				this.parseEmailObj( msg.conversationDetail );
			}else if( msg.type == "CHAT" ){
				this.parseChatObj( msg.conversationDetail );
			}else{
				return false;
			}
		},
		parseEmailObj: function( cMsg ){

			if( cMsg.userMessage[0] == undefined )
				return false;

			console.log( "cMsg status " + cMsg.status );
			var threadID = cMsg.threadID;
			var body = cMsg.userMessage[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userMessage[0].receivedDate, 1, false );
			var subject = cMsg.userMessage[0].subject;
			var important = cMsg.important;
			var read = cMsg.userMessage[0].read;
			var following = cMsg.following;
			var status = cMsg.status;
            var joinDate = cMsg.joinDate;


			if( $("#msg-list-block").attr("data-ctype") == "SENT_MAIL" ){
				var sender = [];
				_.each(cMsg.userMessage[0].toRecipients,function(user){
					var name = ( user.firstName != null && user.firstName != "" ) ? user.firstName : user.username;
					sender.push(name);
				});
				sender = sender.join(",");
				read = true;
			}else{
				var sender = ( cMsg.userMessage[0].fromRecipient.firstName != null && cMsg.userMessage[0].fromRecipient.firstName != "" ) ? cMsg.userMessage[0].fromRecipient.firstName : cMsg.userMessage[0].fromRecipient.username;
			}

			if( cMsg.userMessage[0].fromRecipient.picUrl != undefined ){
				var fAvatar = cMsg.userMessage[0].fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userMessage[0].fromRecipient.avatar+'.png';
			}

			var msg = {
				"threadID" : threadID,
				"body" : body,
				"subject" : subject,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "MAIL",
				"important": important,
				"icon" : "mdi-arrow-left-bold-circle-outline received",
				"read" : read,
				"following" : following,
				"status": status,
                "joinDate" : joinDate
			};

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		parseChatObj: function( cMsg ){

			if( cMsg.userChats[0].chatGroupUsers[0] == undefined )
				return false;

			var threadID = cMsg.threadID;
			var body = cMsg.userChats[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userChats[0].sentDate, 1, false);
			var sender = ( cMsg.userChats[0].chatGroupUsers[0].firstName != null && cMsg.userChats[0].chatGroupUsers[0].firstName != "" ) ? cMsg.userChats[0].chatGroupUsers[0].firstName : cMsg.userChats[0].chatGroupUsers[0].username;

			if( cMsg.userChats[0].chatGroupUsers[0].picUrl != undefined ){
				var fAvatar = cMsg.userChats[0].chatGroupUsers[0].picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userChats[0].chatGroupUsers[0].avatar+'.png';
			}

			var msg = {
				"threadID" : threadID,
				"body" : body,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "CHAT"
			};

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		renderMsgs: function( type ) {

			var self = this;

			if( self.msgOrder.length > 0 ){

				_.each(self.msgOrder, function(threadID){

					var msg = self.eMsgList[threadID];

					if( msg.type == "CHAT" ){
						self.renderChatMsg( msg , type );
					}else{
						userid = self.model.get("userID")
						self.renderEmailMsg( msg , type, userid );

					}
				});
				self.eMsgList = [];
				self.msgOrder = [];
			}
		},
		renderEmailMsg: function( cMsg , type , userid){

			var threadUrl =  "/friend/messages/"+Utils.encodeString(cMsg.threadID) + "/inbox";
			var draftIcon = '';
			if ( cMsg.status == 'DRAFT' ) {
				draftIcon = '<i class="mdi mdi-content-save email-draft-thread red-text"></i>';
			}
			var item = '<a class="msg-item-link" href="'+ threadUrl +'"><li class="msg-'+cMsg.threadID+' collection-item avatar cpointer dost-msg-item hoverable '+
							(( cMsg.read == true ) ? 'old' : '' )+'" data-msgid="'+cMsg.threadID+'" data-type="'+type+
							'" dtype="MAIL" data-important="'+cMsg.important+'">'
				  			+'<div class="msg-img-holder">'
								+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
								//+'<i class="mdi mdi-email-outline msg-icon"></i>'
							+'</div>'
							+'<i data-msgid="'+cMsg.threadID+'" class="mdi msg-severity mdi-arrow-up-bold-circle-outline animated wave-effect waves-light font-18 '+ (( cMsg.important == true ) ? 'high' : '' )+'" '+(( cMsg.important == false ) ? 'title="Mark Important"' : '' )+'></i>'
							+'<i class="mdi mdi-email-open" title="Close thread" id="fsmsg-close" style="color:teal;" ></i><i class="mdi mdi-check" title="Open thread" id="fsmsg-open"></i>'
							+'<i class="mdi mdi-thumb-up" title="Follow" id="msg-follow" style="color:teal;"></i><i class="mdi mdi-thumb-down" title="Unfollow" id="msg-unfollow" style="color:teal;"></i>'
                            + (( cMsg.joinDate ) ? '<i class="mdi mdi-account-multiple-plus" title="Joined Message" id="msg-joined" style="color:teal;"></i>' : '')
							+'<span class="title msg-title '+ (( cMsg.read == true ) ? 'read' : 'notRead') +' truncate">'
							+cMsg.subject+ ( (cMsg.count > 1) ? ' <span class="msg-count">('+cMsg.count+')</span>' : '' ) +'</span>'
							+'<p class="msg-senders">'+cMsg.sender+'</p>'
							+'<div class="truncate msg-content '+(( cMsg.read == false ) ? 'mlist-new' : '' )+'">'+cMsg.body+'</div>'
							+'<div class="secondary-content msg-time">'
							+draftIcon
							+cMsg.receivedTime+'</div>'
							+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
						+'</li></a>';

			this.$el.find("#msg-list-block").find(".fmsg-"+type+"-list").removeClass("hide").append( item );
			var msgID = cMsg.threadID;
			var userID = userid;
			console.log("Inside");

			if(cMsg.following === true){
				$('.msg-'+msgID).find("#msg-follow").addClass("hide");
				$('.msg-'+msgID).find("#msg-unfollow").removeClass("hide");
			}else{
				$('.msg-'+msgID).find("#msg-follow").removeClass("hide");
				$('.msg-'+msgID).find("#msg-unfollow").addClass("hide");
			}

			$.ajax({
				method: 'GET',
				url: Utils.contextPath()+"/v1/users/"+userID+"/messages/"+msgID+"/closedstatus",
			}).done(function (data) {

			   if(data["status"]==true){
				    $('.msg-'+msgID).find("#fsmsg-open").removeClass("hide");
					$('.msg-'+msgID).find("#fsmsg-close").addClass("hide");
				}else{
					$('.msg-'+msgID).find("#fsmsg-open").addClass("hide");
					$('.msg-'+msgID).find("#fsmsg-close").removeClass("hide");
				}
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		renderChatMsg: function( cMsg , type ){

			var item = '<li class="collection-item avatar cpointer dost-msg-item hoverable old chat" data-msgid="'+cMsg.threadID+'" data-type="'+type+'" dtype="CHAT">'
				  			+'<div class="msg-img-holder">'
								+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
							+'</div>'
							+'<p class="msg-senders"><i class="mdi mdi-comment-multiple-outline"></i> Chat with: '+cMsg.sender+'</p>'
							+'<p class="truncate msg-content">'+cMsg.body+'</p>'
							+'<a class="secondary-content msg-time">'+cMsg.receivedTime+'</a>'
							+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
						+'</li>';

			this.$el.find("#msg-list-block").find(".fmsg-"+type+"-list").removeClass("hide").append( item );
		},
		renderSideMenu: function( model ){

			var sideMenuTemplate = JST['app/templates/messages/fmsg_sidemenu.hbs'];
			var specialFriend = false;
			if( model.get("userID") == 101 ){
				specialFriend = true;
			}

			$("#msg-block").find(".msg-side-menu").html( sideMenuTemplate({specialFriend : specialFriend }) );

			model.setUnreadCount();

			$("#msg-block").find(".msg-tags-list").html("");
			$("#msg-list-mobile").find(".msg-tags-list").html("");

			var categories = localStorage.getItem("categories");

	        if( !categories ){

            	var category = {};
            	var categories = {};
            	$.ajax({
                	method: "GET",
                	url: Utils.contextPath()+'/category?include_faq=false'
            	}).done(function(response){
              		_.each(response,function(cat){
                		category[cat.id] = cat.name;
                		categories["c_" + cat.id] = cat.name;
                		var list = "<li class='collection-item aitem ftag' data-tagid='"+cat.id+"'>"+cat.name+"</li>";
	              		$("#msg-block").find(".msg-tags-list").append( list );
              		});
              		localStorage.setItem("categories",JSON.stringify(category));
              		localStorage.setItem("c_categories",JSON.stringify(categories));
              		setTimeout(function(){$("#msg-list-mobile").find(".msg-tags-list").html( $("#msg-block").find(".msg-tags-list").html() );},10);
            	}).fail(function(error){});
          	}else{

          		$.each(JSON.parse(categories),function(key,value){
	              	var list = "<li class='collection-item aitem ftag' data-tagid='"+key+"'>"+value+"</li>";
	              	$("#msg-block").find(".msg-tags-list").append( list );
	            });
	            setTimeout(function(){$("#msg-list-mobile").find(".msg-tags-list").html( $("#msg-block").find(".msg-tags-list").html() );},10);

          	}
		},
		markImportant: function(e){

			e.preventDefault();
			e.stopPropagation();

			var $this = $(e.currentTarget);
			var msgID = $(e.currentTarget).attr("data-msgid");

			if( $this.hasClass("high") ){
				$this.addClass("rotateOut");
				$this.attr("title","Mark Important");
			}
			else{
				$this.addClass("rotateIn");
				$this.attr("title","");
			}
			setTimeout(function(){$this.toggleClass("high");$this.removeClass("rotateIn rotateOut");},800);

			$.ajax({
              method: "POST",
              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/mark/important'
          	}).done(function(response){}).fail(function(error){
          		console.log(error);
          	});
			e.stopPropagation();
		},
		updateUnreadCount: function(){
			setTimeout(function(){
				$(".iheader-msg-badge").addClass("hide").text( sessionStorage.getItem("unread") );
				$(".mobile-msg-badge").text( sessionStorage.getItem("unread") );
			},5);
		},
		renderNoMessage: function(){
			this.$el.find("#msg-list-block").addClass("hide");
			this.$el.find("#no-msg-list-block").removeClass("hide");
		},
		removeNoMessage: function(){
			this.$el.find("#msg-list-block").removeClass("hide");
			this.$el.find("#no-msg-list-block").addClass("hide");
		},
	    autoRefresh: function( obj ){

	    	obj.interval = setInterval(function(){

	    	},60000);
	    },
	    followThread : function(e){
			e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $(e.currentTarget).parents(".collection-item").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("This thread has been followed.");
			    $this.parents(".collection-item").find("#msg-follow").addClass("hide");
				$this.parents(".collection-item").find("#msg-unfollow").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
		unfollowThread : function(e){
			e.preventDefault();
			e.stopPropagation();
			var $this =  $(e.currentTarget);
			var msgID = $(e.currentTarget).parents(".collection-item").attr("data-msgid");
			console.log("Inside");
			$.ajax({
				method: 'POST',
				url: Utils.contextPath()+"/v1/users/"+this.model.get("userID")+"/messages/"+msgID+"/followingstatus",
			}).done(function (data) {

			    Utils.displaySuccessMsg("Not following this thread.");
			    $this.parents(".collection-item").find("#msg-unfollow").addClass("hide");
				$this.parents(".collection-item").find("#msg-follow").removeClass("hide");
				console.log(data)
			}).fail(function(error){
          		console.log(error);
          	});
		},
	});

	FriendMessagePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	FriendMessagePage.prototype.clean = function() {
    	this.remove();
	};

	return FriendMessagePage;
});
