define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'view/messages/user_profile',
	'event/dispatcher',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, Utils, UserProfile, EventBus) {

	var UserProfileCollection = Backbone.View.extend({
		template: JST['app/templates/messages/user_profile_collection.hbs'],
		el: 'main',
		initialize: function() {
			this.userProfile = new UserProfile();
			this.listenTo(EventBus, 'userProfileCollection', this.renderHTML);
		},
		events: {
			"click .close-profile-popup" : "close"
		},
		close: function () {
			Utils.closePopup('user-profile-collection');
			if (window.location.href.indexOf("user/messages") > -1) {
				//disable scrolling
				$('body').css("overflow","hidden");	
			}
		},
		renderHTML: function () {
			var self = this;
			self.$el.append(self.template());
			self.setElement($("main")).render();
		},
		render: function() {
			this.userProfile.$el = this.$('#user-profile');
			this.userProfile.render();
			this.userProfile.delegateEvents();
			Utils.openPopup('user-profile-collection');
		}
	});

	UserProfileCollection.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	UserProfileCollection.prototype.clean = function() {
		this.remove();
	};

	return UserProfileCollection;
});
