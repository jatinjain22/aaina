define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel) {

	var UserProfile = Backbone.View.extend({
		template: JST['app/templates/messages/user_profile.hbs'],
		initialize: function() {
			var self = this;
			this.userModel = new UserModel();
			this.questions = {
				age: "Would you like to give us your age ?",
				gender: "Would you like to give us your gender ?",
				occupation: "Would you like to give us your occupation ?",
				location: "Would you like to give us your location ?",
				complete: "Thank you for your information"
			};
			this.occupations = ["Student", "Self-employed", "Salaried/Employee/Service","Homemaker","Not employed","Retired"];
		},
		events: {
			"click .submit" : "submitProfileData",
			"click .skip" : "showQuestion",
			"click .view-profile" : "trackViewProfile",
			"click .answer" : "hideInfo"
		},
		hideInfo: function () {
			$("#info").html("");
		},
		trackViewProfile: function () {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("User Profile Data - end", { "itemName" :  "View Profile button", "source": "Post Message Submit"});
		},
		submitProfileData: function (evt) {
			var property = evt.currentTarget.getAttribute("data-property");
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("User Profile Data - submitted", { "itemName" : property , "source": "Post Message Submit"});
			var self = this;
			var answer;
			if (property == 'gender') {
				answer = $(".gender-ques input[type='radio']:checked").val();	
			} else { 
				if (property == 'age') {
					answer = parseInt($(".user-profile .answer").html());
					if (isNaN(answer)) {
						$("#info").html("Invalid Age");
						$(".user-profile .answer").html("");
						return;	
					}
					if (!(answer > 17 && answer < 100)) {
						$("#info").html("Invalid Age");
						$(".user-profile .answer").html("");
						return;	
					}
				} else {
					answer = $("#dropdown").find(":selected").text();
				}
			}
			this.response.customProperties[property] = [answer];
			$.ajax({
				method : 'POST',
				url : Utils.contextPath() + '/v2/users/' + this.userModel.getUserID() + '/modify/profile',
				data : JSON.stringify(this.response),
				dataType: "JSON",
				contentType: "application/json; charset=utf-8"
			})
			.done(function (response) {
				self.percentage += 20;
				self.showQuestion();
			})
		},
		showQuestion: function (evt) {
			if (evt && evt.currentTarget.className == "skip"){
				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("User Profile Data - skipped", { "itemName" : evt.currentTarget.getAttribute("data-property") , "source": "Post Message Submit"})	
			}
			var options = {};
			var property = this.properties.pop();
			if (property) {
				if (property == 'gender') options.gender = true;
				if (property == 'age') options.age = true;
				if (property == 'complete') {
					if(this.percentage == 100) {
						options.complete = true;
						options.percentage = this.percentage;
						options.ques = this.questions[property];
						options.property = property;
						this.$el.html(this.template(options));
						return;
					} else {
						this.$el.html("<strong>Thank you !</strong>");
						return;
					}	
				}
				if (property == 'occupation') options.occupations = this.occupations;
				if (property == 'location') options.cities = this.cities;
				options.percentage = this.percentage;
				options.ques = this.questions[property];
				options.property = property;
				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("User Profile Data - requested", { "itemName" : property , "source": "Post Message Submit"});
				this.$el.html(this.template(options));
			} else {
				if (this.percentage !== 100) {
					this.$el.html("<strong>Thank you !</strong>");	
				}
			}
		},
		render: function() {
			this.percentage = 20;
			var self = this;
			Utils.getCities()
			.then(function (res) {
				self.cities = res;
			});
			$.ajax({
				method : 'GET',
				url : Utils.contextPath() + '/v2/users/' + this.userModel.getUserID() + '/profile'
			})
			.done(function (response) {
				self.response = response;
				self.properties = [];
				var keys = ["age", "gender", "occupation", "location"];
				for (var i=3; i>=0; i--) {
					if (!response.customProperties[keys[i]] || response.customProperties[keys[i]].length == 0 || response.customProperties[keys[i]] == "null") {
						self.properties.push(keys[i]);
					} else {
						self.percentage += 20;
					}
				}
				self.properties.splice(0,0,"complete");
				if (self.percentage !== 100) {
					self.showQuestion();	
				} else {
					self.$el.html("<strong>Thank you !</strong>");	
				}
			})
			.fail(function (error) {
			});
		}
	});

	UserProfile.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	UserProfile.prototype.clean = function() {
		this.remove();
	};

	return UserProfile;
});
