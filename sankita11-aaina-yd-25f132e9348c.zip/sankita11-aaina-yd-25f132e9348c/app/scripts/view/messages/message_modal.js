define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, Utils, EventBus, UserModel) {

	var MessageModal = Backbone.View.extend({
		el: "main",
		template: JST['app/templates/messages/compose_message.hbs'],
		initialize: function() {
			this.autoSaveInterval = 15000; //in milliseconds
			_.bindAll(this)   ;
			this.listenTo(EventBus, 'openComposeMessage', this.renderHTML);
			this.userModel = new UserModel();
	
		},
		counselorListLayout: JST['app/templates/messages/counselor_list.hbs'],
		categoryListLayout: JST['app/templates/messages/category_list.hbs'],
		mobileComposeHeaderLayout: JST['app/templates/messages/mobile_compose_header.hbs'],
		events: {
			"click .close-compose" : "close",
			"click .recipient" : "showCounselorList",
			"click .msg-category" : "showCategories",
			"click .counselor" : "selectCounselor",
			"click .msg-category-item" : "selectCategory",
			"click .send" : "sendMessage",
			"click .mobile-send" : "sendMessage",
			"click .subject" : "hideValidationMessages",
			"click .action-delete" : "clearFields",
			"click .message-section" : "closeDropdown",
			//"click .message-content-container" : "startAutoSave",
			"keyup .recipient" : "filterCounselors",
			"keyup .msg-category" : "filterCategories",
			"change #message-attachment" : "uploadFile",
			"click .attached-file .mdi-close" : "removeFile"
		},
		sendMessageParams: {
			categoryIds : [],
			content : "",
			recipients : [],
			subject : "",
			threadID : "",
			attachmentIDs: []
		},
		closeDropdown: function () {
			this.hideCounselorList();
			this.hideCategories();
		},
		startAutoSave: function () {
			this.hideValidationMessages();
			if (!this.autoSavePromise) {
				this.autoSavePromise = setInterval(function () {
					this.sendMessage({isDraft: true});  //flat is true to handle auto save
				}.bind(this), this.autoSaveInterval);
			}
		},
		hideValidationMessages: function () {
			$(".validation").hide();
		},
		populateAssociatedCategories: function (id) {
			if (id == "101") {
				this.categoryList = this.counselorList[1].categories;
				return;	
			}
			var self = this;
			self.counselorList.every(function (details, index) {
				if (details.id == id) {
					self.categoryList = details.categories;
					return false;
				} else {
					return true;
				}
			});
		},
		fillCategory: function (options) {
			if (options.length) {
				this.sendMessageParams.categoryIds = [];
				this.sendMessageParams.categoryIds.push(options[0].id);
			}
			if (options.length) {
				var id = options[0].id;
				this.categoryList.every(function (value, index) {
					if (value.id == id) {
						$(".msg-category").val(value.name);
						return false;
					} else {
						return true;
					}
				});
			}
		},
		fillRecipient: function (options) {
			this.populateAssociatedCategories(options);
			this.sendMessageParams.recipients = [];
			this.sendMessageParams.recipients.push(options);
			this.counselorList.every(function (details, index) {
				if (details.id == options) {
					$(".recipient").val(details.name);
					return false;
				} else {
					return true;
				}
			});
		},
		fillBody: function (details) {
			this.sendMessageParams.content = details;
			$(".message-section .message-content-container").html(details);
		},
		fillSubject: function (details) {
			this.sendMessageParams.subject = details;
			$(".message-section .subject").val(details);
		},
		populateMessageDetails: function (details) {
			/*
				recipient needs to be filled before categories,
				so that associated categories can be loaded
			*/
			//if (details.attachments) this.populateAttachments(details.attachments);
			if (details.recipientId) this.fillRecipient(details.recipientId);
			if (details.categories) this.fillCategory(details.categories);
			if (details.body) this.fillBody(details.body);
			if (details.subject) this.fillSubject(details.subject);
			if (details.threadID) this.sendMessageParams.threadID = details.threadID;
			//if (details.messageID) this.sendMessageParams.messageID = details.messageID;
			if (details.status) this.sendMessageParams.status = details.status;
		},
		filterCounselors: function (evt) {
			var inputValue = evt.currentTarget.value;
			var filteredList = this.counselorList.filter(function (details) {
				return details.name.toUpperCase().includes(inputValue.toUpperCase())
			});
			$(".counselor-list").html(this.counselorListLayout({
				counselorList: filteredList
			}));
		},
		showCounselorList: function (evt) {
			if (evt.target.className.indexOf("recipient") != -1) {
				this.hideCategories();
				this.hideValidationMessages();
				$(".counselor-list").show();
				evt.stopPropagation();	
			}
		},
		hideCounselorList: function () {
			$(".counselor-list").hide();
		},
		selectCounselor: function (evt) {
			var counselorId = evt.currentTarget.getAttribute("data-id");
			this.sendMessageParams['recipients'] = [];
			this.sendMessageParams['recipients'].push(counselorId);
			this.hideCounselorList();
			$(".recipient").val(evt.currentTarget.getAttribute("data-name"));
			this.populateAssociatedCategories(counselorId);
		},
		filterCategories: function (evt) {
			var inputValue = evt.currentTarget.value;
			var filteredList = this.categoryList.filter(function (details) {
				return details.name.toUpperCase().includes(inputValue.toUpperCase())
			});
			$(".category-list").html(this.categoryListLayout({
				categoryList: filteredList
			}));	
		},
		showCategories: function (evt) {
			this.hideCounselorList();
			this.hideValidationMessages();
			$(".category-list").html(this.categoryListLayout({
				categoryList: this.categoryList
			}));	
			$(".category-list").show();
			evt.stopPropagation();
		},
		hideCategories: function () {
			$(".category-list").hide();
		},
		selectCategory: function (evt) {
			var categoryId = evt.currentTarget.getAttribute("data-id");
			this.sendMessageParams['categoryIds'] = [];
			this.sendMessageParams['categoryIds'].push(categoryId);
			this.hideCategories();
			$(".msg-category").val(evt.currentTarget.getAttribute("data-name"));
		},
		formValid: function (options) {
			if (options.isDraft || this.isMobile) return true;
			var valid = true;
			if (!$(".message-section .recipient").val() || this.sendMessageParams['recipients'].length == 0) {
				$(".message-section .recipient-msg").show();
				valid = false;
			}
			if (!$(".message-section .subject").val()) {
				$(".message-section .subject-msg").show();
				valid = false;
			}
			if (!$(".message-section .msg-category").val() || this.sendMessageParams['categoryIds'].length == 0) {
				$(".message-section .category-msg").show();
				valid = false;
			}
			if (!$(".message-section .message-content-container").html() || $(".message-section .message-content-container").html().trim().length < 100) {
				$(".message-section .text-msg").show();
				valid = false;
			}
			return valid;
		},
		sendMessage: function (options) {
			var self = this;
			if (!this.formValid(options)) return;
			options.isDraft = false;
			self.sendMessageParams.status = options.isDraft ? 'DRAFT' : 'SENT';
			self.sendMessageParams.subject = $(".message-section .subject").val();
			self.sendMessageParams.content = $(".message-section .message-content-container").html();
			self.sendMessageParams.threadID = (!options.isDraft && self.sendMessageParams.threadID) || 0;
			//self.sendMessageParams.messageID = (!options.isDraft && self.sendMessageParams.messageID) || 0;
			if (self.fileUploading) return;
			if (options.isDraft) {
				$("#compose-modal .status-msg").html("Saving Draft ... ");
			} else {
				$("#compose-modal .status-msg").html("Sending Message ... ");
			}
			if (self.sendMessageParams.recipients.indexOf("101") == 0) delete self.sendMessageParams.recipients;
			$.ajax({
				method : 'POST',
				url : this.url,
				data : JSON.stringify(this.sendMessageParams),
				dataType: "JSON",
				contentType: "application/json; charset=utf-8",
			})
			.done(function (response) {
				$("#compose-modal .status-msg").html("");
				if (options.isDraft) {
					self.sendMessageParams.threadID = response.conversationDetail.threadID;
					//self.sendMessageParams.messageID = response.conversationDetail.userMessage[0].msgID;
				} else {
					self.close({messageSent: true});
				}
			})
			.fail(function (error) {
				if (error.responseJSON.type == "MAX_LIMIT_EXCEEDED") {
					$("#compose-modal .status-msg").html(error.responseJSON.message);
					return;	
				}
			});
		},
		close: function (options) {
			this.clearFields();
			Utils.closePopup('compose-modal');
			if (options.messageSent) EventBus.trigger('userProfileCollection');
			if (window.location.href.indexOf("user/messages") > -1) {
				//disable scrolling
				$('body').css("overflow","hidden");	
			} else {
				window.location.reload();	
			}
			//clearInterval(this.autoSavePromise); //stop auto save
		},
		clearFields: function () {
			$(".recipient").val("");
			$(".message-section .subject").val("");
			$(".message-section .msg-category").val("");
			$(".message-section .message-content-container").html("");
			$(".attached-files-container").html("");
			$(".status-msg").html("");
			this.hideValidationMessages();
			this.hideCategories();
			this.hideCounselorList();
		},
		removeFile: function (evt) {
			var attachmentId = evt.currentTarget.getAttribute("data-id");
			this.sendMessageParams.attachmentIDs = [];
			$("[data-id=" + attachmentId + "]").parent().hide();
			$(".action-attachment").show();
		},
		uploadFile: function (e) {
			var file = e.target.files[0];
			var maxFileSize = 5 * 1024 * 1024; //5 MB
			if (file.size > maxFileSize) {
				$(".status-msg").html("Max allowed limit is 5 MB");
				return;	
			}
			
			var data = new FormData();
			var self =  this;
			self.fileUploading = true;
			$(".status-msg").html("Uploading ...");

			data.append('file', $('#message-attachment').get(0).files[0]);
			$.ajax({
				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){
				self.fileUploading = false;
				$(".status-msg").html("");
				$(".attached-files-container").append("<span class='attached-file'>" + file.name + "<i class='mdi mdi-close' data-id=" + response.fileID + "></i></span>");
				self.sendMessageParams.attachmentIDs = [];
				self.sendMessageParams.attachmentIDs.push(response.fileID);
				$(".action-attachment").hide();
			}).error(function(error){
				$(".status-msg").html("Error");
			})
		},

		renderHTML : function(options){
			var self = this;
			self.$el.append(self.template(options.info));
			Utils.fetchCounselorList(self.userModel.getUserID())
			.then(function (response) {
				self.counselorList = response;
				// self.$el.find('.counselor-list').append(self.counselorListLayout({
				// 	counselorList: self.counselorList
				// }));
				self.setElement($("main")).render(options);	
			});
		},

		render: function(options) {
			this.url = Utils.contextPath() + "/v1/users/" + this.userModel.getUserID() + "/messages";
			if (Utils.isMobileDevice()) {
				$("#compose-modal .header").html(this.mobileComposeHeaderLayout());
			}
			Utils.openPopup('compose-modal');
			this.hideCounselorList();
			if (options.info) this.populateMessageDetails(options.info);
				
			if (options && options.info && options.info.mobile) {
				this.$el.find('.close-compose').html('<i class="icon dripicons-arrow-thin-left" style="font-size:1.25em;position:relative;top:0.2em"></i>');
				this.$el.find('#compose-msg-title').html("Reply");
				this.isMobile = true;
			} else {
				this.$el.find('#compose-msg-title').html("New Message");
				this.isMobile = false;
			}
			$(".action-attachment").show();
		}
	});

	MessageModal.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	MessageModal.prototype.clean = function() {
		this.remove();
	};

	return MessageModal;
});
