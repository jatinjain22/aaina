define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel',
	'ajax-chosen',
	'smooth-scroll'
], function($,_, Backbone, JST, Utils, EventBus, UserMsgModel) {

	var SingleMessagePage = Backbone.View.extend({
		el: "main",
		initialize: function(options) {

			this.model = new UserMsgModel;
			this.model.set("threadId",Utils.decodeString(this.id));
			this.selectedUsers = {} ;
			this.attachmentIds = [];
			this.showReply = false;

			if( options.type ){
				if( options.type.toLowerCase() == "inbox" ){
					window.msgType = "MAIL";
					window.imsgType = "msg";
				}else{
					window.msgType = false;
					window.imsgType = false;
				}
			}

			if( !window.msgType ){
				//location.href = "/user/messages";
				Backbone.history.navigate("/user/messages", {trigger: true});
				return this;
			}
			this.initSetup();
			this.timeoutId = -1;
			this.threadID = 0;
			this.messageID = 0;
		},
		MessagePageLayout : JST['app/templates/messages/user_layout.hbs'],
		ComposePageLayout : JST['app/templates/messages/compose.hbs'],
		SingleMsgLayout : JST['app/templates/messages/single_umsg_layout.hbs'],
		RatingMsgLayout : JST['app/templates/messages/rating_star.hbs'],
		events: {
			"click #open-ireply": "openPostReply",
			"click #open-reply": "singleMsgReply",
			"click #post-reply": "postReply",
			"click #delete-reply": "deleteReply",
			"click #delete-smsg": "deleteMsg",
			"click .msg-back": "backToList",
			"click .msg-back-inbox": "backToInbox",
            "click #msg-search-btn": "searchMessage",
            "keypress #msg-search-txt": "searchMessageByEnter",
            "click .dost-msg-item": "removeCollapsed",
            'click .smoothscroll': 'smoothScroll',
            'click .msg-single-reply' : 'singleMsgReply',
            'click .counselor-feedback' : 'counselorFeedback',
            'click .counselor-message-rating span' : 'giveCounselorMessageRating',
            "change #ureply-file-attachment" : "uploadFileInUserReply",
            "click .ureply-remove-attached-file" : "uploadNewFileInUser",
            "click .user-download-attachment" : "downloadAttachment",
            "keyup #reply_message": "isMessage"
		},
		autoSaveMessage: function(msg) {
            if(window.pendingDraftsaveRequest)
                return;
			console.log( 'Autosave!' );
        	$(".email-draft-bar").removeClass( "hide" );
	        $( ".email-draft-saving-msg" ).removeClass( "hide" );
	        $( ".email-draft-saved-msg" ).addClass("hide");

			var subject = $("#subject").val() || null;

			var sendTo = $(".user-friend").hasClass("hide") ? $("#send-to").val() : null;
			var sendCategory = $("#send-category").val();

			var self = this ;
			var categoryArr = sendCategory ;



			var userArr = sendTo ;
			if(Utils.isMobileDevice() && userArr != null){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){

				if ( CKEDITOR.instances.message == undefined ) {
					var body = encodeURI(CKEDITOR.instances.reply_message.getData()) || null;
					self.threadID = $("#single-msg-block").attr("data-msgid");

				} else {
					var body = encodeURI(CKEDITOR.instances.message.getData()) || null;

				}


			}else{
				var body = encodeURI($("#reply_message").val().trim()) || null;
				if ( $("#single-msg-block").attr("data-msgid") ) {
					self.threadID = $("#single-msg-block").attr("data-msgid");
				}
			}
			console.log( "subject", subject );
			console.log( "userArr", userArr );
			console.log( "categoryArr", categoryArr );
			console.log( "body", body );

			var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"categoryIds":categoryArr,
					"recipients":userArr,
					"status":"DRAFT"

			};

			console.log( "threadID", self.threadID );


			console.log( "msgJSON", msgJSON );
            window.pendingDraftsaveRequest = true;
			$.ajax({
        		method: "POST",
        		url: Utils.contextPath()+'/v1/users/'+ this.model.get("userID")+'/messages',
        		data: JSON.stringify(msgJSON),
       			contentType: "application/json"
      		}).done(function(response){
                window.pendingDraftsaveRequest = false;
      			console.log( response );
      			self.threadID = response.conversationDetail.threadID;
      			var userMessages = response.conversationDetail.userMessage;
      			var lastMsg = userMessages[userMessages.length - 1];
      			self.messageID = lastMsg.msgID;
      			// messageID = 13340;
      			if (msg == "saveDraft") {
      				Utils.displaySuccessMsg("Your draft has been saved");
      			}
	        	$( ".email-draft-saving-msg" ).addClass( "hide" );
	        	$( ".email-draft-saved-msg" ).removeClass("hide");
	        	return true;
			}).error(function(error){
                window.pendingDraftsaveRequest = false;
				console.log(error);
			});
		},
		isMessage: function(e) {

			//console.log("hello");
			//console.log(e.currentTarget);
			var self = this;

			clearTimeout(self.timeoutId);
    		self.timeoutId = setTimeout(function() {
        		// Runs 1 second (1000 ms) after the last change
        		//self.autoSaveMessage();

    		}, 500);


			console.log("one who knocks");

			if ( $(".imessage").parent().hasClass('error') ) {


				$(".imessage").hide();
				$(".imessageCnt").hide();
				$(".imessage").parent().removeClass('error');


			}

		},

		uploadNewFileInUser : function(e){

			$(".file-name-attached-ureply").addClass("hide");
			$(".file-attachment-ureply-send").removeClass("hide");
			this.attachmentIds = [];
		},

		uploadFileInUserReply : function(e){

			var file = e.target.files[0];
			var data = new FormData();
			$(".ureply-upload-error").addClass("hide")
			if(file.type == "application/x-ms-dos-executable"){

				$(".ureply-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			var self =  this;

			$(".file-name-attached-ureply").removeClass("hide");
			$(".file-attachment-ureply-send").addClass("hide");
			$(".ureply-file-name-attached").html("Uploading ...");

			data.append('file', $('#ureply-file-attachment').get(0).files[0] );
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){

				console.log("Response: "+response)
				$(".ureply-file-name-attached").html(file.name);
				self.attachmentIds.push(response.fileID);

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	        	    mixpanel.track('File Attached', {'mediumSource' : 'website', 'itemName': 'File Attached in Post Reply User'});

	        	}

			}).error(function(error){

				$(".file-name-attached-ureply").addClass("hide");
				$(".file-attachment-ureply-send").removeClass("hide");
				$(".ureply-upload-error").removeClass("hide").html("Upload Error");
				console.log("Error: "+error);
			})
		},
		downloadAttachment : function(e){

			e.stopPropagation();
			e.preventDefault();
			var fileID = $(e.currentTarget).attr("data-fileid");
			// $(e.currentTarget).parents(".msg-content").find(".download-error").addClass("hide");
			// $(e.currentTarget).parents(".msg-content").find(".downloading-text").removeClass("hide");
			// $(e.currentTarget).addClass("hide");

			location.href = Utils.contextPath()+'/file/download/'+fileID;
			//window.open(Utils.contextPath()+'/file/download/'+fileID, '_self')
			// $.ajax({

			// 	method: "GET",
			// 	url : Utils.contextPath()+'/file/download/'+fileID,
			// }).done(function(response){

			// 	console.log("Response: "+response);
			// 	$(e.currentTarget).parents(".msg-content").find(".downloading-text").addClass("hide");
			// 	$(e.currentTarget).removeClass("hide");
			// }).error(function(error){

			// 	console.log("Error: "+error)
			// 	$(e.currentTarget).parents(".msg-content").find(".download-error").removeClass("hide");
			// 	$(e.currentTarget).parents(".msg-content").find(".downloading-text").addClass("hide");
			// 	$(e.currentTarget).removeClass("hide");
			// 	setTimeout(function(){

			// 		$(e.currentTarget).parents(".msg-content").find(".download-error").addClass("hide");
			// 	}, 3000)
			// })
		},
		populateSender : function(){

			var self = this ;
			var searchType = '/v1/counselor/search' ;

			if(Utils.isMobileDevice()){

				$( "#msg-send-to" )
			      // don't navigate away from the field on tab when selecting an item
			      .bind( "keydown", function( event ) {
			        if ( event.keyCode === $.ui.keyCode.TAB &&
			            $( this ).autocomplete( "instance" ).menu.active ) {
			          event.preventDefault();
			        }
		      })
		      .autocomplete({
		        source: function( request, response ) {

		        	$.ajax({
					method: 'GET',
					url: Utils.contextPath()+ searchType + '?name=' + Utils.JUIextractLast( request.term ),
					}).done(function (data) {
						var usersArr = new Array() ;

						$.each(data, function (i, val) {
						usersArr.push({
							"key" : val,
							"value" : i
						});
						});
						response( usersArr );
					});


		        },
		        search: function() {
		          // custom minLength
		          var term = Utils.JUIextractLast( this.value );
		          if ( term.length < 2 ) {
		            return false;
		          }
		        },
		        focus: function() {
		          // prevent value inserted on focus
		          return false;
		        },
		        select: function( event, ui ) {

		          self.selectedUsers[ui.item.value] = ui.item.key ;
		          var terms = Utils.JUIsplit( this.value );
		          // remove the current input
		          terms.pop();
		          // add the selected item
		          terms.push( ui.item.value );
		          // add placeholder to get the comma-and-space at the end
		          terms.push( "" );
		          this.value = terms.join( ", " );
		          return false;
		        }
		      });
			}else{
				self.$el.find("#msg-send-to").ajaxChosen({
					type: 'GET',
					url: Utils.contextPath()+ searchType,
					dataType: 'json',
					jsonTermKey:"name",
					minTermLength:1
				}, function (data) {

					var terms = {};
					$.each(data, function (i, val) {
						terms[val] = i;
					});
					return terms;
				});
			}

		},

		singleMsgReply : function(e){

			var self = this ;

			var targetID = $(e.currentTarget).attr("id") ;

			var cId = $($(".msg-toid")[0]).attr("data-toids")

			/*var checkIfCounselorIsBlocked = checkIfCounselorIsBlocked || Utils.checkIfCounselorIsBlocked(cId);


			checkIfCounselorIsBlocked.then(function(blocked){

				if(blocked){

					$("#open-reply").find(".flow-text").addClass("error").html("This expert is not available for further conversations")
				}else{*/

					if( $("#open-ireply").attr("clicked") == "true" )
						return true;

					$(".open-ireply").attr("clicked",true);
					$("#open-reply").before( $(".reply-block").html() ).addClass("hide");

					if( !Utils.isMobileDevice() )
						Utils.addRTD('reply_message');
					else
						$("#reply_message").focus();

					Utils.scrollTo("#reply-form",-50);

					$("#open-reply").find(".flow-text").removeClass("error").html("Post Reply")

					self.populateSender();

					var msgID    = targetID.split(/-/)[1] ;
					if(targetID == "open-reply"){
						var allMsgs = $(".dost-msg-item")           ;
						var lastMsg = allMsgs[ allMsgs.length - 1 ] ;

						var msgID = $(lastMsg).attr("id") ;
						msgID     = msgID.split(/-/)[1]   ;
					}

					var msgSentByID   = $("#msg-" + msgID).find(".msg-sent-by").attr("data-fromid") ;
					var msgSentByName = $("#msg-" + msgID).find(".msg-sent-by").html()              ;


					var userID = self.model.get("userID") ;

					var replyFrom = [] ;
					if(msgSentByID == userID){
						var msgSentTo = $("#msg-" + msgID).find(".msg-toids span");
						$.each(msgSentTo, function(index, elem){

							var userInfo = {
								"id"   : $(elem).attr("data-toids"),
								"name" : $(elem).html().trim()
							}

							if(replyFrom.indexOf(userInfo) == -1){

								replyFrom.push(userInfo) ;
							}
						});
					}else{
						replyFrom = [{
							"id" : msgSentByID.trim() ,
							"name" : msgSentByName.trim() ,
						}];
					}
					if(Utils.isMobileDevice()){

						var replyFromStr = "" ;
						$.each(replyFrom, function(index, elem){
							replyFromStr += elem.name + ", " ;
							self.selectedUsers[elem.name] = elem.id ;
						});

						$("#msg-send-to").val(replyFromStr) ;
					}else{

						replyFromIDs = [] ;
						$.each(replyFrom, function(index, elem){
							$("#msg-send-to").append("<option value='"+ elem.id +"'>" + elem.name + "</option>") ;
							replyFromIDs.push(elem.id) ;
						});
						setTimeout( function(){
							$("#msg-send-to").val(replyFromIDs) ;
							$("#msg-send-to").chosen({
								width: "100%"
							});
							$("#msg-send-to").trigger("chosen:updated");
							//$("#msg-send-to").addClass("hide");
						},100);


						$("#msg-send-to").addClass("hide");
					}
/*				}
			})
*/
		},
		smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
		backToInbox: function(){

			if( $(".msg-back").attr("data-type") == "search" ){
				this.clearSearch();
				window.imsgType = "msg";
			}

			//location.href = "/user/messages";
			Backbone.history.navigate("/user/messages", {trigger: true});
			return this;
		},
		initSetup: function(){

			this.type = window.msgType;
			this.model.set("type",window.msgType);
			this.model.setMsgUrl();
			this.eMsgList = [];
			this.msgOrder = [];
			this.listenTo(this.model, 'change', function(model) {
        		model.fetch();
    		});
		},
		searchMessageByEnter: function(e){

			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#msg-search-btn").trigger("click");
 			}
		},
		searchMessage: function(e){

			var self = this;

			if( $("#msg-search-txt").val().trim() == "" )
				return false;

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			var search = "content_search="+$("#msg-search-txt").val();
			var params = {"search":search};
			localStorage.setItem( "msearch" , JSON.stringify( params ) );
			window.imsgType = "search";

			if( window.imsgType == "search" ){
				window.search = $("#msg-search-txt").val();
			}

			//location.href = "/user/messages";
			Backbone.history.navigate("/user/messages", {trigger: true});
			return this;
		},
		backToList: function(e){

			window.msgType = $(e.currentTarget).attr("data-type");

			//location.href = "/user/messages";
			Backbone.history.navigate("/user/messages", {trigger: true});
			return this;
		},
		deleteReply: function(e){

			if( !Utils.isMobileDevice() ){

				if( CKEDITOR.instances.reply_message.getData() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}else{

				if( $("#reply_message").text().trim() != "" ){
					if( !confirm("Are you sure you want to discard this message?") ){
						return false;
					}
				}
			}

			Utils.discardDraft( this.model.get("userID"), this.messageID );

			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$("#open-ireply").attr("clicked",false);

			this.uploadNewFileInUser();
		},
		openPostReply: function(e){

			var self = this;
			this.showReply = false;
			var cId = $($(".msg-toid")[0]).attr("data-toids")

			// if( $("#open-ireply").attr("clicked") == "true" )
			// 	return true;

			// $(".open-ireply").attr("clicked",true);
			// $("#open-reply").before( $(".reply-block").html() ).addClass("hide");

			// if( !Utils.isMobileDevice() )
			// 	Utils.addRTD('reply_message');
			// else
			// 	$("#reply_message").focus();

			// Utils.scrollTo("#reply-form",-50);

			// $("#open-reply").find(".flow-text").removeClass("error").html("Post Reply")


			/*var checkIfCounselorIsBlocked = checkIfCounselorIsBlocked || Utils.checkIfCounselorIsBlocked(cId);

			checkIfCounselorIsBlocked.then(function(blocked){

				if(blocked){

					$("#open-reply").find(".flow-text").addClass("error").html("This expert is not available for further conversations")
				}else{*/

					if( $("#open-ireply").attr("clicked") == "true" )
						return true;

					$(".open-ireply").attr("clicked",true);
					$("#open-reply").before( $(".reply-block").html() ).addClass("hide");

					if( !Utils.isMobileDevice() )
						Utils.addRTD('reply_message');
					else
						$("#reply_message").focus();

					Utils.scrollTo("#reply-form",-50);

					self.populateSender();
					$("#open-reply").find(".flow-text").removeClass("error").html("Post Reply")

/*				}
			})
*/		},

		postReply: function(e){

			$(".iauthentication-error").hide() ;

			var isError = false;
			var self = this;
			var sentByArr = [];

			var sendTo = $("#msg-send-to").val();
			if(sendTo == null){
				$(".isend-to").show()
				isError = true;
			}
			console.log(self.selectedUsers);
			var sentByArr = sendTo ;
			if(Utils.isMobileDevice()){
				var senders = sentByArr;
				sendersArr = senders.split(",");
				console.log(sendersArr);
				sentByArr = [] ;
				$.each(sendersArr, function(index,elem){
					if(!elem.trim()){
						return false ;
					}
					sentByArr.push(self.selectedUsers[elem.trim()])
				});
			}

			if(sentByArr.length > 1){

				$(".iauthentication-error").html("You can send message to only one expert");
				$(".iauthentication-error").show() ;
				isError = true;
			}

/*			$(".msg-senders").each(function(){
				if( $(this).attr("data-fromid") != undefined ){
					if( sendTo.indexOf($(this).attr("data-fromid")) < 0
						&&
						( $(this).attr("data-fromid") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-fromid"));
					}
				}
			});

			$(".msg-toid").each(function(){
				if( $(this).attr("data-toids") != undefined ){
					if( sendTo.indexOf($(this).attr("data-toids")) < 0
						&&
						( $(this).attr("data-toids") != self.model.get("userID") ) ){
						sendTo.push($(this).attr("data-toids"));
					}
				}
			});
*/
			var subject = $(".msg-header").text();
			if( !Utils.isMobileDevice() ){

				var body = encodeURI(CKEDITOR.instances.reply_message.getData());
				if( body == "" ){
					CKEDITOR.instances.reply_message.focus();
					$(".imessage").show();
					isError = true;
				}
				// else if( body.length < 100 ){
				// 	CKEDITOR.instances.reply_message.focus();
				// 	$(".imessageCnt").show();
				// 	isError = true;
				// }
			}else{

				var body = encodeURI($("#reply_message").val().trim());
				if( body == "" ){
					$("#reply_message").focus();
					$(".imessage").show();
					isError = true;
				}else if( body.length < 100 ){
					$("#reply_message").focus();
					$(".imessageCnt").show();
					isError = true;
				}
			}
			console.log("reply");




		if( !isError ){

		if(Utils.isMobileDevice()){
			body = body.replace(/%0A/g, '<br />');
		}

		if(self.attachmentIds.length == 0){

			self.attachmentIds = [-1];
		}

		$("#post-reply").addClass("disabled").html("Sending...");
		$("#delete-reply").addClass("disabled");

		var msgJSON = {
			"threadID":$("#single-msg-block").attr("data-msgid"),
			"subject":subject,
			"content":body,
			"recipients":sentByArr,
			"attachmentIDs" : self.attachmentIds
		};

		$.ajax({
          method: "POST",
          url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
          data: JSON.stringify(msgJSON),
          contentType: "application/json",
          statusCode : {
      		417 : function(response){

				var responseText = response.responseText;
				var responseJson = JSON.parse(responseText) ;

				var errorMessage = responseJson.message ;
				var errorType    = responseJson.type ;

				$(".iauthentication-error").html(errorMessage);
				$(".iauthentication-error").show() ;

			},
      		500 : function(){
				$(".iauthentication-error").html("Something went wrong. Please try again");
				$(".iauthentication-error").show() ;
			},
		}

      	}).done(function(response){

      		$(".ureply-file-name-attached").html("");
			$(".file-name-attached-ureply").addClass("hide");
			$(".file-attachment-ureply-send").removeClass("hide");
			this.attachmentIds = [];
      		Utils.displaySuccessMsg("Your message has been sent.");
      		self.addThreadAfterPostReply( response );

      		$("#post-reply")
      			.removeClass("disabled")
      			.html( 'Reply<i class="mdi-content-send right"></i>' );
			$("#delete-reply").removeClass("disabled");

			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){

	            mixpanel.track('Button Click', {'mediumSource' : 'website', 'itemName': 'MESSAGE REPLY', 'itemtype': 'MESSAGE'});

	        }
      	}).fail(function(error){
      		console.log(error);
      		$("#post-reply")
      			.removeClass("disabled")
      			.html( 'Reply<i class="mdi-content-send right"></i>' );
			$("#delete-reply").removeClass("disabled");
      	});
			}else{
				setTimeout(function(){$(".error-msg").hide();$(".input-field").removeClass("error");},3000);
				return false;
			}

		},
		checkForAttachments : function(userMessagesObj){

			$.each(userMessagesObj, function(index){

				if(userMessagesObj[index].attachmentID > 0){

					var fileID = userMessagesObj[index].attachmentID;
					$.ajax({

						method : "GET",
						url : Utils.contextPath() + '/file/type/'+fileID,
						contentType: "application/json",
					}).done(function(response){

						if(response){

							console.log("Response: "+response)
							$("#msg-"+userMessagesObj[index].msgID).find(".msg-content").append('<div class="download-div"><i class="mdi mdi-attachment"></i><a class="user-download-attachment" data-href="'+response.s3Url+'" href="'+Utils.contextPath()+'/file/download/'+fileID+'" data-fileid ="'+response.iD+'">'+response.fileName+'</a><span class="downloading-text hide">Downloading ...</span><span class="download-error hide">Download Error.</span></div>')
						}
					}).error(function(error){

						console.log("Error: "+error)
					})
				}
			})
		},
		renderDraftMessage: function( response ) {

			var self = this;
			var userMessages = response.attributes.conversationDetail.userMessage;
			var userMessagesLength = userMessages.length;
			var lastUserMessage = userMessages[userMessagesLength - 1];

			var allMsgs = $(".dost-msg-item")           ;
			var lastMsg = allMsgs[ allMsgs.length - 1 ] ;

			var msgID = $(lastMsg).attr("id") ;
			msgID     = msgID.split(/-/)[1]   ;

			var msgSentByID   = $("#msg-" + msgID).find(".msg-sent-by").attr("data-fromid") ;
			var msgSentByName = $("#msg-" + msgID).find(".msg-sent-by").html()              ;
			var content = $("#msg-" + msgID).find(".msg-content").html();
			self.openPostReply();

			console.log("content ", content);

			var userID = this.model.get("userID") ;

			var replyFrom = [] ;
			if(msgSentByID == userID){
				var msgSentTo = $("#msg-" + msgID).find(".msg-toids span");
				$.each(msgSentTo, function(index, elem){
					var userInfo = {
						"id"   : $(elem).attr("data-toids"),
						"name" : $(elem).html().trim()
					}

					replyFrom.push(userInfo) ;
				});
			}else{
				replyFrom = [{
					"id" : msgSentByID.trim() ,
					"name" : msgSentByName.trim() ,
				}];
			}
			if(Utils.isMobileDevice()){

				var replyFromStr = "" ;
				$.each(replyFrom, function(index, elem){
					replyFromStr += elem.name + ", " ;
					self.selectedUsers[elem.name] = elem.id ;
				});

				$("#msg-send-to").val(replyFromStr) ;
				$("#reply_message").val(content);


			}else{

				replyFromIDs = [] ;
				$.each(replyFrom, function(index, elem){
					$("#msg-send-to").append("<option value='"+ elem.id +"'>" + elem.name + "</option>") ;
					replyFromIDs.push(elem.id) ;
				});
				setTimeout( function(){
					$("#msg-send-to").val(replyFromIDs) ;
					$("#msg-send-to").chosen({
						width: "100%"
					});
					$("#msg-send-to").trigger("chosen:updated");
				},100);

				$("#msg-send-to").addClass("hide");
				CKEDITOR.instances.reply_message.setData( content );

			}
			$("#msg-" +msgID).remove();
			self.messageID = msgID;
		},
		render: function() {

			if( !window.msgType ){
				return false;
			}

			setTimeout(function(){$(".iheader-msg-badge").addClass("hide");},10);

			var self = this;

			self.$el.html(this.MessagePageLayout());
			self.$el.append(this.ComposePageLayout());

			self.$el.find(".msg-list-bar").remove();

			self.model.addWait();

			self.model.fetch({
				success : function(response){
					console.log("response " + JSON.stringify(response));

					var arr = [];
					var userId = self.model.get("userID") ;
					if (response.attributes.type == "MAIL") {
						var threadId = response.attributes.threadId;
						var userMessages = response.attributes.conversationDetail.userMessage;

						self.checkForAttachments(userMessages);
						$.ajax({
								type: "GET",
				            	url: apiUrl + "/v1/messageRatingExists/" + threadId,

					            success: function(data) {

					            	for (var i = 0; i<data.length; i++) {
					            		arr.push(data[i].messageId);
					            		if (data[i].messageRelevance === 'YES') {

					            			if (data[i].ratingValue == 0) {
					            				$('.counselor-feedback-div-'+data[i].messageId).html('<div class="counselor-message-rating" data-info="'+data[i].messageId+'-'+userId+'"><span value="5">☆</span><span value="4">☆</span><span value="3">☆</span><span value="2">☆</span><span value="1">☆</span> :gnitar ruoy evig esaelP</div>');
					            				$('.counselor-feedback-div-'+data[i].messageId).removeClass("hide");
					            			}else{

						            			$('.counselor-feedback-div-'+data[i].messageId).html('<img src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loop.gif" width="30" height="10">');

						            			callback(data[i]);

						            		}

					            		}

					            		if (data[i].messageRelevance === 'NO') {
					            			//$('.counselor-feedback-div-'+data[i].messageId).html('<img src="http://res.cloudinary.com/http-yourdost-com/image/upload/v1449474743/icons/loop.gif" width="30" height="10">');
					            			$('.counselor-feedback-div-'+data[i].messageId).html('<p><font size="1">The answer was not helpful to you.</font></p>');
					            			$('.counselor-feedback-div-'+data[i].messageId).removeClass("hide");
					            		}

					            	}
					            	for (var i = 0; i<userMessages.length; i++) {

										if (arr.indexOf(userMessages[i].msgID)==-1) {

											$('.counselor-feedback-div-'+userMessages[i].msgID).removeClass("hide");
										}
									}

				            	},
			            		dataType: 'json'
						});
					}

					response.attributes["isMobileDevice"] = Utils.isMobileDevice() ;
					self.$el.find("#msg-block").before(

						self.SingleMsgLayout(response.attributes)
					);
					if ( response.attributes.conversationDetail.status == 'DRAFT' ) {
							self.renderDraftMessage(response);
					}
					setTimeout(function(){
						self.$el.find(".msg-back").attr("data-type",window.imsgType);

						if( self.$el.find(".msg-toids").html() != "" && window.msgType != "CHAT" ){

							self.$el.find(".msg-toids").each(function(){
								$(this).html( $(this).html().slice(0,-2) );
							});

							self.$el.find(".dost-msg-item:last-child").find(".msg-senders").removeClass("truncate");
							self.$el.find(".dost-msg-item:last-child").find(".msg-content").removeClass("hide");
						}

						if( Utils.isMobileDevice() ){
                			$("header").addClass("hide");
                			$(".mmsg-single-view-header").html(	$(".single-msg-btn-mbar").html() );
                			$(".mleft-menu").removeClass("hide");
            			}
					},100);

					Utils.adjustViewPortSize();

					self.model.removeWait();
				},
				error : function(error){
					self.model.removeWait();
					console.log(error);
				}

			});
			// function feedbackMessage(userMessages) {
			// 	for (var i = 0; i<userMessages.length; i++) {
			// 		console.log("message id "+ userMessages[i].msgID);
			// 		$('#counselor-feedback-div').html('<p id="counselor-feedback"><font size="2">Was this helpful? <a style="cursor:pointer" data-info="'+userMessages[i].msgID+'-'+userMessages[i].fromRecipient.id+'-Yes" class="counselor-feedback">Yes</a> or <a style="cursor:pointer" data-info="'+userMessages[i].msgID+'-'+userMessages[i].fromRecipient.id+'-No" class="counselor-feedback">No</a></font></p>');
			// 	}
			// }
			function callback(data){
				setTimeout(100);
				var html_star = '';
				for(i=1;i<=data.ratingValue;i++){

    				html_star += '<span class="rated-star" style="color:teal;"></span>';
    			}
    			for(j=1;j<=5-data.ratingValue;j++){
    				html_star += '<span>☆</span>';
    			}
    			$('.counselor-feedback-div-'+data.messageId).html('<p><font size="1">You have rated '+html_star+'</font></p>');
    			$('.counselor-feedback-div-'+data.messageId).removeClass("hide");
			}

			self.renderElements();
			EventBus.trigger('removeChatScroll');

			setTimeout(function(){$("#filter-msg-nav-btn").remove();},10);

			if( window.imsgType == "search" ){
				$("#msg-search-txt").val( window.search );
			}

			//self.fillMobileSearch();

			$(window).unbind("scroll");

			$( window ).scroll(function() {
		        if( $(window).scrollTop() > 150 ){
		          $("#scroll-up-mbtn").removeClass("hide");
		        }
		        else{
		          $("#scroll-up-mbtn").addClass("hide");
		        }
		    });

			return this;
		},
		fillMobileSearch: function(){

			if( window.device == "mobile" && window.search ){

				setTimeout(function(){
					$("#search-bar").css("left", 0);
					$("#msg-search-txt").val( window.search );
					$("#search-msg-mobile").val( window.search );
				},10);
			}
		},
		renderElements: function(){

			$('html, body').stop().animate({
	      		scrollTop: $("body").offset().top}, 1000,'easeInOutExpo');

			this.$el.find("#msg-block").find("msg-list-block").html("");
			this.$el.find("#msg-block").find(".no-msg-list-block").remove();
			this.$el.find("#single-msg-block").removeClass("hide");
			this.$el.find(".msg-compose").addClass("hide");
		},
		deleteMsg: function(e){

			if( confirm("Are you sure you want to delete this message?") ){

				var msgID = $("#single-msg-block").attr("data-msgid");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages/'+msgID+'/mark/deleted',
	              contentType: "application/json"
	          	}).done(function(response){
	          		Utils.displaySuccessMsg("Your message has been deleted.");
	          		//location.href = "/user/messages";
	          		Backbone.history.navigate("/user/messages", {trigger: true});
	          		return true;
	          	}).fail(function(error){
	          		console.log(error);
	          	});
			}
		},
		clearSearch: function(){
	    	localStorage.removeItem( "msearch" );
	    	$("#msg-search-txt").val("");
	    },
	    removeCollapsed: function(e){

			var $this = $(e.currentTarget);
			// if($this.hasClass("user-download-attachment")){

			// 	return false;
			// 	e.stopPropagation();
			// 	e.preventDefault();
			// }

			if( $this.attr("data-type") == "CHAT" )
				return true;

			if( $this.hasClass("mcollapsed") ){
				$this.removeClass("mcollapsed");
				$this.find(".bcollapsed").addClass("hide");
				$this.find(".msg-content").removeClass("hide");
				$this.find(".msg-senders").removeClass("truncate");
			}else{
				$this.addClass("mcollapsed");
				$this.find(".bcollapsed").removeClass("hide");
				$this.find(".msg-content").addClass("hide");
				$this.find(".msg-senders").addClass("truncate");
			}

			if( $this.is(":last-child") ){
				$this.find(".msg-content").removeClass("hide");
				$this.find(".msg-senders").removeClass("truncate");
			}
	    },
		addThreadAfterPostReply: function( response ){

			var cMsg = response.conversationDetail;

			var threadID = cMsg.threadID;
			var important = cMsg.important;
			var message = cMsg.userMessage[ cMsg.userMessage.length-1 ];
			var attachmentId = message.attachmentID;

			var body = message.body.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');

			body = Utils.replaceUrls(body);

			var receivedTime = Utils.getDateDiff( message.receivedDate );
			var subject = message.subject;
			var read = message.read;
			var sender = message.fromRecipient.firstName != null ? message.fromRecipient.firstName : message.fromRecipient.username;

			if( message.fromRecipient.picUrl != undefined ){
				var fAvatar = message.fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+message.fromRecipient.avatar+'.png';
			}

			var tos = [];
            for( var i = 0 ; i < message.toRecipients.length ; i++ ){
            	var to = message.toRecipients[i];
            	var firstName = to.firstName != null ? to.firstName : to.username;
 				tos.push( '<span class="msg-toid" data-toids="'+to.id+'">'+firstName+'</span>' );
            }

			var item = '<li class="collection-item avatar dost-msg-item rhover expanded" id="msg-'+message.msgID+'" data-msgid="'+threadID+'" data-type="MAIL">'
              				+'<div class="msg-img-holder">'
                  				+'<img src="'+fAvatar+'" class="circle msg-avatar z-depth-1">'
              				+'</div>'
              				+'<p class="msg-senders msg-sent-by" data-fromid="'+message.fromRecipient.id+'">'+sender+'</p>'
              				+'<p class="msg-senders msg-toids">To: '+tos.join(", ")+'</p>'
                			+'<p class="bcollapsed truncate hide">'
                			+message.bodyCollapsed+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
              				+'</p>'
              				+'<p class="msg-content">'+body+'</p>'
              				+'<a class="secondary-content msg-time">'+receivedTime+'</a>'
              				+'<i class="mdi mdi-reply smoothscroll msg-single-reply" id="reply-'+message.msgID+'" href="#reply-form" title="Reply"></i>'
            			+'</li>';

			this.$el.find("#single-msg-block").find(".single-thread").append( item );

			var self = this;
			if(attachmentId > 0){

				$.ajax({

					method : "GET",
					url : Utils.contextPath() + '/file/type/'+attachmentId,
					contentType: "application/json",
				}).done(function(response){

					if(response){

						var attachment = '<div class="download-div"><i class="mdi mdi-attachment"></i><span class="user-download-attachment" data-href="'+response.s3Url+'"  data-fileid ="'+response.iD+'">'+response.fileName+'</span><span class="download-error hide">Download Error.</span></div>';
						$("#msg-"+message.msgID).find(".msg-content").append(attachment);
					}
				}).error(function(error){

					console.log("Error: "+error)
				})
			}

			$("#reply-form").remove();
			$("#open-reply").removeClass("hide");
			$("#open-ireply").attr("clicked",false);
		},
		counselorFeedback: function(e) {
			e.stopPropagation();
			var ratingValue;
			var userId = this.model.get("userID");
			var dataInfo = $(e.currentTarget).attr('data-info');
			var parent = $(e.currentTarget).parent();

			var dataInfoArr = dataInfo.split('-');
			console.log("data info array " + dataInfoArr);
			var msgId = dataInfoArr[0];
			var counselorId = dataInfoArr[1];
			var response = dataInfoArr[2];
			console.log("msgId "+ msgId);
			console.log("counselorId "+ counselorId);
			console.log("response "+ response);
			var threadId = Utils.decodeString(this.id);
			var counselorFeedbackWithRating = function(counselorId, userId, msgId, response, ratingValue) {

				$.ajax({
		            type: "POST",
		            url: apiUrl + "/v1/addCounselorMessageFeedback",
		            headers: {
		                    'Accept': 'application/json',
		                    'Content-Type': 'application/json'
		            },
		            data: JSON.stringify({
		                "counselorId": counselorId,
		                "victimId": userId,
		                "messageId": msgId,
		                "messageRelevance": response,
		                "threadId": threadId,
		                "ratingValue": ratingValue
		            }),
		            success: function(data) {
		              console.log(data);
		              if (data == true) {
		              	$(parent).text("Thank you!");
		              }

		            },
		            dataType: 'json'
          		});

          		$.ajax({
		            type: "POST",
		            url: apiUrl + "/v1/users/"+userId+"/counselor/"+counselorId+"/rating",
		            headers: {
		                    'Accept': 'application/json',
		                    'Content-Type': 'application/json'
		            },
		            data: JSON.stringify({
		            	"star": ratingValue
		            }),
		            success: function(data) {
		              console.log(data);

		            },
	            	dataType: 'json'
      			});
			}

			if (response == "Yes") {

				$.ajax({
		            type: "POST",
		            url: apiUrl + "/v1/addCounselorMessageFeedback",
		            headers: {
		                    'Accept': 'application/json',
		                    'Content-Type': 'application/json'
		            },
		            data: JSON.stringify({
		                "counselorId": counselorId,
		                "victimId": userId,
		                "messageId": msgId,
		                "messageRelevance": response,
		                "threadId": threadId,
		                "ratingValue": 0
		            }),
		            success: function(data) {
		              console.log(data);
		              if (data == true) {

		              	$(parent).html('<div class="counselor-message-rating" data-info="'+msgId+'-'+userId+'"><span value="5">☆</span><span value="4">☆</span><span value="3">☆</span><span value="2">☆</span><span value="1">☆</span> :gnitar ruoy evig esaelP</div>');
		              }

		            },
		            dataType: 'json'
          		});



			}
			else {

				counselorFeedbackWithRating(counselorId, userId, msgId, response, 1);
			}

		},
		giveCounselorMessageRating: function(e) {
			e.preventDefault();
			e.stopPropagation();
			var current = $(e.currentTarget);
			var parent = $(e.currentTarget).closest('#counselor-feedback-div');

			var userId = this.model.get("userID");
			var ratingValue = current.attr("value").trim();
			var dataInfo = parent.attr("data-info").trim();
			var dataInfoArr = dataInfo.split('-');
			var msgId = dataInfoArr[0];
			var counselorId = dataInfoArr[1];
			var response = "YES";
			var threadId = Utils.decodeString(this.id);

			$.ajax({
		            type: "POST",
		            url: apiUrl + "/v1/addCounselorMessageFeedback",
		            headers: {
		                    'Accept': 'application/json',
		                    'Content-Type': 'application/json'
		            },
		            data: JSON.stringify({
		                "counselorId": counselorId,
		                "victimId": userId,
		                "messageId": msgId,
		                "messageRelevance": response,
		                "threadId": threadId,
		                "ratingValue": ratingValue
		            }),
		            success: function(data) {
		              console.log(data);
		              if (data == true) {
		              	$(parent).html("Thank You!");
		              }

		            },
		            dataType: 'json'
          	});

			$.ajax({
	            type: "POST",
	            url: apiUrl + "/v1/users/"+userId+"/counselor/"+counselorId+"/rating",
	            headers: {
	                    'Accept': 'application/json',
	                    'Content-Type': 'application/json'
	            },
	            data: JSON.stringify({
	            	"star": ratingValue
	            }),
	            success: function(data) {
	              console.log(data);

	            },
	            dataType: 'json'
      		});

		}

	});

	SingleMessagePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	$(window).unbind("scroll");
	};

	SingleMessagePage.prototype.clean = function() {
		this.remove();
		$(window).unbind("scroll");
	};

	return SingleMessagePage;
});
