define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/review/review',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel',
	//'view/leaveMessage/page' ,
	'model/users',
	'view/signup/step2',
	'view/paymentPending/payment_pending',
	'view/home2/subview/book_appointment',
	'ajax-chosen',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, ReviewView, Utils, EventBus, UserMsgModel, UserModel,  SignUpStep2View, PaymentPendingView, BookAppointmentView ) {

	var MessagePage = Backbone.View.extend({
		el: "main",
		initialize: function() {

			var url = window.location.href ;
    		url = url.replace("/user/messages", "" );

            var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo;

            this.searchParam = $.url( url ).param( 's' );

			this.signUpStep2 = new SignUpStep2View() ;
			this.reviewView = new ReviewView() ;
			this.bookAppointmentView = new BookAppointmentView();

			this.paymentPendingView = new PaymentPendingView() ;

			this.selectedCategories = {} ;
			this.selectedUsers = {} ;

			this.model = new UserMsgModel();
			this.userModel = new UserModel() ;
			this.initSetup();
			this.timeoutId = -1;
			this.threadID = 0;
			this.messageID = 0;
			this.attachmentIds = [];
		//	this.leaveMessage       = new LeaveMessageView()    ;

			EventBus.bind("msg:updateUnreadCount",this.updateUnreadCount);
		},
		MessagePageLayout : JST['app/templates/messages/user_layout.hbs'],
		ComposePageLayout : JST['app/templates/messages/compose.hbs'],
		BlogThumbailLayout: JST["app/templates/home2/blog_thumbnails.hbs"],
		events: {
			"click .dost-msg-item": "openMessage",
			"click #compose .mclose" : "hideCompose" ,
			"click #compose-btn": "openCompose",
			"click #compose-send-btn": "composeMsg",
			"click .msg-msearch-ficon": "openMobileSearch",
			"click .change-sender": "changeSender",
			"click .back-change-sender": "backChangeSender",
            "click #msg-search-btn": "searchMessage",
            "keyup #msg-search-txt": "searchMessageByEnter",
            "click .msg-back-inbox": "backToInbox",
            "click #reviewCounselor" : "reviewCounselor" ,
            "click #rejectReview" : "rejectReview" ,
            "click #message-counselor-modal .popup-close"  : "hideContainer" ,

            "click #book-appointment-modal .mclose"  : "hideContainer",
            "click .article-link" : "ThumbnailClick",
            "keyup #subject": "isSubject",
            "change #send-to": "isSendTo",
            "keyup #send-to": "isSendToInMobile",
            "keyup #message ": "isMessage",
            "change #send-category": "isCategory",
            "keyup #send-category": "isCategoryInMobile",

            "click .confirm-save-draft-modal-dont-save": "discardDraft",
            "click .confirm-save-draft-modal-save": "saveDraft",
            "click .delete-draft": "hideCompose",
            "change #message-file-attachment" : "uploadFileInMessageList",
            "click .remove-attached-file" : "uploadNewFileMessageList"
		},

		discardDraft: function(e) {

			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();
			console.log( "discarded draft " );
			Utils.discardDraft( this.userModel.getUserID(), this.messageID );
			$("#compose").remove();

		},
		saveDraft: function(e) {

			var self = this;
			Utils.closePopup('confirm-save-draft');
			$("#confirm-save-draft").remove();
			//self.autoSaveMessage("saveDraft");
			$("#compose").remove();


		},

		uploadNewFileMessageList : function(e){

			$(".file-name-attached-message").addClass("hide");
			$(".file-attachment-message-send").removeClass("hide");
		},
		uploadFileInMessageList : function(e){

			var file = e.target.files[0];
			var data = new FormData();
			var self =  this;

			$(".message-upload-error").addClass("hide")
			if(file.type == "application/x-ms-dos-executable"){

				$(".message-upload-error").removeClass("hide").html("File type not allowd");
				return false;
			}
			$(".file-name-attached-message").removeClass("hide");
			$(".file-attachment-message-send").addClass("hide");
			$(".file-name-attached").html("Uploading ...");

			data.append('file', $('#message-file-attachment').get(0).files[0] );
			$.ajax({

				method: "POST",
				data:data,
				cache: false,
			    contentType: false,
			    processData: false,
				url : Utils.contextPath() + '/file/upload/file',
			}).done(function(response){

				//console.log("Response: "+response)
				$(".file-name-attached-message").removeClass("hide");
				$(".file-attachment-message-send").addClass("hide");
				$(".file-name-attached").html(file.name);
				self.attachmentIds.push(response.fileID);

			}).error(function(error){

				$(".file-name-attached-message").addClass("hide");
				$(".file-attachment-message-send").removeClass("hide");
				$(".message-upload-error").removeClass("hide").html("Upload Error");
				console.log("Error: "+error);
			})

		},
		hideCompose : function(){

			Utils.closePopup('compose') ;

			console.log("hello2");
			//this.autoSaveMessage();
			//Utils.openPopup( "confirm-save-draft" );
			$("div#lean-overlay:last").css({'display':'block', 'opacity':'0.5'});

		},
		hideContainer: function(){
			Utils.closePopup('message-counselor-modal') ;

		},
		isCategory: function() {

			//console.log('hello');
			if ( $(".category-field").hasClass("error") ) {
				$(".isend-category").hide();
				$(".category-field").removeClass("error");
			}
		},
		isSubject: function() {
			//console.log("hello");
			if ( $(".isubject").parent().hasClass('error') ) {

				$(".isubject").hide();
				$(".isubject").parent().removeClass('error');
			}

		},
		isSendTo: function() {

			var sendTo = $("#send-to").val();

			if (sendTo != null) {
				var sendToLength = sendTo.length;
			}

			if ( sendToLength === 1 ) {
				if( $(".isend-to").parent().hasClass('error') ) {

					$(".isend-to").hide();
					$(".isend-to").parent().removeClass('error');
				}
			}
		},
		isSendToInMobile: function() {

			if (Utils.isMobileDevice) {

				var sendTo = $("#send-to").val();

				if (sendTo != null) {
					var sendToLength = sendTo.length;
				}

				if ( sendToLength === 1 ) {
					if( $(".isend-to").parent().hasClass('error') ) {

						$(".isend-to").hide();
						$(".isend-to").parent().removeClass('error');
					}
				}
			}
		},
		autoSaveMessage: function(msg) {

			console.log( 'Autosave!' );
            if(window.pendingDraftsaveRequest)
                return;
        	$(".email-draft-bar").removeClass( "hide" );
	        $( ".email-draft-saving-msg" ).removeClass( "hide" );
	        $( ".email-draft-saved-msg" ).addClass("hide");

			var subject = $("#subject").val() || null;

			var sendTo = $(".user-friend").hasClass("hide") ? $("#send-to").val() : null;
			var sendCategory = $("#send-category").val();

			var self = this ;
			var categoryArr = sendCategory ;
			if(Utils.isMobileDevice()){
				categoryArr = new Array() ;
				var categorySelected = sendCategory.split(",");
				_.each(categorySelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					categoryArr.push(self.selectedCategories[elem.trim()]) ;
				});
			}


			var userArr = sendTo ;
			if(Utils.isMobileDevice() && userArr != null){
				userArr = new Array() ;
				var usersSelected = sendTo.split(",");
				_.each(usersSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					userArr.push(self.selectedUsers[elem.trim()]) ;
				});
			}

			if( !Utils.isMobileDevice() ){

				if ( CKEDITOR.instances.message == undefined ) {
					var body = encodeURI(CKEDITOR.instances.reply_message.getData());
					self.threadID = $("#single-msg-block").attr("data-msgid");

				} else {
					var body = encodeURI(CKEDITOR.instances.message.getData());

				}


			}else{
				var body = encodeURI($("#message").val().trim()) || null;
				if ( $("#single-msg-block").attr("data-msgid") ) {
					self.threadID = $("#single-msg-block").attr("data-msgid");
				}
			}
			console.log( "subject", subject );
			console.log( "userArr", userArr );
			console.log( "categoryArr", categoryArr );
			console.log( "body", body );

			var msgJSON = {
					"threadID":self.threadID,
					"subject":subject,
					"content":body,
					"categoryIds":categoryArr,
					"recipients":userArr,
					"status":"DRAFT"
			};

			console.log( "threadID", self.threadID );


			console.log( "msgJSON", msgJSON );
			console.log( 'calling autosave jsut one');
            window.pendingDraftsaveRequest = true;
			$.ajax({
        		method: "POST",
        		url: Utils.contextPath()+'/v1/users/'+this.userModel.getUserID()+'/messages',
        		data: JSON.stringify(msgJSON),
       			contentType: "application/json"
      		}).done(function(response){
                window.pendingDraftsaveRequest = false;
      			console.log( response );
      			self.threadID = response.conversationDetail.threadID;
      			var userMessages = response.conversationDetail.userMessage;
      			var lastMsg = userMessages[userMessages.length - 1];
      			self.messageID = lastMsg.msgID;
      			// messageID = 13340;
      			if (msg == "saveDraft") {
      				Utils.displaySuccessMsg("Your draft has been saved");
      			}
	        	$( ".email-draft-saving-msg" ).addClass( "hide" );
	        	$( ".email-draft-saved-msg" ).removeClass("hide");
	        	return true;
			}).error(function(error){
                window.pendingDraftsaveRequest = false;
				console.log(error);
			});
		},
		isMessage: function(e) {

			//console.log("hello");
			//console.log(e.currentTarget);
			var self = this;

			clearTimeout(self.timeoutId);
    		self.timeoutId = setTimeout(function() {
        		// Runs 1 second (1000 ms) after the last change

        		//self.autoSaveMessage();

    		}, 500);


			console.log("one who knocks");

			var body = $("#message").val().trim();
			//console.log("one who knocks");
			if ( $(".imessage").parent().hasClass('error') ) {


				$(".imessage").hide();
				$(".imessageCnt").hide();
				$(".imessage").parent().removeClass('error');


			}
		},
		isCategoryInMobile: function(e) {

			if (Utils.isMobileDevice) {

					if ( $(".category-field").hasClass("error") ) {
						$(".isend-category").hide();
						$(".category-field").removeClass("error");
				}

			}
		},
		rejectReview : function(){
			var userID  = this.userModel.getUserID();

			var counselorObj = JSON.parse(sessionStorage.getItem("reviewPendingInfo")) ;
			var chatID       = counselorObj.id                                         ;

			$(".review-bar").addClass("hide");
			$("#msg-list-block").css({"margin-top" : "70px"});
  			$.ajax({
  				url : Utils.contextPath() + "/v1/users/"+ userID +"/rating/"+ chatID +"/pending",
  				method : "POST" ,
		        dataType: "JSON",
		        contentType: "application/json; charset=utf-8",
  			}).done(function(response){
  			}).error(function(error){
		        console.log("error"); console.log(error);
  			});

		},
		reviewCounselor : function(){
			//this.reviewView.render() ;
			EventBus.trigger("renderReview", "modal");
		},
		backToInbox: function(){

			if( $("#msg-block").attr("data-type") == "search" ){
				this.clearSearch();
				this.$el.find("#msg-block").addClass("hide").attr("data-type","msg");
				this.$el.find("#msg-block").find(".umsg-list-msg").addClass("hide").html("");
				this.loadMsgs(1);
				return this;
			}
		},
		initSetup: function(){

			if( window.msgType ){
				this.type = window.msgType;
			}
			this.eMsgList = [];
			this.msgOrder = [];
			this.listenTo(this.model, 'change', function(model) {
        		model.fetch();
    		});
		},
		searchMessageByEnter: function(e){

			var code = e.keyCode || e.which;
 			if(code == 13) {
   				$("#msg-search-btn").trigger("click");
 			}

 			if( $("#msg-search-txt").val().trim() == "" ){
				$(".msg-back-inbox").trigger("click");
 			}
		},
		searchMessage: function(e){

			var self = this;

			if( $("#msg-search-txt").val().trim() == "" )
				return false;

			if( this.isLoading ){
				alert("Previous request is in progress...");
				return false;
			}

			this.$el.find("#msg-block").attr("data-type","search");
			this.$el.find("#msg-block").find(".umsg-list-msg").addClass("hide").html("");
			this.$el.find("#msg-block").find(".umsg-list-search").removeClass("hide").html("");

			var search = "content_search="+$("#msg-search-txt").val();
			var params = {"search":search};
			localStorage.setItem( "msearch" , JSON.stringify( params ) );
			self.bindScroll();
			this.loadMsgs( 1 , params );
		},
		backChangeSender: function(e){

			var self = this;
			$(e.currentTarget).parent().addClass("hide");
			self.$el.find("#send-to").addClass("hide");
			self.$el.find(".user-friend").removeClass("hide");
			self.$el.find("#send_to_chosen").hide();
		},
		updateUnreadCount: function(){

			setTimeout(function(){
				$(".iheader-msg-badge").text( sessionStorage.getItem("unread") );
				$(".mobile-msg-badge").text( sessionStorage.getItem("unread") );
              	if( sessionStorage.getItem("unread") > 0 )
                	$(".iheader-msg-badge").removeClass("hide");
			},10);
		},

		changeSender: function(e){

			var self = this;
			$(e.currentTarget).parent().addClass("hide");
			self.$el.find("#send-to").removeClass("hide");
			self.$el.find(".default-user-friend").removeClass("hide");

			if( self.$el.find("#send_to_chosen").length > 0 ){
				self.$el.find("#send_to_chosen").show();
				return true;
			}

			if(Utils.isMobileDevice()){

					$( "#send-to" )
				      // don't navigate away from the field on tab when selecting an item
				      .bind( "keydown", function( event ) {
				        if ( event.keyCode === $.ui.keyCode.TAB &&
				            $( this ).autocomplete( "instance" ).menu.active ) {
				          event.preventDefault();
				        }
			      })
			      .autocomplete({
			        source: function( request, response ) {

			        	$.ajax({
						method: 'GET',
						url: Utils.contextPath()+'/v1/counselor/search?name=' + Utils.JUIextractLast( request.term ),
						}).done(function (data) {
							var usersArr = new Array() ;
							$.each(data, function (i, val) {
							usersArr.push({
								"key" : val,
								"value" : i
							});
							});
							response( usersArr );
						});


			        },
			        search: function() {
			          // custom minLength
			          var term = Utils.JUIextractLast( this.value );

			          if ( term.length < 2 ) {
			            return false;
			          }
			        },
			        focus: function() {
			          // prevent value inserted on focus
			          return false;
			        },
			        select: function( event, ui ) {
			        	//console.log("in select");
			          self.selectedUsers[ui.item.value] = ui.item.key ;

			          var terms = Utils.JUIsplit( this.value );
			          // remove the current input
			          terms.pop();
			          // add the selected item
			          terms.push( ui.item.value );
			          // add placeholder to get the comma-and-space at the end
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
			        }
			      });



			}else{
					self.$el.find("#send-to").ajaxChosen({
						type: 'GET',
						url: Utils.contextPath()+'/v1/counselor/search',
						dataType: 'json',
						jsonTermKey:"name",
						minTermLength:1
					}, function (data) {

						var terms = {};
						$.each(data, function (i, val) {
							terms[val] = i;
						});

						return terms;
					});
			}

		},
		openMobileSearch: function(e){

			$(".filter-container").addClass("wow bounceInUp animated").removeClass("hide");
		},
		openCompose: function(e){

			this.draftCall = 0;
			this.timeoutId = -1;
			this.threadID = 0;
			var self = this;
			var userType = this.userModel.getUserType() ;

			$("#compose").remove();

			self.$el.append(this.ComposePageLayout( {isMobileDevice:Utils.isMobileDevice(), userType : userType } ));
			self.$el.append( this.ConfirmSaveDraftLayout() );

			var user = JSON.parse( localStorage.getItem("user") );

			$(".msg-to-name").text( user.username );
			$(".user-header").removeClass("hide");
			$(".friend-header").addClass("hide");
			$("#send-to").addClass("hide");
			//$(".user-friend").removeClass("hide");
			$(".category-field").removeClass("hide");

			$('body').css({'overflow-y' : 'hidden'});


			Utils.openPopup("compose");

			EventBus.trigger("renderCounselorDropDown", "counselor_dropdownlist_search")

			var category = localStorage.getItem("c_categories");

			if(Utils.isMobileDevice()){

				var categoriesArr = new Array() ;
				var othersHash = {} ;
				$.each(JSON.parse(category),function(key,value){
					categoriesArr.push({
						"key" : key.substr(2) ,
						"value" : value

					}) ;

					if( value.toLowerCase() == "others" ){
						//$("#send-category").val("Others, ") ;
						//self.selectedCategories[value] = key ;
					}

				});


				$( "#send-category" )
			      // don't navigate away from the field on tab when selecting an item
			      .bind( "keydown", function( event ) {
			        if ( event.keyCode === $.ui.keyCode.TAB &&
			            $( this ).autocomplete( "instance" ).menu.active ) {
			          event.preventDefault();
			        }
			      })
			      .bind('focus', function(){ $(this).autocomplete("search"); } )
			      .autocomplete({
			        minLength: 0,
			        source: function( request, response ) {
			          // delegate back to autocomplete, but extract the last term
			          	response( $.ui.autocomplete.filter(
			            categoriesArr, Utils.JUIextractLast( request.term ) ) );
			        },
			        focus: function() {
			          // prevent value inserted on focus
			          return false;
			          // $(this).autocomplete("search");
			        },
			        select: function( event, ui ) {
			        	self.selectedCategories[ui.item.value] = ui.item.key ;

			          var terms = Utils.JUIsplit( this.value );
			          // remove the current input
			          terms.pop();
			          // add the selected item
			          terms.push( ui.item.value );
			          // add placeholder to get the comma-and-space at the end
			          terms.push( "" );
			          this.value = terms.join( ", " );
			          return false;
			        }
			      });
			}else{

				$.each(JSON.parse(category),function(key,value){
/*				  if( value.toLowerCase() == "others" )
	              	var option = "<option value='"+key+"' selected>"+value+"</option>";
	              else
*/	              	var option = "<option value='"+key.substr(2)+"'>"+value+"</option>";
	              $("#send-category").append( option );

	            });
				setTimeout( function(){
					$("#send-category").chosen({
						width: "100%"
					});
					$("#subject").focus();
				},100);

			}

			if( !Utils.isMobileDevice() )
				CKEDITOR.replace( 'message' );
		},
		composeMsg: function(e){

			if( $("#compose-send-btn").hasClass("disabled") ){
				return false ;
			}

			var isError = false;

			var userType = this.userModel.getUserType() ;
			var sendTo = [];
			var sendToval = "";
			if(userType == 'VICTIM'){

				sendToval = $(".user-friend").hasClass("hide") ? $("#searchCounselorList").val() : null;
				if(sendToval == "" || sendToval == null){

					sendTo = []
				}else{

					sendTo.push($("#searchCounselorList").attr("data-cId"))
				}
			}
			if(userType != 'VICTIM'){

				sendTo = $("#send-to").val() ;
			}

			var sendCategory = $("#send-category").val();

			var self = this ;
			var categoryArr = sendCategory ;
			if(Utils.isMobileDevice()){
				categoryArr = new Array() ;
				var categorySelected = sendCategory.split(",");
				_.each(categorySelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					categoryArr.push(self.selectedCategories[elem.trim()]) ;
				});
			}


			var userArr = sendTo ;
			// if(Utils.isMobileDevice() && userArr != null){
			// 	userArr = new Array() ;
			// 	var usersSelected = sendTo.split(",");
			// 	_.each(usersSelected, function(elem){
			// 		if(!elem.trim()){
			// 			return false ;
			// 		}
			// 		userArr.push(self.selectedUsers[elem.trim()]) ;
			// 	});
			// }

			var subject = $("#subject").val();
			if( !Utils.isMobileDevice() ){
				var body = encodeURI(CKEDITOR.instances.message.getData());
			}else{
				var body = encodeURI($("#message").val().trim());
			}

			if( $(".user-friend").hasClass("hide") ){

				if( userArr == null || userArr.length < 1 ){

					$(".isend-to").show().parent().addClass("error");
					isError = true;
				}
				if( userArr != null && userArr.length > 1 ){
					$(".counselor-count-error.isend-to").show().parent().addClass("error");
					$(".counselor-count-error.isend-to").removeClass("hide");
					isError = true;
				}
			}

			if( sendCategory == null || categoryArr.length < 1 ){
				$(".isend-category").show();
				$(".category-field").addClass("error");
				isError = true;
			}

			if( subject == "" ){
				$(".isubject").show().parent().addClass("error");
				isError = true;
			}

			if( body.trim() == "" ){
				$(".imessage").show().parent().addClass("error");
				isError = true;
			}else if(body.trim().length < 100 ){
				$(".imessageCnt").show().parent().addClass("error");
				isError = true;
			}

			if( !isError ){

				if(self.attachmentIds.length == 0){

					self.attachmentIds = [-1];
				}

				if(Utils.isMobileDevice()){
					body = body.replace(/%0A/g, '<br />');
				}

				var msgJSON = {
						"threadID":self.threadID,
						"subject":subject,
						"content":body,
						"categoryIds":categoryArr,
						"status": "SENT",
						//"messageID": self.messageID,
						"attachmentIDs" : self.attachmentIds
					};


				if( sendTo != null ){

					msgJSON["recipients"] = userArr;

				}
				if(Utils.isMobileDevice()){

					$(".compose-overlay-div").removeClass("hide");
				}else{

					$("#compose-send-btn").addClass("disabled").html("Sending...");
				}
				//$("#compose-send-btn").addClass("disabled").html("Sending...");

				$.ajax({
	              method: "POST",
	              url: Utils.contextPath()+'/v1/users/'+this.model.get("userID")+'/messages',
	              data: JSON.stringify(msgJSON),
	              contentType: "application/json",
	              statusCode : {
              		417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						$(".iauthentication-error").html(errorMessage);
						$(".iauthentication-error").show() ;

					},
              		500 : function(){
						$(".iauthentication-error").html("Something went wrong. Please try again");
						$(".iauthentication-error").show() ;
					},

	              }
	          	}).done(function(response){
	          		//Utils.displaySuccessMsg("Your message has been sent.");
	          		if(!Utils.isMobileDevice()){

	          			$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          		}else{

	          			$(".compose-overlay-div").addClass("hide");
	          			$("#compose-send-btn").removeClass("disabled").html('<i class="mdi-content-send right"></i>');
	          		}

	          		Utils.closePopup('compose') ;
	          		$("#compose").remove();
					//show modal

	          		self.$el.find("#message-counselor-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg" style="padding:5%;display:flex;justify-content:center;align-items:center;"><span class="icon-done"><i class="mdi mdi-check"></i></span>Your message has been sent. You shall hear from us soon.</p><p style="padding:0% 5%">In the meanwhile, take a look at some of our trending content:</p><div class="trending_articals"><div class="row"><div class="col article-scroll-left"><i class="mdi-hardware-keyboard-arrow-left"></i></div><div class="col article-jcarousel"> <img class="popup-loader hide" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50"><ul class="articals_div"></ul></div><div class="col article-scroll-right"><i class="mdi-hardware-keyboard-arrow-right"></i></div></div>') ;

					var ArtcalsHtml = '';
					//self.$el.find(".articals_div").html('<img class="popup-loader" src="http://res.cloudinary.com/http-yourdost-com/image/upload/v1449585815/icons/loader.gif" width="50" height="50">');
					$('.article-jcarousel .popup-loader').removeClass('hide');
					$.ajax({
						method : "GET",
						url : Utils.blogJson(),
						dataType: 'jsonp' //"http://local.yourdost.com:9001/scripts/json/sample_blog.json" //
					}).done(function(response){
						$('.article-jcarousel .popup-loader').addClass('hide');
						//console.log("blog json " + JSON.parse(response.posts) );

						self.$el.find(".articals_div").html(self.BlogThumbailLayout({ post : response.posts }));
						$('.trending_articals .article-jcarousel').jCarouselLite({
						  btnNext: '.article-scroll-right',
						  btnPrev: '.article-scroll-left',
						});

					}).error(function(error){
						console.log(error);
					});

					self.$el.find("#message-counselor-modal .fixed-position-container").html( '<p class="modal-thank-msg" style="padding:55% 12%">Your message has been sent. You shall hear from us soon.</p>') ;

					Utils.openPopup( "message-counselor-modal" ) ;
					$("#message-counselor-modal.modal").css("max-height", "600px");
					//end modal
					$(".compose-overlay-div").removeClass("hide");
					return true;
	          	}).fail(function(error){
	          		console.log(error);
	          		if(!Utils.isMobileDevice()){

	          			$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          		}else{

	          			$(".compose-overlay-div").addClass("hide");
	          			$("#compose-send-btn").removeClass("disabled").html('<i class="mdi-content-send right"></i>');
	          		}
	          	});
			}else{
				// setTimeout(function(){
				// 	//$(".error-msg").hide();
				// 	//$(".input-field").removeClass("error");
				// },3000);
				return false;
			}
		},
		ThumbnailClick : function(e){
			e.preventDefault();
			e.stopPropagation();
			var url = "";
			if($(e.target).parents().hasClass("article-author")){
				url = $(e.target).parents(".article-author").find("a").attr("href");
			}else{
			 	url = $(e.currentTarget).attr("data-href");
			}
			window.open(url, "_blank");
		},
		openMessage: function(e){

			var msgId = $(e.currentTarget).attr("data-msgid");
			window.imsgType = $("#msg-block").attr("data-type");
			window.msgType = $(e.currentTarget).attr("data-type");

			if( $("#msg-block").attr("data-type") == "search" ){
				window.search = $("#msg-search-txt").val();
			}
			//location.href = "/user/messages/"+Utils.encodeString(msgId);
			Backbone.history.navigate("/user/messages/"+Utils.encodeString(msgId), {trigger: true});
			return this;
		},
		renderPaymentPending : function(){

			if(Utils.isLoggedIn()){

				this.paymentPendingView.render() ;
			}
		},
		checkForPendingRating : function(){

			var userID = this.userModel.getUserID() ;
			var self = this ;
			$.ajax({
				url : Utils.contextPath() + "/v1/users/" + userID + "/rating/pending"
			}).done(function(response){

				if(response.id){
					$(".review-bar").removeClass("hide");
					sessionStorage.setItem("reviewPendingInfo", JSON.stringify(response));
					self.$el.find("#review-counselor-name").html(response.name) ;

		          	if(!Utils.isMobileDevice()){

		          		//$(".review-bar").css({"margin-top" : "70px"});
		          		$("#msg-list-block").css({"margin-top" : "0px"});
					}

				}
			}).error(function(error){

			});
		},
		ConfirmSaveDraftLayout: JST['app/templates/messages/confirmSaveDraft.hbs'],
		render: function() {

			$(".modal").remove();
			console.log("charmelon");

			if(!Utils.isLoggedIn()){
				var hash = location.pathname;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash ;
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}

			var self = this;
			var user_id = self.userModel.getUserID() ;
			var userType = this.userModel.getUserType() ;


			self.$el.html(this.MessagePageLayout({user_id : user_id}));

			self.$el.append(this.ComposePageLayout({isMobileDevice:Utils.isMobileDevice(), userType : userType}));

			EventBus.trigger("renderCounselorDropDown", "counselor_dropdownlist_search")

			if(localStorage.getItem("fromAppointment") != undefined && localStorage.getItem("fromAppointment") == 1 ){
				this.bookAppointmentView.render();
			}

			self.renderPaymentPending() ;
			self.checkForPendingRating() ;

			var params = "";
			if(self.searchParam != undefined){
				var search = "content_search="+self.searchParam;
				params = {"search":search};
				$("#msg-search-txt").val(self.searchParam);
			}

			this.$el.find("#msg-block").find(".umsg-list-msg").addClass("hide");
			this.$el.find("#msg-block").find(".umsg-list-search").addClass("hide");

			if( window.search ){

          		params += JSON.parse( localStorage.getItem("msearch") );
          		self.loadMsgs(1,params);
          		$("#msg-search-txt").val( window.search );
          		this.$el.find("#msg-block").attr("data-type","search");
				this.$el.find("#msg-block").find(".umsg-list-search").removeClass("hide");
          	}else{
          		this.clearSearch();
          		if(self.searchParam != undefined){
          			$("#msg-search-txt").val(self.searchParam);
          		}
          		self.loadMsgs(1, params);
          		this.$el.find("#msg-block").attr("data-type","msg");
          		this.$el.find("#msg-block").find(".umsg-list-msg").removeClass("hide");
          	}


          	setTimeout(function(){$("#filter-msg-nav-btn").remove();},10);
			self.renderCategories();
			self.renderElements();
			self.bindScroll();
			self.fillMobileSearch();

			setTimeout(function() {
				$( ".email-draft-saving-msg" ).addClass( "hide" );
				$( ".email-draft-saved-msg" ).removeClass("hide");

			}, 3000);


			CKEDITOR.on('instanceCreated', function(e) {
                var listenerFn = function (event) {
			        // change event in CKEditor 4.x
			       // console.log('hello');
			        var body = $("#message").val().trim();
			        console.log( $(".imessageCnt").is(':visible') );
			        if ( $(".imessageCnt").is(':visible') ) {
			        	//console.log("pikachu");
			        	$(".imessage").hide();
						$(".imessageCnt").hide();
						$(".imessage").parent().removeClass('error');
			        }
			    };
			    e.removeListener('change', listenerFn);
			    e.editor.on('change', listenerFn);
				var buffer = this.tools.eventsBuffer( 500, function() {

                	//self.autoSaveMessage();

            	});
            	e.removeListener('change', buffer.input);
			    e.editor.on('change', buffer.input);
			  //   	function (event) {
			  //       // change event in CKEditor 4.x

			  //       buffer.input;
			  //       console.log( event );
			  //       console.log('hello2');
			  //       $(".email-draft-bar").removeClass( "hide" );
			  //       $( ".email-draft-saving-msg" ).removeClass( "hide" );
			  //       $( ".email-draft-saved-msg" ).addClass("hide");

			  //       var body = $("#message").val().trim();
			  //       console.log( $(".imessageCnt").is(':visible') );
			  //       if ( $(".imessageCnt").is(':visible') ) {
			  //       	console.log("pikachu");
			  //       	$(".imessage").hide();
					// 	$(".imessageCnt").hide();
					// 	$(".imessage").parent().removeClass('error');
			  //       }

					// if ( $(".imessage").parent().hasClass('error') ) {
					// 	$(".imessage").hide();
					// 	$(".imessageCnt").hide();
					// 	$(".imessage").parent().removeClass('error');

					// }

			  //   }
			});
			console.log( "hello" );

			setTimeout(function(){

          		if ( $(".review-bar").hasClass('hide') && $(".payment-pending").hasClass("hide") ){

	        	$("#msg-list-block").css({"margin-top" : "70px"});
		        }
		        if( $(".review-bar").hasClass('hide') && !$(".payment-pending").hasClass("hide") ){

		        	$("#msg-list-block").css({"margin-top" : "0px"});
		        }
		        if( !$(".review-bar").hasClass('hide') && $(".payment-pending").hasClass("hide") ){

		        	$("#msg-list-block").css({"margin-top" : "0px"});
		        	$(".review-bar").css({"margin-top" : "70px"})
		        }
          	}, 1000);

			return this;
		},
		loadMsgs: function(pno,params){

			var self = this;

			var type = "msg";
			if( params != undefined ){
				type = "search";
			}

			self.model.addWait();

			if( self.$el.find("#msg-block").find(".umsg-list-"+type).html() != "" ){
				$(".main-loader").addClass("mmain-loader");
			}

			this.isLoading = true;

			self.model.setMsgTypeUrl( pno , params );

			$.ajax({
              method: "GET",
              url: self.model.url,
              dataType: 'json'
          	}).done(function(response){

          		if( response.length > 0 ){

          			self.removeNoMessage();
          			_.each(response, function(msg){
						self.checkTypeAndCleanupMsgList( msg );
					});
					self.renderMsgs( type );
          		}else{

          			if( self.$el.find("#msg-block").find(".umsg-list-"+type).html() == "" ){
          				self.renderNoMessage();
          			}
          			self.unbindScroll();
          		}

          		self.model.setUnreadCount();
				self.updateUnreadCount();

          		self.$el.find("#msg-block").removeClass("hide");
          		Utils.adjustViewPortSize();
				self.model.removeWait();
				self.isLoading = false;

          	}).fail(function(error){

          		Utils.adjustViewPortSize();
          		self.model.removeWait();
				console.log(error);
          	});
		},
		fillMobileSearch: function(){

			if( window.device == "mobile" && window.search ){

				setTimeout(function(){
					$("#search-bar").css("left", 0);
					$("#msg-search-txt").val( window.search );
					$("#search-msg-mobile").val( window.search );
				},10);
			}
		},
		renderElements: function(){

			$("html, body").stop().animate({
	      		scrollTop: $("body").offset().top}, 1000,"easeInOutExpo");

			this.$el.find(".msg-compose").removeClass("hide");
			EventBus.trigger('removeChatScroll');
		},
		checkTypeAndCleanupMsgList: function( msg ){

			if( msg.type == "MAIL" ){
				this.parseEmailObj( msg.conversationDetail );
			}else if( msg.type == "CHAT" ){
				this.parseChatObj( msg.conversationDetail );
			}else{
				return false;
			}
		},
		parseEmailObj: function( cMsg ){

			if( cMsg.userMessage[0] == undefined )
				return false;
			console.log('parseEmailObj cMsg', cMsg);
			var threadID = cMsg.threadID;
			var body = cMsg.userMessage[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userMessage[0].receivedDate );
			var subject = cMsg.userMessage[0].subject;
			var read = cMsg.userMessage[0].read;
			var status = cMsg.status;

			if( cMsg.userMessage[0].messageType == "SENT_MAIL" ){
				var sender = [];
				_.each(cMsg.userMessage[0].toRecipients,function(user){
					var name = user.firstName != null ? user.firstName : user.username;
					sender.push(name);
				});
				sender = sender.join(",");
			}else{
				var sender = cMsg.userMessage[0].fromRecipient.firstName != null ? cMsg.userMessage[0].fromRecipient.firstName : cMsg.userMessage[0].fromRecipient.username;
			}

			if( cMsg.userMessage[0].fromRecipient.picUrl != undefined ){
				var fAvatar = cMsg.userMessage[0].fromRecipient.picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userMessage[0].fromRecipient.avatar+'.png';
			}

			var msg = {
				"threadID" : threadID,
				"body" : body,
				"subject" : subject,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "MAIL",
				"icon" : "mdi-arrow-left-bold-circle-outline received",
				"read" : read,
				"status": status
			};

			if( cMsg.userMessage[0].messageType == "SENT_MAIL" ){
				msg.icon = "mdi-arrow-right-bold-circle-outline sent";
				msg.read = true;
				msg.type = "SENT_MAIL";
			}

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		parseChatObj: function( cMsg ){

			if( cMsg.userChats[0].chatGroupUsers[0] == undefined )
				return false;

			var threadID = cMsg.threadID;
			var body = cMsg.userChats[0].body;
			var receivedTime = Utils.getDateDiff( cMsg.userChats[0].sentDate );
			var sender = cMsg.userChats[0].chatGroupUsers[0].firstName != null ? cMsg.userChats[0].chatGroupUsers[0].firstName : cMsg.userChats[0].chatGroupUsers[0].username;

			if( cMsg.userChats[0].chatGroupUsers[0].picUrl != undefined ){
				var fAvatar = cMsg.userChats[0].chatGroupUsers[0].picUrl;
			}else{
				var fAvatar = '/images/avatar/'+cMsg.userChats[0].chatGroupUsers[0].avatar+'.png';
			}

			var msg = {
				"threadID" : threadID,
				"body" : body,
				"avatar" : fAvatar,
				"receivedTime" : receivedTime,
				"sender" : sender,
				"count" : 1,
				"type" : "CHAT"
			};

			if( this.eMsgList[threadID] ){
				this.eMsgList[threadID]["count"] = this.eMsgList[threadID]["count"]+1;
				if( this.eMsgList[threadID]["sender"] != sender )
					this.eMsgList[threadID]["sender"] = this.eMsgList[threadID]["sender"]+","+sender;
			}else{
				this.eMsgList[threadID] = msg;
				this.msgOrder.push( threadID );
			}
		},
		renderMsgs: function( type ) {

			var self = this;
			if( self.msgOrder.length > 0 ){

				_.each(self.msgOrder, function(threadID){

					var msg = self.eMsgList[threadID];

					if( msg.type == "CHAT" ){
						self.renderChatMsg( msg , type );
					}else{
						self.renderEmailMsg( msg , type );
					}
				});
				self.eMsgList = [];
				self.msgOrder = [];
			}
		},
		renderEmailMsg: function( cMsg , type ){

			console.log( "cMsg ", cMsg );
			console.log( "type ", type );
			var draftIcon = '';
			if ( cMsg.status == 'DRAFT' ) {
				draftIcon = '<i class="mdi mdi-content-save email-draft-thread red-text"></i>';
			}

			console.log('cMsg', cMsg);
			var item = '<li class="collection-item avatar cpointer dost-msg-item hoverable '+ (( cMsg.read == true ) ? 'old' : '' )+'" data-msgid="'+cMsg.threadID+'" data-type="MAIL">'
				  			+'<div class="msg-img-holder">'
								+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
							+'</div>'
							+'<span class="title msg-title truncate '+ (( cMsg.read == true ) ? 'read' : 'notRead') +' ">'
							+'<i class="mdi '+cMsg.icon+' msg-icon"></i> '
							+cMsg.subject+ ( (cMsg.count > 1) ? ' <span class="msg-count">('+cMsg.count+')</span>' : '' ) +'</span>'
							+'<p class="msg-senders">'+cMsg.sender+'</p>'
							+'<p class="truncate msg-content '+(( cMsg.read == false ) ? 'mlist-new' : '' )+'">'+cMsg.body+'</p>'

							+'<a class="secondary-content msg-time">'
							+ draftIcon
							+cMsg.receivedTime+'</a>'
							+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
						+'</li>';

			this.$el.find("#msg-block").find(".umsg-list-"+type).removeClass("hide").append( item );
		},
		renderChatMsg: function( cMsg , type ){

			var item = '<li class="collection-item avatar cpointer dost-msg-item hoverable old chat" data-msgid="'+cMsg.threadID+'" data-type="CHAT">'
				  			+'<div class="msg-img-holder">'
								+'<img src="'+cMsg.avatar+'" alt="" class="circle msg-avatar z-depth-1">'
							+'</div>'
							+'<p class="msg-senders chat-title truncate"><i class="mdi mdi-comment-multiple-outline"></i> Chat with: '+cMsg.sender+'</p>'
							+'<p class="truncate msg-content">'+cMsg.body+'</p>'
							+'<a class="secondary-content msg-time">'+cMsg.receivedTime+'</a>'
							+'<i class="mdi mdi-dots-horizontal msg-dots"></i>'
						+'</li>';

			this.$el.find("#msg-block").find(".umsg-list-"+type).removeClass("hide").append( item );
		},
		renderCategories: function(){

			var categories = localStorage.getItem("categories");

	        if( !categories ){

            	var category = {};
            	var categories = {};
            	$.ajax({
                	method: "GET",
                	url: Utils.contextPath()+'/category?include_faq=false'
            	}).done(function(response){
              		_.each(response,function(cat){
                		category[cat.id] = cat.name;
                		categories["c_" + cat.id] = cat.name;
              		});
              		localStorage.setItem("categories",JSON.stringify(category));
              		localStorage.setItem("c_categories",JSON.stringify(categories));
            	}).fail(function(error){});
          	}
		},
		renderNoMessage: function(){
			this.$el.find("#msg-list-block").addClass("hide");
			this.$el.find("#no-msg-list-block").removeClass("hide");
		},
		removeNoMessage: function(){
			this.$el.find("#msg-list-block").removeClass("hide");
			this.$el.find("#no-msg-list-block").addClass("hide");
		},
		clearSearch: function(){
	    	localStorage.removeItem( "msearch" );
	    	$("#msg-search-txt").val("");
	    	window.search = false;
	    	this.$el.find(".umsg-list-search").addClass("hide").html("").attr("page_number",1);
	    },
		bindScroll: function(){
			var self = this;
			$(window).scroll(function() {
		        self.checkScroll();
		    });
		},
		unbindScroll: function(){
			$(window).unbind("scroll");
		},
	    checkScroll: function () {

	        var triggerPoint = 100; // 20px from the bottom
	        var type = $("#msg-block").attr("data-type");
	        if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {

	          var pno = $("#msg-block").find(".umsg-list-"+type).attr("page_number");
	          pno = parseInt(pno) + 1;

	          	var params = '' ;
				if(this.searchParam != undefined){
					var search = "content_search="+this.searchParam;
					params = {"search":search};
				}

	          if( type == "search" ){
	          	 params = JSON.parse(localStorage.getItem("msearch"));
	          	this.loadMsgs(pno,params);
	          }else{
	          	this.loadMsgs(pno,params);
	          }
	          $("#msg-block").find(".umsg-list-"+type).attr("page_number",pno);
	        }
	    },
	    autoRefresh: function( obj ){

	    	obj.interval = setInterval(function(){

	    	},60000);
	    }
	});

	MessagePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	MessagePage.prototype.clean = function() {
		this.remove();
	};

	return MessagePage;
});
