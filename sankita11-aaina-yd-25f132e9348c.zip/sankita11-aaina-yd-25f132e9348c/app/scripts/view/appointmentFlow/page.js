define([
	'jquery',
	'underscore',
	'moment-timezone-data',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/appointment',
	'model/users',
	'model/login',
	'view/needHelp/page',
	'jcarousellite',
	'jstz',
	'keystop',
	'Swiper'
	//'RazorPay'
], function ($, _, moment, Backbone, JST, Dispatcher, Utils, AppointmentModel, UserModel, LoginStatus, NeedHelpView) {

	var AppointmentFlowView = Backbone.View.extend({

		el: 'main',
		initialize: function () {

			var self = this;

			self.model = new LoginStatus();
			self.userModel = new UserModel();
			self.locationString = blogOrigin;
			self.appointmentModel = new AppointmentModel();
			self.needHelpView = new NeedHelpView()
			self.appointmentModel.set('counselorname', "");
			self.appointmentModel.set('backFromFuture', false);
			self.appointmentModel.set('backFromFuturetoCon', false)
			self.appointmentModel.set('conSource', '');
			self.discountedValue = null;
			self.applyOfferEnable = false;
			self.offerApplied = false;
			self.pendingFeedback = null;
			self.fromLocation = '';
			self.appointmentModel.set('categoriesArray', ["Career", "Family", "Love-Relationship", "Friends", "Others", "", "", "Appointment", "Career Confusion", "Unemployed", "Office Stress", "Concentration", "Anger", "Procrastination", "Competitive Exam Support", "Startup support", "Broken Hearts", "Marriage", "Family Issues", "Shyness", "Social Fear", "Addiction", "Sexual-Wellness", "Porn", "Abuse", "LGBT", "Traumatic Experience", "Body Image", "Loneliness", "Bullying", "Parenting", "Peer Pressure", "Exam Support", "Mood Swings", "Motivation", "Anxiety Disorders", "Child Behavior", "Grief", "Self-esteem"]);
			self.categoryList = null;
			self.subCategoryList = null;
			var url = window.location.href;
			url = url.replace(self.locationString + "/bookAppointment", "");
			console.log('url', url);
			if (url == '') {
				self.fromLocation = 'bookAppointment'
				self.appointmentModel.set('category', '');

			} else if (url.indexOf('?type=f2f') > -1) {
				self.fromLocation = "face2face"
				self.appointmentModel.set('counselorid', 101);
				self.appointmentModel.set('mode', 'face2face');
			}
			else if (url.indexOf('?yd_source=zenparent') != -1) {
				console.log('zenparent' + url);
				self.fromLocation = 'zenparent';
				self.appointmentModel.set('counselorid', 101);

			}
			else {

				self.fromLocation = $.url(url).param('from');
				if (self.fromLocation == 'talkItOut' || self.fromLocation == 'counselor' || self.fromLocation == 'packages') {
					var counselorName = '';
					self.catVar = $.url(url).param('catID');
					self.counselorVar = $.url(url).param('conID');
					if (self.catVar == 'Career-Academic' || self.catVar == "Career/Academic") {
						self.catVar = 'Career Confusion';
					}

					$.ajax({
						url: Utils.contextPath() + "/v1/counselor/" + self.counselorVar
					}).done(function (elem) {

						console.log(elem.name);
						self.appointmentModel.set('counselorid', elem.id);
						self.appointmentModel.set('counselorname', elem.name);
						if (self.fromLocation == 'packages') {
							$.ajax({
								url: Utils.contextPath() + "/packages/" + self.catVar,
							}).done(function (response) {
								self.appointmentModel.set('category', response.name);
								//change package response
							});
						} else {
							self.appointmentModel.set('category', self.catVar);
						}
					});
				}
				if (self.fromLocation == 'payment' || self.fromLocation == 'paymentReschedule') {
					var transactionID = $.url(url).param('t');
					if (transactionID != '') {
						self.appointmentModel.set('transactionID', transactionID);
					} else {
						console.log('parameters not correct!');
					}
				}
				if (self.fromLocation == 'reschedule') {
					self.catVar = $.url(url).param('catID');
					self.counselorVar = $.url(url).param('conID');
					self.modeVar = $.url(url).param('mode');
					self.slotVar = $.url(url).param('slottime');
					var appID = $.url(url).param('appointmentID');
					self.appointmentModel.set('appointmentId', appID);
					var categories = self.appointmentModel.get('categoriesArray');
					self.appointmentModel.set('category', categories[self.catVar]);
					$.ajax({
						url: Utils.contextPath() + "/v1/counselor/" + self.counselorVar
					}).done(function (elem) {
						console.log(elem.name);
						self.appointmentModel.set('counselorid', elem.id);
						self.appointmentModel.set('counselorname', elem.name);
						self.appointmentModel.set('conSource', 'DropDown');
					});
					var mode = self.modeVar.toUpperCase();
					if (mode != '' && mode != 'CHAT') {

						var t = new Date(self.slotVar);
						var mm = t.getMonth();
						var dd = t.getDate();
						var hh = t.getHours();
						var m = t.getMinutes();
						if (dd < 10) { dd = '0' + dd; }
						if (m < 10) { m = '0' + m; }
						var Months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
						var date_final = Months_arr[mm] + " " + dd;
						var time = hh + ":" + m;
						self.appointmentModel.set('mode', mode);

						self.appointmentModel.set('slotdate', date_final);
						self.appointmentModel.set('slottime', time)
					}

				}

			}

			//this.render();
			this.f2fTypes = [
				{
					"title": "individual",
					"imgUrl": "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/face2face/f2f-web-type-individual-192x110.png",
					"price": 1000,
					"people": "1 Person"
				},
				{
					"title": "couple",
					"imgUrl": "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/face2face/f2f-web-type-couple-192x110.png",
					"price": 1500,
					"people": "2 People"
				},
				{
					"title": "group",
					"imgUrl": "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/face2face/f2f-web-type-group-192x110.png",
					"price": 2000,
					"people": "2-4 People"
				}
			]
		},
		SteponeLayout: JST['app/templates/AppointmentFlow/layoutone.hbs'],
		SteptwoLayout: JST['app/templates/AppointmentFlow/layouttwo.hbs'],
		StepthreeLayout: JST['app/templates/AppointmentFlow/layoutthree.hbs'],
		AppointmentRecievedLayout: JST['app/templates/AppointmentFlow/appointmentrecieved.hbs'],
		AppointmentConfirmationLayout: JST['app/templates/AppointmentFlow/appointmentConfirmation.hbs'],
		UpdateInfoLayout: JST['app/templates/AppointmentFlow/Updatecontactinfo.hbs'],
		LoginInfoLayout: JST['app/templates/AppointmentFlow/login.hbs'],
		ExpertCardStep3: JST['app/templates/AppointmentFlow/expert_card_stepthree.hbs'],
		ExpertCard: JST['app/templates/AppointmentFlow/expert_card.hbs'],
		ExpertCard2: JST['app/templates/AppointmentFlow/expert_card2.hbs'],
		FeedbackModal: JST['app/templates/AppointmentFlow/feedback.hbs'],
		BundleAppointmentsModal: JST['app/templates/AppointmentFlow/bundle_appointments.hbs'],
		face2faceLayout: JST['app/templates/AppointmentFlow/f2flayout.hbs'],
		extrapayModalLayout: JST['app/templates/AppointmentFlow/extrapay_modal.hbs'],
		events: {
			"click .next-1": "nextPage1",
			"click .next-2": "nextPage2",
			"click .next-3": "bookModeofContact",
			"click .category": "categorySelected",
			"click .cat-o": "categorySelected",
			"click .tab": "clickTabStep2",
			"click .top-expert-check": "expertSelected",
			"click #default-counselor": "expertSelected",
			"click .fam-experts": "expertSelected",
			"click .expt-drop-item": "selectFromDropDown",
			"click #dropArrow": "dropArrow",
			"click #selected-expert-dropdown": "dropArrow",
			"click .mode-li": "selectModeofContact",
			//"click #bookMode" :"bookModeofContact",
			"click #update-info-form": "UpdatecontactInfo",
			//"click #update-info-form":"initializeRazorPay",
			"click .slot-cell": "slotClicked",
			"click .date-cell": "dateClicked",
			"click #submit-otp": "SubmitOtp",
			"click .back-2": "backtoStart",
			"click .back-3": "backtoExperts",
			"click .backToTalkItOut": "backToTalkItOut",
			"click .back-4": "backtoMode",
			"click .back-5": "backtoUpdate",
			"click #backTosignup": "backtoUpdate",
			"click .login-appointment": "loginAppointment",
			"click #open-login": "initializeLogin",
			"focusout #appointment-user-info #email": "validateEmail",
			"focusout #phone": "validatePhoneno",
			"focusout #appointment-user-info #username": "validateUsername",
			// "mouseover .category": "hoverCategory",
			// "mouseout  .category" : "unhoverCategory",
			"mouseover .expt-dropdown-content li": "hoverDropDown",
			"click .resend-code": "resendCode",
			'keyup #selected-expert-dropdown': 'searchCounselorList',
			"click #submit-age": "submitAge",
			"click #submit-gender": "submitGender",
			"click .conversationLink": "viewConversation",
			"click #skip-1": "skipGender",
			"click #skip-2": "skipAge",
			"focusout #age-input": "validateAge",
			"click #tab2": "closeDrop",
			"click #close-otp": "closeOTP",
			"click #fb-login-button-app": "loginFBappointment",
			//"focusout .offer-name":"checkIfOfferExists",
			"click #apply-offer": "applyOfferForDummy",
			"click .change-offer": "haveAPromo",
			"click #submit-feedback-appointment": "submitFeedback",
			"click #bundle .close": "appointmentConfirmation",
			"click #bundle .continue": "appointmentConfirmation",
			"click #bundle .buy": "buyBundle",
			'click #f2fType .type-card': "f2fType",
			'click .select-city': 'showCities',
			'click .select-area': 'showAreas',
			'click .select-cities li': 'selectCity',
			'click .select-areas li': 'selectArea',
			'click .select-date': 'showDates',
			'click .select-dates li': 'selectDate',
			'click #f2fLayout .next-4': 'appointmentConfirmation',
			'click .extrapay-btn': 'handleExtraPay',
			'click .ps-d-btn': 'redirectToAppointent',
			'change #sel-category-div': 'getSelectedCatVal',
			'change #sub-category-div': 'onSubCategoryChange',
			//"click .have-a-promo":"haveAPromo",
		},
		redirectToAppointent: function (e) {
			Backbone.history.navigate("/bookAppointment", { trigger: true });
		},
		getDates: function (startDate, addDays) {
			var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
			var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
			var currentDate = startDate
			var dates = []
			for (var i = 1; i <= addDays; i++) {
				var nextDate = new Date(currentDate.setDate(startDate.getDate() + 1))
				dates.push(days[nextDate.getDay()] + ", " + nextDate.getDate() + " " + months[nextDate.getMonth()] + " " + nextDate.getFullYear())
			}
			return dates;
		},
		showDates: function (e) {
			var startDate = new Date()
			startDate = startDate.setDate(startDate.getDate() + 2)
			var dates = this.getDates(new Date(startDate), 7);
			var html = ''
			dates.forEach(function (elm) {
				html += '<li class="select-date-item" data-value="' + elm + '">' + elm + '</li>'
			})
			$(e.currentTarget).parents(".select-date-div").find("i").addClass("active")
			document.querySelector('.select-dates').innerHTML = html
			document.querySelector('.select-dates').classList.remove('hide')
			if (!this.appointmentModel.get("date")) document.querySelector('.select-date').classList.remove("selected")
		},
		selectDate: function (e) {
			$(".select-dates li").removeClass('selected')
			e.currentTarget.classList.add('selected')
			var date = e.currentTarget.getAttribute("data-value")
			document.querySelector('.select-date').value = date
			document.querySelector('.select-date').classList.add("selected")
			document.querySelector('.select-dates').classList.add('hide')
			$(e.currentTarget).parents(".select-date-div").find("i").removeClass("active")
			this.appointmentModel.set("date", date)
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Face To Face", { "mediumSource": "website", itemName: "Date Selected", item: date });
			}
			this.enableNext()
		},
		enableNext: function () {
			if (this.appointmentModel.get("city") && this.appointmentModel.get("area")
				&&
				this.appointmentModel.get("date") && this.appointmentModel.get("f2fType")
			) {
				$(".next-4").removeClass("disabled")
			} else {
				$(".next-4").addClass("disabled")
			}
		},
		f2fType: function (e) {
			var self = this;
			var el = document.querySelectorAll(".type-card")
			el.forEach(function (elm) {
				if (elm.classList.contains('selected')) {
					elm.classList.remove('selected')
				}
			})
			var targetElm = e.currentTarget ? e.currentTarget : e.srcElement;
			targetElm.classList.add('selected')
			var type = targetElm.getAttribute("data-type")
			this.appointmentModel.set("f2fType", type)
			this.f2fTypes.forEach(function (obj) {
				if (obj.title == type) self.appointmentModel.set('rate', obj.price)
			})
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Face To Face", { "mediumSource": "website", itemName: "Type Selected", item: type });
			}
			this.enableNext()
		},
		getOptions: function (className, cities) {
			var sortedCities = cities.sort();
			var html = ''
			_.each(sortedCities, function (city) {
				html += '<li class="' + className + '" data-value="' + city + '">' + city.toUpperCase() + '</li>'
			})
			return html;
		},
		selectCity: function (e) {
			$(".select-cities li").removeClass('selected')
			e.currentTarget.classList.add('selected')
			var city = e.currentTarget.getAttribute("data-value")
			document.querySelector('.select-city').value = city
			document.querySelector('.select-city').classList.add("selected")
			var areas = this.citiesObj[city]
			var html = this.getOptions("areas", areas)
			document.querySelector('.select-areas').innerHTML = html
			document.querySelector('.select-area').classList.remove("selected")
			document.querySelector('.select-area').value = ''
			document.querySelector('.select-cities').classList.add('hide')
			$(e.currentTarget).parents(".select-city-div").find("i").removeClass("active")
			this.appointmentModel.set("city", city)
			this.appointmentModel.set("area", '')
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Face To Face", { "mediumSource": "website", itemName: "City Selected", item: city });
			}
			this.enableNext()
		},
		selectArea: function (e) {
			$(".select-areas li").removeClass('selected')
			e.currentTarget.classList.add('selected')
			var area = e.currentTarget.getAttribute("data-value")
			document.querySelector('.select-area').value = area
			document.querySelector('.select-area').classList.add("selected")
			document.querySelector('.select-areas').classList.add('hide')
			$(e.currentTarget).parents(".select-city-div").find("i").removeClass("active")
			this.appointmentModel.set("area", area)
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Face To Face", { "mediumSource": "website", itemName: "Area Selected", item: area });
			}
			this.enableNext()
		},
		showAreas: function (e) {
			if (!this.appointmentModel.get("area")) document.querySelector('.select-area').classList.remove("selected")
			document.querySelector('.select-areas').classList.remove("hide")
			$(e.currentTarget).parents(".select-city-div").find("i").addClass("active")
		},
		showCities: function (e) {
			var cities = Object.keys(this.citiesObj)
			if (!this.appointmentModel.get("city")) document.querySelector('.select-city').classList.remove("selected")
			document.querySelector('.select-city').value = ''
			var html = this.getOptions("cities", cities)
			$('.select-cities').removeClass("hide").html(html)
			$(e.currentTarget).parents(".select-city-div").find("i").addClass("active")
		},
		haveAPromo: function () {
			$('.have-a-promo').addClass('hide');
			$('.success-offer-msg').addClass('hide');
			$('.apply-offer').removeClass('hide');
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Button Click", { "itemName": "Promotion Clicked" });
			}
		},
		applyOfferForDummy: function () {
			var self = this;
			self.discountedValue = self.appointmentModel.get('rate');
			if (!Utils.isLoggedIn()) {
				self.checkIfOfferExists()
					.then(function (res) {
						if (res) {
							$('.error-offer-msg').addClass('hide');
							var offer_name = $('.offer-name').val();
							if (!offer_name) return;
							self.offerName = offer_name;
							var mode = self.appointmentModel.get('mode');
							if (mode == 'Voice Call') {
								mode = "AUDIO";
							}
							if (mode == 'Video Call') {
								mode = "VIDEO";
							}

							var dataToSend = {
								"offer_name": offer_name,
								"product_type": mode,
								"no_of_items": 1,
								"cart_value": parseInt(self.appointmentModel.get('rate'))
							}
							$.ajax({
								url: Utils.contextPath() + "/v1/offers/check_apply",
								method: 'POST',
								dataType: "json",
								xhrFields: {
									withCredentials: true
								},
								contentType: "application/json",
								data: JSON.stringify(dataToSend),
							}).done(function (resp) {
								if (!resp.errorMsg) {
									//self.user_offer_mapping_id = parseInt(resp.user_offer_mapping_id);
									self.discountedValue = resp.after_discount_value;
									$('.apply-offer').addClass('hide');
									$('.success-offer-msg').removeClass('hide');
									$('#charges-appointment').css({ 'text-decoration': 'line-through' });
									$('#charges-appointment').addClass('red-text');
									$('#charges-discount-appointment').removeClass('hide');
									$('#charges-discount-appointment').text(self.discountedValue);
									if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
										mixpanel.track("Button Click", { "itemName": offer_name, 'status': 'successful' });
									}
									self.applyOfferEnable = true;
								} else {
									$('.error-offer-msg').text(resp.errorMsg);
									$('.error-offer-msg').removeClass('hide');
									if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
										mixpanel.track("Button Click", { "itemName": offer_name, 'status': 'error' });
									}

								}

							})
								.error(function (err) {
									alert(err)
								});
						} else {
							$('.error-offer-msg').text("Invalid coupon code");
							$('.error-offer-msg').removeClass('hide');
							if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
								mixpanel.track("Button Click", { "itemName": offer_name, 'status': 'error' });
							}
							$('#charges-appointment').css({ 'text-decoration': 'none' });
							$('#charges-appointment').removeClass('red-text');
							$('#charges-discount-appointment').addClass('hide');

						}
					});
			} else {
				self.applyOffer();
			}
		},
		applyOffer: function (name) {
			var self = this;
			self.discountedValue = self.appointmentModel.get('rate');
			var offer_name = name || $('.offer-name').val();
			if (!offer_name) return;
			self.offerName = offer_name;
			var mode = self.appointmentModel.get('mode');
			if (mode == 'Voice Call') {
				mode = "AUDIO";
			}
			if (mode == 'Video Call') {
				mode = "VIDEO";
			}
			if (mode == 'face2face') {
				mode = "FACE2FACE";
			}
			if (self.appointmentModel.get('insta')) mode = 'INSTANT_AUDIO';
			var dataToSend = {
				"offer_name": offer_name,
				"product_type": mode,
				"no_of_items": 1,
				"cart_value": parseInt(self.appointmentModel.get('rate'))
			}

			$.ajax({
				url: Utils.contextPath() + "/v1/offers/" + self.userModel.getUserID() + "/apply",
				method: 'POST',
				dataType: "json",
				xhrFields: {
					withCredentials: true
				},
				contentType: "application/json",
				data: JSON.stringify(dataToSend),
			}).done(function (resp) {
				if (!resp.errorMsg) {
					self.user_offer_mapping_id = parseInt(resp.user_offer_mapping_id);
					self.discountedValue = resp.after_discount_value;
					$('.error-offer-msg').addClass('hide');
					$('.apply-offer').addClass('hide');
					$('.success-offer-msg').removeClass('hide');
					$('#charges-appointment').css({ 'text-decoration': 'line-through' });
					$('#charges-appointment').addClass('red-text');
					$('#charges-discount-appointment').removeClass('hide');
					$('#charges-discount-appointment').text(self.discountedValue);
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Offer Applied", { "itemName": offer_name, 'status': 'sucess' });
					}
					self.applyOfferEnable = false;
					self.offerApplied = true;
					if (name) self.redirectToPayment();

				} else {
					if (name) return;
					if (self.audioPromo || self.videoPromo || self.f2fPromo) {
						$('.error-offer-msg').text(resp.errorMsg);
						$('.error-offer-msg').removeClass('hide');
						return;
					}
					$('.razorpay-container').addClass('hide')
					self.$el.html(self.AppointmentRecievedLayout());
					$(".multi-user-screen").append(self.UpdateInfoLayout());
					$('select').material_select();
					console.log('category select 1', $('select'));
					self.renderAppointmentRecieved();
					if (Utils.isLoggedIn()) {
						$('#appointment-user-info #username').val(self.userModel.getUserName());
						$('#appointment-user-info #username').focus();
						$('#appointment-user-info #username').addClass('disabled');
						$('#appointment-user-info #email').val(self.userModel.getUserEmail());
						$('#appointment-user-info #email').focus();
						$('#phone').val(self.userModel.getPhoneNo());
						$('#phone').focus();
						$('#showHideLogin').addClass('hide');

					}
					$('#int-no').prop('checked', false)
					$('#error-phoneno-msg').addClass('hide');
					if (self.appointmentModel.get('mode') == 'Video Call' || self.appointmentModel.get('mode') == 'VIDEO') {
						$('#email-div label').text("SkypeID/Email")
					}
					$('.razorpay-container').addClass('hide')
					$('.have-a-promo').addClass('hide');
					$('.apply-offer').removeClass('hide')
					$('.error-offer-msg').text(resp.errorMsg);
					$('.error-offer-msg').removeClass('hide');
					$('.offer-name').val(self.offerName);
					if (JSON.parse(localStorage.getItem("user"))["loggableUser"]["orgId"] != -1) {
						$(".not-org").addClass("hide")
						$(".org").removeClass("hide")
					}
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Offer Applied", { "itemName": offer_name, 'status': 'error' });
					}
					self.applyOfferEnable = true;
					//window.location.pathname = "/bookAppointment";
				}

			});
		},
		checkIfOfferExists: function () {

			var offer_name = $('.offer-name').val();
			var deferred = $.Deferred();
			$.ajax({
				url: Utils.contextPath() + "/v1/offers/" + offer_name + "/exists",
			}).done(function (response) {
				deferred.resolve(response);
			});
			return deferred.promise();

		},
		closeOTP: function () {
			$('#verifyOtpModal').closeModal();

		},
		closeDrop: function (e) {
			if (!$(e.currentTarget).parent().hasClass('expt-dropdown-bar')) {
				if ($('.expt-dropdown-content').is(":visible")) {
					$('.expt-dropdown-content').addClass('hide');

					$('.swiper-button-next').css({ 'top': '50%' });
					$('.swiper-button-prev').css({ 'top': '50%' });

				}
			}
		},
		viewConversation: function (e) {
			var self = this;
			var counselorName = $(e.currentTarget).attr("cName");

			counselorName = counselorName.replace(/\s.*?$/, "");
			console.log(self.locationString + "/user/messages?s=" + counselorName);
			window.open(self.locationString + "/user/messages?s=" + counselorName, '_blank');

		},
		dropArrow: function (e) {
			e.stopPropagation();
			if ($('.expt-dropdown-content').is(":visible")) {
				$('.expt-dropdown-content').addClass('hide');
				$('.swiper-button-next').css({ 'top': '50%' });
				$('.swiper-button-prev').css({ 'top': '50%' });

			} else {
				$('html,body').animate({ scrollTop: $(e.currentTarget).offset().top + $(".af-exprt-dropdown").height() - 60 }, 'slow')
				$('#selected-expert-dropdown').focus();
				$('#selected-expert-dropdown').text("");
				$('#selected-expert-dropdown').val("");
				this.searchCounselorList();
			}
		},
		validateAge: function () {
			var age = $('#age-input').val();
			var isNumber = /^\d+$/.test(age);
			if (!isNumber) {
				$('#error-age-msg').removeClass('hide');
				$('#error-age-msg').addClass('red-text');
				$('#error-age-msg').text('Age cannot be in alphabets.')
			}
			else {
				$('#error-age-msg').addClass('hide');
				$('#error-age-msg').removeClass('red-text');
			}

		},
		skipGender: function () {
			$('.extra-info-gender').addClass('hide');
			$('.extra-info-age').removeClass('hide');
		},
		skipAge: function () {
			$(".extra-info-header").css({ "visibility": "hidden" })
			$('.extra-info-age').addClass('hide');
			location.href = this.locationString;

		},
		submitGender: function () {
			var gender = $('input[name = "gender"]:checked').val();
			this.updateUser('Gender', gender.toUpperCase());
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Gender Entered", { "mediumSource": "website", "itemName": 'bookAppointment' });
			}
			$(".extra-info-header").css({ "visibility": "hidden" })
			$('.extra-info-gender').addClass('hide');
			$('.extra-info-age').removeClass('hide');
		},
		submitAge: function () {
			var self = this;
			var age = $('#age-input').val();
			self.updateUser('Age', age);
			$('.extra-info-age').addClass('hide');
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Age Entered", { "mediumSource": "website", "itemName": 'bookAppointment' });
			}
			$(".extra-info-header").addClass("hide")
			location.href = self.locationString;
		},

		renderAppointmentConfirmation: function () {
			var self = this;
			var appointmentID = self.appointmentModel.get('transactionID');
			var transactionPromise = $.ajax({
				url: Utils.contextPath() + "/v1/user/transaction/" + appointmentID
			});
			var offersPromise = $.ajax({
				url: Utils.contextPath() + "/v2/users/" + self.userModel.getUserID() + "/offers"
			});
			$.when(transactionPromise, offersPromise)
				.done(function (response, offerDetails) {
					response = response[0];
					offerDetails = offerDetails[0];
					//var amount_final = response.amount;
					var type_final = response.lineItems[0].product.type;
					var audioAppointmentType;;
					if (type_final == 'INSTANT_AUDIO') {
						audioAppointmentType = 'instant';
					} else {
						audioAppointmentType = 'regular;'
					}
					for (var i = 0; i < offerDetails.length; i++) {
						if (offerDetails[i]['discounted_product_type'] == type_final && offerDetails[i]['redemption_count'] == 1) {
							var appliedOfferDetails = offerDetails[i];
							break;
						}
					}
					if (type_final !== "OFFLINE_PAYMENTS") {
						var t = new Date(response.lineItems[0].product.appointment.slotStartTime);
						var categoryId = response.lineItems[0].product.appointment.area;

						var categories = self.appointmentModel.get('categoriesArray');

						if (categories == '' || categories == null) {
							categories = 'Others'
						}
						var topic_final = categories[categoryId];
						if (self.fromLocation == 'packages') {
							topic_final = self.appointmentModel.get('category');
						}
						console.log(topic_final);
						var mm = t.getMonth();
						var dd = t.getDate();
						var hh = t.getHours();
						var m = t.getMinutes();
						if (dd < 10) { dd = '0' + dd; }
						if (m < 10) { m = '0' + m; }
						var Months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
						var date_final = Months_arr[mm] + " " + dd;

						var time = hh + ":" + m;
						var time_final = self.tconvert(time);
					}
					var counselorID = 1912
					if (type_final !== "OFFLINE_PAYMENTS") counselorID = response.lineItems[0].product.appointment.counselorID;

					console.log()
					if (type_final == 'AUDIO') {
						type_final = "Voice Call";
					}
					if (type_final == 'VIDEO') {
						type_final = "Video Call";
					}
					if (type_final == 'CHAT') {
						type_final = "Text Chat";
					}
					if (type_final == "INSTANT_AUDIO") {
						type_final = "Instant Audio";
					}
					var final_amount = response.amount - response.discount;

					if (final_amount < 1) final_amount = 0;
					if (appliedOfferDetails && !final_amount) {
						var options = {
							'name': appliedOfferDetails.name,
							'type': type_final === 'FACE2FACE' ? 'Face To Face' : type_final,
							'sessions': appliedOfferDetails.overall_quota,
							'remaining': appliedOfferDetails.overall_quota - appliedOfferDetails.redemption_count
						}
						self.$el.html(self.AppointmentConfirmationLayout({ 'details': options }));
					} else {
						var options = {}
						if (type_final === "FACE2FACE") {
							options.type = "Face To Face"
							options.cType = response.lineItems[0].product.appointment.counselingType.toLowerCase();
							options.city = response.lineItems[0].product.appointment.counselingCenter + ", " + response.lineItems[0].product.appointment.counselingCity.toUpperCase()
						}
						options.extraPay = false
						if (type_final === 'OFFLINE_PAYMENTS') {
							options.extraPay = true;
							options.extrapayId = response.id;
							var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
							var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
							var metaData = JSON.parse(response.lineItems[0].product.productDetails.metadata);
							var date = new Date(parseInt(metaData.dateOfAppt));
							options.date = days[date.getDay()] + ", " + months[date.getMonth()] + " " + date.getDate() + ", " + date.getFullYear();
							options.amount = response.amount;
							options.type = response.lineItems[0].product.productDetails.prouctType;
							if (options.type === "INSTANT_AUDIO") {
								options.type = "Instant Audio"
							}
							if (options.type === "AUDIO") {
								options.type = "Audio Call"
							}
							if (options.type === "VIDEO") {
								options.type = "Video Call"
							}
							options.cName = metaData.counselorName;
						}
						self.$el.html(self.AppointmentConfirmationLayout({ options: options }));
					}
					var mode = "regular"
					if (type_final === "FACE2FACE") {
						mode = response.lineItems[0].product.appointment.counselingType.toLowerCase();
					}
					if (appliedOfferDetails) {
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Payment successful Appointment Confirmation", { "mediumSource": "website", "itemName": 'bookAppointment', 'counselorID': counselorID, 'planType': type_final.split(" ")[0] + appliedOfferDetails.overall_quota, 'type': type_final, 'mode': mode });
						}
					} else {
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Payment successful Appointment Confirmation", { "mediumSource": "website", "itemName": 'bookAppointment', 'counselorID': counselorID, 'type': type_final, 'mode': mode });
						}
					}


					if (self.fromLocation == 'packages') {
						$('.rowtabular:contains("Charges")').addClass('hide')
					}
					self.needHelpView.render("step-3", false)
					Utils.appendGoogleConversion(final_amount)
					$('.appointment-confirm-details #charges-appointment').text(final_amount);
					type_final = type_final === 'FACE2FACE' ? 'Face To Face' : type_final

					if (type_final !== 'OFFLINE_PAYMENTS') {
						$('.appointment-confirm-details #type-appointment').text(type_final);
						$('.appointment-confirm-details #date-appointment').text(date_final);
						$('.appointment-confirm-details #time-appointment').text(time_final);
						$('.appointment-confirm-details #topic-appointment').text(topic_final);
						$.ajax({
							url: Utils.contextPath() + "/v1/counselor/" + counselorID
						}).done(function (elem) {
							console.log(elem.name);
							if (counselorID == 101) {
								elem.name = "Best Available Expert";
							}
							$('.appointment-confirm-details #expert-appointment').text(elem.name);

						});
					}
					console.log('fetch appointment', response);

				});
			$.ajax({
				method: "GET",
				url: Utils.contextPath() + "/v2/users/" + self.userModel.getUserID() + "/profile",
			}).done(function (response) {
				console.log('user object from profile api', response);
				var age = response['customProperties']['age'];
				var gender = response['customProperties']['gender'];
				if (gender != undefined && gender != null && gender != '') {
					$('.extra-info-gender').addClass('hide');
					$('.extra-info-age').removeClass('hide');
					if (age != undefined && age != null && age != '') {
						$('.extra-info-age').addClass('hide');
						$('#text-age-gender').addClass('hide');
						$('.back-to-homepage').removeClass('hide');
					}
				}
				if (gender && age) {
					$(".extra-info-header").css({ "visibility": "hidden" })
				}
			});
		},
		searchCounselorList: function (e) {

			var self = this;
			var search_term = $("#selected-expert-dropdown").val();


			if (search_term == '' || search_term == ' ') {

				$('.swiper-button-next').css({ 'top': '37%' });
				$('.swiper-button-prev').css({ 'top': '37%' });
				$('.expt-dropdown-content').removeClass('hide');
				$('.expt-drop-item').removeClass('hide')

			}
			else {
				$('.expt-dropdown-content').removeClass('hide');
				$('.expt-drop-item').addClass('hide');

				$('.swiper-button-next').css({ 'top': '40%' });
				$('.swiper-button-prev').css({ 'top': '40%' });

				$('.expt-drop-item').each(function () {
					console.log($(this).find('#exprt-name').text());
					if ($(this).find("#exprt-name").text().toUpperCase().indexOf(search_term.toUpperCase()) != -1) {

						$(this).removeClass('hide');
					} else {

						$(this).addClass('hide');
					}
				});
			}


		},
		resendCode: function () {
			var self = this;
			var phno = self.appointmentModel.get('mobno');
			$('#resend-otp-msg').removeClass('hide');
			self.verifyMobileNo(phno, true);

		},
		hoverDropDown: function (e) {
			//$(e.currentTarget).parent().find('.ex-selected-2').removeClass('ex-selected-2');
			//$(e.currentTarget).addClass('ex-selected-2');
		},
		selectFromDropDown: function (e) {
			var self = this;
			//$('.check-experts').addClass("hide");
			$("input[type='checkbox']").prop("checked", false);
			$('.ex-selected-2').removeClass('ex-selected-2');
			$(e.currentTarget).find("input[type='checkbox']").prop("checked", 'checked');
			$(e.currentTarget).find('.check-experts').removeClass("hide");
			$(e.currentTarget).addClass('ex-selected-2');

			var counselorID = $(e.currentTarget).find('.check-experts').attr("data-counselorid");
			var counselorName = "Special Friend";
			if (counselorID != 0) {
				counselorName = $(e.currentTarget).find("#exprt-name").text();
			}
			console.log(counselorID);
			$('#selected-expert-dropdown').val(counselorName);
			self.appointmentModel.set('conSource', 'DropDown');
			self.appointmentModel.set('counselorid', counselorID);
			self.appointmentModel.set('counselorname', counselorName);
			$('.expt-dropdown-content').addClass('hide');
			$('.swiper-button-next').css({ 'top': '47%' });
			$('.swiper-button-prev').css({ 'top': '47%' });

		},
		signupNew: function () {

			var self = this;
			if (self.appointmentModel.get('mobno') == undefined || self.appointmentModel.get('mobno') == null) {
				self.appointmentModel.set('mobno', '');
			}
			if (self.appointmentModel.get('emailNew') == undefined || self.appointmentModel.get('emailNew') == null) {
				self.appointmentModel.set('emailNew', '');
			}
			if (self.appointmentModel.get('usernameNew') == undefined || self.appointmentModel.get('usernameNew') == null) {
				self.appointmentModel.set('usernameNew', '');
			}
			var dataToSend = { 'mobile': self.appointmentModel.get('mobno'), 'email': this.appointmentModel.get('emailNew'), 'username': this.appointmentModel.get('usernameNew') };
			console.log(dataToSend);

			$.ajax({
				url: Utils.contextPath() + '/v2/users/appointment/signup',
				method: 'POST',
				dataType: "json",
				xhrFields: {
					withCredentials: true
				},
				contentType: "application/json",
				data: JSON.stringify(dataToSend),
				statusCode: {
					417: function (response) {
						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText);

						var errorMessage = responseJson.message;
						var errorType = responseJson.type;
						$('#error-otp-msg').addClass('invalid');
						$('#error-otp-msg').text(errorMessage);
						$('#error-otp-msg').addClass('red-text')

					}
				},
			}).done(function (response) {

				console.log('signup successful');
				console.log(response);
				self.model.save(response);
				self.checkForExtraPay()
				//self.signUpProgress = 1 ;
				sessionStorage.setItem("firstTimeUser", 1);
				Raygun.setUser(response.username, false, response.email, response.firstName, response.firstName, response.id);
				if (self.fromAction == 'book_appointment') {
					//localStorage.setItem("fromAppointment", 1) ;
				}

				if ((typeof mixpanel != 'undefined') && (typeof mixpanel.register === "function")) {

					mixpanel.register({
						userInfo: response,
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.alias(response.id, distinct_id);
					mixpanel.track('SIGNUP', { 'type': 'NORMAL', 'itemName': 'bookAppointment', 'itemMedium': 'NORMAL' });

					if ((typeof fbq != 'undefined')) {
						fbq('track', 'CompleteRegistration');
					}

					if (typeof ga != 'undefined') {
						ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up' });
					}

					mixpanel.people.set({
						'username': response.username,
						'name': response.username,
						'$email': response.email,
						'id': response.id,
						'src': 'NORMAL',
						'userType': response["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: response.username
					});
				}
				if (self.applyOfferEnable) {
					self.applyOffer();
				}
				self.redirectToPayment();

			});

		},
		renderContactInfo: function () {
			var self = this;
			$(".multi-user-screen").empty();
			$(".multi-user-screen").append(self.UpdateInfoLayout());
			$('select').material_select();
			console.log('category select 2', $('select'));
			$('#int-no').prop('checked', false)
			$('#error-phoneno-msg').addClass('hide');
			if (self.appointmentModel.get('mode') == 'Video Call' || self.appointmentModel.get('mode') == 'VIDEO') {
				$('#email-div label').text("SkypeID/Email")
			}
			if (!Utils.isMobileDevice()) {

				$('body').animate({ scrollTop: 60 }, 'slow');
			}
			self.renderAppointmentRecieved();
			self.checkPaymentPending();
			self.checkFeedbackPending();
			if (Utils.isLoggedIn()) {
				$('#appointment-user-info #username').val(self.userModel.getUserName());
				$('#appointment-user-info #username').focus();
				$('#appointment-user-info #username').addClass('disabled');
				$('#appointment-user-info #email').val(self.userModel.getUserEmail());
				$('#appointment-user-info #email').focus();
				$('#phone').val(self.userModel.getPhoneNo());
				if (self.userModel.getPhoneNo() != '') {
					$("#error-phoneno-msg").text("Important for communication.");
				}
				$('#phone').focus();
				$('#showHideLogin').addClass('hide');

			}
			//$('select').material_select();
			// to activate the dropd down
		},
		loginFBappointment: function (e) {

			e.preventDefault();
			var self = this;

			if (FB.getUserID() && FB.getUserID() != "") {

				FB.getLoginStatus(function (response) {
					console.log(response);
					if (response.status != "connected") {
						FB.login(function (response) {
							self.statusChangeCallbackApp(response);
						}, { scope: 'public_profile,email' });
					} else {
						self.statusChangeCallbackApp(response);
					}

				});
			} else {

				FB.login(function (response) {
					self.statusChangeCallbackApp(response);
				}, { scope: 'public_profile,email' });
			}
		},
		statusChangeCallbackApp: function (response) {

			var self = this;

			if (response.status === 'connected') {

				FB.api('/me', function (response) {
					console.log('Successful login for: ' + response.name);
				});

				var base64 = "FB " + btoa(response.authResponse.userID + ":" + response.authResponse.accessToken);
				self.loginThroughAppappointment(base64, 'FB');

			} else if (response.status === 'not_authorized') {
				console.log('Please log into this app.');
			} else {
				console.log('Please try again later. Some error occurred');
			}
		},

		loginAppointment: function () {
			var self = this;


			var username = $(".appointment-login #username").val().trim();
			var pwd = $(".appointment-login #password").val();

			$(".appointment-login #login").hide();
			$(".appointment-login #login-progress").show();


			var loginUrl = Utils.contextPath() + "/v2/users/login";
			var source = "website";
			if (this.sso != undefined) {
				loginUrl = loginUrl + "?sso=" + this.sso;
				source = "FORUM";
			} else {
				loginUrl = loginUrl;
			}

			$.ajax({
				type: "POST",
				dataType: "JSON",
				contentType: "application/json; charset=utf-8",
				url: loginUrl,
				xhrFields: {
					withCredentials: true
				},

				beforeSend: function (xhr) {
					xhr.setRequestHeader("Authorization", "Basic " + btoa(username + ":" + pwd));
				},

				statusCode: {
					401: function (response) {

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText);

						var errorMessage = responseJson.message;
						var errorType = responseJson.type;
						$(".login-error").removeClass("hide");
						$(".appointment-login #login").show();
						$(".appointment-login #login-progress").hide();
						if (errorType == "BLOCKED") {
							$(".login-error").html("We have noticed some unusual activites from this account. Please <a href='mailto:customersupport@yourdost.com'>contact us</a> to learn more. ");
						} else {
							$(".login-error").html("The username and password do not match");
						}


					},
				},
				data: JSON.stringify({ "shouldGenerateCookie": true, "ipSession": false })
			}).done(function (data, status, xhr) {
				$(".login-error").addClass("hide");
				Raygun.setUser(data.username, false, data.email, data.firstName, data.firstName, data.id);
				if ((typeof mixpanel != 'undefined') && (typeof mixpanel.register === "function")) {

					mixpanel.register({
						userInfo: data,
					});

					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.identify(data.id);
					mixpanel.track('LOGIN', { 'type': 'NORMAL', 'mediumSource': source, 'itemName': "bookAppointment", 'itemMedium': 'NORMAL' });
					mixpanel.people.set({
						'username': data.username,
						'name': data.username,
						'$email': data.email,
						'id': data.id,
						'userType': data["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				self.model.save(data);
				self.checkForExtraPay()
				self.checkOffer()
					.then(function () {
						if (self.audioPromo || self.videoPromo || self.f2fPromo) {
							self.appointmentModel.set('planId', '');
						}
						self.appointmentConfirmation();
					});
				Dispatcher.trigger("renderHeader");
				$('#logo-container').addClass('hide');
				$('#small-logo-container').removeClass('hide');
				self.renderContactInfo();
				self.checkPaymentPending();
				self.checkFeedbackPending();

			}).error(function (error) {
				console.log(error);
				$("#login").show();
				$("#login-progress").hide();
			});
			//self.$el.html(self.AppointmentConfirmationLayout());

		},
		loaderHTML: function () {

			var html = '<div class="preloader-wrapper small active" style="width: 50px;height: 50px; position: absolute;top: 45%;left: 45%;">';
			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
			html += '<div class="gap-patch"><div class="circle"></div></div>';
			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>';
			return html;

		},
		loaderHTML2: function () {

			var html = '<div class="preloader-wrapper small active" style="width: 50px;height: 50px; position: absolute;top: 60%;left: 25%;">';
			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
			html += '<div class="gap-patch"><div class="circle"></div></div>';
			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>';

			return html;

		},
		loaderHTML3: function () {

			var html = '<div class="preloader-wrapper small active" style="width: 50px;height: 50px; position: absolute;top: 45%;left: 45%;">';
			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
			html += '<div class="gap-patch"><div class="circle"></div></div>';
			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>';
			html += '<div style="position: absolute;top: 50%;margin-left: 20%;width:60%;text-align:center">Redirecting to Payment...Please Wait!</div>'

			return html;

		},
		loaderHTML4: function () {

			var html = '<div class="preloader-wrapper small active" style="width: 50px;height: 50px; position: absolute;top: 45%;left: 45%;">';
			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
			html += '<div class="gap-patch"><div class="circle"></div></div>';
			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>';
			html += '<div style="position: absolute;top: 50%;margin-left: 20%;width:60%;text-align:center">Rescheduling your appointment...Please Wait!</div>'

			return html;

		},
		loaderHTML5: function () {

			var html = '<div class="preloader-wrapper small active" style="width: 50px;height: 50px; position: absolute;top: 45%;left: 45%;">';
			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
			html += '<div class="gap-patch"><div class="circle"></div></div>';
			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>';
			html += '<div style="position: absolute;top: 50%;margin-left: 20%;width:60%;text-align:center">Scheduling your call...Please Wait!</div>'

			return html;

		},
		handleBundlePayment: function (planId) {
			var self = this;
			$.ajax({
				url: Utils.contextPath() + '/v1/user/' + this.userModel.getUserID() + '/appointment/bundle',
				method: 'POST',
				dataType: "json",
				xhrFields: {
					withCredentials: true
				},
				contentType: "application/json",
				data: JSON.stringify({ 'plan_id': planId }),
			})
				.done(function (res) {
					if (!res.error) {
						var transactionID = res.uri;
						self.appointmentModel.set('source', 'bundle');
						self.initializeRazorPay(transactionID);
					}
				});
		},
		redirectToPayment: function () {
			var self = this;
			var planId = self.appointmentModel.get('planId');
			if (planId && !self.offerApplied) {
				self.handleBundlePayment(planId);
				return;
			}
			if (self.fromLocation == 'reschedule') {
				self.$el.html(self.loaderHTML4());
			} else if (self.fromLocation == 'packages') {
				self.$el.html(self.loaderHTML5());
			}
			else {
				self.$el.html(self.loaderHTML3());
			}
			var categories = self.appointmentModel.get('categoriesArray');
			$('#verifyOtpModal').closeModal();

			var message = self.appointmentModel.get('description');
			if (message == undefined || message == null) {
				message = '';
			}
			var categoryId = 5;
			var category_user = self.appointmentModel.get('category')
			if (category_user == '' || category_user == null || category_user == undefined) {
				category_user == 'Others'
			}
			for (var i = 0; i <= categories.length; i++) {
				if (categories[i] == category_user) {
					categoryId = i;
				}
			}
			if (self.fromLocation == 'packages') {
				categoryId = self.catVar;
			}
			var today = new Date();
			var y = today.getFullYear();
			var slotTime = self.appointmentModel.get('slotdate') + " " + y + " " + self.appointmentModel.get('slottime');
			var formattedslotTime = new Date(slotTime).getTime();
			var formattedslotEndTime = formattedslotTime + (1000 * 60 * 60 * 1.5);
			if (self.appointmentModel.get('mode') == "face2face") {
				formattedslotTime = Date.parse(new Date(self.appointmentModel.get('date').replace(',', '')))
				formattedslotEndTime = formattedslotTime
			}
			var refID = this.userModel.getUserID();
			var type = self.appointmentModel.get('mode');
			// Adding category and sub category
			var selectedCategory = localStorage.getItem('selectedCategory');
			var selectedSubCategory = localStorage.getItem('subCategory');
			type = type.replace(' Call', '');
			type = type.replace('Text ', '');
			type = type.toUpperCase();
			if (type == "VOICE") { type = "AUDIO"; }
			if (type == "face2face") type = "Face To Face"
			var counselorID = self.appointmentModel.get('counselorid');
			if (!counselorID) {
				counselorID = 101;
			}
			var topic = self.appointmentModel.get('category') + self.appointmentModel.get('cat-o');
			var arr = topic.split('|');
			console.log(arr);
			if (self.fromLocation == 'reschedule') {
				var dataToSend = {
					amount: parseInt(this.appointmentModel.get('rate')),
					duration: ' 90',
					startTime: formattedslotTime,
					counselorID: parseInt(counselorID).toString()
				};
				console.log(dataToSend);
				$.ajax({
					url: apiUrl + "/v1/user/appointment/schedule/" + self.appointmentModel.get('appointmentId'),
					data: JSON.stringify(dataToSend),
					method: "POST",
					dataType: "JSON",
					contentType: "application/json; charset=utf-8",
					xhrFields: {
						withCredentials: true
					},
				}).done(function (r) {
					self.updateFeedback();
					location.href = self.locationString + '/bookAppointment?from=paymentReschedule&t=' + self.appointmentModel.get('appointmentId');
				}).error(function (error) {
					console.log("error");
				})
			}
			else {
				if (self.fromLocation == 'packages') {
					var isPackageCall = true;
					var dataToSend = {
						"area": categoryId,
						"message": message,
						"slotEndTime": formattedslotEndTime,
						"slotStartTime": formattedslotTime,
						"refID": refID,
						"type": type,
						"timezone": "ASIA/KOLKATA",
						"counselorID": parseInt(counselorID),
						"packageCall": isPackageCall,
						"isInternational": self.internationalFlag,
						"category": selectedCategory,
						"subCategory": selectedSubCategory

					};
				} else {
					var dataToSend = {
						"area": categoryId,
						"message": message,
						"slotEndTime": formattedslotEndTime,
						"slotStartTime": formattedslotTime,
						"refID": refID,
						"type": type,
						"amount": self.appointmentModel.get('rate'),
						"timezone": "ASIA/KOLKATA",
						"counselorID": parseInt(counselorID),
						"isInternational": self.internationalFlag,
						"category": selectedCategory,
						"subCategory": selectedSubCategory
					};
				}
				if (self.appointmentModel.get('insta')) dataToSend.type = 'INSTANT_AUDIO';
				if (self.appointmentModel.get('mode') == 'face2face') {
					dataToSend["counselingType"] = self.appointmentModel.get('f2fType').toUpperCase()
					dataToSend["counselingCity"] = self.appointmentModel.get('city')
					dataToSend["counselingCenter"] = self.appointmentModel.get('area')
					dataToSend["counselorID"] = 101;
					dataToSend.type = "FACE2FACE"
				}
				$.ajax({
					url: Utils.contextPath() + '/v2/users/' + refID + '/appointment',
					method: 'POST',
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: JSON.stringify(dataToSend),
				}).done(function (res) {
					console.log(res);
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Appointment recieved to YD", { "mediumSource": "website", "itemName": 'bookAppointment' });
					}
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Redirected to Payment", { "mediumSource": "website", "itemName": 'bookAppointment' });
					}
					if (self.fromLocation == 'packages') {
						self.appointmentModel.set('transactionID', res.uri);
						self.createFeedback();
						self.renderAppointmentConfirmation();
					} else {
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Payment status", { "mediumSource": "website", "itemName": 'bookAppointment', 'status': 'initiated' });
						}
						var transactionID = res.uri + "";
						self.appointmentModel.set('transactionID', res.uri);
						self.createFeedback();
						self.initializeRazorPay(transactionID)
					}
				}).error(function (error) {
					console.log(error);
				});
			}
		},
		initializeRazorPay: function (transaction_id) {
			var self = this;

			var amount = 0;
			amount = this.appointmentModel.get("rate") + "";
			if (self.discountedValue != null) {
				amount = self.discountedValue;
			}

			var requestOptions = {
				"amount": amount,
				"transaction_id": transaction_id,
				"source": "web"
			};

			if (amount == 0 && self.offerApplied) {
				var availOffer = {
					"offer_name": self.offerName,
					"transaction_id": parseInt(transaction_id),
					"cart_value": parseInt(self.appointmentModel.get('rate')),
					"discounted_value": self.discountedValue
				}
				$.ajax({
					url: Utils.contextPath() + "/v1/offers/" + self.userModel.getUserID() + "/avail/" + self.user_offer_mapping_id,
					method: 'POST',
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: JSON.stringify(availOffer),
				}).done(function (response) {
					if (!response.errorMsg) {
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Offer Availed", { "itemName": self.offerName, 'status': 'sucess' });
						}
						$.ajax({
							method: 'POST',
							url: Utils.contextPath() + '/v1/user/transaction/free',
							data: requestOptions
						}).done(function (response) {

							window.location.href = "/bookAppointment?from=payment&t=" + transaction_id;

						});

					} else {
						alert('Error occured in availing the offer.');
						self.renderAppointmentRecieved();
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Offer Availed", { "itemName": self.offerName, 'status': 'error' });
						}
					}
				});

			} else {
				var options = {
					"key": Utils.paymentGatewayKey(),
					"amount": (self.appointmentModel.get('bundlePrice') || amount) * 100, // we take amount in paise
					"name": "Your Dost",
					"description": this.appointmentModel.get("mode") === "face2face" ? "Face To Face" : this.appointmentModel.get("mode"),
					"image": "https://d1hny4jmju3rds.cloudfront.net/main-logo/yd-logo.png",
					"handler": function (response) {
						var requestOptions = {
							"amount": self.appointmentModel.get('bundlePrice') || amount,
							"transaction_id": transaction_id,
							"source": self.appointmentModel.get('source') || "web",
							"razorpay_payment_id": response.razorpay_payment_id
						};
						$.ajax({
							method: 'POST',
							url: Utils.contextPath() + '/v1/user/transaction/razorpay',
							data: requestOptions
						}).done(function (response) {
							if (self.appointmentModel.get('source') == 'bundle') {
								$.ajax({
									url: Utils.contextPath() + "/v2/users/" + self.userModel.getUserID() + '/offers'
								})
									.done(function (res) {
										if (res && res.length) {
											var mode = self.appointmentModel.get('mode');
											mode = mode.split(" ")[0].toUpperCase();
											mode = (mode == 'VOICE') ? 'AUDIO' : mode;
											var offerName;
											for (var i = 0; i < res.length; i++) {
												if (res[i]['discounted_product_type'] == mode) {
													offerName = res[i]['name'];
													break;
												}
											}
											self.applyOffer(offerName);
										}
									});
								return;
							}
							var status = $.url(response).param('status');
							if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
								mixpanel.track("Payment status", { "mediumSource": "website", "itemName": 'bookAppointment', 'status': 'successful' });
							}
							if (status == "paid") {
								if (self.offerApplied) {
									var availOffer = {
										"offer_name": self.offerName,
										"transaction_id": transaction_id,
										"cart_value": parseInt(self.appointmentModel.get('rate')),
										"discounted_value": self.discountedValue
									}
									$.ajax({
										url: Utils.contextPath() + "/v1/offers/" + self.userModel.getUserID() + "/avail/" + self.user_offer_mapping_id,
										method: 'POST',
										dataType: "json",
										xhrFields: {
											withCredentials: true
										},
										contentType: "application/json",
										data: JSON.stringify(availOffer),
									}).done(function (response) {
										if (!response.errorMsg) {
											if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
												mixpanel.track("Offer Availed", { "itemName": self.offerName, 'status': 'sucess' });
											}
											window.location.href = "/bookAppointment?from=payment&t=" + transaction_id;
											return;
										} else {
											alert('Error occured in availing the offer.');
											if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
												mixpanel.track("Offer Availed", { "itemName": self.offerName, 'status': 'error' });
											}
											self.renderAppointmentRecieved();
										}
									});
								} else {
									window.location.href = "/bookAppointment?from=payment&t=" + transaction_id;
									return;
								}
							}

						}).fail(function (error) {
							self.render();
						});
					},
					"prefill": {
						"name": this.userModel.getUserName(),
						"email": this.userModel.getUserEmail() || this.appointmentModel.get("emailNew"),
						"contact": self.appointmentModel.get("mobno"),
					},
					"theme": {
						"color": "#2fa59a"
					},
					"modal": {}
				};
				options.modal.ondismiss = function () {
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Payment status", { "mediumSource": "website", "itemName": 'bookAppointment', 'status': 'exit' });
					}
					window.location.href = "/bookAppointment";
				};
				new Razorpay(options).open();
			}
		},
		initializeLogin: function (e) {
			var self = this;
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Login screen Book Appointment", { "mediumSource": "website", "itemName": 'bookAppointment' });
			}
			$(".multi-user-screen").empty();
			$(".multi-user-screen").append(this.LoginInfoLayout());
			self.checkPaymentPending();
			self.checkFeedbackPending();
			self.startGoogleApp();
			$('.back-4').addClass('back-5');
			$('.back-4').removeClass('back-4');
		},
		startGoogleApp: function () {
			var self = this;
			gapi.load('auth2', function () {

				if (typeof auth2 == 'undefined') {
					auth2 = gapi.auth2.init({
						client_id: Utils.getGoogleApiId(),
					});
				}

				self.attachSigninAppointment(document.getElementById('customBtn'));
			});
		},
		attachSigninAppointment: function (element) {
			var self = this;

			auth2.attachClickHandler(element, {},
				function (googleUser) {
					window.googleInfo = googleUser;
					var gUserID = googleUser.getBasicProfile().getId();
					var gUserEmail = googleUser.getBasicProfile().getEmail();
					var oauthToken = "";
					for (var key in window.googleInfo) {
						if (typeof window.googleInfo[key].access_token != 'undefined') {
							oauthToken = window.googleInfo[key].access_token;
							console.log(window.googleInfo[key].access_token)
						}
					}

					var base64 = 'GPLUS ' + btoa(gUserID + "__" + gUserEmail + ":" + oauthToken);
					self.loginThroughAppappointment(base64, 'GPLUS');
				}, function (error) {
					console.log(JSON.stringify(error, undefined, 2));
				});
		},
		loginThroughAppappointment: function (loginHeader, src) {

			var self = this;

			$("#login").hide();
			$("#login-progress").show();
			var loginUrl = Utils.contextPath() + "/auth/login";

			var source = "website";

			if (this.sso != undefined) {

				loginUrl = loginUrl + "?sso=" + this.sso;
				source = "FORUM";
			} else {

				loginUrl = loginUrl;
			}

			$.ajax({
				type: 'POST',
				url: loginUrl,
				dataType: "JSON",
				data: JSON.stringify({ "shouldGenerateCookie": true, "ipSession": false }),
				contentType: "application/json; charset=utf-8",
				xhrFields: {
					withCredentials: true
				},
				beforeSend: function (xhr) {
					xhr.setRequestHeader("Authorization", loginHeader);
				},
				statusCode: {
					417: function (response) {

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText);

						var errorMessage = responseJson.message;
						var errorType = responseJson.type;

						$(".appointment-login .login-error").removeClass("hide");
						$(".appointment-login .login-error").html(errorMessage);
						$(".appointment-login #login").show();
						$(".appointment-login #login-progress").hide();

					},
				},
			}).done(function (userInfo) {
				$(".appointment-login.login-error").addClass("hide");

				var data = userInfo.user;
				Raygun.setUser(data.username, false, data.email, data.firstName, data.firstName, data.id);
				if ((typeof mixpanel != 'undefined') && (typeof mixpanel.register === "function")) {

					mixpanel.register({
						userInfo: data,
					});
					//mixpanel.identify(data.id);
					var distinct_id = mixpanel.get_distinct_id();
					var method = "";

					if (data.lastLogin == "null") {

						method = "SIGNUP";
						mixpanel.alias(data.id, distinct_id);

					} else {

						var timediff = Math.abs(data.lastLogin - data.registrationDate);

						if (timediff / 60000 < 5) {

							method = "SIGNUP";
							mixpanel.alias(data.id, distinct_id);
						} else {

							method = "LOGIN";
							mixpanel.identify(data.id);
						}
					}

					if (method == "SIGNUP") {
						if ((typeof fbq != 'undefined')) {
							fbq('track', 'CompleteRegistration');
						}

						if (typeof ga != 'undefined') {
							ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up' });
						}
					}

					mixpanel.track(method, { 'type': src, 'mediumSource': 'website', 'itemName': self.sourceDesc, 'itemMedium': src });

					mixpanel.people.set({
						'username': data.username,
						'name': data.username,
						'$email': data.email,
						'id': data.id,
						'src': src,
						'userType': data["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				self.model.save(data);
				self.checkOffer()
					.then(function () {
						if (self.audioPromo || self.videoPromo || self.f2fPromo) {
							self.appointmentModel.set('planId', '');
						}
						self.appointmentConfirmation();
					});
				self.checkForExtraPay()
				Dispatcher.trigger("renderHeader");
				$('#logo-container').addClass('hide');
				$('#small-logo-container').removeClass('hide');
				self.renderContactInfo();


			}).error(function (error) {
				console.log(error);
				$(".appointment-login #login").show();
				$(".appointment-login #login-progress").hide();

			});
		},
		backToTalkItOut: function () {
			var self = this;
			var url = window.location.href;
			url = url.replace(this.locationString + "/bookAppointment", "");
			var fromLocation = $.url(url).param('from');
			if (fromLocation == 'talkItOut') {
				location.href = self.locationString + "/talkItOut";
			}
			if (fromLocation == 'counselor') {
				var conName = $.url(url).param('conName');
				var conId = $.url(url).param('conID');
				location.href = self.locationString + "/counselor/" + conName + '-' + conId;

			}
			if (fromLocation == 'packages') {
				var conName = $.url(url).param('catID');
				var conId = $.url(url).param('conID');
				location.href = self.locationString + "/packages/" + conName + 'schedule';

			}

		},
		backtoUpdate: function () {
			var self = this;
			$(".multi-user-screen").empty();
			$(".multi-user-screen").append(self.UpdateInfoLayout());
			$('select').material_select();
			console.log('category select 3', $('select'));
			$('#int-no').prop('checked', false)
			$('#error-phoneno-msg').addClass('hide');
			if (self.appointmentModel.get('mode') == 'Video Call' || self.appointmentModel.get('mode') == 'VIDEO' || self.appointmentModel.get('mode') == 'face2face') {
				$('#email-div label').text("SkypeID/Email")
			}
			if (!Utils.isMobileDevice()) {

				$('body').animate({ scrollTop: 60 }, 'slow');
			}
			self.renderAppointmentRecieved();
			self.checkPaymentPending();
			self.checkFeedbackPending();
			if (Utils.isLoggedIn()) {
				$('#appointment-user-info #username').val(self.userModel.getUserName());
				$('#appointment-user-info #username').focus();
				$('#appointment-user-info #username').addClass('disabled');
				$('#appointment-user-info #email').val(self.userModel.getUserEmail());
				$('#appointment-user-info #email').focus();
				$('#phone').val(self.userModel.getPhoneNo());
				$('#phone').focus();
				$('#showHideLogin').addClass('hide');
			}
			$('.back-5').addClass('back-4');
			$('.back-5').removeClass('back-5');
		},
		intializeSelectedCounselorCard: function () {
			var self = this;
			var cId = this.appointmentModel.get('counselorid');
			if (!cId || cId == 0) cId = 101;
			if (self.fromLocation == 'talkItOut' || self.fromLocation == 'counselor' || self.fromLocation == 'packages') {
				cId = self.counselorVar;
			}
			$(".counselor-card-step3").html('<div class="af-exprt-step3-loader">Loading Counselor ...</div>');
			$.ajax({
				url: Utils.contextPath() + "/v1/counselor/" + cId
			}).done(function (elem) {
				if (cId == 101) {
					var formattedDate = Utils.getDateString(elem.lastActive * 1000, "shortdate");
					if (cId == 101) elem.name = "YourDOST will assign the best available expert for you";
					$('.counselor-card-step3').html(self.ExpertCardStep3({ counselor: elem }));
					if (cId == 101) {
						$('.expert-conversation-info').addClass('hide')
						$('.expert-personal-info-app').removeClass('l6');
						$('.expert-personal-info-app').addClass('l12');
						$('.expert-personal-info-app').css({ 'border-right': 'none' })
						$('.expert-personal-info-app').css({ 'margin-top': '35px!important' })
					}
				} else {
					var statusPromise = self.sendRequest({ method: "GET", url: Utils.contextPath() + "/v1/counselor/status" });
					$.when(statusPromise)
						.then(function (status) {
							var formattedDate = Utils.getDateString(elem.lastActive * 1000, "shortdate");
							self.sendRequest({ method: "GET", url: Utils.contextPath() + "/v1/counselor/" + elem.id + '/ratingFavoriteCnt' })
								.then(function (res) {
									$('.counselor-card-step3').html(self.ExpertCardStep3({ status: status[elem.id]['status'], counselor: elem, formattedDate: formattedDate, rating: elem.rating, reviewCount: res.rating }));
								})
						})
				}
			});
		},
		backtoMode: function () {

			location.reload();
			return;
			var self = this;
			var slottime = self.appointmentModel.get('slottime');
			var type = self.appointmentModel.get('mode');
			type = type.replace(' Call', '');
			type = type.replace('Text ', '');
			type = type.toUpperCase();
			if (type == "VOICE") { type = "AUDIO"; }
			var slotdate = self.appointmentModel.get('slotdate') || self.appointmentModel.get('date');
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Back to Step-3 Appointment", { "mediumSource": "website", "itemName": 'bookAppointment' });
			}
			var orgUser = true
			if (Utils.isLoggedIn()) {
				if (JSON.parse(localStorage.getItem("user"))["loggableUser"]["orgId"] != -1) {
					orgUser = false
				}
			}
			self.$el.html(self.StepthreeLayout({ orgUser: orgUser }));
			self.intializeSelectedCounselorCard();
			self.initializeMode();
			self.initializeSlotPicker();
			self.checkPaymentPending();
			self.checkFeedbackPending();
			self.checkForExtraPay();
			$('#head-step3').text("Change your Mode of Contact or Slot");
			if (self.fromLocation == 'zenparent') {
				$('.normal-rate').addClass('hide')
				$('.zenparent-rate').removeClass('hide')
				$('.zenparent-text').removeClass('hide')
				$('.zenparent-img').removeClass('hide')
				$('#progressBar').addClass('hide')
				$('.zenparent-img').parent().css({ 'margin-bottom': '20px' })
				$('.backToTalkItOut').addClass('disabled')
				$('#VIDEO').addClass('hide')
			}
			$('#' + type).find('.mode-container #selectMode').addClass('hide');
			$('#' + type).find('.mode-container #bookMode').removeClass('hide');
			$('#' + type).addClass('ex-selected-2');
			var rate = $('#' + type).find('#charges').html();
			self.appointmentModel.set('rate', rate);
			if (self.fromLocation == 'zenparent' && type == 'AUDIO') {
				self.appointmentModel.set('rate', 300);
			}
			var selectedMode = self.appointmentModel.get('mode');

			if (selectedMode == 'Video Call') {

				selectedMode = 'video';
				$('#video-slot-picker .slot-cell').removeClass('ex-selected-2')
				$('#video-slot-picker').removeClass('hide');
				$('#video-slot-picker').find('.ex-selected-2').removeClass('ex-selected-2');
				$('#voice-slot-picker').addClass('hide');
				//	$('.hide-large').css({'bottom':$('#video-slot-picker').height()+15})
				$('#VIDEO').css({ 'margin-top': '' });

			}
			if (selectedMode == 'Voice Call') {
				selectedMode = 'voice';
				$('#voice-slot-picker .slot-cell').removeClass('ex-selected-2')
				$('#video-slot-picker').addClass('hide');
				$('#voice-slot-picker').removeClass('hide');
				$('#voice-slot-picker').find('.ex-selected-2').removeClass('ex-selected-2');
				$('.hide-large').css({ 'bottom': '5px' })
				var h = $('.slot-picker').height() + 40;

				if (self.fromLocation != 'zenparent') {
					$('#VIDEO').css({ 'margin-top': h });
					$('#video-slot-picker').removeClass('zenparent-adjust');
				} else {
					$('#video-slot-picker').addClass('zenparent-adjust');

				}

			}
			if (selectedMode == 'Text Chat') {
				selectedMode = 'chat';
			}
			$("#selectedMode").text(selectedMode);
			//$('.slot-picker').removeClass('hide')
			//$('.slot-picker').find('.ex-selected-2').removeClass('ex-selected-2');
			var today = new Date();
			dd = today.getDate();
			mm = today.getMonth();
			dd++;
			var Months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
			if (dd < 10) {
				dd = '0' + dd;
			}
			var d = Months_arr[mm] + ' ' + dd;
			if (d != slotdate) {
				$('.slot-container').find('.hide').removeClass('hide')
			}
			//$('.date-cell:contains('+slotdate+')').addClass('ex-selected-2');
			$('.date-cell:contains("' + slotdate + '")').addClass('ex-selected-2');
			$('.slot-cell:contains(' + slottime + ')').addClass('ex-selected-2');
			$('.main-app-content').addClass('adjust-step3');
			$('.next-3').removeClass('disabled');
			var url = window.location.href;
			url = url.replace(this.locationString + "/bookAppointment", "");
			var fromLocation = $.url(url).param('from');
			if (fromLocation == 'talkItOut' || fromLocation == 'counselor') {
				$('.back-3').addClass('backToTalkItOut');
				$('.back-3').removeClass('back-3');
			}


		},
		backtoExperts: function () {
			var self = this;
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Back to Step-2 Appointment", { "mediumSource": "website", "itemName": 'bookAppointment' });
			}
			self.loadExperts();
			self.appointmentModel.set('backFromFuturetoCon', true)
			$('.main-app-content').removeClass('adjust-step3');
			self.checkPaymentPending();
			self.checkFeedbackPending();
		},
		backtoStart: function () {
			location.href = this.locationString;

			//if category step is involved
			/*var self = this;
			self.appointmentModel.set('backFromFuture',true);
			self.render()
			self.checkPaymentPending();*/


		},
		updateUser: function (type, value) {
			//type can be Mobile Number, Age, Gender
			var self = this;

			$.ajax({
				method: "GET",
				url: Utils.contextPath() + "/v2/users/" + this.userModel.getUserID() + "/profile",
			}).done(function (response) {
				console.log('user object from profile api', response);


				var infoToEdit = response;


				if (type == "MobileNumber") {
					infoToEdit['phone'] = value;
				}
				if (type == 'Gender') {
					infoToEdit['customProperties']['gender'] = [value];
				}
				if (type == 'Age') {
					infoToEdit['customProperties']['age'] = [value];
				}
				console.log(JSON.stringify(infoToEdit));
				$.ajax({
					url: Utils.contextPath() + "/v2/users/" + self.userModel.getUserID() + "/modify/profile",
					method: "POST",
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: JSON.stringify(infoToEdit)
				}).done(function (response) {
					console.log('modified user api ', response);
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Update User Info", { "mediumSource": "website", "itemName": 'bookAppointment' });
					}

				}).error(function (error) {
					console.log("error");
					console.log(error);
				});
			});


		},
		SubmitOtp: function () {
			var self = this;
			var otp = $('#verify-code').val();
			if (otp == "") {
				$('#verify-code').addClass('invalid');
				$('#error-otp-msg').text("Please enter otp!");
				$('#error-otp-msg').addClass('red-text');
			} else {
				$("#submit-otp").hide();
				$("#submit-otp-progress").show();
				console.log('otp', otp);
				var dataToSend = { 'verificationCode': otp };
				$.ajax({
					url: Utils.contextPath() + '/v2/users/mobile/' + this.appointmentModel.get('mobno') + '/validate',
					method: 'POST',
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: otp,
					statusCode: {
						417: function (response) {
							var responseText = response.responseText;
							var responseJson = JSON.parse(responseText);

							var errorMessage = responseJson.message;
							var errorType = responseJson.type;
							$('#verify-code').addClass('invalid');
							$('#error-otp-msg').text(errorMessage);
							$('#error-otp-msg').addClass('red-text');
							$("#submit-otp").show();
							$("#submit-otp-progress").hide();
							if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
								mixpanel.track("Incorrect OTP", { "mediumSource": "website", "itemName": 'Incorrect OTP entered' });
							}

						}
					},
				}).done(function (res) {
					if (res.status) {
						if (Utils.isLoggedIn()) {

							//save user details api
							// book appointment api without payment

							self.$el.html(self.loaderHTML());

							self.appointmentModel.set('usernameNew', self.userModel.getUserName());
							self.updateUser('MobileNumber', self.appointmentModel.get('mobno'));
							if (self.applyOfferEnable) {
								self.applyOffer();
							}
							self.redirectToPayment();



						} else {
							self.$el.html(self.loaderHTML());
							self.signupNew();


						}
						$('#verify-code').removeClass('invalid');
						$('#verify-code').addClass('valid');
						$('#error-otp-msg').text('');
						$('#error-otp-msg').removeClass('red-text')
						$("#submit-otp").show();
						$("#submit-otp-progress").hide();
					}
				});

			}
		},
		verifyMobileNo: function (mobNo, resend_flag) {
			var self = this;
			self.appointmentModel.set('mobno', mobNo);
			var dataToSend = { 'mobile': mobNo };
			$.ajax({
				url: Utils.contextPath() + '/v2/users/mobile/otp/send',
				method: 'POST',
				dataType: "json",
				xhrFields: {
					withCredentials: true
				},
				contentType: "application/json",
				data: mobNo,
			}).done(function (res) {
				console.log('otp send', res);
				if (res.status) {
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("OTP Send", { "mediumSource": "website", "itemName": 'bookAppointment' });
					}
					if (!resend_flag) {
						$('#verifyOtpModal').openModal({ dismissible: false, keyboard: true });

						$("#update-info-form").show();
						$("#update-info-progress").hide();
						setTimeout(function () {
							if ($('#verifyOtpModal').is(":visible")) {
								console.log("user stuck at otp screen");
								var self = views.AppointmentFlowView;
								var today = new Date();
								var y = today.getFullYear();
								var slotTime = self.appointmentModel.get('slotdate') + " " + y + " " + self.appointmentModel.get('slottime');
								var formattedslotTime = new Date(slotTime).getTime();
								var username = '';
								var phone;
								if (Utils.isLoggedIn()) {
									username = self.userModel.getUserName();
									phone = self.userModel.getPhoneNo();

									if (self.appointmentModel.get('mobno') == '' || self.appointmentModel.get('mobno') == null || self.appointmentModel.get('mobno') == undefined) {
										phone = null;
									}
									console.log('user is away in non paid state for more than 5 mins');
									var dataToSend = { 'phone': phone, 'email': self.appointmentModel.get('emailNew'), 'slotStartTime': formattedslotTime, 'username': username };
									$.ajax({
										url: Utils.contextPath() + '/users/trigger/inactivity/otp',
										method: 'POST',
										dataType: "json",
										contentType: "application/json",
										data: JSON.stringify(dataToSend),
									}).done(function (res) {
										console.log('otp inactivity mailer send')
										if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
											mixpanel.track("Inactivity Mailer Appointment", { "mediumSource": "website", "itemName": 'OTP state' });
										}
									});
								}
							}
						}, 180000);
					}
					$('#otp-phn').text(self.appointmentModel.get('mobno'))
					$('#verify-code').text('');
					$('otp-resend-msg').removeClass('hide');
					$('#verify-code').removeClass('valid');
					$('#verify-code').removeClass('invalid');
				}
				else {
					console.log("OtP send api failed.")
					//self.verifyMobileNo();
				}
			});

		},
		validateUsername: function () {
			var self = this;
			var uname = $("#appointment-user-info #username").val();
			if (uname == "" || uname == null) {
				$('#appointment-user-info #username').addClass('invalid');
				$("#error-username-msg").text("Please enter your username.")
				$('#error-username-msg').addClass('red-text');
			} else {


				if (!Utils.isLoggedIn()) {
					var regex = new RegExp('^[a-zA-Z][a-zA-Z0-9]+$');
					if (uname.match(regex) != null) {
						//$("#appointment-user-info #username-div").append( this.loaderHTML()) ;
						$.ajax({
							url: Utils.contextPath() + "/v2/users/exists?type=username&item=" + uname,
							statusCode: {
								404: function (resp) {
									console.log(resp);
									$('#appointment-user-info #username').removeClass('invalid');
									$('#appointment-user-info #username').addClass('valid');
									$('#error-username-msg').removeClass('red-text');
									$("#error-username-msg").text("As you are a new User, we will create an account for you.");
									self.appointmentModel.set('usernameNew', uname);
									self.appointmentModel.set('valid_username', true);

								}
							},

						}).done(function (response) {

							$('#appointment-user-info #username').addClass('invalid');
							$("#error-username-msg").text("This username is already in use on YourDOST, please select another username. ");
							$('#error-username-msg').addClass('red-text');
							self.appointmentModel.set('valid_username', false);

						});
					} else {

						$('#appointment-user-info #username').addClass('invalid');
						$("#error-username-msg").text("Username must start with an alphabet. Special characters are not allowed");
						$('#error-username-msg').addClass('red-text');

					}

				} else {
					self.appointmentModel.set('valid_username', true);
				}

			}
		},
		validateEmail: function () {
			var self = this;
			var email = $("#appointment-user-info #email").val();
			var phno = $("#appointment-user-info #phone").val();
			if (Utils.isLoggedIn()) {
				self.checkPhoneVerified(phno, function () {

				});
			}
			if (!self.phoneVerified) {
				if (email == "" || email == null) {
					$('#appointment-user-info #email').addClass('invalid');
					$("#error-email-msg").text("Please enter an email id.");
					$('#error-email-msg').addClass('red-text');
				} else {
					//$("#appointment-user-info #email-div").append( this.loaderHTML()) ;
					var regex = new RegExp('^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$', 'i');
					if (email.match(regex) != null) {

						if (Utils.isLoggedIn()) {
							if (email != self.userModel.getUserEmail() && self.phoneVerified) {
								$.ajax({
									url: Utils.contextPath() + '/v2/users/' + self.userModel.getUserID() + '/email/' + email + '/free',
									statusCode: {
										417: function (errorResponse) {
											var responseText_free = errorResponse.responseText;
											var responseJson_free = JSON.parse(responseText_free);

											var errorMessage_free = responseJson_free.message;
											var errorType_free = responseJson_free.type;
											$("#appointment-user-info #email").addClass('invalid');
											$('#error-email-msg').text(errorMessage_free);
											$('#error-email-msg').addClass('red-text');
											$("#update-info-form").show();
											$("#update-info-progress").hide();

										},
										404: function (resp) {
											$("#appointment-user-info #email").removeClass('invalid');
											$("#appointment-user-info #email").addClass('valid');
											$('#error-email-msg').text('Important communication will be sent here');
											$('#error-email-msg').removeClass('red-text');
											self.appointmentModel.set('emailNew', email);


										}
									},

								}).done(function (resp) {
									if (!resp.inUse) {
										$("#appointment-user-info #email").removeClass('invalid');
										$("#appointment-user-info #email").addClass('valid');
										$('#error-email-msg').text('Important communication will be sent here');
										$('#error-email-msg').removeClass('red-text');
										self.appointmentModel.set('emailNew', email);

									}


								});
							}
							else {
								$("#appointment-user-info #email").removeClass('invalid');
								$("#appointment-user-info #email").addClass('valid');
								$('#error-email-msg').text('Important communication will be sent here');
								$('#error-email-msg').removeClass('red-text');
								self.appointmentModel.set('emailNew', email);
							}

						} else {

							if (!self.phoneVerified) {
								$.ajax({
									url: Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
									statusCode: {
										404: function (resp) {
											console.log(resp);
											$('#appointment-user-info #email').removeClass('invalid');
											$('#appointment-user-info #email').addClass('valid');
											$('#error-email-msg').removeClass('red-text');
											$("#error-email-msg").text("Important communication will be sent here");
											self.appointmentModel.set('emailNew', email);
											self.appointmentModel.set('valid_email', true);

										}
									},

								}).done(function (response) {

									$('#appointment-user-info #email').addClass('invalid');
									$("#error-email-msg").text("This email ID is already registered to another account, please provide another ID.");
									$('#error-email-msg').addClass('red-text');
									self.appointmentModel.set('valid_email', false);


								});
							} else {
								self.appointmentModel.set('valid_email', true);
							}



						}



					} else {
						$('#appointment-user-info #email').addClass('invalid');
						$("#error-email-msg").text("Please enter a valid email Id!!");
						$('#error-email-msg').addClass('red-text');


					}
				}
				self.appointmentModel.set('valid_email', true);
			} else {

				self.appointmentModel.set('valid_email', true);
			}
		},
		validatePhoneno: function () {
			var self = this;
			var mobno = $('#phone').val();
			var isNumber = /^\d+$/.test(mobno)
			self.internationalFlag = $('#int-no').prop('checked');
			var internationalFlag = self.internationalFlag;
			var length = 10;
			if (!internationalFlag) {
				if (mobno == "") {
					$("#phone").addClass('invalid');
					$("#error-phoneno-msg").text("Please enter phone no.");
					$("#error-phoneno-msg").addClass('red-text');
					$('#error-phoneno-msg').removeClass('hide')
					self.appointmentModel.set('valid_phn', false);
				} else {
					if (mobno.length == length && isNumber) {
						$('#phone').removeClass('invalid');
						$('#error-phoneno-msg').removeClass('red-text');
						$("#error-phoneno-msg").text("We will send the verfication code on this number");
						$('#error-phoneno-msg').addClass('hide')
						$('#phone').addClass('valid')
						self.appointmentModel.set('valid_phn', true);
					}
					if (mobno.length != 10) {
						$("#phone").addClass('invalid');
						$("#error-phoneno-msg").text("Please enter a valid phone no.");
						$('#error-phoneno-msg').addClass('red-text');
						$('#error-phoneno-msg').removeClass('hide')
						self.appointmentModel.set('valid_phn', false);

					}
					if (!isNumber) {
						$("#phone").addClass('invalid');
						$("#error-phoneno-msg").text("Phone number should not have any alphabets.");
						$('#error-phoneno-msg').addClass('red-text');
						$('#error-phoneno-msg').removeClass('hide')
						self.appointmentModel.set('valid_phn', false);
					}
				}
			} else {
				if (mobno == "" || !isNumber) {
					$("#phone").addClass('invalid');
					$("#error-phoneno-msg").text("Please enter a valid phone no.");
					$("#error-phoneno-msg").addClass('red-text');
					$('#error-phoneno-msg').removeClass('hide')
					self.appointmentModel.set('mobno', mobno);
					self.appointmentModel.set('valid_phn', false);
				} else {
					$('#phone').removeClass('invalid').addClass("valid");
					$('#error-phoneno-msg').addClass("hide").removeClass('red-text').text("We will send the verfication code on this number");
					self.appointmentModel.set('mobno', mobno);
					self.appointmentModel.set('valid_phn', true);
				}
			}

		},
		checkPhoneVerified: function (phno, cb) {
			var self = this;
			$.ajax({
				url: Utils.contextPath() + '/v2/users/' + self.userModel.getUserID() + '/mobile/' + phno.toString() + '/verified',
			}).done(function (response) {
				console.log('verified response', response);
				if (response.verified) {
					self.phoneVerified = true;
					cb();
					// return true;
				}
				else {
					self.phoneVerified = false;
					cb();
					// return false;
				}
			});
		},
		UpdatecontactInfo: function (e) {
			e.preventDefault();
			e.stopPropagation();
			$("#update-info-form").hide();
			$("#update-info-progress").show();
			$('#appointment-user-info #username').focusout();
			$('#appointment-user-info #email').focusout();
			$('#appointment-user-info #phone').focusout();
			var self = this;
			var phoneNumber = $('#phone').val();
			var emailUpdate = $('#appointment-user-info #email').val();
			var username = $('#appointment-user-info #username').val();
			var internationalFlag = $('#int-no').prop('checked');
			self.internationalFlag = internationalFlag;
			self.validatePhoneno();
			self.validateEmail();
			self.validateUsername();
			var valid_phn = self.appointmentModel.get('valid_phn');
			var valid_email = self.appointmentModel.get('valid_email');
			var valid_username = self.appointmentModel.get('valid_username');
			var mainCategory = $('#sel-category-div').val();
			var mainSubCategory = $('#sel-sub-category-div').val();
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Appointment - Review", { "mediumSource": "website", itemName: "Clicked Continue" });
			}
			if (valid_phn && valid_email && valid_username && mainCategory && mainSubCategory) {
				if (internationalFlag) {
					if (Utils.isLoggedIn()) {
						self.updateUser('MobileNumber', phoneNumber);
						if (self.applyOfferEnable) {
							self.applyOffer();
						}
						self.redirectToPayment();
					} else {
						self.signupNew();
					}
				} else {
					if (Utils.isLoggedIn()) {
						if (phoneNumber == self.userModel.getPhoneNo()) {
							self.checkPhoneVerified(phoneNumber, function () {
								if (self.phoneVerified) {
									if (self.applyOfferEnable) {
										self.applyOffer();
									}
									self.redirectToPayment();
								} else {
									self.verifyMobileNo(phoneNumber, false);
									$('#appointment-user-info #username').removeClass('invalid');
									$('#appointment-user-info #username').addClass('valid');
									$('#appointment-user-info #email').removeClass('invalid');
									$('#appointment-user-info #email').addClass('valid');
									$('#phoneno').removeClass('invalid');
									$('#error-username-msg').removeClass('red-text');
									$('#error-phoneno-msg').removeClass('red-text');
									$('#error-email-msg').removeClass('red-text');
									$("#update-info-form").show();
									$("#update-info-progress").hide();
								}
							});
						} else {
							$.ajax({
								url: Utils.contextPath() + '/v2/users/' + self.userModel.getUserID() + '/mobile/' + parseInt(phoneNumber) + '/free',
								statusCode: {
									417: function (errorResponse) {
										var responseText_free = errorResponse.responseText;
										var responseJson_free = JSON.parse(responseText_free);

										var errorMessage_free = responseJson_free.message;
										var errorType_free = responseJson_free.type;
										$("#phone").addClass('invalid');
										$('#error-phoneno-msg').text(errorMessage_free);
										$('#error-phoneno-msg').addClass('red-text');
										$('#error-phoneno-msg').removeClass('hide')
										$("#update-info-form").show();
										$("#update-info-progress").hide();

									}
								},
							}).done(function (resp) {
								if (!resp.inUse) {
									if (username == "" || username == null) {
										$('#appointment-user-info #username').addClass('invalid');
										$("#error-username-msg").text("Account will be created for you with this username.")
									}
									if (emailUpdate == "" || emailUpdate == null) {
										$('#appointment-user-info #email').addClass('invalid');
										$("#error-email-msg").text("Please enter your email Id.")

									}
									if (username != "" && emailUpdate != "") {
										self.appointmentModel.set('emailNew', emailUpdate);
										self.appointmentModel.set('usernameNew', username);
										self.verifyMobileNo(phoneNumber, false);
									}
								}


							});
						}
					} else {
						if (username == "" || username == null) {
							$('#appointment-user-info #username').addClass('invalid');
							$("#error-username-msg").text("Account will be created for you with this username.")
						} else if (emailUpdate == "" || emailUpdate == null) {
							$('#appointment-user-info #email').addClass('invalid');
							$("#error-email-msg").text("Please enter your email Id!!")
						} else {
							$.ajax({
								url: Utils.contextPath() + '/v2/users/exists?type=mobile&item=' + parseInt(phoneNumber),
								statusCode: {
									404: function (response) {
										var responseText = response.responseText;
										var responseJson = JSON.parse(responseText);
										var errorMessage = responseJson.message;
										var errorType = responseJson.type;
										if (errorType == "Mobile Does Not Exists") {
											$("#phone").addClass('valid');
											$("#error-phoneno-msg").text("We will send the verfication code on this number");
											$("#error-phoneno-msg").removeClass('red-text')
											$('#phone').addClass('valid')
											if (username != "" && email != "" && errorMessage == "Mobile Does Not Exists") {
												self.verifyMobileNo(phoneNumber, false);
											}
											//self.$el.html(self.AppointmentConfirmationLayout());
										} else {
											$("#phone").addClass('invalid');
											$('#error-phoneno-msg').text("This Mobile is in use with another account");
											$("#error-phoneno-msg").addClass('red-text');
											$("#update-info-form").show();
											$("#update-info-progress").hide();
										}
									}
								},
							}).done(function (res) {
								console.log(res);
								$("#phone").addClass('invalid');
								$('#error-phoneno-msg').text("This Mobile is in use with another account");
								$("#error-phoneno-msg").addClass('red-text');
								$("#update-info-form").show();
								$("#update-info-progress").hide();

							});
						}
					}
				}
			} else {
				$("#update-info-form").show();
				$("#update-info-progress").hide();
			}
			if (!Utils.isMobileDevice()) {
				if (!mainCategory && !mainSubCategory) {
					$("#error-cat-msg").removeClass("hide");
					$("#error-subcat-msg").removeClass("hide");
					$(".select-dropdown").addClass("invalid");
				} else if (!mainSubCategory) {
					$("#sub-category-div .select-dropdown").addClass("invalid");
					$("#error-subcat-msg").removeClass("hide");
				} else {
					$("#error-cat-msg").addClass("hide");
					$("#error-subcat-msg").addClass("hide");
				}
			} else {
				if (!mainCategory && !mainSubCategory) {
					$("#error-cat-msg").removeClass("hide");
					$("#error-subcat-msg").removeClass("hide");
					$("#sel-category-div").addClass("select-invalid");
					$("#sel-sub-category-div").addClass("select-invalid");
				} else if (!mainSubCategory) {
					$("#error-subcat-msg").removeClass("hide");
					$("#sel-sub-category-div").addClass("select-invalid");
				} else {
					$("#error-cat-msg").addClass("hide");
					$("#error-subcat-msg").addClass("hide");
				}
			}
		},
		tconvert: function (time) {
			// Check correct time format and split into components
			time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

			if (time.length > 1) { // If time format correct
				time = time.slice(1);  // Remove full string match value
				time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
				time[0] = +time[0] % 12 || 12; // Adjust hours
			}
			return time.join(''); // return adjusted time or original string
		},
		renderAppointmentRecieved: function () {
			var self = this;
			var exprtName = self.appointmentModel.get('counselorname');
			if (exprtName == "" || exprtName == 'Special Friend') {
				exprtName = "Best Available Expert";
			}
			var mode = self.appointmentModel.get('mode')
			var slotdate = self.appointmentModel.get('slotdate')
			var time = self.tconvert(self.appointmentModel.get('slottime'))
			$('#time-appointment').text(time);
			if (mode === "face2face") {
				mode = "Face To Face"
				slotdate = self.appointmentModel.get('date')
				$('#cType-appointment').text(self.appointmentModel.get("f2fType"));
				$('#city-appointment').text(self.appointmentModel.get('area') + ", " + self.appointmentModel.get('city').toUpperCase());
				exprtName = "Best Available Expert";
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Book Appointment - step 4", { "mediumSource": "website", "itemName": 'appointment recieved', type: mode, mode: self.appointmentModel.get("f2fType") });
				}
			} else {
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Book Appointment - step 4", { "mediumSource": "website", "itemName": 'appointment recieved', type: mode });
				}
			}
			$('#expert-appointment').text(exprtName);
			$('#date-appointment').text(slotdate);
			$('#type-appointment').text(mode);
			if (mode !== "face2face") {
				var catTemp = self.appointmentModel.get('category')
				if (catTemp == '' || catTemp == null || catTemp == undefined) {
					catTemp = 'Others';
				}
				self.appointmentModel.set('category', catTemp);
				$('#topic-appointment').text(catTemp);
			}
			$('#charges-appointment').text(self.appointmentModel.get('rate'));

			if (self.fromLocation == 'packages') {
				$('.rowtabular:contains("Charges")').addClass('hide')
			}

			setTimeout(function () {
				var self = views.AppointmentFlowView;

				if ($('.multi-user-screen').is(":visible")) {

					var today = new Date();
					var y = today.getFullYear();

					var slotTime = views.AppointmentFlowView.appointmentModel.get("slotdate") + " " + y + " " + views.AppointmentFlowView.appointmentModel.get("slottime");
					var formattedslotTime = new Date(slotTime).getTime();
					var username = '';
					var phone;
					if (self.appointmentModel.get('mobno') == '' || self.appointmentModel.get('mobno') == null || self.appointmentModel.get('mobno') == undefined) {
						phone = null;
					}
					if (Utils.isLoggedIn()) {
						username = self.userModel.getUserName();
						phone = self.userModel.getPhoneNo();

						console.log('user is away in non paid state for more than 5 mins');
						var dataToSend = { 'phone': phone, 'email': self.appointmentModel.get('emailNew'), 'slotStartTime': formattedslotTime, 'username': username };
						$.ajax({
							url: Utils.contextPath() + '/users/appointment/trigger/inactivity/mail',
							method: 'POST',
							dataType: "json",
							contentType: "application/json",
							data: JSON.stringify(dataToSend),
						}).done(function (res) {
							console.log('inactivity mailer send');
							if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
								mixpanel.track("Inactivity Mailer Appointment", { "mediumSource": "website", "itemName": 'Non-Paid state' });
							}

						});
					}
				}
			}, 300000);
			/*if(!Utils.isLoggedIn()){
				$('.have-a-promo').addClass('hide');
			}else{
				$('.have-a-promo').removeClass('hide');
			}
			if(!($('.success-offer-msg').is(":visible"))){
				$('.have-a-promo').removeClass('hide');
			}
			*/
		},
		bookModeofContact: function (e) {
			var self = this;
			var mode = self.appointmentModel.get('mode');
			if (mode == "face2face" || self.fromLocation === "face2face") {
				self.$el.html(self.face2faceLayout({ type: self.f2fTypes }))
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Face To Face", { "mediumSource": "website", itemName: "Page Rendered" });
				}
				$('select').material_select();
				self.checkForExtraPay();
				return;
			}
			var bundlePricingOptions = {
				'audio': [{ 'qty': 5, 'originalPrice': 2000, 'discountedPrice': 1600, 'planId': 5 }, { 'qty': 10, 'originalPrice': 4000, 'discountedPrice': 3200, 'planId': 6 }],
				'video': [{ 'qty': 5, 'originalPrice': 3000, 'discountedPrice': 2400, 'planId': 7 }, { 'qty': 10, 'originalPrice': 6000, 'discountedPrice': 4800, 'planId': 8 }]
			};
			if (mode == 'Voice Call' && !self.audioPromo) var bundlePricing = bundlePricingOptions['audio'];
			if (mode == 'Video Call' && !self.videoPromo) var bundlePricing = bundlePricingOptions['video'];
			if (mode == 'face2face' && !self.f2fPromo) var bundlePricing = bundlePricingOptions['f2f'];
			var orgId = -1;
			if (Utils.isLoggedIn()) {
				var user = JSON.parse(localStorage.getItem("user"))
				orgId = user["loggableUser"]["orgId"]
			}
			if (bundlePricing && !self.appointmentModel.get('insta') && orgId == -1) {
				self.$el.append(self.BundleAppointmentsModal({ 'details': bundlePricing }));
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Bundle Popup Rendered", { "mediumSource": "website" });
				}
				Utils.openPopup("bundle");
			} else {
				self.appointmentConfirmation(e);
			}
		},
		buyBundle: function (e) {
			var planId = e.currentTarget.getAttribute('data-id');
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Button Click", { "itemName": "Buy Bundle", 'planId': planId });
			}
			this.appointmentModel.set('planId', planId);
			this.appointmentConfirmation(e);
		},
		appointmentConfirmation: function (e) {
			var isMobile = Utils.isMobileDevice();
			console.log("isMobile", isMobile);
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Button Click", { "itemName": "Continue Booking" });
			}
			$("#bundle").closeModal();
			$("body").css("overflow", "auto");
			var self = this;
			if (self.appointmentModel.get('insta')) {
				self.appointmentModel.set('counselorid', 0);
				self.appointmentModel.set('counselorname', 'Special Friend');
			}
			if (e) {
				e.preventDefault();
				e.stopPropagation();
			}
			if (showZopimAppointment == 1) {
				clearTimeout(self.inactivityTimer);
			}

			var modeAppointment = self.appointmentModel.get('mode');
			var slottimeAppointment = self.appointmentModel.get('slottime');
			var slotdateAppointment = self.appointmentModel.get('slotdate');
			if (modeAppointment === "face2face") {
				slotdateAppointment = self.appointmentModel.get('date');
				slottimeAppointment = "f2f";
			}

			if (modeAppointment != '' && slottimeAppointment != '' && slotdateAppointment != '') {

				if (showZopimAppointment == 1) {
					self.checkforInactivity(30);
				}

				$('.next-3').removeClass('disabled');
				var planId = self.appointmentModel.get('planId');
				if (planId) {
					var bundleDetails = {};
					if (planId == 5) {
						bundleDetails.type = 'Audio';
						bundleDetails.qty = 5;
						bundleDetails.price = 1600;
					} else if (planId == 6) {
						bundleDetails.type = 'Audio';
						bundleDetails.qty = 10;
						bundleDetails.price = 3200;
					} else if (planId == 7) {
						bundleDetails.type = 'Video';
						bundleDetails.qty = 5;
						bundleDetails.price = 2400;
					} else {
						bundleDetails.type = 'Video';
						bundleDetails.qty = 10;
						bundleDetails.price = 4800;
					}
				}
				this.appointmentModel.set('bundlePrice', bundleDetails && bundleDetails.price);
				var options = {
					'planId': self.appointmentModel.get('planId'),
					'type': bundleDetails && bundleDetails.type,
					'qty': bundleDetails && bundleDetails.qty,
					'price': bundleDetails && bundleDetails.price,
					'date': self.appointmentModel.get('slotdate'),
					'time': self.appointmentModel.get('slottime'),
					'name': self.appointmentModel.get('counselorname') || 'Best Available Expert',
				};
				if (modeAppointment === 'face2face') {
					options.type = "face2face"
					options.date = slotdateAppointment
					options.name = 'Best Available Expert'
				}
				if (!planId && !self.appointmentModel.get('insta')) {
					if (self.appointmentModel.get('mode') == 'Voice Call' && self.audioPromo) {
						options.promo = self.audioPromo;
						options.remaining = self.audioPromoRemaining;
						options.type = 'voice';
					}
					if (self.appointmentModel.get('mode') == 'Video Call' && self.videoPromo) {
						options.promo = self.videoPromo;
						options.remaining = self.videoPromoRemaining;
						options.type = 'video';
					}
					if (self.appointmentModel.get('mode') == 'face2face' && self.videoPromo) {
						options.promo = self.f2fPromo;
						options.remaining = self.f2fPromoRemaining;
						options.type = 'face2face';
					}
				}
				if (Utils.isLoggedIn()) {
					options.orgUser = false
					if (JSON.parse(localStorage.getItem("user"))["loggableUser"]["orgId"] != -1) {
						options.orgUser = true
					}
				}
				this.$el.html(self.AppointmentRecievedLayout(options));
				$(".offer-name").val(options.promo);
				self.appointmentModel.set('valid_email', false);
				self.appointmentModel.set('valid_phn', false);
				self.appointmentModel.set('valid_username', false);

				$(".multi-user-screen").append(self.UpdateInfoLayout({ 'catList': self.categoryList, 'isMobile': isMobile }));
				$('select').material_select();
				//console.log('category select 4', catList);
				$('#int-no').prop('checked', false)
				$('#error-phoneno-msg').addClass('hide');
				if (self.appointmentModel.get('mode') == 'Video Call' || self.appointmentModel.get('mode') == 'VIDEO') {
					$('#email-div label').text("SkypeID/Email")
				}
				if (!Utils.isMobileDevice()) {
					$('body').animate({ scrollTop: 60 }, 'slow');
				}
				self.renderAppointmentRecieved();
				self.checkPaymentPending();
				self.checkFeedbackPending();
				self.needHelpView.render("step-3", false)
				window.scrollTo(0, 0);
				if (Utils.isLoggedIn()) {
					$('#appointment-user-info #username').val(self.userModel.getUserName());
					$('#appointment-user-info #username').focus();
					$('#appointment-user-info #username').addClass('disabled');
					$('#appointment-user-info #email').val(self.userModel.getUserEmail());
					$('#appointment-user-info #email').focus();
					$('#phone').val(self.userModel.getPhoneNo());
					$('#phone').focus();
					$('#showHideLogin').addClass('hide');
				}

			} else {
				var selectedMode = self.appointmentModel.get('mode');
				if (selectedMode == 'Video Call') {
					$('#error-step3-msg').text("Please pick a preferred date and time for your appointment.");
				}
				if (selectedMode == 'Voice Call') {
					$('#error-step3-msg-2').text("Please pick a preferred date and time for your appointment.");
				}
				$('.next-3').addClass('disabled');
			}
			if (self.appointmentModel.get('insta')) {
				$(".af-app-data .insta").css('visibility', 'visible');
				$(".insta_info").css('visibility', 'visible');
				$(".insta_info").css('display', 'inline-block');
			}
			$(".insta_info .icon").hover(function (e) {
				$(".extra-charge-info").css("visibility", "visible");
			}, function (e) {
				$(".extra-charge-info").css("visibility", "hidden");
			});
			$(window).scrollTop(0);
		},
		selectModeofContact: function (e) {
			var self = this;
			var loggedInOrgId = JSON.parse(localStorage.getItem("user"));
			var orgIdOfUser;
			if (loggedInOrgId) {
				orgIdOfUser = loggedInOrgId.loggableUser.orgId;
			} else {
				orgIdOfUser = -1;
			}
			//console.log(loggedInOrgId.loggableUser.orgId);
			$('html,body').animate({ scrollTop: $(e.currentTarget).offset().top - 50 }, 'slow');
			$(e.currentTarget).find('.btn')[0];
			$(e.currentTarget).siblings().removeClass('ex-selected-2');
			$(e.currentTarget).parent().find('.mode-container #bookMode').addClass('hide');
			$(e.currentTarget).parent().parents().find('.mode-container #selectMode').removeClass('hide');

			if (showZopimAppointment == 1) {
				clearTimeout(self.inactivityTimer);
				self.checkforInactivity(30);
			}

			var mode = $(e.currentTarget).find('.mode').text();
			if (mode.search("face to face") > -1) {
				mode = "face2face"
			}
			console.log("Mode: ", mode);
			/*if(!Utils.isMobileDevice()){
	
				$('body').animate({scrollTop:220}, "slow");
			}else{
				$('body').animate({scrollTop:300}, "slow");
			}*/
			self.appointmentModel.set('mode', mode);
			var rate = $(e.currentTarget).find('#charges').html();
			self.appointmentModel.set('rate', '');
			self.appointmentModel.set('slottime', '');
			self.appointmentModel.set('rate', rate);
			$('.next-3').addClass('disabled');
			$(e.currentTarget).addClass('ex-selected-2');
			$(e.currentTarget).find('#bookMode').removeClass('hide');
			$(e.currentTarget).find('#selectMode').addClass('hide');
			$('#head-step3').text("Select Date & Time");
			if (mode === "face2face") $("#head-step3").text("Choose a mode of Contact");
			var selectedMode = self.appointmentModel.get('mode');
			//self.initializeSlotPicker();
			if (selectedMode == "face2face") {
				self.appointmentModel.set('insta', false);
				if (self.f2f_charges) {
					var elem = self.f2f_charges
					elem.type = 'F2F';
					$('#' + elem.type + " #charges").text(elem.amount['base']);
					$('#' + elem.type + " #charges-small").text(elem.amount['base']);
					$('#' + elem.type + " #init-time").text(elem.measure['base']);
					$('#' + elem.type + " #extra-time").text(elem.measure['extra']);
					$('#' + elem.type + " #extra-rate").text(elem.amount['extra']);
				}
				$('.next-3').removeClass('disabled').addClass("video");
				$('#video-slot-picker .slot-cell, #voice-slot-picker .slot-cell ').removeClass('ex-selected-2')
				$('#voice-slot-picker, #video-slot-picker').addClass('hide');
				$('#VIDEO').css({ 'margin-top': '' });
			}
			if (selectedMode == 'Video Call') {
				self.appointmentModel.set('insta', false);
				var elem = self.audio_charges;
				elem.type = 'AUDIO';
				$('#' + elem.type + " #charges").text(elem.amount['base']);
				$('#' + elem.type + " #charges-small").text(elem.amount['base']);
				$('#' + elem.type + " #init-time").text(elem.measure['base']);
				$('#' + elem.type + " #extra-time").text(elem.measure['extra']);
				$('#' + elem.type + " #extra-rate").text(elem.amount['extra']);
				selectedMode = 'video';
				self.initializeSlotPicker(true);
				$('#video-slot-picker .slot-cell').removeClass('ex-selected-2')
				$('#video-slot-picker').removeClass('hide');
				$('#voice-slot-picker').addClass('hide');
				//	$('.hide-large').css({'bottom':$('#video-slot-picker').height()+15})
				$('#VIDEO').css({ 'margin-top': '' });

			}
			if (selectedMode == 'Voice Call') {
				selectedMode = 'voice';
				if (orgIdOfUser !== -1) {
					self.initializeSlotPicker(true);
					$(".insta-msg").addClass("hide");
				} else {
					self.initializeSlotPicker();
				}
				$('#voice-slot-picker .slot-cell').removeClass('ex-selected-2')
				$('#video-slot-picker').addClass('hide');
				$('#voice-slot-picker').removeClass('hide');

				$('.hide-large').css({ 'bottom': '5px' })
				var h = $('.slot-picker').height() + 40;
				if (self.fromLocation != 'zenparent') {
					$('#VIDEO').css({ 'margin-top': h });
					$('#video-slot-picker').removeClass('zenparent-adjust');
				} else {
					$('#video-slot-picker').addClass('zenparent-adjust');
				}
			}
			if (selectedMode == 'Text Chat') {
				selectedMode = 'chat';
			}
			$("#selectedMode").text(selectedMode);
			$('.main-app-content').addClass('adjust-step3');

			self.offerName = '';
			self.discountedValue = null;
			self.applyOfferEnable = false;
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Appt step 3- mode selected", { "mediumSource": "website", "itemName": self.appointmentModel.get('mode') });
			}
		},
		slotClicked: function (e) {

			var self = this;
			if (self.appointmentModel.get('mode') == 'Voice Call') {
				if ($(e.currentTarget).find('.insta').length) {
					var elem = self.insta_charges;
					self.appointmentModel.set('insta', true);
				} else {
					var elem = self.audio_charges;
					self.appointmentModel.set('insta', false);
				}
				elem.type = 'AUDIO';
				self.appointmentModel.set('rate', elem.amount['base']);
				$('#' + elem.type + " #charges").text(elem.amount['base']);
				$('#' + elem.type + " #charges-small").text(elem.amount['base']);
				$('#' + elem.type + " #init-time").text(elem.measure['base']);
				$('#' + elem.type + " #extra-time").text(elem.measure['extra']);
				$('#' + elem.type + " #extra-rate").text(elem.amount['extra']);
			}

			$(e.currentTarget).siblings().removeClass('ex-selected-2');
			$('#error-step3-msg').text('');
			$('#error-step3-msg-2').text('');
			$('.next-3').removeClass('disabled');
			$(e.currentTarget).addClass('ex-selected-2');
			var st = $(e.currentTarget).find('.date-text').text();
			self.appointmentModel.set('slottime', st);

			if (showZopimAppointment == 1) {
				clearTimeout(self.inactivityTimer);
				self.checkforInactivity(30);
			}
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Appointment", { "mediumSource": "website", "itemName": 'bookAppointment', 'slotClicked': self.appointmentModel.get('insta') ? 'insta' : 'regular' });
			}

		},
		removeNonServiceableSlots: function (startingHour, isVideoAppointment) {
			console.log("startingHour", startingHour);
			console.log("isVideoAppointment", isVideoAppointment);
			if (isVideoAppointment && startingHour == 23) startingHour = 0;
			var startingHour = startingHour || 5;
			var hour;
			for (var i = 0; i <= startingHour; i++) {
				if (i < 10) {
					hour = "0" + i;
				} else {
					hour = i;
				}
				$('#voice-slot-picker #' + hour + '\\:00').parent().addClass('hide');
				$('#voice-slot-picker #' + hour + '\\:30').parent().addClass('hide');

				$('#video-slot-picker #' + hour + '\\:00').parent().addClass('hide');
				$('#video-slot-picker #' + hour + '\\:30').parent().addClass('hide');
			}
			$('#voice-slot-picker #23\\:30').parent().addClass('hide');
			$('#video-slot-picker #23\\:30').parent().addClass('hide');
		},
		markInstaBookingSlotsForToday: function (hh, min) {
			var hour;
			if (hh < 23) $('.slot-container').children().addClass('hide');
			for (var i = hh + 1; i <= 23; i++) {
				if (i < 10) {
					hour = "0" + i;
				} else {
					hour = i;
				}
				if (!(i > 1 && i < 8)) $('#voice-slot-picker #' + hour + '\\:00').addClass('insta').parent().removeClass('hide');
				if (!(i >= 1 && i < 8)) $('#voice-slot-picker #' + hour + '\\:30').addClass('insta').parent().removeClass('hide');

				//$('#video-slot-picker #'+hour+'\\:00').addClass('insta').parent().removeClass('hide');
				//$('#video-slot-picker #'+hour+'\\:30').addClass('insta').parent().removeClass('hide');

				if (i == hh + 1 && min < 30) {
					hour = hour - 1;
					if (hour == 8 || hour == 9) hour = "0" + hour;
					$('#voice-slot-picker #' + hour + '\\:30').addClass('insta').parent().removeClass('hide');
					//$('#video-slot-picker #'+hour+'\\:30').addClass('insta').parent().removeClass('hide');
				}
			}
			if (hh >= 23) {
				if (hh == 23 && min < 30) {
					$('.slot-container').children().addClass('hide');
					$('#voice-slot-picker #23\\:30').addClass('insta').parent().removeClass('hide');
					//$('#video-slot-picker #23\\:30').addClass('insta').parent().removeClass('hide');
				} else {
					this.allStotsMarked = true;
					this.markInstaBookingSlots({
						'hours': hh,
						'min': min,
						'index': 1
					})
				}
			}
		},
		markInstaBookingSlots: function (options) {
			var index = options.index;
			if (index && options.dateClicked && this.allStotsMarked) {
				this.removeNonServiceableSlots();
				return;
			}
			var hh = options.hours;
			var min = options.min;
			var hour;
			//var instaBooking = false;
			if (index) {
				var startHour = 0;
				if (this.allStotsMarked && hh > 23) {
					startHour = hh - 23;
					var slotHH;
					for (var j = 0; j < startHour; j++) {
						slotHH = "0" + j;
						$('#voice-slot-picker #' + slotHH + '\\:00').parent().addClass('hide');
						$('#voice-slot-picker #' + slotHH + '\\:30').parent().addClass('hide');

						//$('#video-slot-picker #'+slotHH+'\\:00').parent().addClass('hide');
						//$('#video-slot-picker #'+slotHH+'\\:30').parent().addClass('hide');
					}
					if (min < 30) {
						$('#voice-slot-picker #' + slotHH + '\\:30').addClass('insta').parent().removeClass('hide');
						//$('#video-slot-picker #'+ slotHH +'\\:30').addClass('insta').parent().removeClass('hide');
					}
				}
				for (var i = startHour; i < hh - 1; i++) {
					if (i < 10) {
						hour = "0" + i;
					} else {
						hour = i;
					}

					if (!(i > 1 && i < 8)) {
						$('#voice-slot-picker #' + hour + '\\:00').addClass('insta');
					} else {
						$('#voice-slot-picker #' + hour + '\\:00').parent().addClass('hide');
					}
					if (!(i >= 1 && i < 8)) {
						$('#voice-slot-picker #' + hour + '\\:30').addClass('insta');
					} else {
						$('#voice-slot-picker #' + hour + '\\:30').parent().addClass('hide');
					}

					//$('#video-slot-picker #'+hour+'\\:00').addClass('insta').parent().removeClass('hide');
					//$('#video-slot-picker #'+hour+'\\:30').addClass('insta').parent().removeClass('hide');
					//instaBooking = true;

				}
				if (min < 30) {
					$('#voice-slot-picker #' + hour + '\\:30').removeClass('insta');
					//$('#video-slot-picker #'+hour+'\\:30').removeClass('insta');
				}
				//if (!instaBooking) this.removeNonServiceableSlots();
				if (hh == 25 && min >= 30) return;
				$('#voice-slot-picker #23\\:30').parent().addClass('hide');
				//$('#video-slot-picker #23\\:30').parent().addClass('hide');
			} else {
				//current date
				this.markInstaBookingSlotsForToday(hh, min);
			}
		},
		dateClicked: function (e) {

			var self = this;
			var orgIdOfLoggedInUsr = JSON.parse(localStorage.getItem("user"));
			var usrOrgId;
			if (orgIdOfLoggedInUsr) {
				usrOrgId = orgIdOfLoggedInUsr.loggableUser.orgId;
			} else {
				usrOrgId = -1;
			}
			if (showZopimAppointment == 1) {
				clearTimeout(self.inactivityTimer);
				self.checkforInactivity(30);
			}

			var today = new Date();
			if (self.appointmentModel.get('mode') == 'Video Call' || (self.appointmentModel.get('mode') == 'Voice Call' && usrOrgId !== -1)) {
				today = new Date(today.getTime() + 60 * 60 * 24 * 1000);
			} else {
				today = new Date(today.getTime() + 60 * 60 * 2 * 1000);
			}
			//today = new Date(today.getTime() + 60 * 60 * 7 * 1000);
			var dd = today.getDate();
			//dd++;
			var mm = today.getMonth();
			var hh = today.getHours();
			var Months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
			if (dd < 10) {
				dd = '0' + dd;
			}
			var today_str = Months_arr[mm] + ' ' + dd;
			$(e.currentTarget).siblings().removeClass('ex-selected-2')
			$(e.currentTarget).siblings().removeClass('ex-selected');
			var dt = $(e.currentTarget).find('.date-text').text();
			var dateIndex = $(e.currentTarget).index();
			/*
				Index 0 is current date
				Index 1 is next date
				For all indexes > 1, insta booking is not applicable (we remove non serviceable slots post 11pm to 6am)
			*/
			$('.slot-container').children().removeClass('hide');
			$('.slot-container .insta').removeClass('insta');
			if (dateIndex > 1) {
				self.removeNonServiceableSlots();
			} else {
				if (self.appointmentModel.get('mode') == 'Video Call' || (self.appointmentModel.get('mode') == 'Voice Call' && usrOrgId !== -1)) {
					if (dateIndex) {
						self.removeNonServiceableSlots();
					} else {
						self.initializeSlotPicker(true);
					}
				} else {
					if (hh == 0) hh = 24;
					if (hh == 1) hh = 25;
					self.markInstaBookingSlots({
						'index': dateIndex,
						'hours': hh,
						'min': today.getMinutes(),
						'dateClicked': true
					});
				}
			}
			// if(dt == today_str){
			// 	if(hh >06 && hh < 24){
			// 		var hour = 06;
			// 		for(i = 6 ; i<= hh +2; i++){
			// 			if(i < 10){
			// 				hour = "0"+i;
			// 			}else{
			// 				hour = i;
			// 			}
			// 			$('#voice-slot-picker #'+hour+'\\:00').parent().addClass('hide');
			// 			$('#voice-slot-picker #'+hour+'\\:30').parent().addClass('hide')

			// 			$('#video-slot-picker #'+hour+'\\:00').parent().addClass('hide');
			// 			$('#video-slot-picker #'+hour+'\\:30').parent().addClass('hide');
			// 		}
			// 	}
			// }
			// else{
			// 	$('.slot-container').children().removeClass('hide');
			// }
			$(e.currentTarget).addClass('ex-selected-2');
			$(e.currentTarget).parents().find('.slot-cell').removeClass('ex-selected-2');
			$(e.currentTarget).parents().find('.slot-cell').removeClass('ex-selected');
			$('.next-3').addClass('disabled');

			this.appointmentModel.set('slotdate', dt);
			this.appointmentModel.set('slottime', '');
			if (self.appointmentModel.get('mode') == 'Voice Call') {
				var h = $('.slot-picker').height() + 40;
				$('#VIDEO').css({ 'margin-top': h });
			}
		},
		initializeMode: function (e) {
			var self = this;
			$.ajax({
				url: Utils.contextPath() + '/v1/appointment/fare',
			}).done(function (res) {
				_.each(res, function (elem, index) {
					if (elem.type == 'AUDIO') self.audio_charges = elem;
					if (elem.type == 'INSTANT_AUDIO') self.insta_charges = elem;
					if (elem.type == 'FACE2FACE') {
						self.f2f_charges = elem;
						elem.type = "F2F"
					}
					$('#' + elem.type + " #charges").text(elem.amount['base']);
					$('#' + elem.type + " #charges-small").text(elem.amount['base']);
					$('#' + elem.type + " #init-time").text(elem.measure['base']);
					$('#' + elem.type + " #extra-time").text(elem.measure['extra']);
					$('#' + elem.type + " #extra-rate").text(elem.amount['extra']);
					if (self.fromLocation == 'zenparent') {
						$('#AUDIO #charges').text('300');
						$('#AUDIO #charges-small').text('300');
						$('.back-3').addClass('disabled');
						$('.backToTalkItOut').addClass('disabled');

					}

				});

			});

		},
		initializeSlotPicker: function (isVideoAppointment) {
			var self = this;
			var today = new Date();
			if (isVideoAppointment) {
				today = new Date(today.getTime() + 60 * 60 * 24 * 1000);
			} else {
				today = new Date(today.getTime() + 60 * 60 * 2 * 1000);
			}
			//today = new Date(today.getTime() + 60 * 60 * 7 * 1000);
			var date_cell = new Date(today.getTime());
			//new Date().getTime() + 60 * 60 * 24 * 1000);
			var dd = today.getDate();
			dd++;
			var mm = today.getMonth();
			var yyyy = today.getYear();
			var day = today.getDay() - 1;
			var hour = today.getHours();
			var min = today.getMinutes();
			var slots = [
				'00:00',
				'00:30',
				'01:00',
				'01:30',
				'02:00',
				'02:30',
				'03:00',
				'03:30',
				'04:00',
				'04:30',
				'05:00',
				'05:30',
				'06:00',
				'06:30',
				'07:00',
				'07:30',
				'08:00',
				'08:30',
				'09:00',
				'09:30',
				'10:00',
				'10:30',
				'11:00',
				'11:30',
				'12:00',
				'12:30',
				'13:00',
				'13:30',
				'14:00',
				'14:30',
				'15:00',
				'15:30',
				'16:00',
				'16:30',
				'17:00',
				'17:30',
				'18:00',
				'18:30',
				'19:00',
				'19:30',
				'20:00',
				'20:30',
				'21:00',
				'21:30',
				'22:00',
				'22:30',
				'23:00',
				'23:30'
			]
			if (dd < 10) {
				dd = '0' + dd;
			}



			var Months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
			var Days_arr = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
			var appendDate = '';
			var appendDay = '';
			var appendSlot = '';

			_.each(slots, function (slot, index) {
				var br_flag = 1;
				appendSlot += '<div class = "slot-cell cpointer" data-desc="Appt step 3 - slot selected"><p class="date-text" id =' + slot + '>' + slot + '</p></div>';

			});
			$('.slot-container').html(appendSlot);

			var flagEleven = false;
			date_cell = new Date(new Date(date_cell).getTime() - 60 * 60 * 24 * 1000);
			for (var i = 1; i <= 7; i++) {
				date_cell = new Date(new Date(date_cell).getTime() + 60 * 60 * 24 * 1000);
				dd = date_cell.getDate();
				if (dd < 10) {
					dd = '0' + dd;
				}
				var d = Months_arr[date_cell.getMonth()] + ' ' + dd;
				//if(Utils.isMobileDevice()) d = dd;
				if (i == 1) {
					var h = today.getHours();
					if (h <= 23 && dd == today.getDate()) {
						if (h == 23 && (min >= 30 || isVideoAppointment)) {
							flagEleven = true;
							day++;
							if (day > 6) day = 0;
						} else {
							self.appointmentModel.set('slotdate', d);
							appendDate += '<div class="date-cell cpointer ex-selected-2"><p class="date-text">' + d + '</p></div>';
						}
					}
				} else {
					if (flagEleven && i == 2) {
						appendDate += '<div class="date-cell ex-selected-2 cpointer"><p class="date-text">' + d + '</p></div>';
						self.appointmentModel.set('slotdate', d);
					}
					else {
						appendDate += '<div class="date-cell cpointer"><p class="date-text">' + d + '</p></div>';
					}
				}
				if (day == -1) day += 7;
				appendDay += '<div class="day-cell"><p class="day-text">' + Days_arr[day] + '</p></div>';
				day++;
				if (day > 6) { day = 0; }
			}

			if (flagEleven) {
				if (isVideoAppointment) {
					var d = parseInt(d.split(" ")[1]) + 1;
					if (d < 10) d = "0" + d;
					d = Months_arr[date_cell.getMonth()] + " " + d;
					appendDate += '<div class="date-cell cpointer"><p class="date-text">' + d + '</p></div>';
				} else {
					var d = dd + ' ' + Months_arr[mm];
					appendDate += '<div class="date-cell cpointer"><p class="date-text">' + d + '</p></div>';
				}
			}
			//appendSlot = this.slotPicker();
			$('.day-container').html(appendDay);
			$('.date-container').html(appendDate);
			var hh = today.getHours();
			if (isVideoAppointment) {
				self.removeNonServiceableSlots(hh, isVideoAppointment);
			} else {
				if (hh == 0) hh = 24;
				if (hh == 1) hh = 25;
				self.markInstaBookingSlotsForToday(hh, min);
			}
		},
		nextPage2: function () {
			var self = this;


			//self.$el.html(self.loaderHTML());
			if (self.appointmentModel.get('counselorid') == 0) {
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Appt step-2 Expert selected", { "mediumSource": "website", "itemName": "Default" });
				}
			}

			if (self.fromLocation == 'reschedule') {
				//var mode = self.appointmentModel.get('mode');
				self.backtoMode();
			} else {
				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Book Appointment Step-3", { "source": " HomePage", "itemName": self.fromLocation });
				}
				var orgUser = true
				if (Utils.isLoggedIn()) {
					if (JSON.parse(localStorage.getItem("user"))["loggableUser"]["orgId"] != -1) {
						orgUser = false
					}
				}
				self.$el.html(self.StepthreeLayout({
					'audioPromo': self.audioPromo,
					'videoPromo': self.videoPromo,
					orgUser: orgUser
				}));
				self.intializeSelectedCounselorCard();
				self.initializeMode();
				self.needHelpView.render("step-2", false)
				//self.initializeSlotPicker();
				window.scrollTo(0, 0);
				self.checkPaymentPending();
				self.checkForExtraPay()
				self.checkFeedbackPending();
				$('#head-step3').text("Choose your mode of Contact");

				if (showZopimAppointment == 1) {
					self.checkforInactivity(30);
				}

			}

		},
		checkforInactivity: function (inactivityTimeOut) {

			var self = this;

			this.chatVisible = 0;

			inactivityTimeOut = inactivityTimeOut * 1000;

			this.inactivityTimer = setTimeout(function () {

				self.showChat();

			}, inactivityTimeOut);

		},
		showChat: function () {

			var self = this;

			self.chatVisible = 1;
			clearTimeout(self.inactivityTimer);

			$zopim(function () {
				$zopim.livechat.window.show();
			});


		},
		expertSelected: function (e) {
			var self = this;
			self.appointmentModel.set('conSource', '');
			var top_expt_flag = $(e.currentTarget).hasClass('top-expert-check');
			var my_expt_flag = $(e.currentTarget).hasClass('fam-experts');
			var default_flag = $(e.currentTarget).hasClass('default-counselor');

			//$('.check-experts').addClass("hide");
			$("input[type='checkbox']").prop("checked", false);
			$('#selected-expert-dropdown').val("");
			$('.expt-dropdown-content').addClass('hide');

			$('.ex-selected').removeClass('ex-selected');
			$('.ex-selected-2').removeClass('ex-selected-2');
			$(e.currentTarget).find("input[type='checkbox']").prop("checked", 'checked');
			$(e.currentTarget).find('.check-experts').removeClass("hide");
			$(e.currentTarget).addClass('ex-selected-2');
			var counselorID = $(e.currentTarget).find(".check-experts").attr("data-counselorId");
			var counselorName = "Special Friend";
			if (counselorID != 0) {
				counselorName = $(e.currentTarget).find("#exprt-name").text();
			}
			console.log(counselorID);

			if (top_expt_flag) {
				self.appointmentModel.set('conSource', 'TopExperts');
			}
			if (my_expt_flag) {
				self.appointmentModel.set('conSource', 'MyExperts');
			}
			if (default_flag) {
				self.appointmentModel.set('conSource', 'Default');
			}
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track("Appt step-2 Expert selected", { "mediumSource": "website", "itemName": self.appointmentModel.get('conSource') });
			}
			self.appointmentModel.set('counselorid', counselorID);
			self.appointmentModel.set('counselorname', counselorName);

		},
		initializeSwiper: function () {

			var self = this;
			self.swiper = new Swiper('.swiper-container', {

				// Optional parameters
				direction: 'horizontal',
				loop: true,
				slidesPerView: 3,
				initialSlide: 0,
				//autoplay: 4000,
				// Navigation arrows
				nextButton: '.swiper-button-next',
				prevButton: '.swiper-button-prev',
				breakpoints: {
					// when window width is <= 320px
					320: {
						slidesPerView: 'auto',
						spaceBetweenSlides: 5
					},
					// when window width is <= 480px
					480: {
						slidesPerView: 'auto',
						spaceBetweenSlides: 5
					},
					// when window width is <= 640px
					640: {
						slidesPerView: 'auto',
						spaceBetweenSlides: 10
					},
					768: {
						slidesPerView: 'auto',
						spaceBetweenSlides: 15
					},
					992: {
						slidesPerView: 3,
						spaceBetweenSlides: 10
					},
					1024: {
						slidesPerView: 3,
						spaceBetweenSlides: 10
					}
				}
			});
		},
		sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				})
				.fail(function (error) {
					deferred.reject(error);
				})
			return deferred.promise();
		},
		loadExperts: function () {
			var self = this;
			self.$el.html(self.loaderHTML());
			var url = Utils.contextPath() + '/v1/counselor'
			self.sendRequest({ url: url, method: 'GET' })
				.then(function (resp) {
					self.$el.html(self.SteptwoLayout({ post_all: resp }));
					self.needHelpView.render("step-1", false)
					if (Utils.isLoggedIn()) url = Utils.contextPath() + '/v1/counselor/?user=' + self.userModel.getUserID() + '&familiar=true'
					self.sendRequest({ url: url, method: 'GET' })
						.then(function (res) {
							self.checkPaymentPending();
							self.checkForExtraPay();
							self.checkFeedbackPending();
							$('.experts-top-slider ul').html(self.loaderHTML());
							if (res.length) {
								if (Utils.isLoggedIn()) $(".af-top-experts").find(".title").html("or,select from your experts")
								showExperts(res)
							} else {
								var url = Utils.contextPath() + '/v1/counselor'
								self.sendRequest({ url: url, method: 'GET' })
									.then(function (res) {
										showExperts(res)
									})
							}
							function showExperts(res) {
								res = res.slice(0, 10)
								var promiseArr = []
								var counselorHashList = []
								$('.experts-top-slider ul').html('');
								$("#default-counselor").addClass('ex-selected-2');
								promiseArr.push(self.sendRequest({ method: "GET", url: Utils.contextPath() + "/v1/counselor/status" }))
								$.each(res, function (index, elem) {
									var counselorHash = {}
									counselorHash = elem;
									var formattedDate = Utils.getDateString(elem.lastActive * 1000, "shortdate");
									counselorHash["formattedDate"] = formattedDate
									counselorHashList.push(counselorHash);
									promiseArr.push(self.sendRequest({ method: "GET", url: Utils.contextPath() + "/v1/counselor/rating/" + elem.id }))
								})
								$.when.apply($, promiseArr)
									.then(function (result) {
										var responseArr = Array.prototype.slice.call(arguments);
										var statusObj = responseArr[0];
										for (i = 0; i < counselorHashList.length; i++) {
											var statusDetails = statusObj[counselorHashList[i].id];
											$('.experts-top-slider ul').append(self.ExpertCard2({ status: statusDetails.status, counselor: counselorHashList[i], formattedDate: counselorHashList[i].formattedDate, rating: counselorHashList[i].rating, reviewCount: responseArr[i + 1].length }));
										}
										self.initializeSwiper()
										self.retainExperts();
									})
							}
						})
				})
		},
		retainExperts: function () {

			var self = this;

			if (self.appointmentModel.get('backFromFuturetoCon') || self.fromLocation == 'reschedule') {

				var temp = self.appointmentModel.get('conSource');
				var counselorname = self.appointmentModel.get('counselorname');
				var counselorId = self.appointmentModel.get('counselorid');
				//$('.check-experts').addClass("hide");
				$("input[type='checkbox']").prop("checked", false);
				$('#selected-expert-dropdown').val("");
				$('.expt-dropdown-content').addClass('hide');

				$('.ex-selected').removeClass('ex-selected');
				$('.ex-selected-2').removeClass('ex-selected-2');
				if (temp == 'MyExperts') {

					var card = $('.fam-experts:contains("' + counselorname + '")');
					card.find("input[type='checkbox']").prop("checked", 'checked');
					card.find('.check-experts').removeClass("hide");
					card.addClass('ex-selected-2');
				}
				if (temp == 'TopExperts') {

					var card = $('.top-expert-check:contains("' + counselorname + '")');
					card.find("input[type='checkbox']").prop("checked", 'checked');
					card.find('.check-experts').removeClass("hide");
					card.addClass('ex-selected-2');

				}
				if (temp == 'Default' || temp == undefined || temp == null || temp == '') {

					$("#default-counselor").addClass('ex-selected-2');
					$('#default-counselor  .default-check').removeClass('hide')
					$('#default-counselor input[type="checkbox"]').prop('checked', true);

				}
				if (temp == 'DropDown') {
					var card = $('.expt-dropdown-content li:contains("' + counselorname + '")');
					card.find("input[type='checkbox']").prop("checked", 'checked');
					card.find('.check-experts').removeClass("hide");
					card.addClass('ex-selected-2');
					$('#selected-expert-dropdown').val(counselorname);
					$('#selected-expert-dropdown').text(counselorname);

				}
				if (Utils.isLoggedIn() && (temp == 'TopExperts' || temp == 'Default' || temp == 'DropDown')) {
					$('#appointmentTab').removeClass('hide');
					$('#my-experts a').removeClass('active-tab');
					$('#choose-experts a').addClass('active-tab');
					$('#tab1').addClass('hide');
					$('#tab2').removeClass('hide');
				}
				self.appointmentModel.set('backFromFuturetoCon', false)
			}
		},
		clickTabStep2: function (e) {

			if ($(e.currentTarget).prop('id') == "my-experts") {

				$('#tab1').removeClass('hide');
				$('#tab2').addClass('hide');
				$('#choose-experts a').removeClass('active-tab');
				$('#my-experts a').addClass('active-tab');
			} else {

				$('#tab1').addClass('hide');
				$('#tab2').removeClass('hide');
				$('#choose-experts a').addClass('active-tab');
				$('#my-experts a').removeClass('active-tab');
				this.initializeSwiper();
			}
		},
		nextPage1: function (e) {

			var self = this;
			self.appointmentModel.set('description', $('.description').val());

			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {

				mixpanel.track("Step-2 Book Appointment", { "mediumSource": "website", "itemName": 'Category:' + self.appointmentModel.get('category') });
			}
			if (self.fromLocation == 'reschedule') {
				self.backtoExperts();
			} else {
				self.appointmentModel.set('conSource', 'Default');
				self.appointmentModel.set('backFromFuturetoCon', false);
				self.loadExperts();
				self.checkPaymentPending();
				self.checkFeedbackPending();
			}
		},
		categorySelected: function (e) {

			var self = this;
			e.stopPropagation();
			e.preventDefault();
			var select_flag = 0;
			var other_open;
			var card = $(e.currentTarget);
			var other_clicked = card.hasClass('cat-o');

			if (!Utils.isMobileDevice()) {

				$('html, body').animate({ scrollTop: 100 }, 'slow');
			} else {

				$('html, body').animate({ scrollTop: 250 }, 'slow');
			}

			var category_select = this.appointmentModel.get('category');
			var cat = card.find('input').val();
			var selected_flag = card.find("input[type='checkbox']").prop("checked");
			$('#step-1 .ex-selected').removeClass('ex-selected')
			$("#step-1 input[type='checkbox']").prop('checked', false);

			if (!selected_flag && !other_clicked) {

				$('.selected-cat').removeClass('selected-cat');
				//$(".category .check-cat").addClass('hide');
				$(".selected-cat-circle").addClass('cat-circle');
				$(".selected-cat-circle").removeClass('selected-cat-circle');
				card.addClass('selected-cat');
				card.find(".cat-circle").addClass('selected-cat-circle');
				card.find(".cat-circle").removeClass('cat-circle');
				card.find("input[type='checkbox']").prop('checked', true);
				$('.description').removeClass('hide');

				if (cat == 'Others') {

					$('.other-cat').removeClass('hide');
					$('.cat-others').addClass("addarrow")
					$('.cat-o input[type="checkbox"]').prop('checked', false);
					self.appointmentModel.set('category', '');

				} else {
					card.find(".check-cat").removeClass('hide');
					if (cat == 'Career-Academic' || cat == 'Career/Academic') {
						cat = 'Career Confusion';
					}
					if (cat == 'Sexual Wellness') {
						cat = 'Sexual-Wellness';
					}
					if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
						mixpanel.track("Category Selected", { "mediumSource": "website", "itemName": 'bookAppointment Step-1' });
					}
					self.appointmentModel.set('category', cat);
					$('.other-cat').addClass('hide');
					$('.cat-others').removeClass("addarrow")
				}

			} else if (selected_flag && !other_clicked) {

				$(e.currentTarget).removeClass('selected-cat ');
				$(e.currentTarget).find(".selected-cat-circle").addClass('cat-circle');
				$(e.currentTarget).find(".selected-cat-circle").removeClass('selected-cat-circle');
				if (cat == 'Others') {

					$('.other-cat').addClass('hide');
					$('.cat-others').removeClass("addarrow")
					//$(".cat-others").find("input[type='checkbox']").prop('checked', false);
					$('.cat-o input[type="checkbox"]').prop('checked', false);

				} else {
					//$(e.currentTarget).find(".check-cat").addClass('hide');
					self.appointmentModel.set('category', '');
					//	cat_flag--;

				}
				$('.description').addClass('hide');

				self.appointmentModel.set('category', '');
			} else if (!selected_flag && other_clicked) {

				$('.cat-o').find('input[type="checkbox"]').prop('checked', false);

				$(".cat-others").find("input[type='checkbox']").prop('checked', true);

				if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
					mixpanel.track("Other Category Selected", { "mediumSource": "website", "itemName": 'bookAppointment Step-1' });
				}
				self.appointmentModel.set('category', cat);
				$(e.currentTarget).find('input[type="checkbox"]').prop('checked', true);
			} else if (selected_flag && other_clicked) {

				self.appointmentModel.set('category', '');
				$('.cat-o input[type="checkbox"]').prop('checked', false);
				$(".cat-others").find("input[type='checkbox']").prop('checked', true);
			}

			console.log(self.appointmentModel.get('category'))
			var a = self.appointmentModel.get('category');
			a = a.replace(undefined, '');
			self.appointmentModel.set('category', a);
		},
		updateFeedback: function () {
			var self = this;
			if (Utils.isLoggedIn()) {
				var txnID = self.appointmentModel.set('appointmentId');
				var userID = self.userModel.getUserID();
				var mode = self.appointmentModel.get('mode')
				if (mode === 'face2face') mode = 'Face To Face'
				var product_context_info = "Feedback for " + mode + " call with " + self.appointmentModel.get('counselorname') + " at " + self.appointmentModel.get('slotdate') + " " + self.appointmentModel.get('slottime');
				var feedback_id = 0;
				$.ajax({
					url: Utils.contextPath() + "/v1/user/feedback/" + userID + "/APPOINTMENT/" + txnID,
				}).done(function (response) {
					console.log("Feedback fetched!")
					feedback_id = response.id

				});
				var dataToSend = {
					"feedback_id": feedback_id,
					"counselor_id": self.appointmentModel.get('counselorid'),
					"victim_id": userID,
					"description": "",
					"feeling": "",
					"category": "",
					"channel": "web",
					"product_info": "APPOINTMENT",
					"product_context_id": txnID.toString(),
					"product_context_info": product_context_info
				}
				$.ajax({
					url: Utils.contextPath() + "/v1/user/feedback/update",
					method: 'POST',
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: JSON.stringify(dataToSend),
				}).done(function (res) {
					if (res) {
						console.log("Feedback updated!")
					}

				});
			}
		},
		createFeedback: function () {
			var self = this;

			if (Utils.isLoggedIn()) {
				var userID = self.userModel.getUserID();
				if (self.appointmentModel.get('counselorid') == 0) {
					self.appointmentModel.set('counselorid', 101);
					self.appointmentModel.set('counselorname', "Special Friend");

				}
				var mode = self.appointmentModel.get('mode')
				if (mode === 'face2face') mode = 'Face To Face'
				var product_context_info = "Feedback for " + mode + " with " + self.appointmentModel.get('counselorname') + " at " + self.appointmentModel.get('slotdate') + " " + self.appointmentModel.get('slottime');

				var dataToSend = {
					"counselor_id": self.appointmentModel.get('counselorid'),
					"victim_id": userID,
					"description": "",
					"feeling": "",
					"category": "",
					"channel": "web",
					"product_info": "APPOINTMENT",
					"product_context_id": self.appointmentModel.get('transactionID').toString(),
					"product_context_info": product_context_info
				}

				$.ajax({
					url: Utils.contextPath() + "/v1/user/feedback/create",
					method: 'POST',
					dataType: "json",
					xhrFields: {
						withCredentials: true
					},
					contentType: "application/json",
					data: JSON.stringify(dataToSend),
				}).done(function (response) {
					if (response.status == 'success') {
						self.feedbackID = response.id;
						console.log("Feedback created!")
					} else {
						console.log("Feedback creation error occured!")
					}

				});
			}
		},
		submitFeedback: function () {


			var self = this;

			if (Utils.isLoggedIn()) {

				var userID = self.userModel.getUserID();
				var star = $('input[name=group1]:checked').val();
				var feeling = $('input[name=group2]:checked').val();
				var description = $('#feedback-description').val()
				if (star == undefined) {
					$('#rate-expert-error').removeClass('hide')
				} else if (feeling == undefined) {
					$('#feel-expert-error').removeClass('hide')
				} else {
					$('#submit-feedback-appointment').addClass('hide');
					$('#submit-feedback-appointment-progress').removeClass('hide');
					var mode = self.appointmentModel.get('mode')
					if (mode === 'face2face') mode = 'Face To Face'
					var product_context_info = "Feedback for " + mode + " with " + self.appointmentModel.get('counselorname') + " at " + self.appointmentModel.get('slotdate') + " " + self.appointmentModel.get('slottime');
					self.pendingFeedback['star'] = parseInt(star)
					self.pendingFeedback['feeling'] = feeling
					self.pendingFeedback['description'] = description
					$.ajax({
						url: Utils.contextPath() + "/v1/user/feedback/submit",
						method: 'POST',
						dataType: "json",
						xhrFields: {
							withCredentials: true
						},
						contentType: "application/json",
						data: JSON.stringify(self.pendingFeedback),
					}).done(function (response) {
						if (response) {
							self.feedbackID = response.id;
							$('#feedbackModal').closeModal();
							self.render();
							$('body').css({ 'overflow': 'auto' });
							console.log("Feedback submitted!")
						} else {
							console.log("Feedback creation error occured!")
							$('#submit-feedback-appointment').removeClass('hide');
							$('#submit-feedback-appointment-progress').addClass('hide');
						}

					});
				}
			} else {
				self.render()
			}


		},
		checkPaymentPending: function () {
			var self = this;
			if (Utils.isLoggedIn()) {
				console.log('checking payment...');
				var userID = self.userModel.getUserID();
				$.ajax({
					url: Utils.contextPath() + "/v1/user/transaction/pending/" + userID,
				}).done(function (pendingID) {

					var isPendingAmount = 0;
					if (pendingID > 0) {
						console.log('payment pending...')
						isPendingAmount = 1;
						self.pendingID = pendingID;
						$('.pending-msg-header').removeClass('hide');
						$(".payment-pending-url").attr("href", "/sessions");
						$('.next-3').addClass('disabled');
						$('.next-2').addClass('disabled');
						$('.next-1').addClass('disabled');
						$('#update-info-form').addClass('disabled');
						window.scrollTo(0, 0);
					}
				});
			}
		},
		checkFeedbackPending: function () {
			var self = this;
			if (Utils.isLoggedIn()) {
				console.log('checking feedback...');
				var userID = self.userModel.getUserID();
				$.ajax({
					url: Utils.contextPath() + "/v1/user/feedback/" + userID + "/1/APPOINTMENT/last",
				}).done(function (resp) {
					if (!resp.errorMsg && resp.state == 1) {
						self.pendingFeedback = resp;
						self.$el.append(self.FeedbackModal({ feedback: resp }));
						Utils.openPopup("feedbackModal");
					}
				});
			}
		},
		checkOffer: function () {
			var self = this;
			var deferred = $.Deferred();
			if (Utils.isLoggedIn()) {
				$.ajax({
					url: Utils.contextPath() + "/v2/users/" + this.userModel.getUserID() + "/offers"
				})
					.done(function (res) {
						res.forEach(function (offer) {
							if (offer.discounted_product_type == 'AUDIO') {
								self.audioPromo = offer.name;
								self.audioPromoRemaining = offer.overall_quota - offer.redemption_count;
							}
							if (offer.discounted_product_type == 'VIDEO') {
								self.videoPromo = offer.name;
								self.videoPromoRemaining = offer.overall_quota - offer.redemption_count;
							}
							if (offer.discounted_product_type == 'FACE2FACE') {
								self.f2fPromo = offer.name;
								self.f2fPromoRemaining = offer.overall_quota - offer.redemption_count;
							}
						})
						deferred.resolve();
					});
			} else {
				deferred.resolve();
			}
			return deferred.promise();
		},
		renderCities: function () {
			var that = this;
			this.sendRequest({ url: Utils.scriptPath() + '/f2fcities.json' })
				.then(function (res) {
					that.citiesObj = res.cities;
				})
			$(document).mouseup(function (e) {
				var container = $(".select-cities").is(':visible') ? $(".select-cities") : ($(".select-areas").is(':visible') ? $(".select-areas") : $(".select-dates"));
				if (!container.is(e.target) && container.has(e.target).length === 0) {
					container.addClass("hide")
					$(".select-date-div i, .select-city-div i").removeClass('active')
				}
			});
		},
		handleExtraPay: function () {
			this.appointmentModel.set("rate", this.extrapayAmount);
			this.appointmentModel.set('transactionID', this.extrapayId);
			this.initializeRazorPay(this.extrapayId)
		},
		checkForExtraPay: function () {
			var self = this;
			// self.$el.append(self.extrapayModalLayout({details : ''}));
			// Utils.openPopup('extrapayModal') ;
			if (Utils.isLoggedIn) {
				this.sendRequest({
					url: Utils.contextPath() + '/v1/user/transaction/extra/created?ptype=AUDIO,VIDEO,INSTANT_AUDIO,FACE2FACE',
					method: 'GET'
				}).then(function (res) {
					if (res.length) {
						var transItem = res[0];
						var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
						var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
						var options = {};
						self.extrapayAmount = transItem.transaction.amount;
						self.extrapayId = transItem.transaction.id;
						options.amount = transItem.transaction.amount;
						options.type = transItem.offlinePaymentContext.productDetails.type;
						if (options.type === 'FACE2FACE') options.type = "Face To Face"
						if (options.type === 'INSTANT_AUDIO') options.type = "Instant Audio"
						var date = new Date(transItem.offlinePaymentContext.productDetails.slotStartTime);
						options.date = days[date.getDay()] + ", " + months[date.getMonth()] + " " + date.getDate() + ", " + date.getFullYear();
						var metaData = JSON.parse(transItem.transaction.lineItems[0].product.productDetails.metadata);
						options.time = metaData.extraDuration;
						self.sendRequest({ url: Utils.contextPath() + '/v1/counselor/' + transItem.offlinePaymentContext.productDetails.counselorID, mthod: 'GET' })
							.then(function (res) {
								options.name = res.name
								self.$el.append(self.extrapayModalLayout({ details: options }));
								Utils.openPopup('extrapayModal');
							})
					}
				}, function (err) {
					console.log("Error: ", err)
				})
			}
		},
		render: function () {
			var self = this;
			self.renderCities()
			self.checkOffer()
				.then(function () {
					self.$el.html(self.loaderHTML());
					document.title = "Book Appointment | Counselors, Psychologists & Other Experts";
					$('meta[name=description]').attr('content', "Find the right YourDOST expert & schedule an online chat, phone or video call for career advice, relationship help, overcoming depression & anxiety, etc.");
					$('meta[name=title]').attr('content', "Book Appointment | Counselors, Psychologists & Other Experts");
					$('meta[property="og:description"]').attr('content', "Find the right YourDOST expert & schedule an online chat, phone or video call for career advice, relationship help, overcoming depression & anxiety, etc .");
					$('meta[property="og:title"]').attr('content', " Book Appointment | Counselors, Psychologists & Other Experts");
					$('link[rel="canonical"]').attr('href', 'https://yourdost.com/bookappointment');

					if (self.fromLocation == 'talkItOut' || self.fromLocation == 'counselor' || self.fromLocation == 'packages' || self.fromLocation == 'zenparent') {

						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {

							mixpanel.track("Book Appointment Step-3", { "source": " expert card on expert page", "itemName": self.fromLocation });
						}
						var orgUser = true
						if (Utils.isLoggedIn()) {
							if (JSON.parse(localStorage.getItem("user"))["loggableUser"]["orgId"] != -1) {
								orgUser = false
							}
						}
						self.$el.html(self.StepthreeLayout({
							'audioPromo': self.audioPromo,
							'videoPromo': self.videoPromo,
							'f2fPromo': self.f2fPromo,
							orgUser: orgUser
						}));
						self.intializeSelectedCounselorCard();
						self.initializeMode();
						self.checkForExtraPay();
						self.initializeSlotPicker();
						self.needHelpView.render("step-1", false)
						$('.back-3').addClass('backToTalkItOut');
						$('.back-3').removeClass('back-3');
						$('#head-step3').text("Choose your mode of Contact");
						self.checkPaymentPending();
						self.checkFeedbackPending();
						if (self.fromLocation == 'packages') {

							self.$el.find("#step-3 .collection").addClass("hide")
							self.$el.find(".appointment-heading-2").addClass("hide")
							self.$el.find(".slot-picker .appointment-heading-2").removeClass("hide").html("Pick a date and time to book Appointment")
							var item = $('#AUDIO')

							item.find('.btn')[0];
							item.siblings().removeClass('ex-selected-2');
							item.parent().find('.mode-container #bookMode').addClass('hide');
							item.parent().parents().find('.mode-container #selectMode').removeClass('hide');

							var mode = item.find('.mode').text();
							console.log(mode);
							if (!Utils.isMobileDevice()) {

								$('body').animate({ scrollTop: 220 }, "slow");
							} else {
								$('body').animate({ scrollTop: 300 }, "slow");
							}
							self.appointmentModel.set('mode', mode);
							var rate = item.find('#charges').html();
							self.appointmentModel.set('rate', '');
							self.appointmentModel.set('rate', rate);
							item.addClass('ex-selected-2');
							item.find('#bookMode').removeClass('hide');
							item.find('#selectMode').addClass('hide');
							var selectedMode = self.appointmentModel.get('mode');
							if (selectedMode == 'Video Call') {

								selectedMode = 'video';
								$('#video-slot-picker').removeClass('hide');
								$('#voice-slot-picker').addClass('hide');
								var h = $('.slot-picker').height() + 40;
								$('#AUDIO').css({ 'margin-top': h });

							}
							if (selectedMode == 'Voice Call') {
								selectedMode = 'voice';
								$('#video-slot-picker').addClass('hide');
								$('#voice-slot-picker').removeClass('hide');
								$('#AUDIO').css({ 'margin-top': '' });

							}
							if (selectedMode == 'Text Chat') {
								selectedMode = 'chat';
							}
							//$('#VIDEO').addClass('hide');
							$('#step-3 ul').addClass('hide')
							$('p:contains("mode of Contact")').addClass('hide');
							$("#selectedMode").text(selectedMode);
							$('.main-app-content').addClass('adjust-step3');
							$('.slot-picker').removeClass('hide');
						}
						if (self.fromLocation == 'zenparent') {
							$('.normal-rate').addClass('hide')
							$('.zenparent-rate').removeClass('hide')
							$('.zenparent-text').removeClass('hide')
							$('.zenparent-img').removeClass('hide')
							$('#progressBar').addClass('hide')
							$('.zenparent-img').parent().css({ 'margin-bottom': '20px' })
							$('.backToTalkItOut').addClass('disabled')
							$('#VIDEO').addClass('hide')

						}
					}
					else if (self.fromLocation == 'payment' || self.fromLocation == 'paymentReschedule') {
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Payment Confirmation", { "mediumSource": "website", "itemName": 'AppointmentConfirmation' });
						}
						self.renderAppointmentConfirmation();
					}
					else {
						if (self.fromLocation == "face2face") {
							self.bookModeofContact(null)
							return;
						}
						self.appointmentModel.set('conSource', 'Default');
						self.appointmentModel.set('backFromFuturetoCon', false);
						self.loadExperts();
						self.checkPaymentPending();
						self.checkFeedbackPending();
						if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
							mixpanel.track("Book appointment - step 2", { "source": "home appointment icon", "itemName": 'appointment booking started' });
						}
					}
				});
			self.getCategories();
		},
		getCategories: function () {
			var self = this;
			$.ajax({
				method: 'GET',
				url: Utils.scriptPath() + "/categories.json"
			}).done(function (res) {
				console.log('res', res);
				self.categoryList = res.categories;
			})
		},
		getSelectedCatVal: function (evt) {
			// console.log('clicked',evt.val())
			var optionSelected = $('#sel-category-div').val();
			console.log("optionSelected", optionSelected);
			if (optionSelected && !Utils.isMobileDevice()) {
				$("#error-cat-msg").addClass("hide");
				console.log("optionSelected", optionSelected);
				this.populateSubCategory(optionSelected);
				var subCat = $('#sel-sub-category-div').val()
				localStorage.setItem('selectedCategory', optionSelected);
				localStorage.setItem('subCategory', subCat);
				$("#category-div .select-dropdown").addClass("valid");
			} else {
				$("#error-cat-msg").addClass("hide");
				console.log("optionSelected", optionSelected);
				this.populateSubCategory(optionSelected);
				var subCat = $('#sel-sub-category-div').val()
				localStorage.setItem('selectedCategory', optionSelected);
				localStorage.setItem('subCategory', subCat);
				$("#sel-category-div").addClass("select-valid").removeClass("select-invalid");
			}
			$("#category-div .select-dropdown").css("color", "#444444");
		},
		populateSubCategory: function (catName) {
			var self = this;
			self.subCategoryList = self.categoryList[catName];
			var $el = $('#sel-sub-category-div');
			$el.empty();
			$el.append($("<option selected disabled></option>")
				.attr("value", "").text("Sub category"));
			$.each(self.subCategoryList, function (key, value) {
				console.log('key', key);
				console.log('value', value);
				$el.append($("<option></option>")
					.attr("value", value).text(value));

			});
			$('select').material_select();
			console.log('self', self.categoryList);
			console.log('sub cat list', self);
		},
		onSubCategoryChange: function () {
			var selectedSubCat = $('#sel-sub-category-div').val()
			console.log(selectedSubCat);
			localStorage.setItem('subCategory', selectedSubCat);
			$("#error-subcat-msg").addClass("hide");
			if (!Utils.isMobileDevice()) {
				$("#sub-category-div .select-dropdown").addClass("valid").removeClass("invalid");
			} else {
				$("#sel-sub-category-div").addClass("select-valid").removeClass("select-invalid")
			}
			$("#sub-category-div .select-dropdown").css("color", "#444444");
		}
	});
	AppointmentFlowView.prototype.remove = function () {

		this.$el.empty();
		this.$el.off();
		this.undelegateEvents();
		this.unbind();
	};

	AppointmentFlowView.prototype.clean = function () {

		this.remove();
	};

	return AppointmentFlowView;
});
