define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/login',
	'event/dispatcher',
	'keystop',
], function($, _, Backbone, JST, Utils, LoginModel, Dispatcher) {

	var SignUpPage = Backbone.View.extend({
		el: "main",
		initialize: function() {

			this.signUpProgress = 0 ;
			this.model = new LoginModel();

			var url = window.location.href ;
    		url = url.replace("/login", "" );

			var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo;

			this.fromAction  = '' ;
			this.extraParams = '' ;
			this.fromPage    = '' ;
			this.buttonDesc  = '' ;

			this.validateJSON = {
				"fields" : {
					"signupUsername" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z0-9]+$",
						"minLength" : 4 ,
						"messages" : {
							"required" : "Please enter a valid username" ,
							"regexp"   : "Username must start with an alphabet. Special characters are not allowed",
							"minLength": "Username must be minimum 4 characters"
						}
					},
					"signupEmail" : {
						//"required" : true ,
						"regexp" : "^[a-zA-Z0-9-_+.]+@[a-zA-Z0-9-_.]+\\.[a-zA-Z]+$",
						"messages" : {
							"required" : "Please enter a valid email id" ,
							"regexp"   : "Please enter a valid email id"
						}
					},
					"signupPassword" : {
						"required" : true ,
						"regexp" : "^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$",
						"minLength" : 8 ,
						"messages" : {
							"required"    : "Please enter a valid password" ,
							"minLength"   : "Password must be minimum 8 characters",
							"regexp"      : "Password must contain atleast 8 characters, at least 1 Alphabet, 1 Number and 1 Special Character (!,@,#,$,&,*,_,-)"
						}

					},
				}
			}

			_.bindAll(this)                ;
			this.listenTo(Dispatcher, 'renderSignup', this.renderHTML);

		},
		events: {
			'click #signup input[type=radio]' : 'showHideOptions',
			'click #signup .mclose' : 'hideSignUp' ,
			'submit #sign-up-form': "signUp",
			//'keyup #signupEmail' : 'checkForEmail',
			'keyup #security-answer':'checkforSecurityQuestion',
			'change #security-question':'checkforSecurityQuestion',
			'focusout #signupEmail' : 'checkForEmail',
			'change #tos-check'          : 'validateTOS',
			'click #login-redirect' : 'loginRedirect' ,
			// 'click #tos-redirect' : 'tosRedirect' ,
			'click #fb-signup-button' : 'loginFacebook'
		},
		statusChangeCallback : function(response){

			var self = this ;

			if (response.status === 'connected') {
			    FB.api('/me', function(response) {
			      console.log('Successful login for: ' + response.name);
			    });

			    var base64 = "FB "+btoa( response.authResponse.userID + ":" + response.authResponse.accessToken );
        		self.loginThroughApp(base64, 'FB');

			} else if (response.status === 'not_authorized') {
			  document.getElementById('status').innerHTML = 'Please log ' +
			    'into this app.';
			} else {
			  document.getElementById('status').innerHTML = 'Please try again later. Some error occurred';
			}
		},

		startGoogleApp : function() {
			var self = this ;

			gapi.load('auth2', function(){

				if( typeof auth2 == 'undefined'){
					auth2 = gapi.auth2.init({
						client_id: Utils.getGoogleApiId(),
					});
				}
				self.attachSignin(document.getElementById('customBtnSignup'));
			});
		},

		attachSignin: function(element) {
		    var self = this ;

		    auth2.attachClickHandler(element, {},
		        function(googleUser) {
		        	window.googleInfo = googleUser ;
		        var gUserID = googleUser.getBasicProfile().getId();
		        var gUserEmail = googleUser.getBasicProfile().getEmail();
		        var oauthToken = "" ;

		        for( var key in window.googleInfo ){
		        	if( typeof window.googleInfo[key].access_token != 'undefined' ) {
		        		oauthToken = window.googleInfo[key].access_token;
		        		console.log( window.googleInfo[key].access_token )
		        	}
		        }

		        var oauthToken = "" ;
				for( var key in window.googleInfo ){
					if( typeof window.googleInfo[key].access_token != 'undefined' ) {
						oauthToken = window.googleInfo[key].access_token ;
						console.log( window.googleInfo[key].access_token )
					}
				}

		        var base64 = 'GPLUS '+btoa( gUserID+"__"+gUserEmail + ":" + oauthToken );
		        self.loginThroughApp(base64, 'GPLUS');
		        }, function(error) {
		          console.log(JSON.stringify(error, undefined, 2));
		        });
		},

		loginThroughApp : function(loginHeader, src){

			var self = this ;

			$("#signup-btn").hide();
 			$("#signup-progress").show() ;

			$.ajax({
                type: 'POST',
                url: Utils.contextPath() +'/auth/login',
                dataType: "JSON",
                data: JSON.stringify({"shouldGenerateCookie": true,"ipSession": false}),
                contentType: "application/json; charset=utf-8",
                xhrFields: {
     				withCredentials: true
			    },
			    beforeSend :function(xhr){
			    	xhr.setRequestHeader( "Authorization", loginHeader );
			    },
			    statusCode:{
			    	417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

			    		$(".signin-error").removeClass("hide") ;
			    		$(".signin-error").html(errorMessage) ;
			    		$("#signup-btn").show();
 						$("#signup-progress").hide() ;
			    	},
			    },
            }).done(function(userInfo) {
				$(".login-error").addClass("hide") ;

				var data = userInfo.user ;
				self.hideSignUp();
				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : data ,
					});
					//mixpanel.identify(data.id);
					var distinct_id = mixpanel.get_distinct_id();
					var method = "";

					if(data.lastLogin == "null"){

						method = "SIGNUP"
						mixpanel.alias(data.id, distinct_id);
					}else{

						var timediff = Math.abs(data.lastLogin - data.registrationDate);

						if(timediff/60000 < 5){

							method = "SIGNUP"
							mixpanel.alias(data.id, distinct_id);

						}else{
							
							method = "LOGIN";
							mixpanel.identify(data.id);

						}
					}

					if(method == "SIGNUP"){
						if (  ( typeof fbq != 'undefined' ) ){
							fbq('track', 'CompleteRegistration');
						}

						if( typeof ga != 'undefined'){
							ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
						}
					}

					mixpanel.track(method, {'type' : src, 'mediumSource' : 'website', 'itemName' : self.buttonDesc, 'itemMedium' : src  });


					mixpanel.people.set({
	    			'username': data.username,
	    			'name' : data.username ,
	    			'$email': data.email,
	    			'id' : data.id,
	    			'src' : src,
 	    			'userType' : data["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				self.model.save(data) ;
				if( data.uri ){
					location.href = data.uri ;
					//Backbone.history.navigate(data.uri, {trigger: true});
				}else{
					/*if(self.fromAction == 'book_appointment'){
						//localStorage.setItem("fromAppointment", 1) ;
					}
*/
					console.log(self.redirectTo) ;
					if(self.fromAction == 'book_appointment'){
						//location.href = "/bookAppointment";
						Backbone.history.navigate("/bookAppointment", {trigger: true});
					}else if(self.fromAction == "home_chat"){
						location.href = Utils.chatUrl() + data.username;
					}else if( self.fromAction == "counselorChat"){
						var counselorChatUrl = self.extraParams ;
					location.href = counselorChatUrl + "&username=" + data.username;
					}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
						Backbone.history.navigate(self.extredirectTo, {trigger: true});
					}else{
						var paramUrl = "" ;
						if(self.fromAction == "message"){
							var counselorInfo = self.extraParams ;
							paramUrl = "?from=message&counselorID=" + counselorInfo.id ;
						}
						//location.href = "/talkItOut" + paramUrl;
						Backbone.history.navigate("/talkItOut" + paramUrl, {trigger: true});
					}
				}
            }).error(function(error){
  				console.log(error) ;
  			});
		},
		loginFacebook : function(e){
			var self = this ;

			if( FB.getUserID() && FB.getUserID() != "" ){
				FB.getLoginStatus(function(response) {
					self.statusChangeCallback(response);
				});
			}else{

				FB.login(function(response){
					self.statusChangeCallback(response);
				},{scope: 'public_profile,email'});
			}
		},
		loginRedirect : function(e){
			this.hideSignUp() ;

			Dispatcher.trigger("renderLogin", "click LOGIN Signup Modal", "login-modal", "") ;

			// currentPage = window.location.hash ;

			// if(!currentPage || currentPage == "#!"){
			// 	currentPage = "home";
			// }
			// currentPage = currentPage.replace("#", "");

			// var self = this ;
			// var buttonDesc = self.buttonDesc ;
			// buttonDesc = buttonDesc.replace("#", "");
			// var paramUrl = "?fromPage=" + currentPage + "&sourceDesc=" + buttonDesc ;
			// if(self.fromAction == "home_chat"){
			// 	paramUrl += "&from=home_chat" ;
			// }else if( self.fromAction == "counselorChat"){
			// 	var counselorChatUrl = self.extraParams ;
			// 	paramUrl += "&from=counselorChat&extraParams=" + counselorChatUrl ;
			// }else if(self.fromAction == "message"){
			// 	var counselorInfo = self.extraParams ;
			// 	paramUrl += "&from=message&extraParams=" + counselorInfo.id ;
			// }else if(self.fromAction == "book_appointment"){
			// 	paramUrl += "&from=book_appointment" ;
			// }

			// location.href = "#login" + paramUrl ;
		},
		tosRedirect : function(e){
			// this.hideSignUp() ;
			//location.href = "/termsOfService" ;
			// Backbone.history.navigate("/termsOfService", {trigger: true});
			window.open(
  				'/termsOfService',
  				'_blank' // <- This is what makes it open in a new window.
			);
		},
		validateTOS : function(e){
			if(!$("#tos-check").is(":checked") || !this.checkForAllFields()){
				$("#signup-btn").addClass("disabled") ;
				$("#signup-btn").attr("disabled", true) ;
			}else{
				$("#signup-btn").removeClass("disabled") ;
				$("#signup-btn").attr("disabled", false) ;
			}
		},
		checkForAllFields : function(){
			var username = $("input[name='signupUsername']").val();
			var password = $("input[name='signupPassword']").val().trim();
			//var confirmPassword = $("input[name='confirm_password']").val().trim();

			if( username.length <= 0 || password.length <= 0  ){
				return 0 ;
			}

			if(!$("#tos-check").is(":checked")){
				return 0 ;
			}

			if($('input[name="user_identity"]:checked').attr("id") == "email-option"){
				var email = $("input[name='signupEmail']").val();
				// if(email.length <=0 ){
				// 	return 0 ;
				// }
			}else{
				var securityAnswer = $("#security-answer").val() ;
				var securityQuestion = $("#security-question").val() ;
				// if( securityAnswer.length <= 0 || securityQuestion == undefined){
				// 	return 0 ;
				// }
			}
			return 1 ;
		},
		hideSignUp : function(e){
			console.log("hide signup");
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('signup');
			$("#lean-overlay").remove();
			$('#signup').remove() ;
		},
		disableSubmit : function(targetName){
			$("#validate-" + targetName ).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-close red-text prefix'></i>")
    		$("input[name='"+ targetName +"']").removeClass("valid").addClass("invalid") ;
			$("#signup-btn").addClass("disabled") ;
			$("#signup-btn").attr("disabled", true) ;
			$("#form-error-"+ targetName).show() ;
		},
		enableSubmit : function(targetName){
			$("#validate-" + targetName).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-check green-text prefix'></i>")

    		//	$("#validate-icon-" + targetName ).removeClass('mdi-navigation-close red-text').addClass('mdi-navigation-check green-text');
			$("input[name='"+ targetName +"']").removeClass("invalid").addClass("valid") ;
			$("#form-error-"+ targetName).html("") ;
			$("#form-error-"+ targetName).hide() ;

			var allFieldsValid = this.checkForAllFields();

			if(!allFieldsValid){
				$("#signup-btn").addClass("disabled") ;
				$("#signup-btn").attr("disabled", true) ;
				return 0 ;
			}

			if($(".form-valid i").hasClass("mdi-navigation-close")){
				$("#signup-btn").addClass("disabled") ;
				$("#signup-btn").attr("disabled", true) ;
			}else{
				$("#signup-btn").removeClass("disabled") ;
				$("#signup-btn").attr("disabled", false) ;
			}
			return 1 ;
		},
		checkForPassword : function(e){

			var targetName = $(e.currentTarget).attr("name") ;
			$("#validate-" + $(e.currentTarget).attr("name") ).html( this.loaderHTML()) ;
			var validPassword = this.validateText( $(e.currentTarget).attr("name")) ;

			if(validPassword == 0){
				this.disableSubmit( $(e.currentTarget).attr("name")) ;
			}else{
				this.enableSubmit( $(e.currentTarget).attr("name")) ;
			}

			/*if( targetName == 'signupPassword' && $("input[name='confirm_password']").val().trim().length > 0 ){
				var isValid = this.validateText("confirm_password") ;
				if(!isValid){
					this.disableSubmit( "confirm_password") ;
				}else{
					this.enableSubmit( 'confirm_password' ) ;
				}
			}*/

		} ,

		loaderHTML : function(){

			var html =  '<div class="preloader-wrapper small active" style="width: 20px;height: 20px;">';
    			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
    			html += '<div class="gap-patch"><div class="circle"></div></div>';
    			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>' ;

    			return html ;

		},
		checkForUsername : function(e){

			var self = this ;
			var username = $("#signupUsername").val() ;

			$("#validate-signupUsername").html( this.loaderHTML()) ;
			var usernameValid = this.validateText("signupUsername");
			if(usernameValid == 0 ){
				this.disableSubmit("signupUsername") ;
				return 0 ;
			}

			$("#validate-signupUsername").html( this.loaderHTML()) ;

			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=username&item=" + username,
				statusCode:{
            		404 : function(){
						$("#validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
						$("#form-error-signupUsername" ).hide() ;
            			self.enableSubmit("signupUsername") ;
            		}
        		},

				}).done(function(response){

					if(response == true ){
						if($("#form-error-signupUsername" ).length == 0){
							$("input[name='signupUsername']").after("<div id='form-error-signupUsername'  class='red-text'></div>");
						}

						$("#validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
						$("#form-error-signupUsername" ).html("This username already exists") ;
						$("input[name='signupUsername']").removeClass("valid").addClass("invalid") ;
						$("#signup-btn").addClass("disabled") ;
						$("#signup-btn").attr("disabled", true) ;
						$("#form-error-signupUsername").show() ;
					}

				}).error(function(){

				});

		},
		checkforSecurityQuestion : function(e){

			var targetID = $(e.currentTarget).attr("id") ;

			if($('input[name="user_identity"]:checked').attr("id") != "security-question-option"){
				return 1 ;
			}

			if($("#security-question").val() == undefined && $("#security-answer").val().length > 0 ){
				$("#form-error-securityAns" ).html("Please enter valid security question") ;
				return 0 ;
			}

			if($("#form-error-securityAns" ).length == 0){
				$("#security-answer").after("<div id='form-error-securityAns'  class='form-error red-text'></div>");
			}


			var securityAnswer = $("#security-answer").val() ;
			if(securityAnswer.length <= 0 && targetID != "security-question" && ( $("#security-question").val() != undefined || $("#security-question").val() != null) ){
				$("#form-error-securityAns" ).html("Please enter valid security answer") ;
				return 0 ;
			}

			$("#form-error-securityAns" ).html("") ;
			this.enableSubmit("security-answer") ;

		},
		checkForEmail : function(e){

			var self = this ;
			var email = $("#signupEmail").val() ;

			if($('input[name="user_identity"]:checked').attr("id") != "email-option" ){
				return 1 ;
			}

			if(email.length <= 0){
				this.enableSubmit("signupEmail");
				return 1;
			}

			$("#validate-signupEmail").html( this.loaderHTML()) ;
			var emailValid = this.validateText("signupEmail");
			if(emailValid == 0 ){
				this.disableSubmit("signupEmail") ;
				return 0 ;
			}



			$("#validate-signupEmail").html( this.loaderHTML()) ;
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
				statusCode:{
            		404 : function(){
						$("#validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
            			self.enableSubmit("signupEmail") ;
            		}
        		},

				}).done(function(response){

					if(response == true ){
						if($("#form-error-signupEmail" ).length == 0){
							$("input[name='signupEmail']").after("<div id='form-error-signupEmail'  class='red-text'></div>");
						}

						$("#validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
						$("#form-error-signupEmail" ).html("This email already exists") ;
						$("#validate-icon-signupEmail" ).removeClass('mdi-navigation-check green-text').addClass('mdi-navigation-close red-text');
						$("input[name='signupEmail']").removeClass("valid").addClass("invalid") ;
						$("#signup-btn").addClass("disabled") ;
						$("#signup-btn").attr("disabled", true) ;
						$("#form-error-signupEmail").show() ;
					}

				}).error(function(){

				});

		},

		validateText :  function(targetName){
			//var targetName = $(e.currentTarget).attr("name") ;
			var fieldsToValidate = this.validateJSON["fields"][targetName] ;
			if($("#form-error-" + targetName ).length == 0){
				//$("input[name='"+ targetName +"']").before("<i id='validate-icon-"+ targetName +"' class='prefix form-valid'></i>");
				$("input[name='"+ targetName +"']").after("<div id='form-error-"+ targetName +"'  class='form-error red-text'></div>");
				$("#form-error-" + targetName ).hide() ;
			}

			var textValue = $("input[name='"+ targetName +"']").val() ;

			if(targetName != "modal-signupUsername" && targetName != "modal-signupEmail"){
				textValue = textValue.trim() ;
			}

			var isValid = 1 ;
			_.each( fieldsToValidate, function(value, key){

				if( key == "required" && textValue.length == 0 ){
					isValid = 0 ;
					$("#form-error-"+ targetName ).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "minLength" && textValue.length < value ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "equalsTo" &&  textValue != $("input[name='"+ value +"']").val() ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "regexp" ){

					if(targetName == 'signupPassword'){

						var pattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$/;

						if( !pattern.test(textValue) ){

							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}

					}else{

						var regex = new RegExp(value, "i");
						if(!textValue.match(regex)){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}
					}

				}

			});

			return isValid ;
		},
		signUp: function(e){

			var self = this ;

			var isValidEmail    = this.checkForEmail();
			var isValidUsername = this.validateText("signupUsername");
			var isValidSecurityQuestion = this.checkforSecurityQuestion(e) ;

			if(isValidUsername == 0 ){
				this.disableSubmit("signupUsername") ;
				return false ;
			}

			if( isValidEmail == 0 ){
				this.disableSubmit("signupEmail") ;
				return false ;

			}
			if( isValidSecurityQuestion == 0 ){
				this.disableSubmit("security-answer") ;
				return false ;

			}

			if($("#signup-btn").hasClass("disabled")){
				return false ;
			}

			var currentDateTime = new Date().toISOString() ;
			var currentDate     = currentDateTime.split("T")[0] ;


 			var dataToSend = {
					"password" : $("input[name='signupPassword']").val().trim() ,
					"username" : $("input[name='signupUsername']").val().trim() ,
    				"avatar"   : "avatar7"                               ,
    				//"confirmPassword" : $("input[name='confirm_password']").val() ,
    				"securityQuestions" : []
				} ;

			if($("input[type=radio]:checked").attr("id") != 'email-option' ){
 				var qID     = $("#security-question").val() ;
 				var qAnswer = $("#security-answer").val() ;

 				dataToSend[ "securityQuestions" ] = [{
 					"qID" : qID ,
 					"answer" : qAnswer
 				}] ;
 				dataToSend[ "email" ] = "";

 			}else{
 				dataToSend[ "email" ] = $("#signupEmail").val();
 			}

 			$("#signup-btn").hide();
 			$("#signup-progress").show() ;

			var url = window.location.href ;
    		url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso');
 			var loginUrl = Utils.contextPath() + "/v2/users/signup";
			if(sso != undefined ){
				loginUrl = loginUrl + "?sso=" + sso ;
			}else{
				loginUrl = loginUrl ;
			}

 			$.ajax({
				method : 'POST',
				url : loginUrl,
				dataType : "json" ,
				xhrFields: {
     				 withCredentials: true
			    },
				contentType: "application/json",
				data: JSON.stringify(dataToSend),
			}).done(function(response, status, xhr){
				self.model.save(response) ;
				self.signUpProgress = 1 ;
				sessionStorage.setItem("firstTimeUser" , 1 ) ;
				Raygun.setUser( response.username, false, response.email, response.firstName, response.firstName, response.id ) ;
				if(self.fromAction == 'book_appointment'){
					//localStorage.setItem("fromAppointment", 1) ;
				}

				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : response ,
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.alias(response.id, distinct_id);
					mixpanel.track('SIGNUP', {'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : self.buttonDesc, 'itemMedium' : 'NORMAL'  });

					if (  ( typeof fbq != 'undefined' ) ){
						fbq('track', 'CompleteRegistration');
					}

					if( typeof ga != 'undefined'){
						ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
					}

					mixpanel.people.set({
	    			'username': response.username,
	    			'name' : response.username ,
	    			'$email': response.email,
	    			'id' : response.id,
	    			'src' : 'NORMAL',
	    			'userType' : response["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: response.username
					});
				}

				self.hideSignUp();
				if( response.uri ){
					location.href = response.uri;
					//Backbone.history.navigate(response.uri, {trigger: true});
				}else{

					if(self.fromAction == 'book_appointment'){
						//location.href = "/bookAppointment";
						Backbone.history.navigate("/bookAppointment", {trigger: true});
					}else if(self.fromAction == "home_chat"){
						location.href = Utils.chatUrl() + response.username;
					}else if( self.fromAction == "counselorChat"){
						var counselorChatUrl = self.extraParams ;
						location.href = counselorChatUrl + "&username=" + response.username;
					}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
					Backbone.history.navigate(self.extredirectTo, {trigger: true});
					}else{
						var paramUrl = "" ;
						if(self.fromAction == "message"){
							var counselorInfo = self.extraParams ;
							paramUrl = "?from=message&counselorID=" + counselorInfo.id ;
						}
						//location.href = "/talkItOut" + paramUrl;
						Backbone.history.navigate("/talkItOut" + paramUrl, {trigger: true});
					}
				}

			}).fail(function(error){
				console.log("ERROR");
				console.log(error) ;
			});

		},
		showHideOptions : function(e){

			var targetID = $(e.currentTarget).attr("id") ;

			if(targetID == 'email-option' ){
				$(".email-block").show();
				$(".security-block").hide();
				$("#form-error-securityAns" ).html('') ;
				$("#security-answer").removeClass("valid");
				$("#security-answer").removeClass("invalid");
				this.enableSubmit('security-answer');
			}else{
				$(".email-block").hide();
				$(".security-block").show();
				$("#signupEmail").val("");
				this.enableSubmit('signupEmail');
				setTimeout(function(){
					$("#validate-signupEmail").html('');
					$("#validate-icon-signupEmail").hide();
					$("#form-error-signupEmail" ).html('') ;
					$("input[name='signupEmail']").removeClass("valid");
					$("input[name='signupEmail']").removeClass("invalid");

				}, 1000);

			}
		},
		SignUpPageLayout : JST['app/templates/signup/signup.hbs'],
		renderHTML : function(buttonDesc, fromPage, fromAction, extraParams){
			$('#signup').remove() ;
			$("#signup-step2").remove();
			var currentPage = window.location.pathname;
			this.$el.append(this.SignUpPageLayout({isMobileDevice : Utils.isMobileDevice(), fromPage: fromAction, currentPage : fromPage}));
			this.setElement($("main")).render(buttonDesc, fromPage, fromAction, extraParams);
		},
		render: function( buttonDesc, fromPage, fromAction, extraParams ) {

			var self = this ;

			Utils.openPopup('signup') ;

			self.startGoogleApp();

			/*FB.getLoginStatus(function(response) {
			    console.log(response);
			});*/

			this.fromAction = fromAction ;
			this.fromPage    = fromPage ;
			this.extraParams = extraParams ;
			this.buttonDesc = buttonDesc.replace("#", "") ;

			if(fromAction != undefined && fromAction != ""){
				$(".action-based-signup-msg").html("Please create your account to start "+ fromAction +". Don't worry you are completely anonymous and can share anything with us");
			}else{
				$(".action-based-signup-msg").html(" ") ;
			}

			$("#signupUsername").focus() ;

			if($("#anonymous-chat-name-txt").val()!= undefined && $("#anonymous-chat-name-txt").val().length){
				$("#signupUsername").val( $("#anonymous-chat-name-txt").val() ) ;
				$("#signupPassword").focus() ;
			}

			if(Utils.isMobileDevice() == false){
				$("#signup").css("top", "5%") ;
				$("#signup").css("max-height", "83%") ;
			}

			$.ajax({
				url : Utils.contextPath() + "/question"
			}).done(function(response){
				_.each(response, function(eachQues, qID){
					self.$el.find('#security-question').append('<option value="'+ qID +'">'+ eachQues +'</option>') ;
				});
				$('select').not('.disabled').material_select();
			}).error(function(error){

			});

			$("#signupUsername").keystop( function(event){
				self.checkForUsername(event) ;
			}, 1000 ) ;

			$("input[type=password]").keystop( function(event){
				self.checkForPassword(event) ;
			}, 1000 ) ;

			$("#signupEmail").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1500 ) ;

		}
	});

	SignUpPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	//this.undelegateEvents();
    	this.unbind();
    	//this.stopListening();
	};

	SignUpPage.prototype.clean = function() {
    	this.remove();
	};

	return SignUpPage;
});
