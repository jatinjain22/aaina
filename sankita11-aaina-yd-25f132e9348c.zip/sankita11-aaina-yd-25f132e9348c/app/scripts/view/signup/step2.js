define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'router/app-router',
	'utils',
	'model/login',
	'jquery-ui',
	'ui-autocomplete',
	'ajax-chosen',
], function($, _, Backbone, JST,Router, Utils, LoginModel) {
	
	var SignUpPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.model = new LoginModel();
		},
		events: {
			'click .avatar-img-signup' : 'selectAvatar',
			'click #signup-update-btn' : 'updateUser' ,
			'click #signup-step2 .mclose'  : 'hideSignUp' ,
			'click #signup-skip-btn' : 'hideSignUp'
		},
		updateUser : function(e){

			var self = this ;

			var selectedAvatar = $("#selected-avatar-id").val() ;
			var selectedCommunity = $("#community").val() ;

			var communityArr = selectedCommunity ;
			if(Utils.isMobileDevice()){
				communityArr = new Array() ;
				var communitiesSelected = selectedCommunity.split(",");
				_.each(communitiesSelected, function(elem){
					if(!elem.trim()){
						return false ;
					}
					communityArr.push(elem.trim()) ;
				});
			}

			var dataToSend = {
				"avatar" : selectedAvatar ,
				"communities" : communityArr,
			};
			
			$.ajax({
				url : Utils.contextPath() + "/v2/users/update" ,
				method : "POST" ,
				dataType : "json" ,
				contentType: "application/json",
				data: JSON.stringify(dataToSend),
			}).done(function(response){
				self.model.save(response) ;
				var userAvatar = Utils.avatarToImage(selectedAvatar) ;
				$(".user-section-header img").attr("src", userAvatar);
				Utils.closePopup("signup-step2");
			}).error(function(error){
				console.log("error") ;
				console.log(error) ;
			});
		},
		selectAvatar : function(e){
			var avatarID = $(e.currentTarget).attr("id") ;
			$(".avatar-img-signup").removeClass("avatar-selected") ;
			$("#" + avatarID).addClass("avatar-selected") ;
			$("#selected-avatar-id").val(avatarID) ;
		},
		hideSignUp : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('signup-step2');
		},
		signUp: function(e){


		},
		showHideOptions : function(e){

		},
		SignUpPageLayout : JST['app/templates/signup/signup.hbs'],
		render: function() {

			$('#signup-step2').remove() ;
			var userObject = JSON.parse(localStorage.getItem("user")) ;
			
			var self = this ;

			this.$el.append(this.SignUpPageLayout({username: userObject.username, isMobileDevice : Utils.isMobileDevice()}));

			$.ajax({
				url : Utils.contextPath() + '/community',
			}).done(function(data){

				if(Utils.isMobileDevice()){

					var communities = new Array() ;

					$.each(data, function (i, val) {
						communities.push(val) ;
					});

						$( "#community" )
					      // don't navigate away from the field on tab when selecting an item
					      .bind( "keydown", function( event ) {
					        if ( event.keyCode === $.ui.keyCode.TAB &&
					            $( this ).autocomplete( "instance" ).menu.active ) {
					          event.preventDefault();
					        }
					      })
					      .autocomplete({
					        minLength: 0,
					        source: function( request, response ) {
					          // delegate back to autocomplete, but extract the last term
					          response( $.ui.autocomplete.filter(
					            communities, Utils.JUIextractLast( request.term ) ) );
					        },
					        focus: function() {
					          // prevent value inserted on focus
					          return false;
					        },
					        select: function( event, ui ) {
					          var terms = Utils.JUIsplit( this.value );
					          // remove the current input
					          terms.pop();
					          // add the selected item
					          terms.push( ui.item.value );
					          // add placeholder to get the comma-and-space at the end
					          terms.push( "" );
					          this.value = terms.join( ", " );
					          return false;
					        }
					      });	
				}else{

					
					$.each(data, function (i, val) {
						var option = "<option value='"+val+"'>"+val+"</option>";
	              		$("#community").append( option );
					});
					setTimeout( function(){
						$("#community").chosen({
							width: "100%"
						});				
					},100);
	
				}

			});


			Utils.openPopup('signup-step2') ;
		}
	});

	SignUpPage.prototype.remove = function() {};

	SignUpPage.prototype.clean = function() {};

	return SignUpPage;
});