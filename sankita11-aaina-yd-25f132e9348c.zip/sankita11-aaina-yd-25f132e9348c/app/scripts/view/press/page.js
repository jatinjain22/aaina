define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'purl'
], function($, _, Backbone, Utils, JST ) {

	var PressPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			
		},
		events: {

		},
		
		LoaderLayout: JST['app/templates/press/layout.hbs'],

		render: function() {
			
			document.title="Press Page | YourDOST";
			$('meta[name=description]').attr('content', "YourStory, NDTV, The Huffington Post and a few others have said a lot of good things about us. Read on.");
			$('meta[name=title]').attr('content',"Press Page | YourDOST");
			$('meta[property="og:description"]').attr('content', "YourStory, NDTV, The Huffington Post and a few others have said a lot of good things about us. Read on.");
			$('meta[property="og:title"]').attr('content',"Press Page | YourDOST");
        	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/press');


			this.$el.html(this.LoaderLayout()) ;

			$(".ydmt-media-text")
		    .on('mouseover', function(){

		    		$(this).find('.grey_image').addClass("hide");
		    		$(this).parents(".ydmt-story").find(".ydmt-head-title").addClass("hovered")
		    		$(this).find('.red_image').removeClass("hide");
		    	}
		    )
		    .on('mouseout', function(){

		    	$(this).find('.grey_image').removeClass("hide");
		    	$(this).parents(".ydmt-story").find(".ydmt-head-title").removeClass("hovered")
		    	$(this).find('.red_image').addClass("hide");
		    });
		    $(".ydmt-head-title")
		    .on('mouseover', function(){

		    		$(this).parents(".ydmt-story").find('.grey_image').addClass("hide");
		    		$(this).parents(".ydmt-story").find(".ydmt-head-title").addClass("hovered")
		    		$(this).parents(".ydmt-story").find('.red_image').removeClass("hide");
		    	}
		    )
		    .on('mouseout', function(){

		    	$(this).parents(".ydmt-story").find('.grey_image').removeClass("hide");
		    	$(this).parents(".ydmt-story").find(".ydmt-head-title").removeClass("hovered")
		    	$(this).parents(".ydmt-story").find('.red_image').addClass("hide");
		    });  
		},

	});

	PressPage.prototype.remove = function() {
		
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	PressPage.prototype.clean = function() {

    	this.remove();

	};

	return PressPage;
});