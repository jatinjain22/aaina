define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'model/users',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function($, _, EventBus, UserModel,Backbone, JST, Utils) {
	
	var WhyDonationPage = Backbone.View.extend({
		
		el: "main",

		initialize: function() {

			this.userModel       = new UserModel();
			this.amount = 0;
			this.socialShareResponse = {};
		},
		events: {

			'click .donation-page-spread-btn' : 'spreadTheWordDonationPage',
			'click .donation-page-donation-amount-span' : 'selectAmountDonationPage',
			'click .donation-page-donate-now-btn' : 'donateNowDonationPage',
			'keyup .donation-page-donation-input-amount' : 'inputDonationAmountDonationPage',
			'click .donate-page-donate-btn' : 'scrollToDonateNow'
		},

		WhyDonationLayout: JST['app/templates/whyDonation/layout.hbs'],

		isInt : function (value) {

		  	return 	!isNaN(value) && parseInt(Number(value)) == value && !isNaN(parseInt(value, 10));
		},

		scrollToDonateNow : function(e){

			this.scrollToDiv("donation-page-donate-now-div");
		},

		scrollToDiv : function(id){

    		$('html,body').animate({

        		scrollTop: $("#"+id).offset().top},
        	'slow');
		},
		
		selectAmountDonationPage : function(e){

			if($(e.currentTarget).hasClass("donation-page-input-donation")){

				return;
			}

			$(".donation-page-donation-amount-error").addClass("hide").html("")
			
			if($(e.currentTarget).hasClass("selected")){

				$(".donation-page-donation-amount-span").removeClass("selected")
				$(e.currentTarget).removeClass("selected")
				this.amount = 0;
			}else{

				$(".donation-page-donation-amount-span").removeClass("selected")
				$(e.currentTarget).addClass("selected")
				this.amount = $(e.currentTarget).attr("data-value");
			}

			if(this.amount == 0){

				this.amount = parseInt($(".donation-page-donation-input-amount").val());
			}
		},
		inputDonationAmountDonationPage : function(e){

			jQuery(".donation-page-donation-amount-span").removeClass("selected")
			this.amount = 0;
			this.amount = parseInt($(".donation-page-donation-input-amount").val());

			if(!this.isInt(this.amount)){

				jQuery(".donation-page-donation-amount-error").removeClass("hide").html("Please select or enter amount")
				return false;
			}
			if(this.amount < 50){

				$(".donation-page-donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}
			$(".donation-page-donation-amount-error").addClass("hide").html("")
			this.amount = parseInt($(".donation-page-donation-input-amount").val());
		},

		donateNowDonationPage : function(){

			$(".donation-page-donation-amount-error").addClass("hide").html("")

			$(".donation-page-donate-now-btn").find("span").html("Redirecting...")

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Page', {'mediumSource' : 'website', 'itemName': 'Clicked FAQ Donate Now'});
	          
	        } 

			var donationAmount = this.amount;
			console.log("Amount ",donationAmount);

			if(!donationAmount || donationAmount == 0 ){

				$(".donation-page-donation-amount-error").removeClass("hide").html("Please select or enter amount")
				$(".donation-page-donate-now-btn").find("span").html("Pay Securely")
				return false;
			}
			if(this.amount < 50){

				$(".donation-page-donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}

			$(".donation-page-donate-now-btn").find("span").html("Redirecting...")
			$(".donation-page-donation-amount-error").addClass("hide").html("")

			var userID = this.userModel.getUserID() ; 

			$.ajax({
				url         : Utils.contextPath() + '/v1/user/'+ userID +'/donate/'+ donationAmount+'?source=virality',
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
			}).done(function(response){

				$(".donation-page-donate-now-btn").find("span").html("Pay Securely")

				if( !response.error){

					location.href = response.uri;
				}else{

					$(".donation-page-donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
				}

			}).error(function(response){

				$(".donation-page-donate-now-btn span").html("Pay Securely")
				$(".donation-page-donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
			})
		},
		spreadTheWordDonationPage : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Page Spread', {'mediumSource' : 'website', 'itemName': 'Clicked Donation Page Spread'});
	          
	        } 
			var self = this;

			var targetElement = $(".donation-page-spread-btn");
	        var loaderElement = $(".donation-page-spread-the-word-loader");
	        var mixpanelEvent = "Spread The Word";

	        targetElement.addClass("hide");
	        loaderElement.removeClass("hide");
	        
	        self.socialShareResponse["utm_campaign"] = "spread_whydonatePage"

	        Utils.shareOnFacebook( self.socialShareResponse, targetElement, loaderElement, mixpanelEvent ).then(function(response) {
	                
	            if(response){

	        		console.log("Response ---", response)
	            	self.updateUserStatusShared(targetElement);
	            	targetElement.hide();
	            	$(".donation-page-share-inner-div").find(".h4").addClass("hide");
	            	targetElement.after('<div class="facebook-share-success">Thank you for spreading the word!</div>');
	            }else{

	            	targetElement.removeClass("hide");
	        		loaderElement.addClass("hide");

	            }  

	        }, function(error) {

	            console.log("Failed!", error);
	        }); 
		},

		updateUserStatusShared : function(ele){

			if(!Utils.isLoggedIn()){

				$.cookie("shareDone", "yes", {path: '/', expires : 60})
				setTimeout(function(){

					$(".facebook-share-success").addClass("hide");
				}, 3000)
			}else{

				var userId = this.userModel.getUserID() ; 
				var dataToSend = {
									"allowed":0,
									 "userId":userId,
									 "type":"SHARE"
								};
				$.ajax({
	                url : Utils.contextPath() + "/v2/users/"+userId+"/intrupts/status",
	                data:JSON.stringify(dataToSend),
	                method : 'POST',
					dataType: "JSON",
	                contentType: "application/json; charset=utf-8",
	          	}).done(function(response){

	          		ele.hide();
	          		$(".facebook-share-success").addClass("hide");
	          	}).error(function(error){

	                console.log(error)
	                $(".facebook-share-success").addClass("hide");
	          	});
	        }

		},	
		render: function() {

			var self = this;

			if(typeof $.cookie("shareDone") != 'undefined'){

				self.$el.html(self.WhyDonationLayout({shareDone:true}));				
			}else{

				self.$el.html(self.WhyDonationLayout({shareDone:false}));
			}

			$.ajax({
                url : Utils.scriptPath() + "/socialShare.json",
                cache: false
          	}).done(function(response){

                var url = "donate"
                self.socialShareResponse = response[ url ];

          	}).error(function(error){
                console.log(error)
          	}); 
		}
	});

	WhyDonationPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	WhyDonationPage.prototype.clean = function() {

		this.remove();
	};

	return WhyDonationPage;
});