define([
  'jquery',
  'underscore',
  'event/dispatcher',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'Swiper',
  'model/users',
  'model/UserMsgModel',
  'view/leaveMessage/page' 
], function($,_, Dispatcher, Backbone, JST, Utils, Swiper, UserModel, UserMsgModel, LeaveMessageView ) {

    var TipsLandingPage = Backbone.View.extend({

      el: 'main',
      
      Layout: JST["app/templates/tipsLandingPage/layout.hbs"],
      CounselorInfoLayout: JST["app/templates/tipsLandingPage/counselorInfo.hbs"],

      CounselorTipLayout: JST["app/templates/tipsLandingPage/counselorTips.hbs"],

      initialize: function() {
        this.userModel = new UserModel() ;
        this.userMsgModel = new UserMsgModel();
        this.leaveMessage = new LeaveMessageView(); 
        this.counselorTips = [];
        this.tipCount = 0;
        this.useenTipCount = 5;
        this.fromPage = 'hiddenTips';
        this.urlJsonMapping = {
                                "/tips-counselor-page": { "title": "10 TIPS FOR BETTER COMMUNICATION IN THE WORKPLACE", 
                                                          "jsonFile": "counselorTips.json", 
                                                          "itemname": "Counselor Tips Landing Page" },

                                "/tips-spouse-communication": { "title": "10 TIPS FOR BETTER COMMUNICATION WITH YOUR SPOUSE", 
                                                                "jsonFile": "spouseCommunicationTips.json", 
                                                                "itemname": "Spouse Communication Tips Landing Page" }
                              };
      },
      
      events: {
        'click .fexp-chat' : "chatCounselor",
        'click .fexp-msg'  : "msgCounselor", 
        "click .tipsLandingPage-previous-tip-box": "getPreviousTip",
        "click .tipsLandingPage-next-tip-box": "getNextTip",
        "click .tipsLandingPage-signup-msg-btn a": "showSignUp",
        "click .tipsLandingPage-talk-to-counselor-btn": "takeToCounselorPage",
        "click .login-clicked": "showLogin",
        'click .user-dropdown' : 'userPersonalMenu',
        "click .tipsLandingPage-return-home a": "returnToHomePage" 
      },
      returnToHomePage: function(e) {

        var self = this;
        self.tipCount = 0;
        self.render();
      
      },
      userPersonalMenu : function(e){

          console.log("hello");
          var dropDownEl = $("#loggedin-dropdown5");
          if ( dropDownEl.hasClass("hide") ) {
            dropDownEl.removeClass("hide").addClass("fadeInDown animated");
          } else {
            dropDownEl.addClass("hide").addClass("fadeInDown animated");
          }
            

          // var top = 60;
          // var left = $(".user-dropdown").addClass("active").offset().left - 75 ;
          // $('#loggedin-dropdown1').css({
          //   top:top,
          //   left:left
          // });
      },
      trackMixpanel: function( eventName, pageNo ) {
        
        var self = this;

        var pathname = window.location.pathname;
        var itemname =   self.urlJsonMapping[ pathname ].itemname;
        
        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
          
          var mixpanelObject = {'mediumSource' : 'website', 'itemtype': 'landing page', 'itemName': itemname };
          
          if ( pageNo === undefined) {
            

            mixpanel.track( eventName, mixpanelObject );
          }
          else {
            mixpanelObject["pageNo"] = pageNo;
            mixpanel.track( eventName, mixpanelObject );
          }
       
        }

      }, 
      takeToCounselorPage: function(e) {

        var categoryId = 1;
        var url = "/talkItOut?category="+ categoryId;
        Backbone.history.navigate( url, {trigger: true} );


      },

      showLogin: function(e) {

        e.preventDefault();
        e.stopPropagation();
        console.log( "login" );
        if(!Utils.isLoggedIn()){
          Dispatcher.trigger("renderLogin", "click Landing Home Page", "login", "loginButton") ;
        }

      },

      showSignUp: function() {

        var buttonDesc = "hideFurtherTips";
        var fromPage = "tips-landing-page";
        var fromAction = "hideFurtherTips";
        var url = window.location.pathname;
        var redirectURL = url + "?fromPage=hiddenTips";
        Dispatcher.trigger( "renderLogin", buttonDesc, fromPage, fromAction, redirectURL ) ;

      },

      showForLastPage: function() {

        $(".tipsLandingPage-next-tip-box").addClass("hide");
        $( ".tipsLandingPage-talk-to-counselor" ).removeClass( "hide" );

      },

      hideFurtherTips: function() {

        var self = this;
        if ( !Utils.isLoggedIn() ) {
          $( ".tipsLandingPage-overlay" ).removeClass( "hide" );
          $( ".tipsLandingPage-signup-msg" ).removeClass( "hide" );
          $( ".tipsLandingPage-counselor-tips-title" ).addClass( "blurredText" ); 
          $( ".tipsLandingPage-counselor-tips-content" ).addClass( "blurredText" );
          $( ".tipsLandingPage-return-home" ).removeClass( "hide" );
          self.trackMixpanel( "Unseen Tip" );
        }
        
        

      },

      renderCounselorTip: function( tipCount ) {

        var self = this;
        var counselorTip = self.counselorTips[ tipCount ];
        
        if ( counselorTip !== undefined ) {
           
          if (!$( ".tipsLandingPage-previous-tip-box" ).hasClass("cpointer") ) {
              $( ".tipsLandingPage-previous-tip-box" ).addClass("cpointer");
          }          
          if (!$( ".tipsLandingPage-next-tip-box" ).hasClass("cpointer") ) {
              $( ".tipsLandingPage-next-tip-box" ).addClass("cpointer");
          }

          $(".tipsLandingPage-counselor-tips-container").html( self.CounselorTipLayout({CounselorTip: counselorTip}) );
          
          $( ".tipsLandingPage-previous-tip-box" ).removeClass( "hide" );
          $( ".tipsLandingPage-next-tip-box" ).removeClass( "hide" );

          if ( tipCount === 0 ) {
          
            $( ".tipsLandingPage-previous-tip-box" ).addClass( "hide" );
          
          }
          else if (tipCount === self.useenTipCount) {

            self.hideFurtherTips();
          
          }  else if ( tipCount === (self.counselorTips.length - 1) ) {

            self.showForLastPage();
          }

        
        } 

      },

      getPreviousTip: function(e) {
        
        var self = this;
        self.tipCount -= 1;

        if ( self.tipCount  === -1 ) {
          
          self.tipCount = 0;
          $( e.currentTarget ).removeClass( "cpointer" );
          $( e.currentTarget ).children().attr("disabled","disabled");

        } else {
          if (!$( e.currentTarget ).hasClass("cpointer") ) {
              $( e.currentTarget ).addClass("cpointer")
          }        
          self.renderCounselorTip( self.tipCount );  
        } 
        var pageNo = self.tipCount + 1;
        self.trackMixpanel( "Previous Tip", pageNo );
      
      },
      
      getNextTip: function(e) {
        
        var self = this;
        self.tipCount += 1;

        if ( self.tipCount  === self.counselorTips.length ) {
        
          self.tipCount = self.counselorTips.length - 1;
          $( e.currentTarget ).removeClass( "cpointer" );
        
        } else {

          self.renderCounselorTip( self.tipCount );
        
        }
        var pageNo = self.tipCount + 1;
        self.trackMixpanel( "Next Tip", pageNo );
          
        
      },

      chatCounselor : function(e){
      
        var chatURL = $(e.currentTarget).attr("data-href") ;
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
          Dispatcher.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL) ;
          //EventBus.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL ) ;
        }else{
          if ( !$(e.currentTarget).hasClass("disabled") ) {
            var username =  this.userModel.getUserName() ;
            location.href = chatURL + "&username=" + username;
            $(e.currentTarget).addClass("disabled");
            console.log( 'hi' );
          }
        }
      },

      msgCounselor : function(e){

        var counselorIdName = $(e.currentTarget).attr("data-attr");
        var counselorInfo = {
          id : counselorIdName.split("_")[0] ,
          name : counselorIdName.split("_")[1] ,
        };

        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
          Dispatcher.trigger("renderLogin", buttonDesc, "home", "message", JSON.stringify(counselorInfo)) ;
          //EventBus.trigger("renderLogin", buttonDesc, "home", "message", counselorInfo) ;
        }else{

          if(!counselorIdName || counselorIdName == undefined || counselorIdName == null ){
            this.leaveMessage.render() ;
          }else{
            this.leaveMessage.render( counselorInfo ) ;
          }
          
        }

      },
      getJson: function( pathname ) {

        var self = this;
        var jsonFile = self.urlJsonMapping[ pathname ].jsonFile;
        return $.ajax({
            method : "GET",
            url : Utils.scriptPath() + "/" + jsonFile,
            cache: false
          });
      },
      
      renderCounselorInfo: function( onlineCounselorInfo, isOnline ) {

        var self = this;
        
        var url = Backbone.history.getFragment();
        var pathname = window.location.pathname;
        var title = self.urlJsonMapping[ pathname ].title;
        console.log( "pathname", pathname );
        var fromPage = $.url( url ).param('fromPage') ;
        console.log( "fromPage "+ fromPage );

        var counselorToPrint  =  onlineCounselorInfo.slice(0,1)[0] ;

          var ratingHTML = "" ;
          for(index = 0; index < counselorToPrint.rating; index ++ ){
            ratingHTML += '<i class="mdi-action-grade yellow-text rating"></i>' ;
          }
          for(index = counselorToPrint.rating; index < 5; index++){

            ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
          }

          console.log( counselorToPrint );

          var username    = "" ;
          var userAvatar  = "" ;
          var firstName   = "" ;
          var userType = "VICTIM";
          var picUrl = "" ;
          var user_id = '';

          if( Utils.isLoggedIn() ){  
              username = this.userModel.getUserName() ;
              firstName = this.userModel.getFirstName() ;
              picUrl = this.userModel.getPicUrl();
              user_id = this.userModel.getUserID() ; 
              if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){
                username = firstName ;
              }
              if(picUrl){
                userAvatar = picUrl ;
              }else{
                userAvatar = this.userModel.getUserAvatar() ;
                userAvatar = Utils.avatarToImage(userAvatar) ;
              }
              userType = this.userModel.getUserType();
          }
          console.log( "isLoggedIn", Utils.isLoggedIn() );
          self.$el.html( self.Layout({ title: title, blogOrigin: blogOrigin, userAvatar: userAvatar, user_id : user_id, username : username , isLoggedIn : Utils.isLoggedIn,  userType: userType } ) );
          

          $(".tipsLandingPage-counselor-info-container").html( self.CounselorInfoLayout({counselor: counselorToPrint}) );
          $("#couselor-rating-" + counselorToPrint.id).html( ratingHTML );
            
          $.ajax({
            url : Utils.contextPath() + '/v1/counselor/status' ,
          }).done(function(response){
          
            _.each(response, function(value, key){
        
              if( value.status == "true" && $("#chat-home2-" + key).length ){
                $("#chat-home2-" + key).removeClass("hide");
                $("#chat-home2-" + key).attr("data-href", value.url);

              }
            });
          }).error(function(error){
            console.log( error );
          });  
          
          
          

          self.getJson( pathname ).done(function(response){
            
            self.counselorTips = response;
            console.log( self.counselorTips );
            var firstCounselorTip = self.counselorTips[ self.tipCount ];
            console.log( firstCounselorTip );
            
            if ( fromPage == self.fromPage ) {

              self.tipCount = self.useenTipCount;
              self.renderCounselorTip( self.tipCount );
              window.history.pushState( '', '', pathname );
            
            } else {
            
              $(".tipsLandingPage-counselor-tips-container").html( self.CounselorTipLayout({CounselorTip: firstCounselorTip}) );  
              $( ".tipsLandingPage-previous-tip-box" ).addClass( "hide" ); 
              self.trackMixpanel( "Counselor Tips Home Page");
            }

            
          }).error(function(error){
            console.log(error);
          });


      },

      render: function() {
        
        var self = this;
        

        $.ajax({
          method : "GET",
          url : Utils.contextPath() + "/v1/counselor/?page_number=1&online=true"
        }).done(function( onlineCounselorInfo ){
          
          var isOnline = false;
          if ( onlineCounselorInfo.length ) {
            var isOnline = true;
            self.renderCounselorInfo( onlineCounselorInfo, isOnline );  
          }
          else {
             
            $.ajax({
              method : "GET",
              url : Utils.contextPath() + "/v1/counselor/?page_number=1"
            }).done( function( onlineCounselorInfo ){
              self.renderCounselorInfo( onlineCounselorInfo, isOnline );  
              
            }).error(function(error){

            });

          }
          



        }).error(function(error){
          console.log(error);
        });
          
      
      }
      
    });

  TipsLandingPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind(); 
	};

	TipsLandingPage.prototype.clean = function() {

      this.remove();

	};

    return TipsLandingPage;
});
