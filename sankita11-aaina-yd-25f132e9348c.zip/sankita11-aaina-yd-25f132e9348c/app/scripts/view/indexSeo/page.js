define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'event/dispatcher',
  'utils',
  'purl',
  'keystop'
], function($, _, Backbone, JST, Dispatcher, Utils){

	var IndexPage = Backbone.View.extend({

		el : 'main',

		events: {

			"click .i-index" : "trackLink"
		},

		initialize : function(){

			this.content = window.location.pathname.split("/")[1];
			this.content = this.content.split("-")[0]
			if( this.content == "city") this.content = "location"
		},

		trackLink : function(evt){

            var href = $(evt.currentTarget).attr('href');
            var url = href.replace(/^\//,'').replace('\#\!\/','');

            var item = url.replace("-counsellors","")
            item = "category_"+item
            
            if($(evt.currentTarget).hasClass("city")){

	            item = url.replace("counsellors-in-","")
	            item = "city_"+item
	        }
            if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
       
              mixpanel.track('Button click', {'itemName' : "city", 'itemUrl': url, 'mediumSource' : 'website' });
        	} 
      	},

		getContent : function(url){

			var defer = $.Deferred();

			$.ajax({

				method : 'GET',
				url : url
			}).done(function(response){

				defer.resolve(response)
			}).error(function(error){

				defer.reject(error);
			})

			return defer.promise()
		},

		mainTemplate: JST['app/templates/indexSeo/layout.hbs'],
		catContentTemplate: JST['app/templates/indexSeo/catContent.hbs'],
		citContentTemplate: JST['app/templates/indexSeo/citContent.hbs'],
		LoaderLayout           : JST['app/templates/loader.hbs'],

		showContent : function( data ){

			var self = this;

			_.each( data, function(item){

				if( item.name == self.content && self.content == "category"){

					var filters = item.filters;

					$(".i-container-inner").html(self.catContentTemplate({filters : filters}))

					return false;
				}
				if( item.name == self.content && self.content == "location"){

					var filters = item.filters;

					filters = self.sortFilters(filters);

					$(".i-container-inner").html(self.citContentTemplate({filters : filters}))

					return false;
				}
			})
		},

		sortFilters : function( data ){

			data.sort(function(a,b){
  				
  			  var valA = a.value.toUpperCase()
  			  var valB = b.value.toUpperCase()

			  if(valA < valB){

			    return -1;
			  }
			  if(valA > valB){

			    return 1;
			  }

			  return 0;
			})

			return data;
		},

		render : function(){

			var title = "";
			var desc = "";
			
			if(this.content == "location"){

				title = "City Based Counsellors, Psychologists & Experts from India | YourDOST";
				desc = "Categorization of counsellors based on cities in India. Find & book appoinment with right counsellor or psychologist ";
			}else{

				title = "Counsellors, Psychologists & Experts in India based on key categories serviced | YourDOST";
				desc = "List of counsellors in India based on key categories serviced. Find & book appoinment with right counsellor or psychologist ";
			}	

	        document.title= title;
			$('meta[name=description]').attr('content', desc);
			$('meta[name=title]').attr('content',title);
			$('meta[property="og:description"]').attr('content', desc);
			$('meta[property="og:title"]').attr('content',title);
	        $('link[rel="canonical"]').attr('href', window.location.href);
			
			this.$el.html(this.mainTemplate())
			$("i-container-inner").html(this.LoaderLayout());
			var self = this;

			if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
       
              mixpanel.track('IndexPage', {'itemName': window.location.pathname.split("/")[1], 'mediumSource' : 'website' });
        	} 

			this.getContent(Utils.contextPath() + '/v1/counselor/filters')
			.then(function(response){

				self.showContent(response)
			}, function(error){

				console.log("Error :", error)
			})

		}

	})

	IndexPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	IndexPage.prototype.clean = function() {

		this.remove() ;
	};

	return IndexPage;
});