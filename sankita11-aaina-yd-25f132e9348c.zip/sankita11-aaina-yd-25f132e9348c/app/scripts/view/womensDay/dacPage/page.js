define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function( $, _, Backbone, JST, Dispatcher, Utils ) {

	var womensDayDacPage = Backbone.View.extend({

		el: "main",

		initialize: function() {

		},

		events: {

			"click .wd-dac-content-container" : "directToChat",
			"click .wd-dac-story-read" : "takeHome",
			"click .wd-dac-story-submit" : "directToStoryForm",
			"click .wd-dac-chat-btn" : "directToChat"
		},

		redirect: function (options) {

			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "","", "womensDayCat");
		},

		takeHome : function( evt ){

			this.trackMixpanel("click_read_stories", { key: "Mktg_Womensday_dac", value: "lp" })
			window.open("/womens-day-2017", "_self")
		},

		directToStoryForm : function( evt ){

			this.trackMixpanel("click_submitstory", { key: "Mktg_Womensday_dac", value: "lp" })
			window.open("/womens-day-2017/submit-your-story", "_self")
		},

		directToChat: function (evt) {

			var category = evt.currentTarget.getAttribute("data-category");
			var categoryID = evt.currentTarget.getAttribute("data-category-id");

			if( $(evt.currentTarget).hasClass("wd-dac-chat-btn") ){

				category = "loverelationship"
				categoryID = 6
				this.trackMixpanel("click_chatnow", { key: "Mktg_Womensday_dac", value: "lp" })
			}
			
			if (!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "Mktg_Womensday_dac", "", "free_chat", {
					options : {
						type: 'chat',
						categoryID : categoryID
					},
					callback: this.redirect
				} ) ;
			}else{
				
				this.redirect({
					"type"	: 'chat',
					categoryID : categoryID
				});
			}
		},

		mainLayout : JST['app/templates/womensDay/dacPage/layout.hbs'],
		catLayout : JST['app/templates/womensDay/dacPage/category.hbs'],

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_Womensday_dac", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		getContent : function(url){

			var defer = $.Deferred();
			$.ajax({
				url : url,
				method: "GET"
			}).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		getCategories : function(){

			var categories = [
				{
					"category" : "loverelationship",
					"categoryId" : 1,
					"title" : "Love & Relationships",
					"content" : "Relationship counseling, Marriage Counseling, Break-up Support",
					"imageUrl" : "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/Heart+icon.png",
					"color" : "#E41655;"
				},
				{
					"category" : "worklifebalance",
					"categoryId" : 2,
					"title" : "Work-Life Balance",
					"color" : "#511E78;",
					"content" : "Managing work and family, Working mothers, Career change",
					"imageUrl" : "	https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/Work+life+balance+icon.png"
				},
				{
					"category" : "Career Growth",
					"categoryId" : 2,
					"title" : "Career Growth",
					"color" :"#FCC314",
					"content" : "Networking, Finding a mentor, Developing skills, Entrepreneurship",
					"imageUrl" : "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/career+icon.png"
				},
				{
					"category" : "selfconfidence",
					"categoryId" : 4,
					"title" : "Self- Confidence",
					"color" : "#1AA59A;",
					"content" : "Communication skills, Body image issues, Decision making",
					"imageUrl" : "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/self+confidence+icon.png"
				},
				{
					"category" : "Others",
					"categoryId" : 6,
					"title" : "Others",
					"color" :"#DC3737;",
					"content" : "Anxiety, Stress, Depression, Sexual wellness",
					"imageUrl" : "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/Others+icon.png"
				}
			]

			return categories;
		},	

		render: function() {

			var self = this;

			this.trackMixpanel("page_load", { key: "Mktg_Womensday_dac", value: "lp" })
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout())

			$(".wd-dac-cats-content").html(this.catLayout({categories : this.getCategories()}))
			document.title="The New Age Indian Woman & Her Challenges | YourDOST";
			$('meta[name=description]').attr('content', "With multiple responsibilities at work and at home, the new age woman is more stressed than before. It is time to take action.");
			$('meta[name=title]').attr('content',"The New Age Indian Woman & Her Challenges | YourDOST");
			$('meta[property="og:description"]').attr('content', "With multiple responsibilities at work and at home, the new age woman is more stressed than before. It is time to take action.");
			$('meta[property="og:title"]').attr('content',"The New Age Indian Woman & Her Challenges | YourDOST");
			$('meta[property="og:image"').attr("content", "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/womens_day/heroBG.jpg");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/womens-day-2017/dac');

		}
	});

	womensDayDacPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	womensDayDacPage.prototype.clean = function() {

		this.remove() ;
	};

	return womensDayDacPage;
});
