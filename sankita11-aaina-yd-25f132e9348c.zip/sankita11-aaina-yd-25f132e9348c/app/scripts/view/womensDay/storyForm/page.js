define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function( $, _, Backbone, JST, Utils ) {

	var womensDayFormPage = Backbone.View.extend({

		el: "main",

		initialize: function() {

		},

		events: {

			"click .wd-form-submit" : "submitStory",
			"click .wd-take-home" : "takeHome",
			"click .wd-submit-another" : "directToStoryForm",
			"click .wd-form-read-stories-btn" : "readStories"
		},

		mainLayout : JST['app/templates/womensDay/storyForm/layout.hbs'],
		successLayout : JST['app/templates/womensDay/storyForm/success.hbs'],

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_Women_of_2017", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		takeHome : function( evt ){

			Utils.closePopup('wd-success') ;
			$("#wd-success").remove();
			window.open("/womens-day-2017", "_self")
		},

		readStories : function( evt ){

			this.trackMixpanel("click_read_stories_form", {})
			window.open("/womens-day-2017", "_self")
		},

		directToStoryForm : function( evt ){

			Utils.closePopup('wd-success') ;
			$("#wd-success").remove();
			window.open("/womens-day-2017/submit-your-story", "_self")
		},

		showError : function( txt ){

			$(".wd-form-error").html(txt)
			$("wd-form-error").removeClass("hide")
			$(".wd-form-submit").html("SUBMIT YOUR STORY")
		},

		hideError : function(  ){

			$(".wd-form-error").html("")
			$("wd-form-error").addClass("hide")
		},

		generateUploadUrl : function( filename ){

			var s3 = new AWS.S3({

			  accessKeyId: 'AKIAIM44H66YO26ALVYQ',
			  secretAccessKey: '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'
			});

			var uploadPreSignedUrl = s3.getSignedUrl('putObject', {

			    Bucket: 'ydattachments',
			    Key: filename,
			    ACL: 'authenticated-read',
			    ContentType: 'application/octet-stream'

			});

			return uploadPreSignedUrl;
		},


		generateUid : function(){

			function ran(){

				return (Math.random(0,1)*10000).toString(20).substring(4,8);
			}

			return ran()+"-"+ran();
		},

		submitStory : function( ){

			var self = this;

			this.hideError()
			$(".wd-form-submit").html("Submitting...")

			var storyOf = $(".wd-a input[type=radio]:checked").attr("id")
			if( typeof storyOf == 'undefined' || storyOf == ""){

				this.showError("Please select whose story")
				return false;
			}

			var name = $("#name").val()
			if(typeof name == 'undefined' || name == ""){

				this.showError("Please enter your name")
				return false;
			}

			var file = $(".wd-form input[type='file']").get(0).files[0];
			if( typeof file == 'undefined' || file == ''){

				this.showError("Please choose a picture")
				return false;
			}

			file = this.imageUrl;

			var story = $(".step-3").find("textarea").val();
			if( typeof story == 'undefined' || story == ""){

				this.showError("Please enter the story you want to share")
				return false;
			}else{

				story = story.replace(/\s\s+/g, ' ');
				if( story.split(" ").length < 100){

					this.showError("Please enter at least 100 words")
					return false;
				}
			}

			var email = $("#email").val()
			var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
						
			if( typeof email == 'undefined' || email == "" ){

				this.showError("Please enter a valid email")
				return false;
			}else{

				if( !pattern.test(email) ){

					this.showError("Please enter a valid email")
					return false;
				}
			}

			var mobile = $("#mobile").val()
			if( typeof mobile == 'undefined' || mobile == "" || mobile.length != 10){

				this.showError("Please enter a valid mobile no")
				return false;
			}

			this.hideError()

			var dataToSend = {

				"mailTo" : [155387],
				"mailFrom" : 101,
				"mailParams" : {
					"story_of" : storyOf,
					"name" : name,
					"imageUrl" : this.imageUrl,
					"mobile" : mobile,
					"email" : email,
					"story" : story
				},
				"mailTemplate" : "WOMENSDAY_TEMPLATE"
			}

			$.ajax({
				method : "POST",
				url : Utils.contextPath()+"/sendMail",
				data : JSON.stringify(dataToSend),
				contentType : "application/json"
			}).done( function( response){

				self.showSuccesModal()
				$(".wd-form-submit").html("SUBMIT YOUR STORY")

			}).fail( function( error){

				self.showError("Something went wrong. Please try again later")
			})
		},


		showSuccesModal : function( ){

			this.$el.append(this.successLayout());	

			Utils.openPopup('wd-success') ;
		},

		putContent : function(url, options){

			var defer = $.Deferred();
			$.ajax(options).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		attachFile : function( evt ){

			var fileName = $(".wd-form input[type='file']").val().split('/').pop().split('\\').pop();
			fileName = fileName.replace(/ /g, "-")
	        var self = this;
	        $(".file-path").val(fileName)
	        var uploadUrl = this.generateUploadUrl(fileName)

	        var options = {

				type : 'PUT',
		      	url: uploadUrl,
		      	contentType: 'application/octet-stream',
		      	processData: false,
		      	data: $(".wd-form input[type='file']").get(0).files[0]
			}

			this.putContent(uploadUrl, options).then(function(response){

	        	self.imageUrl = "https://s3-ap-southeast-1.amazonaws.com/ydattachments/"+fileName;
	        }, function( error ){

	        	self.imageUrl = "";
	        })
		},

		changeContent : function( evt ){

			if( $(evt.currentTarget).attr("id") != "own"){

				$(".s-name").html("Name of nominee*")
				$(".s-tory").html("Nominee’s story of courage (100 - 600 words)*")
				$(".s-pic").html("High resolution picture of nominee*")
			}else{

				$(".s-name").html("Your Name*")
				$(".s-tory").html("Your story of courage (100 - 600 words)*")
				$(".s-pic").html("Your high resolution picture*")
			}
		},

		render: function() {

			var self = this;

			this.trackMixpanel("page_load", { key: "womens day 2017", value: "form" })
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout({}))


          	$( ".wd-form input[type='file']" ).change(function(event){

            	self.attachFile(event);
          	});

          	$(".wd-a input[type='radio']").change( function( evt ){

          		self.changeContent( evt );
          	})
			
		}
	});

	womensDayFormPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	womensDayFormPage.prototype.clean = function() {

		this.remove() ;
	};

	return womensDayFormPage;
});
