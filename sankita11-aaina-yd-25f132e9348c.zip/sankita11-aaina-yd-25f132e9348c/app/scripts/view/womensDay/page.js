define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/womensDay/subview/stories',
	'utils'
], function( $, _, Backbone, JST, StoriesPage, Utils ) {

	var womensDayPage = Backbone.View.extend({

		el: "main",

		initialize: function() {

			this.storiesPage = new StoriesPage()
		},

		events: {

			"click .wd-btn" : "scrollToStories",
			"click .wd-sticky-btn" : "directToStoryForm",
			"click .wd-story-a" : "directToStory",
			"click .wd-fb-share" : "trackFbShare",
			"click .wd-tt-share" : "trackTwitShare",
			"click .wd-load-more-btn" : "trackLoadMore",
			"click .swiper-button-prev" : "trackQuotesScroll",
			"click .swiper-button-next" : "trackQuotesScroll"
		},

		mainLayout : JST['app/templates/womensDay/layout.hbs'],
		bannerLayout : JST['app/templates/womensDay/subview/banner.hbs'],
		stickyLayout : JST['app/templates/womensDay/subview/sticky.hbs'],
		quotesLayout : JST['app/templates/womensDay/subview/quotes.hbs'],
		footerLayout : JST['app/templates/womensDay/subview/footer.hbs'],

		directToStoryForm : function( evt ){

			this.trackMixpanel("click_submit_story_lp", {key:"womens day 2017", value : "lp"})
			window.open("/womens-day-2017/submit-your-story", "_self")
		},

		trackTwitShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("share_womenstory_lp", {key:"channel", value : "twitter", title : title, url : url})
		},

		trackLoadMore : function( evt ){

			this.trackMixpanel("click_loadmore_lp", {key:"womens day 2017", value : "lp"})
		},

		trackQuotesScroll : function( evt ){

			this.trackMixpanel("scroll_quotes_lp",{key:"womens day 2017", value : "lp"})
		},

		trackFbShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("share_womenstory_lp", {key:"channel", value : "fb", title : title, url : url})
		},

		directToStory : function( evt ){

			var title = $(evt.currentTarget).attr("data-title")
			this.trackMixpanel("click_submit_story_lp", {key:"content_title", value : title})
		},

		scrollToStories : function( evt ){

			this.trackMixpanel("click_read_stories_lp", {key:"womens day 2017", value : "lp"})

			$("body, html").animate({

				scrollTop : $(".wd-stories").offset().top - $(".wd-sticky").height() }, 
			'slow');
			
		},

		getContent : function(url){

			var defer = $.Deferred();
			$.ajax({
				url : url,
				method: "GET"
			}).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_Women_of_2017", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		stickSubmit : function( evt,h ){

			if( $(document).scrollTop() > h+20){

				$(".wd-sticky").addClass("fixed")
				var height = $(".wd-sticky").height()
				$(".wd-stories").css({"margin-top" : (height-10)+"px"})
			}else{

				$(".wd-sticky").removeClass("fixed")
				$(".wd-stories").css({"margin-top" : "0px"})
			}
		},

		render: function() {

			var self = this;
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout({}))

			$(".wd-banner").html(this.bannerLayout());
			$(".wd-sticky").html(this.stickyLayout());
			this.storiesPage.render();

			this.trackMixpanel("page_load", { key: "womens day 2017", value: "lp" })

			this.getContent(Utils.scriptPath()+"/quotes.json")
			.then(function(response){

				$(".wd-quotes").html(self.quotesLayout({quotes : response.quotes}))
				var mySwiper = new Swiper ('.wd-quotes-content', {
				    
	        		autoplay: 15000,
	        		keyboardControl: true,
	        		slidesPerView: '1',
	        		loop : true,
			        nextButton: '.swiper-button-next',
			        prevButton: '.swiper-button-prev',
				});
			})

			document.title="#WomenOf2017 - An ode to our strong women | YourDOST";
			$('meta[name=description]').attr('content', "YourDOST takes pride in honoring our courageous women. Their stories deserve to be shared and celebrated");
			$('meta[name=title]').attr('content',"#WomenOf2017 - An ode to our strong women | YourDOST");
			$('meta[property="og:description"]').attr('content', "YourDOST takes pride in honoring our courageous women. Their stories deserve to be shared and celebrated");
			$('meta[property="og:title"]').attr('content',"#WomenOf2017 - An ode to our strong women | YourDOST");
			$('meta[property="og:image"]').attr("content", "https://d1hny4jmju3rds.cloudfront.net/womens_day/40839680_ml-cutout.png");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/womens-day-2017');
			$('meta[property="og:url"]').attr('content', 'https://yourdost.com/womens-day-2017');
			
			$(".wd-footer").html(this.footerLayout());
			var h = $(".wd-sticky").offset().top;
			$(document).scroll(function( evt ){

				self.stickSubmit.call(self, evt, h)
			})
		}
	});

	womensDayPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	womensDayPage.prototype.clean = function() {

		this.remove() ;
	};

	return womensDayPage;
});
