define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel) {

	var PaymentSuccessView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
			var self = this ;
			var url = window.location.href ;
    		url = url.replace("/paymentSuccess", "" );
			var id = $.url( url ).param('t') ;
			var zionCookie = $.url( url ).param('z') ;
			this.zionCookie = zionCookie ;

			this.counselorID = '' ;
			this.userID      = '' ;
			this.bookType    = '' ;

		},
		events: {
			'submit .appointment-feedback-form' : 'submitFeedback'

		},
		PaymentSuccessViewLayout: JST['app/templates/bookAppointment/payment_success.hbs'],
		submitFeedback : function(){

			var self = this ;

			var rating    = $("input[name='review-rating']:checked").val() ;
			var description = $("#app-msg").val() ;

			var dataToSend = {
		        "feeling" : self.bookType,
		        "star" : $("input[name='review-rating']:checked").val() ,
		        "description" : $("#app-msg").val(),
		        "gender" : '',
		        "age" : '',
		        "area" : ''				
			}
		    
		    var headersToPass = {
				"X-DOST-ZION-AUTH" : this.token ,
			} ;

			console.log(dataToSend);

			$.ajax({
				url : Utils.contextPath() + '/v1/users/'+ this.userID +'/counselor/'+ this.counselorID +'/rating',
				method : "POST",
				dataType: "JSON",
				contentType: "application/json; charset=utf-8",
				data : JSON.stringify(dataToSend)
			}).done(function(response){
				console.log(response);
				$(".success-msg").removeClass("hide");
				$(".success-msg").html("Thank you for your feedback.");
				$(".appointment-feedback-form").addClass("hide");
			}).error(function(error){
				console.log("error"); console.log(error);
			});

		},
		render: function() {
	
			var self = this ;
			var url = window.location.href ;
    		url = url.replace("/paymentSuccess", "" );
			var id = $.url( url ).param('t') ;
			var status = $.url( url ).param('status') ;
			if (status == "paid") {
				self.$el.html(self.PaymentSuccessViewLayout({}));
				return;
			}
	
			$.ajax({
				url : Utils.contextPath() + "/v1/user/transaction/" + id
			}).done(function(response){
				console.log(response);
				
				self.bookType = response.lineItems[0].product.type;

				if(self.bookType == "PAID_CHATS"){
					
					self.$el.html(self.PaymentSuccessViewLayout({ transaction : response }));

					setInterval(function(){
						var username     = self.userModel.getUserName() ;
						var chatStartUrl = Utils.chatUrl() + username   ;
						location.href =chatStartUrl ;	
					}, 5000);
							
				}else{
				
					var counselorID = response.lineItems[0].product.productDetails.counselorID ;
					self.counselorID = counselorID ;
					self.userID      = response.userID ;

					var duration = ( response.lineItems[0].product.productDetails.slotEndTime -
										response.lineItems[0].product.productDetails.slotStartTime )  ;

					duration = (duration / ( 1000 * 60 ) );

					var hours   = Math.floor(duration / 60);
					var minutes = Math.floor((duration - (hours * 60)));
					var durationStr = "" ;
					if(hours){
						durationStr += hours + " hours ";
					}
					if(minutes){
						durationStr += minutes + " minutes" ;
					}

					self.$el.html(self.PaymentSuccessViewLayout({ transaction : response, durationStr : durationStr }));


					$.ajax({
						url : Utils.contextPath() + "/v1/counselor/" + counselorID
					}).done(function(response){
						console.log(response);
						$(".counselor-name").html(response.name);
					}).error(function(error){
						console.log(error);
					});
					
				}

			}).error(function(error){
				console.log(error);
			});
		}
	});

	PaymentSuccessView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	PaymentSuccessView.prototype.clean = function() {
		this.remove() ;
	};

	return PaymentSuccessView;
});
