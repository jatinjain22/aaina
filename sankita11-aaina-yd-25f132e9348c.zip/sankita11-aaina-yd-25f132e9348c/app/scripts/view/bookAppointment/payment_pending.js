define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel) {

	var PaymentPendingView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;

			var url = window.location.href ;
    		url = url.replace("/paymentPending", "" );
			var id = $.url( url ).param('id') ;

			this.id = id ;

		},
		events: {
			"click #pay-now" : "redirectToPayment",
		},
		redirectToPayment : function(e){

			//location.href = "/process?id=" + this.id ;
			Backbone.history.navigate("/process?id=" + this.id, {trigger: true});
 
		},
		PaymentPendingViewLayout: JST['app/templates/bookAppointment/payment_pending.hbs'],
		render: function() {
	
			var self = this ;
			var url = window.location.href ;
    		url = url.replace("/paymentPending", "" );
			var id = $.url( url ).param('id') ;
	
			$.ajax({
				url : Utils.contextPath() + "/v1/user/transaction/" + id
			}).done(function(response){
				console.log(response);
				var counselorID = response.lineItems[0].product.appointment.counselorID ;

				var duration = ( response.lineItems[0].product.appointment.slotEndTime -
									response.lineItems[0].product.appointment.slotStartTime )  ;

				duration = duration / ( 1000 * 60) ;

				var hours   = Math.floor(duration / 60);
				var minutes = Math.floor((duration - (hours * 60)));
				var durationStr = "" ;
				if(hours){
					durationStr += hours + " hours ";
				}
				if(minutes){
					durationStr += minutes + " minutes" ;
				}

				self.$el.html(self.PaymentPendingViewLayout({ transaction : response, durationStr : durationStr }));


				$.ajax({
					url : Utils.contextPath() + "/v1/counselor/" + counselorID
				}).done(function(response){
					console.log(response);
					$(".counselor-name").html(response.name);
				}).error(function(error){
					console.log(error);
				});


			}).error(function(error){
				console.log(error);
			});


		}
	});

	PaymentPendingView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	PaymentPendingView.prototype.clean = function() {
		this.remove() ;
	};

	return PaymentPendingView;
});
