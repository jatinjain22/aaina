define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel) {

	var PaymentFailureView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;
			var url         = window.location.href ;
    		url             = url.replace("/paymentFailure", "" );
			this.params = $.url( url ).param('t') ;
            this.retryURL = $.url( url ).param('retryURL');

		},

		PaymentFailureViewLayout: JST['app/templates/bookAppointment/payment_failure.hbs'],

		render: function() {

			var userEmail = this.userModel.getUserEmail();
            var retryURL = this.retryURL;
			var homeurl = 'no';

			if(this.params && this.params == "donate"){

				var homeurl = 'yes'
			}
			this.$el.html(this.PaymentFailureViewLayout({ email : userEmail, homeurl : homeurl, retryURL : retryURL }));


		},
	});


	PaymentFailureView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	PaymentFailureView.prototype.clean = function() {
		this.remove() ;
	};

	return PaymentFailureView;
});
