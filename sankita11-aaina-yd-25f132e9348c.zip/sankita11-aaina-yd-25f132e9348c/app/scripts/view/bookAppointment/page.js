define([
	'jquery',
	'underscore',
	'moment-timezone-data',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'view/paymentPending/payment_pending',
	'view/leaveMessage/page' ,
	'purl',
	'jcarousellite',
	'jstz',
	'keystop'
], function($,_, moment, Backbone, JST, Dispatcher, Utils, UserModel, PaymentPendingView, LeaveMessageView) {

	var BookAppointmentView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;
			this.pendingMsg = new PaymentPendingView();

			this.pendingID = 0 ;
			this.payment = '';
			this.name = '';
			this.duration = '';
			this.startDate = '';
			this.pendingDetails = {} ;
			this.mobileVerified = 0 ;
			this.leaveMessage       = new LeaveMessageView(); 
			// _.bindAll(this, "reRender")                ;
			Dispatcher.bind('reRender', this.reRender );
			//_.bindAll(this);
			//this.listenTo(Dispatcher, 'keystop', this.render);

		},
		events: {
			"click .book-appointment"      : "bookAppointment",
			"click .pay-now"               : "redirectToPay", 
			"click .pending-details" : "viewPendingDetails",
	//		"click .pending-details-phone" : "viewPendingDetailsPhone",
			"click .article-link"          : "redirectToBlog",
			"click .appointment-main-container" : "hidePending",
			//"keyup #app-email": "checkForEmail"
			"click .mobile-nav-tab" : "showHideCard",
			'click #hide_coupon_notification_header' : "hideCouponNotificationHeader",
			"click .banner-high-traffic-div a": "leaveMessageBanner",
			"click .banner-high-traffic-row-close": "closeHighTrafficBanner"
			//"click .verify-call" : "callAppointmentAPI"
		},
		BookAppointmentViewLayout: JST['app/templates/bookAppointment/layout.hbs'],
		SuccessMessageLayout: JST['app/templates/bookAppointment/success_message.hbs'],
		VerifyEmailLayout: JST['app/templates/bookAppointment/verify_email.hbs'],
		LoaderLayout : JST['app/templates/loader.hbs'],
		BlogThumbnailLayout: JST["app/templates/home2/blog_thumbnails.hbs"],
		closeHighTrafficBanner: function (e) {
			console.log('hello');
			$('.banner-high-traffic-row-talkitout').addClass('hide');
		},
		leaveMessageBanner: function(e) {
			
			
			var buttonDesc = 'leaveMessage';	
			if(!Utils.isLoggedIn()){
				
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "message", '' ) ;
			}else{
				
				this.leaveMessage.render(  ) ;
	
			}

		},
		showHideCard : function(e){
			
			$(".mobile-nav-tab").removeClass("mobile-nav-active");
			$(e.currentTarget).addClass("mobile-nav-active");

			var cardID = $(e.currentTarget).attr("card-attr");
			$(".method-type-card").addClass("hide-on-small-only");

			$("#" + cardID).removeClass("hide-on-small-only");

		},
		checkForEmail: function(e) {
			console.log('hello2');
		},
		checkForMobile : function(mobile,bookType){
			
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=mobile&item=" + mobile,
				statusCode:{
            		404 : function(){
            			if(bookType == "audio"){
								$("#app-phone-417-error").addClass("hide");
							}else{
								$("#app-video-phone-417-error").addClass("hide");
							}
						return true;
            		}
        		},

			}).done(function(response){

					if(response == true ){
						if(bookType == "audio"){
								$("#app-phone-417-error").html("Phone number already exists.");
								$("#app-phone-417-error").removeClass("hide");
								$("#app-phone").addClass("input-mbottom0");								
							}else{
								$("#app-video-phone-417-error").html("Phone number already exists.");
								$("#app-video-phone-417-error").removeClass("hide");
								$("#app-video-phone").addClass("input-mbottom0");															
							}
							return false;
					}

					return true;
					

				}).error(function(){

				});
		},
		redirectToPay : function(e){
			//location.href = "/process?id=" + this.pendingID;
			Backbone.history.navigate("/process?id=" + this.pendingID, {trigger: true});
		},
		hidePending : function(e){
			
			if($(e.target).attr("class") == undefined){
				$(".pending-amt-container").addClass("hide");
				return true ;
			}
			if($(e.target).attr("class") != undefined && !$(e.target).attr("class").match("pending-details")){
				$(".pending-amt-container").addClass("hide");
			}
		},
		viewPendingDetails: function(e){

			var self = this;

			console.log($(e.currentTarget));

			var divID = $(e.currentTarget).attr("card-id");
			var info = self.$el.find('.pending-amt-container');

			var pendingDetails = self.pendingDetails ;

			var duration = ( pendingDetails.lineItems[0].product.appointment.slotEndTime -
								pendingDetails.lineItems[0].product.appointment.slotStartTime )  ;

			duration = duration / ( 1000 * 60) ;
			var startTime = pendingDetails.lineItems[0].product.appointment.slotStartTime;
			var hours   = Math.floor(duration / 60);
			var minutes = Math.floor((duration - (hours * 60)));
			var durationStr = "" ;
			if(hours){
				durationStr += hours + " hours ";
			}
			if(minutes){
				durationStr += minutes + " minutes" ;
			}

			var bookTypeStr = 'Video' ;
			var bookType =pendingDetails.lineItems[0].product.type ;
			if(bookType == 'AUDIO'){
				bookTypeStr = 'Audio' ;
			}

			var pendingAmount = pendingDetails.amount ;
			var slotDate = Utils.getDateString(startTime, "date");
			var slotTime = Utils.getDateString(startTime, "time");
			
			console.log(info);
			var innerHtml = '<div>'+ bookTypeStr +' call with '+ self.name +'</div>' 
									+ '<div><span class="grey-text">'+ slotDate +';' + slotTime +' </span></div><div><span class="grey-text">'+ durationStr+' </span></div>' 
									+ '<div><span>Amount Payable: </span><span style="float:right">'+ pendingAmount +'</span></div>' 
			info.find(".pending-amt-details").html(innerHtml);
			info.removeClass('hide');

			$("#" + divID ).find(".pending-amount-holder").html(info);

			
		},
		redirectToBlog : function(e){
			var blogUrl = $(e.currentTarget).attr("data-href");
			Backbone.history.navigate(blogUrl,{trigger:true}) ;

		},
		validateCommonFields : function(e){
			var commonFields = $(".common-fields .required");
			var fieldError   = 0  ;
			_.each(commonFields, function(elem){

				var elemVal = $(elem).val() ;
				if($(elem).hasClass("select-wrapper")){
					return true ;
				}
				if(elemVal == undefined || elemVal == null || elemVal == ""){
					fieldError = 1;
					$(elem).siblings(".form-error").removeClass("hide");
					if($(elem).attr("id") == "book-app-area"){
						$("#app-cat-error").removeClass("hide");
					}
					$("html, body").animate({ scrollTop: 0 }, "slow");
				}else{
					$(elem).siblings(".form-error").addClass("hide");
					if($(elem).attr("id") == "book-app-area"){
						$("#app-cat-error").addClass("hide");
					}
				}

			});

			return fieldError ;
		},
		validateEmail : function(e){
			var email = $("#app-email").val();

			if(!Utils.formEmailCheck(email)){
				$("#app-email").siblings(".form-error").removeClass("hide");
				return false ;
			}else{
				$("#app-email").siblings(".form-error").addClass("hide");
			}

			return true ;

		},
		checkIfMobileVerified : function(phone){


			var self = this ;
			$.ajax({
				url : Utils.contextPath() + '/v2/users/number/' + phone,
			}).done(function(response){
				console.log(response);
				if(response.status != "Whitelist"){
					$(".verify-overlay").show();
					$(".verify-toast").show();
					self.mobileVerified = 0 ;
				}else{
					self.mobileVerified = 1 ;
				}
			}).error(function(error){
				console.log(error);
			});

		},
		validateCardInputs : function(e, bookType){

			var self = this ;

			var fieldError = 0 ;
			var cardID     = $(e.currentTarget).attr("card-id");
			var cardInputs = $("#" + cardID).find("input");

			_.each(cardInputs, function(elem){

				if($(elem).attr("type") == "hidden"){
					return true;
				}

				var elemVal = $(elem).val() ;
				if(elemVal == undefined || elemVal == null || elemVal == ""){
					fieldError = 1;
					$(elem).siblings(".form-error").removeClass("hide");
					console.log($(elem).siblings(".form-error"));
					$(elem).addClass("input-mbottom0");
				}else{
					$(elem).siblings(".form-error").addClass("hide");

					if($(elem).attr("request-key") == "phone"){
						$('#app-phone-417-error').addClass("hide");
						$('#app-video-phone-417-error').addClass("hide");
						
						var isValidMobile = Utils.formMobileCheck(elemVal);
						if(!isValidMobile){
							fieldError = 1;
							$(elem).siblings(".form-error").removeClass("hide");
							$(elem).addClass("input-mbottom0");
							return false ;							
						}
					}

					$(elem).removeClass("input-mbottom0");
				}

			});

			return fieldError ;

		},
		callAppointmentAPI : function(bookType, cardID){

			var self = this ;

			var dataToSend = {} ;
			dataToSend["type"] = bookType.toUpperCase() ;

			var localtz            = jstz() ;
	    	var localTimezone = localtz.timezone_name ;

	    	dataToSend["timezone"] = localTimezone ;

			var formInput = $(".form-input");
			_.each(formInput, function(elem){
				if($(elem).hasClass("select-wrapper")){
					return true ;
				}
				var requestKey = $(elem).attr("request-key");
				var elemVal    = $(elem).val() ;

				if(requestKey == "slotStartTime"){
					var slotStartEpoch = new Date(elemVal).getTime();
					dataToSend[requestKey] = slotStartEpoch ;
					dataToSend["slotEndTime"] = slotStartEpoch + ( 1000 * 60 * 60 ) ;		
				}else{
					dataToSend[requestKey] = elemVal ;
				}

			});

			var cardInputs = $("#" + cardID).find(".card-input");
			_.each(cardInputs, function(elem){
				var requestKey = $(elem).attr("request-key");
				var elemVal    = $(elem).val() ;
				dataToSend[requestKey] = elemVal ;

			});

			console.log(dataToSend);

			$(".appointment-container .appointment-loader").removeClass("hide");
			$(".appointment-container .appointment-main-container").addClass("hide");
			$(".pending-msg-header").addClass("hide");
			$(".request-title").addClass("hide");

			var userID = self.userModel.getUserID();

			$(".form-error-417").addClass("hide");
			$(".card-input").removeClass("input-mbottom0");
			$(".verify-overlay").hide();
			$(".verify-toast").hide();

			$.ajax({
				url : Utils.contextPath() + "/v2/users/" + userID + "/bookappointment",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend),
            	statusCode :{
					417 : function(response){

						$("#" + bookType +"-progress").hide();
						$("#" + bookType + "-card .book-appointment").show();

						$(".appointment-container .appointment-loader").addClass("hide");
						$(".appointment-container .appointment-main-container").removeClass("hide");
						
						if(self.pendingID > 0){
							$(".pending-msg-header").removeClass("hide");	
						}
						
						$(".request-title").removeClass("hide");
						
						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						if( errorType == "EmailExists"){
							$("#app-email-417-error").html(errorMessage);
							$("#app-email-417-error").removeClass("hide");
						}else if(errorType == "SkypeIDExists"){
							$("html, body").animate({ scrollTop: $(document).height() }, "slow");
							$("#app-skype-417-error").html(errorMessage);
							$("#app-skype-417-error").removeClass("hide");
							$("#app-skypeID").addClass("input-mbottom0");								
						}else if(errorType == "PhoneExists"){
							$("html, body").animate({ scrollTop: $(document).height() }, "slow");
							if(bookType == "audio"){
								$("#app-phone-417-error").html(errorMessage);
								$("#app-phone-417-error").removeClass("hide");
								$("#app-phone").addClass("input-mbottom0");								
							}else{
								$("#app-video-phone-417-error").html(errorMessage);
								$("#app-video-phone-417-error").removeClass("hide");
								$("#app-video-phone").addClass("input-mbottom0");															
							}
						}else{
							$("#common-417-error").html(errorMessage);
							$("#common-417-error").removeClass("hide");
						}



					},
				}

			}).done(function(response){

				var emailVerified = response.verified ;

				var userEmail = self.userModel.getUserEmail();

				if(emailVerified == "true"){
					$(".appointment-container").html(self.SuccessMessageLayout());
				}else{
					$(".appointment-container").html(self.VerifyEmailLayout({verified:response.verified}));					
				}
				
				localStorage.removeItem("user");
				$('.article-jcarousel .popup-loader').removeClass('hide');
				console.log("blog json "+ Utils.blogJson());
				$.ajax({
					method : "GET",
					url : Utils.blogJson(),
					dataType: "jsonp"
				}).done(function(response){
					$('.article-jcarousel .popup-loader').addClass('hide');
					console.log("json " + JSON.stringify(response.posts));
					self.$el.find(".articals_div").html(self.BlogThumbnailLayout({ post : response.posts }));
					$('.trending_articals .article-jcarousel').jCarouselLite({
					  btnNext: '.article-scroll-right',
					  btnPrev: '.article-scroll-left',
					});
				}).error(function(error){
					console.log(error);
				});

			}).error(function(error){
				console.log(error);
			});

		},
		bookAppointment : function(e){

			var self = this ;
			var fieldError = this.validateCommonFields() ;
			var validEmail = this.validateEmail() ;
			var inputError = this.validateCardInputs(e);

			var event = e ;

			var bookType = $(e.currentTarget).attr("book-type");
			var cardID     = $(e.currentTarget).attr("card-id");
			if(bookType == "audio" || bookType == "video"){				
				if(!validEmail || fieldError || inputError ){
					return false ;
				}
			}else{
				if(fieldError){
					return false ;
				}
			}

			var mobileNumber = $("#app-video-phone").val();
			if(bookType == "audio"){
				mobileNumber = $("#app-phone").val();
			}

			var cardID     = $(e.currentTarget).attr("card-id");
			$("#" + bookType +"-progress").show();
			$("#" + bookType + "-card .book-appointment").hide();
			if(bookType == "chat"){
				self.callAppointmentAPI(bookType, cardID);
			}else{
				var interval = setInterval(function(){

				    if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				      mixpanel.track("Mobile-Verifying", {"mediumSource" : "website", "bookType" : bookType});
				    }

					self.checkIfMobileVerified(mobileNumber);

					if(self.mobileVerified == 1){
					    if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
					      mixpanel.track("Mobile-Verified", {"mediumSource" : "website", "bookType" : bookType});
					    }
						clearInterval(interval);
						self.callAppointmentAPI(bookType, cardID);
					}

				}, 2000)

			}





		},
		render: function() {
			
			var self = this ;
			var userEmail = this.userModel.getUserEmail();
			var userID = this.userModel.getUserID();

			var userPhone   = this.userModel.getPhoneNo();
			var userSkypeID = this.userModel.getSkypeID();

			self.$el.html(self.LoaderLayout());

			$.ajax({
				method : "GET", 
				url : Utils.contextPath() + '/v1/appointment/fare'
			}).done(function(response){
				console.log(response);
				var fareType = {} ;
				
				$.ajax({
					url : Utils.contextPath() + "/v1/user/transaction/pending/" + userID
				}).done(function(pendingID){

					var isPendingAmount = 0 ;
					if(pendingID > 0){
						isPendingAmount = 1 ;
						self.pendingID = pendingID;
					}

					_.each(response, function(elem){

						fareType[elem.type] = elem ;
					});	

						self.$el.html(self.BookAppointmentViewLayout({ email : userEmail, phone: userPhone, skypeID: userSkypeID,fare: fareType, isPendingAmount : isPendingAmount }));
						$(".appointment-container .appointment-loader").html(self.LoaderLayout());
						
						$.ajax({
							url : Utils.contextPath() + '/v1/coupon/get' ,
						}).done(function(response){
							if(response){

								var audio_coupon_info = "";
								var video_coupon_info = "";

								var discount = ""
								if(response.type == "FIXED"){
									discount = "Rs." + response.value;
								}else{
									discount = response.value + "%";
								}

								if(response.incentiveOn == "ALL" || response.incentiveOn == "VIDEO"){
									if(response.incentiveType == "FREE" ){
										video_coupon_info += " You have one free video call! ";
									}else{
										video_coupon_info += " Get " + discount + " discount on your first call! ";
									}
								}
								if(response.incentiveOn == "ALL" || response.incentiveOn == "AUDIO"){
									if(response.incentiveType == "FREE" ){
										audio_coupon_info += " You have one free audio call! ";
									}else{
										audio_coupon_info += " Get " + discount + " discount on your first call! ";
									}
								}
								$('#audio_coupon_info').html(audio_coupon_info);
								$('#video_coupon_info').html(video_coupon_info);

								if( localStorage.getItem("hideCouponNotificationHeader") != 1){
									$('#coupon_notification_header').html( video_coupon_info ? video_coupon_info : audio_coupon_info);
									$('#coupon_notification_header').addClass('slideLeft');
									$('#coupon_notification_header').show();

									$('#coupon_notification_header').append("<span class='right cpointer' id='hide_coupon_notification_header'>X</span>");
								}

							}
						}).error(function(error){
							console.log("Error");
							console.log(error) ;
						});
						$.ajax({
        
			          		url: Utils.scriptPath() + "/banner.json",
			        		cache: false
			        	}).done( function( data ) {
			            
			            	if ( data.visibility == "on") {
			            		console.log("hello");
			            		console.log( $(".page-title") );
			            		$(".page-title").css("margin-bottom", "0px");
			            		$(".banner-high-traffic-row-talkitout").removeClass("hide");
			            	}
			 
			        	}).error(function(error){
			        
			          		console.log(error)
			        
			        	});
						//verfication on typing 
						$("#app-skypeID").keystop( function (event) {
							var elem = "#app-skypeID";
							var elemVal = $(elem).val();
							if (elemVal.length > 0 && elemVal.length < 5) {
								$(elem).siblings(".form-error").removeClass("hide");
								$(elem).addClass("input-mbottom0");
							}
							else {
								$(elem).siblings(".form-error").addClass("hide");
								$(elem).removeClass("input-mbottom0");
							}
						}, 2000);

						$("#app-email").keystop( function(event){
							self.validateEmail();
						}, 2000 ) ;

						$("#app-phone").keystop( function(event){
							var elem = "#app-phone";
							var elemVal = $("#app-phone").val();
							console.log(elemVal);
							if (elemVal) {
								$('#app-phone-417-error').addClass("hide");
								var verify = self.checkForMobile(elemVal, "audio");
								
								var isValidMobile = Utils.formMobileCheck(elemVal);
								if(!isValidMobile){
									$(elem).siblings(".form-error").removeClass("hide");
									$(elem).addClass("input-mbottom0");
									$('#app-phone-417-error').addClass("hide");
								    $('#app-video-phone-417-error').addClass("hide");
									//return false ;							
								}
								else {
				
									$(elem).siblings(".form-error").addClass("hide");
									$(elem).removeClass("input-mbottom0");
									//return false ;
								}
							
							}
							else {
								
								$(elem).siblings(".form-error").addClass("hide");
								$(elem).removeClass("input-mbottom0");
							}
						}, 2000 ) ;

						$("#app-video-phone").keystop( function(event){
							var elem = "#app-video-phone";
							var elemVal = $("#app-video-phone").val();
							console.log(elemVal);
							if (elemVal) {
								$('#app-video-phone-417-error').addClass("hide");
								var verify = self.checkForMobile(elemVal, "video");
								
								var isValidMobile = Utils.formMobileCheck(elemVal,"video");
								if(!isValidMobile){
									
									$(elem).siblings(".form-error").removeClass("hide");
									$(elem).addClass("input-mbottom0");
									$('#app-phone-417-error').addClass("hide");
								    $('#app-video-phone-417-error').addClass("hide");
									//return false ;							
								}
								else {
									
									$(elem).siblings(".form-error").addClass("hide");
									$(elem).removeClass("input-mbottom0");
									//return false ;
								}
							
							}
							else {
								
								$(elem).siblings(".form-error").addClass("hide");
								$(elem).removeClass("input-mbottom0");
							}
						}, 2000 ) ;
						

						if(pendingID > 0){
							$(".pending-msg-header").removeClass("hide");
							$(".payment-pending-url").attr("href", "/sessions" );
						}
					


					$.ajax({
		            	method: "GET",
		            	url: Utils.contextPath()+'/category?include_faq=false'
		        	}).done(function(response){

		        		_.each(response, function(elem){
		        			$("#book-app-area").append('<option value="'+elem.id+'">'+elem.name+'</option>');
		        		})

						$('select').material_select();

		        	}).fail(function(error){});

					var currentDate = new Date() ;
					var currentHour = currentDate.getHours() ;
					if(currentHour < 6 ){
						currentDate.setHours(6);
						currentDate.setMinutes(0);
					}

					if(currentHour >= 23 ){
						currentDate.setHours(6);
						currentDate.setMinutes(0);	
						currentDate.setDate(currentDate.getDate() +1);
					}


					$("#start-slot").datetimepicker({
						minDate :  new Date(currentDate.setDate(currentDate.getDate() +1)),
						allowTimes:[
						  '06:00',
						  '06:30',
						  '07:00',
						  '07:30',
						  '08:00',
						  '08:30',
						  '09:00',
						  '09:30',
						  '10:00',
						  '10:30',
						  '11:00',
						  '11:30',
						  '12:00',
						  '12:30',
						  '13:00',
						  '13:30',
						  '13:00',
						  '13:30',
						  '14:00',
						  '14:30',
						  '15:00',
						  '16:30',
						  '17:00',
						  '17:30',
						  '18:00',
						  '18:30',
						  '19:00',
						  '19:30',
						  '20:00',
						  '20:30',
						  '21:00',
						  '21:30',
						  '22:00',
						  '22:30',
						  '23:00',
						],
						step : 30 ,
						format : "d M Y H:i",
						defaultDate : new Date(currentDate.setDate(currentDate.getDate() )) ,
						todayButton : false,
						onSelectTime : function(ct){
							var currentDate = new Date();
							var selectedDate = new Date(ct.setHours(ct.getHours()) );
							var ritDate = new Date();
							var currentDate = new Date(ritDate.setHours( ritDate.getHours() + 24 ));
							if(selectedDate < currentDate){
								$("#app-time-error").html("Please book your appointment atleast 24 hrs in advance.");
								$("#app-time-error").removeClass("hide");
								return false;
							}else{
								$("#app-time-error").html("");
								$("#app-time-error").addClass("hide");
							}
						},
					});

					if( self.pendingID > 0 ){
						$.ajax({
						url : Utils.contextPath() + "/v1/user/transaction/" + self.pendingID,
						method: 'GET'
						}).done(function(response){
						console.log(response);
			
						self.pendingDetails = response ;
						var counselorID = response.lineItems[0].product.appointment.counselorID ;

						var duration = ( response.lineItems[0].product.appointment.slotEndTime -
											response.lineItems[0].product.appointment.slotStartTime )  ;

						duration = duration / ( 1000 * 60) ;
						var startTime = response.lineItems[0].product.appointment.slotStartTime;
						var hours   = Math.floor(duration / 60);
						var minutes = Math.floor((duration - (hours * 60)));
						var durationStr = "" ;
						if(hours){
							durationStr += hours + " hours ";
						}
						if(minutes){
							durationStr += minutes + " minutes" ;
						}

						var bookTypeStr = 'Video' ;
						var bookType =response.lineItems[0].product.type ;
						if(bookType == 'AUDIO'){
							bookTypeStr = 'Audio' ;
							$("#video-card .card").append($(".disable-other-card"));
							$("#video-card .disable-other-card").removeClass("hide");
							$(".disable-other-card .pay-now").attr("data-desc", "click #PayNow VIDEO No Amt");
						}else{
							$("#audio-card .card").append($(".disable-other-card"));							
							$("#audio-card .disable-other-card").removeClass("hide");
							$(".disable-other-card .pay-now").attr("data-desc", "click #PayNow AUDIO No Amt");
						}

						var pendingAmount = response.amount ;
						var slotDate = Utils.getDateString(startTime, "date");
						var slotTime = Utils.getDateString(startTime, "time");						

						var overlayHTML = $(".disable-actual-card").clone() ;

						overlayHTML.find(".pending-start-time").html(slotDate + " " + slotTime);
						overlayHTML.find(".pending-duration").html(durationStr) ;
						overlayHTML.find(".pending-amount").html("Rs. " + pendingAmount);
						overlayHTML.find(".pending-book-type").html(bookTypeStr);
						overlayHTML.removeClass("hide");

						var lowerCaseType = bookType.toLowerCase() ;
						$("#" + lowerCaseType + "-card .card" ).append(overlayHTML) ;
						$("#" + lowerCaseType + "-card .card-image").html("Please pay your previous charges to place new calls");
						$("#" + lowerCaseType + "-card .card-image" ).attr("class", "card-image small");
						$("#" + lowerCaseType + "-card .card-image" ).addClass("white-text font-13b center");
						$("#" + lowerCaseType + "-card .card-image" ).css("background","rgba(0, 150, 136, 0.4)");
						$("#" + lowerCaseType + "-card .card-image" ).css("z-index", 998);
						$("#" + lowerCaseType + "-card .card-image" ).css("padding", "6px");
						$("#" + lowerCaseType + "-card .card-image").css("line-height", "15px");
						$("#" + lowerCaseType + "-card .counselor-img-container").css("z-index", 998);
						$("#" + lowerCaseType + "-card .counselor-img-container .app-type-logo").removeClass("white").css("background", "#fbd453");
						$("#" + lowerCaseType + "-card .counselor-img-container .app-type-logo i").attr("class", "mdi mdi-alert-outline white-text");
						$("#" + lowerCaseType + "-card .counselor-img-container .app-type-logo i").css("font-size", "25px");
						$("#" + lowerCaseType + "-card .counselor-img-container .app-type-logo i").css("line-height", "50px");
						$("#" + lowerCaseType + "-card .counselor-img-container .app-type-logo").css("border", "3px solid rgba(255,171,0, 0.6)");						
						$(".disable-actual-card .pay-now").attr("data-desc", "click #PayNow " + bookType + " Show Amt" );

						Utils.trackBalancePayment();

					$.ajax({
						url : Utils.contextPath() + "/v1/counselor/" + counselorID
					}).done(function(response){
						console.log(response);
						self.name = response.name;
						$(".pending-counselor-name").html(response.name);
					}).error(function(error){
						console.log(error);
					});


			}).error(function(error){
				console.log(error);
			});
		}	

		});

			}).error(function(error){
				console.log(error);
			});



		},
		'hideCouponNotificationHeader' : function(e){
			$('#coupon_notification_header').hide();
			localStorage.setItem("hideCouponNotificationHeader",1);
		}
	});

	BookAppointmentView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	BookAppointmentView.prototype.clean = function() {
		this.remove() ;
	};

	return BookAppointmentView;
});
