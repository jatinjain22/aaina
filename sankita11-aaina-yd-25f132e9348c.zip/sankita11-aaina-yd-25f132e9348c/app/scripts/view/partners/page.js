define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function( $, _, Backbone, JST, Utils ) {
	
	var PartnersPage = Backbone.View.extend({
		el: "main",
		initialize: function() {

		
		},
		events: {},
		PartnersLayout : JST['app/templates/partners/layout.hbs'],
		render: function() {	

         	document.title="Partners Page | YourDOST";
            $('meta[name=description]').attr('content', "Know the partners associated with YourDOST. Do you also wish to be one among them? You are welcome!");
            $('meta[name=title]').attr('content',"Partners Page | YourDOST");
            $('meta[property="og:description"]').attr('content', "Know the partners associated with YourDOST. Do you also wish to be one among them? You are welcome!");
            $('meta[property="og:title"]').attr('content',"Partners Page | YourDOST");
            $('link[rel="canonical"]').attr('href', 'https://yourdost.com/partners');
			var self = this ;

			$.ajax({
				url : Utils.scriptPath() + "/partners.json",
			}).done(function(response){
				console.log(response.partners) ;
				self.$el.html(self.PartnersLayout( {partners: response.partners }));	
			}).error(function(error){
				console.log(error) ;
			});


			return this;

		}
	});

	PartnersPage.prototype.remove = function() {};

	PartnersPage.prototype.clean = function() {};

	return PartnersPage;
});
