define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var GuestBlogFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],
      GuestBlogFormPageLayoutTemplate: JST['app/templates/contactUs/forms/guestBlog.hbs'],

      events: {
        "click #submit-share-a-exp": "saveUserInfo"
      },
      checkForName : function(e){
      var name = $("#share-a-experience-name").val();
      if( !Utils.checkForNameField(name) ){
        $("#exp-name-error").html("Please enter valid name");
        $("#exp-name-error").removeClass("hide");
        $("#share-a-experience-name").addClass("invalid").removeClass("valid") ;
        Utils.formDisableSubmit('submit-share-exp');
        return 0 ;
      }else{
        $("#exp-name-error").addClass("hide");
        $("#share-a-experience-name").addClass("valid").removeClass("invalid") ;
        Utils.formEnableSubmit('submit-share-a-exp');
        return 1 ;
      }

    },
    checkForDesc : function(e){

      var desc = $("#share-a-experience-story").val().trim();
      if(desc.length <= 100){
        $("#exp-story-error").html("Please enter text that is longer than 100 characters");
        $("#exp-story-error").removeClass("hide");
        $("#share-a-experience-story").addClass("invalid").removeClass("valid") ;
        Utils.formDisableSubmit('submit-share-a-exp');
        return 0 ;
      }else{
        $("#exp-story-error").addClass("hide");
        $("#share-a-experience-story").addClass("valid").removeClass("invalid") ;
        Utils.formEnableSubmit('submit-share-a-exp');
        return 1 ;
      }

    },
    checkForEmail : function(e){
      var isValidEmail = Utils.formEmailCheck($("#share-a-experience-email").val());
      if(!isValidEmail){
        $("#exp-email-error").html("Please enter valid email id");
        $("#exp-email-error").removeClass("hide");
        $("#share-a-experience-email").addClass("invalid").removeClass("valid") ;
        Utils.formDisableSubmit('submit-share-a-exp');
        return 0 ;
      }else{
        $("#exp-email-error").addClass("hide");
        $("#share-a-experience-email").addClass("valid").removeClass("invalid") ;
        Utils.formEnableSubmit('submit-share-a-exp');
        return 1 ;
      }
    },
    checkForMobile : function(e){
      var isValidMobile = Utils.formMobileCheck($("#share-a-experience-mobile").val());
      if(!isValidMobile && $("#share-a-experience-mobile").val().length > 0){
        $("#exp-mobile-error").html("Please enter valid 10 digit mobile number");
        $("#exp-mobile-error").removeClass("hide");
        $("#share-a-experience-mobile").addClass("invalid").removeClass("valid") ;
        Utils.formDisableSubmit('submit-share-a-exp');
        return 0 ;
      }else{
        $("#exp-mobile-error").addClass("hide");
        $("#share-a-experience-mobile").addClass("valid").removeClass("invalid") ;
        Utils.formEnableSubmit('submit-share-a-exp');
        return 1 ;
      }
    },
    saveUserInfo : function (e) {

      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'Guest Blog' });
      }
      var isValidName = this.checkForName() ;
      var isValidEmail = this.checkForEmail() ;
      var isValidMobile = this.checkForMobile() ;
      var isValidDesc = this.checkForDesc() ;

      if( isValidName == 0  || isValidEmail == 0 || isValidMobile == 0 || isValidDesc == 0 ){
        return false;
      }

      var self = this ;
      var dataToSend = {
        "name"   : $("#share-a-experience-name").val() ,
        "email"  : $("#share-a-experience-email").val() ,
        "mobile" : $("#share-a-experience-mobile").val() ,
        "description" : $("#share-a-experience-story").val()
      }

      $.ajax({
        url : Utils.contextPath() + "/experience",
        method : "POST",
        dataType: "JSON",
              contentType: "application/json; charset=utf-8",
              data : JSON.stringify(dataToSend)
      }).done(function(response){
          var title = "Thank you for sharing your story.";
          var subtitle = "Someone from the team will soon get in touch with you";
          self.$el.find('#guestBlogForm').html( self.ContactUsPageSuccessLayoutTemplate({title:title, subtitle: subtitle}) );
          Utils.scrollTo(".contact-us-layout", 0);

      }).error(function(error){
        console.log(error) ;
      });

    },

    render: function() {

        document.title="Guest Blog | YourDOST";
        $('meta[name=description]').attr('content', "Interested in contributing content to YourDOST blog? You are most welcome for guest posting! Please visit yourdost.com/blog to get a taste of our writing style.");
        $('meta[name=title]').attr('content',"Guest Posting | YourDOST");
        $('meta[property="og:description"]').attr('content', "Interested in contributing content to YourDOST blog? You are most welcome for guest posting! Please visit yourdost.com/blog to get a taste of our writing style.");
        $('meta[property="og:title"]').attr('content',"Guest Posting | YourDOST");

      var self = this;
      var header = "GUEST BLOG";
      self.$el.html( self.ContactUsPageLayoutTemplate({header:header}) );
      self.$el.find('.contact-us-layout-inner').html( self.GuestBlogFormPageLayoutTemplate() );

      $("#share-a-experience-name").keystop( function(event){
        self.checkForName(event) ;
      }, 1000 ) ;

      $("#share-a-experience-story").keystop( function(event){
        self.checkForDesc(event) ;
      }, 1000 ) ;

      $("#share-a-experience-email").keystop( function(event){
        self.checkForEmail(event) ;
      }, 1000 ) ;

      $("#share-a-experience-mobile").keystop( function(event){
        self.checkForMobile(event) ;
      }, 1000 ) ;
    }

    });

  	GuestBlogFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  GuestBlogFormPage.prototype.clean = function() {

      this.remove();
	   };

    return GuestBlogFormPage;
});
