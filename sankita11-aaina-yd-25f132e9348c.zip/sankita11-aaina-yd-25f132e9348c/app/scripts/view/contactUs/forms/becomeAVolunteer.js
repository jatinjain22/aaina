define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var BecomeAVolunteerFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],
      BecomeAVolunteerFormPageLayoutTemplate: JST['app/templates/contactUs/forms/becomeAVolunteer.hbs'],

      events: {
        "click #submit-become-volunteer": "saveVolunteerInfo"
      },

      checkForName : function(e){

        var name = $("#volunteer-name").val();
        if( !Utils.checkForNameField(name) ){
          $("#vol-name-error").html("Please enter valid name");
          $("#vol-name-error").removeClass("hide");
          $("#volunteer-name").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-name').scrollIntoView(true);

          return 0 ;
        }else{
          $("#vol-name-error").addClass("hide");
          Utils.formEnableSubmit('submit-become-volunteer');
          $("#volunteer-name").addClass("valid").removeClass("invalid") ;
          return 1 ;
        }

      },
      checkForCity: function(e) {

        var city = $("#volunteer-city").val();

        if( !Utils.checkForCityField( city ) ){

          $("#vol-city-error").html( "Please enter valid city" );
          $("#vol-city-error").removeClass("hide");
          $("#volunteer-city").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-name').scrollIntoView(true);

          return 0 ;
        }else{

          $("#vol-city-error").addClass("hide");
          Utils.formEnableSubmit('submit-become-volunteer');
          $("#volunteer-city").addClass("valid").removeClass("invalid") ;
          return 1 ;

        }
      },

      checkForEmail : function(e){
        var isValidEmail = Utils.formEmailCheck($("#volunteer-email").val());
        if(!isValidEmail){
          $("#vol-email-error").html("Please enter valid email id");
          $("#vol-email-error").removeClass("hide");
          $("#volunteer-email").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-email').scrollIntoView(true);

          return 0 ;
        }else{
          $("#vol-email-error").addClass("hide");
          $("#volunteer-email").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }
      },
      checkForMobile : function(e){
        var isValidMobile = Utils.formMobileCheck($("#volunteer-phone").val());
        if(!isValidMobile){
          $("#vol-phone-error").html("Please enter valid 10 digit phone number");
          $("#vol-phone-error").removeClass("hide");
          $("#volunteer-phone").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-phone').scrollIntoView(true);

          return 0 ;
        }else{
          $("#vol-phone-error").addClass("hide");
          $("#volunteer-phone").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }
      },
      checkForDesc :  function(e){
        var description = $("#volunteer-desc").val().trim() ;
        if( description.length < 100 ){
          $("#volunteer-desc").addClass("invalid") ;
          $("#form-error-volunteer-desc").removeClass("hide") ;

          return 0;
        }else{
          if($("#volunteer-desc").hasClass("invalid"))
            $("#volunteer-desc").removeClass("invalid");
          if(! $("#form-error-volunteer-desc").hasClass("hide"))
            $("#form-error-volunteer-desc").addClass("hide") ;
          return 1;
        }
      },
      checkForVolunteerSkillSet :  function(e){

        var description = $("#volunteer-skill-set").val().trim() ;
        if( description.length < 100 ){
          $("#volunteer-skill-set").addClass("invalid") ;
          $("#form-error-volunteer-skill-desc").removeClass("hide") ;

          return 0;
        }else{
          if($("#volunteer-skill-set").hasClass("invalid"))
            $("#volunteer-skill-set").removeClass("invalid");
          if(! $("#form-error-volunteer-skill-desc").hasClass("hide"))
            $("#form-error-volunteer-skill-desc").addClass("hide") ;
          return 1;
        }
      },

      checkForFacebookProfileURL: function(e) {

        var isValidFacebookProfileUrl = Utils.formFacebookProfileUrlCheck( $( "#volunteer-fb-link" ).val() );
        console.log( isValidFacebookProfileUrl );
        if( !isValidFacebookProfileUrl ){
          console.log( "hello" );
          $("#volunteer-fb-link-error").html("Please enter valid facebook profile url");
          $("#volunteer-fb-link-error").removeClass("hide");
          $("#volunteer-fb-link").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');

          return 0 ;
        }else{

          $("#volunteer-fb-link-error").addClass("hide");
          $("#volunteer-fb-link").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }

      },

      saveVolunteerInfo : function (e) {

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'Become A Volunteer' });
        }

        var isValidDesc = this.checkForDesc();
        var isValidVolunteerSkillSet = this.checkForVolunteerSkillSet();
        var isValidName = this.checkForName() ;
        var isValidEmail = this.checkForEmail() ;
        var isValidMobile = this.checkForMobile() ;
        var isValidCity = this.checkForCity();
        var isValidFacebookProfileUrl = this.checkForFacebookProfileURL();


        if( isValidDesc == 0 || isValidVolunteerSkillSet == 0 || isValidName == 0  || isValidEmail == 0 || isValidMobile == 0 || isValidCity == 0 || isValidFacebookProfileUrl == 0 ){
          return false;
        }

        var self = this ;
        var dataToSend = {
          "description": $("#volunteer-desc").val() ,
          "skills" : $("#volunteer-skill-set").val(),
          "name" : $("#volunteer-name").val(),
          "city" : $("#volunteer-city").val(),
          "email" : $("#volunteer-email").val(),
          "phone" : $("#volunteer-phone").val(),
          "profileUrlLink": $("#volunteer-fb-link").val()
        };

        $.ajax({
          url : Utils.contextPath() + "/volunteer",
          method : "POST",
          dataType: "JSON",
                contentType: "application/json; charset=utf-8",
                data : JSON.stringify(dataToSend)
        }).done(function(){

          var title = "Thank you for your interest.";
          var subtitle = "We will soon get in touch with you.";

          self.$el.find('#becomeAVolunteerForm').html( self.ContactUsPageSuccessLayoutTemplate({title:title, subtitle: subtitle}) );
          Utils.scrollTo(".contact-us-layout", 0);
        }).error(function(error){
          console.log(error) ;
        });

      },
      render: function() {


          document.title="Become A Volunteer | YourDOST";
          $('meta[name=description]').attr('content', "Want to utilise your skills and join hands with YourDOST in helping people. Fill this simple form, we shall get in touch with you.");
          $('meta[name=title]').attr('content',"Become A Volunteer | YourDOST");



        var self = this;
        var header="BECOME AN EXPERT";
        self.$el.html( self.ContactUsPageLayoutTemplate({header: header}) );
        self.$el.find('.contact-us-layout-inner').html( self.BecomeAVolunteerFormPageLayoutTemplate() );
         $('select').material_select();

        $("#volunteer-desc").keystop( function(event){
          self.checkForDesc(event) ;
        }, 1000 ) ;

        $("#volunteer-skill-set").keystop( function(event){
          self.checkForVolunteerSkillSet(event) ;
        }, 1000 ) ;


        $("#volunteer-name").keystop( function(event){
          self.checkForName(event) ;
        }, 1000 ) ;

        $("#volunteer-email").keystop( function(event){
         self.checkForEmail(event) ;
        }, 1000 ) ;

        $("#volunteer-phone").keystop( function(event){
          self.checkForMobile(event) ;
        }, 1000 ) ;

        $( "#volunteer-city" ).keystop( function(event){
          self.checkForCity(event);
        });

        $( "#volunteer-fb-link" ).keystop( function(event) {
            self.checkForFacebookProfileURL( event );
        });

      }

    });

  	BecomeAVolunteerFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  BecomeAVolunteerFormPage.prototype.clean = function() {

      this.remove();
	   };

    return BecomeAVolunteerFormPage;
});
