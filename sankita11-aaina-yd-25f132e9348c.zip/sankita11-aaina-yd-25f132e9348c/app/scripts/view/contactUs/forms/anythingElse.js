define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var AnythingElseFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],
      AnytingElseFormPageLayoutTemplate: JST['app/templates/contactUs/forms/anythingElse.hbs'],

      events: {

      },

      render: function() {

        var self = this;

        self.$el.html( self.ContactUsPageLayoutTemplate() );
        self.$el.find('.contact-us-layout-inner').html( self.AnytingElseFormPageLayoutTemplate() );


      }

    });

  	AnythingElseFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  AnythingElseFormPage.prototype.clean = function() {

      this.remove();
	   };

    return AnythingElseFormPage;
});
