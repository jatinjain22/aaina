define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var IssuesInOurServiceFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      IssuesInOurServiceFormPageLayoutTemplate: JST['app/templates/contactUs/forms/issuesInOurService.hbs'],

      events: {

      },

      render: function() {

        var self = this;

        self.$el.html( self.ContactUsPageLayoutTemplate() );
        self.$el.find('.contact-us-layout-inner').html( self.IssuesInOurServiceFormPageLayoutTemplate() );


      }

    });

  	IssuesInOurServiceFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  IssuesInOurServiceFormPage.prototype.clean = function() {

      this.remove();
	   };

    return IssuesInOurServiceFormPage;
});
