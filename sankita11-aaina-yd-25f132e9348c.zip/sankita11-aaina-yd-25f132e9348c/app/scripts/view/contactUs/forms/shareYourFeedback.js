define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var ShareYourFeedbackFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        innerSelf = '';


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],
      ShareYourFeedbackFormPageLayoutTemplate: JST['app/templates/contactUs/forms/shareYourFeedback.hbs'],

      events: {
        "click #submit-share-feedback" : "saveUserInfo"
      },
      checkForName : function(e){

        var name = $("#share-a-feedback-name").val();
        if( !Utils.checkForNameField( name ) ){
          $("#feedback-name-error").html("Please enter valid name");
          $("#feedback-name-error").removeClass("hide");
          $("#share-a-feedback-name").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-share-a-feedback');
          return 0 ;
        }else{
          $("#feedback-name-error").addClass("hide");
          $("#share-a-feedback-name").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-share-a-feedback');
          return 1 ;
        }

      },
      checkForEmail : function(e){

        var isValidEmail = Utils.formEmailCheck($("#share-a-feedback-email").val());
        if(!isValidEmail){
          $("#feedback-email-error").html("Please enter valid email id");
          $("#feedback-email-error").removeClass("hide");
          $("#share-a-feedback-email").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-share-a-feedback');
          return 0 ;
        }else{
          $("#feedback-email-error").addClass("hide");
          $("#share-a-feedback-email").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-share-a-feedback');
          return 1 ;
        }
      },
      checkForDesc : function(e){
        var desc = $("#share-a-feedback-desc").val().trim();
        if(desc.length <= 100){
          $("#feedback-desc-error").html("Please enter text that is longer than 100 characters");
          $("#feedback-desc-error").removeClass("hide");
          $("#share-a-feedback-desc").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-share-a-feedback');
          return 0 ;
        }else{
          $("#feedback-desc-error").addClass("hide");
          $("#share-a-feedback-desc").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-share-a-feedback');
          return 1 ;
        }

      },
      trackMixPanelEvent: function() {

        var url = window.location.href ;
        url = url.replace("/feedback", "" );

        var id    = $.url( url ).param('id');
        var intId = parseInt(id);

        if( intId == 4) {
          if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
            mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'SHARE YOUR FEEDBACK' });
          }
        }
        else if( intId == 5 ) {
          if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
            mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'ISSUES IN OUR SERVICES' });
          }
        }
        else if( intId == 6 ) {
          if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
            mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'ANYTHING ELSE' });
          }
        }

      },
      giveFormSuccessfullMessage: function( response ){

        var url = window.location.href ;
        url = url.replace("/feedback", "" );

        var id    = $.url( url ).param('id');
        var intId = parseInt(id);

        var self = innerSelf;
        console.log( this );
        console.log( response );

        if ( response == true ) {

          $.ajax({
            url: Utils.scriptPath() + "/contactUs.json",
          }).done(function( data ){
            var feedbackTitle = data[intId - 1].feedbackTitle;
            var feedbackSubtitle = data[intId -1 ].feedbackSubtitle;


            self.$el.find('#share-your-feedback-form').html( self.ContactUsPageSuccessLayoutTemplate({title:feedbackTitle, subtitle: feedbackSubtitle}) );
            Utils.scrollTo(".contact-us-layout", 0);

          }).error(function(error){

            console.log(error)

          });

        }

      },
      getDataToSend: function() {

        var self = this;
        var url = window.location.href ;
        url = url.replace("/feedback", "" );

        var id    = $.url( url ).param('id');
        var intId = parseInt(id);

          $.ajax({
            url: Utils.scriptPath() + "/contactUs.json",
          }).done(function( data ){
            var title = data[intId - 1].title;

            var name = "( " + title + " ) " + $("#share-a-feedback-name").val();
            var email =  $("#share-a-feedback-email").val();
            var description =  $("#share-a-feedback-desc").val();

            var dataToSend = {
              "name"   :  name,
              "email"  :  email,
              "description" : description
            }

            $.ajax({
              url : Utils.contextPath() + "/experience",
              method : "POST",
              dataType: "JSON",
              contentType: "application/json; charset=utf-8",
              data : JSON.stringify(dataToSend)
            }).done(
              self.giveFormSuccessfullMessage
            ).error(function(error){
              console.log(error) ;
            });


          }).error(function(error){

            console.log(error)

          });

      },
      saveUserInfo : function (e) {


        var isValidName = this.checkForName() ;
        var isValidEmail = this.checkForEmail() ;
        var isValidDesc = this.checkForDesc() ;

        if( isValidName == 0  || isValidEmail == 0 || isValidDesc == 0  ){
          return false;
        }

        var self = this ;
        innerSelf = self;
        self.trackMixPanelEvent();
        self.getDataToSend();



    },
      render: function() {


        if( Backbone.history.getFragment().match(/feedback\?id=[0-9]/) ){
          console.log("hello");
          document.title="Share Your Feedback |YourDOST";
          $('meta[name=description]').attr('content', "Have something to share with us? Kindly use the feedback form");
          $('meta[name=title]').attr('content',"Share Your Feedback | YourDOST");
          $('meta[property="og:description"]').attr('content', "Have something to share with us? Kindly use the feedback form");
          $('meta[property="og:title"]').attr('content',"Share Your Feedback | YourDOST");
        }
        else{
          document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
          $('meta[name=description]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
          $('meta[name=title]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
          $('meta[property="og:description"]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
          $('meta[property="og:title"]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
        }

        var self = this;

        var url = window.location.href ;
        url = url.replace("/feedback", "" );

        var id    = $.url( url ).param('id');
        var intId = parseInt(id);

        $.ajax({
          url: Utils.scriptPath() + "/contactUs.json",
        }).done(function( data ){
          console.log( "data" );
          console.log( data );
          var title = data[intId - 1].title;
          var subtitle = data[intId -1 ].subtitle;

          self.$el.html( self.ContactUsPageLayoutTemplate({header: title}) );
          self.$el.find('.contact-us-layout-inner').html( self.ShareYourFeedbackFormPageLayoutTemplate({title: title, subtitle: subtitle}) );

          $("#share-a-feedback-name").keystop( function(event){
            self.checkForName(event) ;
          }, 1000 ) ;

          $("#share-a-feedback-desc").keystop( function(event){
            self.checkForDesc(event) ;
          }, 1000 ) ;

          $("#share-a-feedback-email").keystop( function(event){
            self.checkForEmail(event) ;
          }, 1000 ) ;

        }).error(function(error){

          console.log(error)

        });



      }

    });

  	ShareYourFeedbackFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  ShareYourFeedbackFormPage.prototype.clean = function() {

      this.remove();
	   };

    return ShareYourFeedbackFormPage;
});
