define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher ) {

	var BeASaviourFormPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],
      BeASaviourFormPageLayoutTemplate: JST['app/templates/contactUs/forms/beASaviour.hbs'],

      events: {
        'click #submit-be-a-savior' : 'saveInfo'
      },
      checkForEmail : function(e){
        var isValidEmail = Utils.formEmailCheck($("#be-a-savior-email").val());
        if(!isValidEmail){
          $("#sav-email-error").html("Please enter valid email id");
          $("#sav-email-error").removeClass("hide");
          $("#be-a-savior-email").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-be-a-savior');
          return 0 ;
        }else{
          $("#sav-email-error").addClass("hide");
          $("#be-a-savior-email").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-be-a-savior');
          return 1 ;
        }
      },
      saveInfo : function(e){

        var self = this ;

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'Become A Saviour' });
        }

        var isValidEmail = this.checkForEmail() ;
        if( isValidEmail == 0 ){
          return false;
        }

        var email = $("#be-a-savior-email").val() ;

        var emailRegex = new RegExp("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$") ;

        if($("#form-error-be-savior-email"  ).length == 0){
          $("#be-a-savior-email").after("<span id='form-error-be-savior-email'  class='margin0 form-error red-text'></span>");
        }

        if(email.length == 0 || !email.match(emailRegex)){
          $("#form-error-be-savior-email" ).html("Please give a valid email id") ;
          return 0 ;
        }


        var dataToSend = { "email" : email } ;

        $.ajax({
          url : Utils.contextPath() + "/saviour",
          method : "POST",
          dataType: "JSON",
                contentType: "application/json; charset=utf-8",
                data : JSON.stringify(dataToSend)
        }).done(function(){
          var title = 'Thank you for sharing';
          var subtitle = 'I am sure together we will be able to help our friend.';
          self.$el.find('#be-a-savior-form').html( self.ContactUsPageSuccessLayoutTemplate({title:title, subtitle: subtitle}) );

        });
      },
      render: function() {

          document.title="Become A Volunteer";
          $('meta[name=description]').attr('content', "Know any friend who is going through tough time and would like to help him? Drop in his mail id here, we will contact him.");
          $('meta[name=title]').attr('content',"Be a Saviour | YourDOST");
          $('meta[property="og:description"]').attr('content', "Know any friend who is going through tough time and would like to help him? Drop in his mail id here, we will contact him.");
          $('meta[property="og:title"]').attr('content',"Be a Saviour | YourDOST");

        var self = this;
        var header = "BE A SAVIOUR";
        self.$el.html( self.ContactUsPageLayoutTemplate({header:header}) );
        self.$el.find('.contact-us-layout-inner').html( self.BeASaviourFormPageLayoutTemplate() );

        $("#be-a-savior-email").keystop( function(event){
          self.checkForEmail(event) ;
        }, 1000 ) ;

      }

    });

  	BeASaviourFormPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	  };

	  BeASaviourFormPage.prototype.clean = function() {

      this.remove();
	   };

    return BeASaviourFormPage;
});
