define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'purl',
  'masonry',
  'imagesloaded',
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher, Masonry, imagesLoaded ) {

	var ContactUsPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },

      ContactUsPageLayoutTemplate : JST['app/templates/contactUs/layout.hbs'],
      ContactUsCardPageLayoutTemplate: JST['app/templates/contactUs/contactUsCards.hbs'],


      events: {
        "click .contact-us-column": "trackMixpanel"
      },
      trackMixpanel : function(e){

        var url = $(e.currentTarget).find(".contact-us-card").attr("href");
        console.log("in track");
        console.log(url);
        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Contact Us Card Click", { "mediumSource" : "website", "itemName" : url });
        }
      },
      render: function() {

        var self = this;

        setTimeout(function(){
          if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

            console.log( 'inside mixpanel' );
            mixpanel.track('Contact Us Page', {'mediumSource' : 'website', 'itemtype': 'Contact Us Page', 'itemName': 'Contact Us Page'});

          }
        }, 2000);

        $.ajax({

          url: Utils.scriptPath() + "/contactUs.json",

        }).done( function( data ) {
            var header = "CONTACT US";
            var headerSentence = "What do you want to talk about?";
            var className = 'contact-us-home-page-header';
            self.$el.html( self.ContactUsPageLayoutTemplate({header:header, header_sentence: headerSentence, className: className}) );
            self.$el.find('.contact-us-layout-inner').html( self.ContactUsCardPageLayoutTemplate( {contact: data} ));

        }).error(function(error){

          console.log(error)

        });



      }

    });

  	ContactUsPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind();
	};

	ContactUsPage.prototype.clean = function() {

      this.remove();

	};

    return ContactUsPage;
});
