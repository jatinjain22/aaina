define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var StatsView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {},
		events: {},
		StatsViewLayout: JST['app/templates/home2/stats.hbs'],
		render: function() {
			$(".stats-block").html(this.StatsViewLayout());
		}
	});

	StatsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	StatsView.prototype.clean = function() {
		this.remove() ;
	};

	return StatsView;
});
