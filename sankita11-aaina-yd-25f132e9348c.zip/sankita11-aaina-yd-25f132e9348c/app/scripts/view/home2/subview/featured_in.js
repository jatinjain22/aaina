define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var FeaturedInView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {},
		events: {},
		FeaturedInViewLayout: JST['app/templates/home2/featured_in.hbs'],
		render: function() {
			var self = this ;
			$.ajax({
				url : "https://d3dlm19tttbkds.cloudfront.net/featured_in.json",
			}).done(function(response){
				$(".featured-in-block").html(self.FeaturedInViewLayout( {featuredIn : response.featuredIn}));
			}).error(function(error){
				console.log(error) ;
			});

		}
	});

	FeaturedInView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	FeaturedInView.prototype.clean = function() {
		this.remove() ;
	};

	return FeaturedInView;
});
