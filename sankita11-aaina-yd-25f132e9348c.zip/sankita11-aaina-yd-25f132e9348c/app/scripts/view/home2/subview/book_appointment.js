define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/users',
	'keystop',
	'datetimepicker',
	'jcarousellite'
], function($,_, Backbone, JST, Utils, UserModel) {

	var BookAppointmentView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		BlogThumbnailLayout: JST["app/templates/home2/blog_thumbnails.hbs"],
		events: {
			'submit #book-app-form' : 'saveUserInfo' ,
			'click #book-appointment-modal .popup-close'  : 'hideContainer' ,
			"click #book-appointment-modal .mclose"  : "hideContainer", 
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "book-appointment-modal"  );
		},
		saveUserInfo : function (e) {

			var self = this ;

			var userID = this.userModel.getUserID();

			var slotStart      = $("#start-slot").val() ;
			var slotStartEpoch = new Date(slotStart ).getTime();

			$("#app-time-error").addClass("hide") ;
			if(!slotStart){
				$("#app-time-error").html("Please enter valid preferred time slot") ;
				$("#app-time-error").removeClass("hide") ;
				return false ;
			}

			var endDefaultTime = slotStartEpoch + ( 1000 * 60 * 60 ) ;

			//var slotEnd      = $("#end-slot").val() ;
			var slotEndEpoch = endDefaultTime;

			if( ( slotEndEpoch - slotStartEpoch ) <= 0 ){
				$("#app-time-error").html("Start time cannot be less than or equal to end time") ;
				$("#app-time-error").removeClass("hide") ;
				return false ;
			}



			var message = $("#book-app-msg").val();

			if(message.length == 0){
				message = "N/A" ;
			}

			var category = $("#book-app-area").val() ;
			if( $("#book-app-area").val() == null){
				category = 5 ;
			}

			var dataToSend = {
				"area"         :  category,
				"slotStartTime":  slotStartEpoch,
				"slotEndTime"  :  slotEndEpoch,
				"message"      :  message,
			};

			$("#appointment-progress").removeClass("hide");
			$("#submit-appointment").addClass("hide");
			$.ajax({
				url : Utils.contextPath() + "/v2/users/" + userID + "/bookappointment",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend)
			}).done(function(response){
				self.$el.find('#book-appointment-modal .header').addClass('hide');
				self.$el.find("#book-appointment-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><div class="modal-thank-msg" style="padding:5%"><div class="icon-done"><i class="mdi mdi-check"></i></div><div style="margin-left: 60px;">We have received your appointment request. <br/>We shall confirm the status of the request in a while - look out for an email from us! </div></div><p style="padding:0% 5%">In the meanwhile, take a look at some of our trending content:</p><div class="trending_articals"><div class="row"><div class="col article-scroll-left"><i class="mdi-hardware-keyboard-arrow-left"></i></div><div class="col article-jcarousel"> <img class="popup-loader hide" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50"><ul class="articals_div"></ul></div><div class="col article-scroll-right"><i class="mdi-hardware-keyboard-arrow-right"></i></div></div>') ;
				var ArtcalsHtml = '';
				//self.$el.find('.articals_div').html('<img class="popup-loader" src="http://res.cloudinary.com/http-yourdost-com/image/upload/v1449585815/icons/loader.gif" width="50" height="50">');
				$('.article-jcarousel .popup-loader').removeClass('hide');
				$.ajax({
					method : "GET",
					url : Utils.blogJson() //"http://local.yourdost.com:9001/scripts/json/sample_blog.json" //
				}).done(function(response){
					$('.article-jcarousel .popup-loader').addClass('hide');
					console.log(response.posts);
					//var template = '<li class="col article-link" data-href={post_url}?utm_source=YD&amp;utm_medium=web&amp;utm_campaign=appointment-slider><div class="cpointer hoverable z-depth-1 article-img-container"><img src="{thumbnail_url}" /><div class="white-text articles-info"><div><div class="article-title">{post_title}</div><div class="article-author"><a class="white-text" href="https://yourdost.com/blog/author/{author_slug}?utm_source=YD&amp;utm_medium=web&amp;utm_campaign=appointment-slider" target="_blank"><i class="teal-text font-20 mdi-social-person"></i><span>{author_name}</span></a></div></div></div></div></li>';

					// $.each(response.posts, function(index){
					// 	var post = response.posts[index]
					// 	var author = post.author;
					// 	if(post.attachments.length < 1){
					// 		return;
					// 	}else{
					// 		if(post.thumbnail_images == undefined){
					// 			return false ;
					// 		}
					// 		var imgUrl = post.thumbnail_images.full.url ; //post.attachments[0].images["full"].url;
					// 	}
					// 	ArtcalsHtml += template.replace(/{post_url}/g, post.url).replace(/{post_title}/g, post.title).replace(/{author_slug}/g, author["slug"]).replace(/{author_name}/g, author["name"]).replace(/{thumbnail_url}/g, imgUrl);
					// });
					self.$el.find(".articals_div").html(self.BlogThumbnailLayout({ post : response.posts }));
					$('.trending_articals .article-jcarousel').jCarouselLite({
					  btnNext: '.article-scroll-right',
					  btnPrev: '.article-scroll-left',
					});
				}).error(function(error){
					console.log(error);
				});

				self.$el.find("#book-appointment-modal .fixed-position-container").html( '<p class="modal-thank-msg" style="padding:55% 12%">We have received your appointment request. We shall confirm you in a while</p>') ;
				Utils.openPopup( "book-appointment-modal" ) ;
				$("#book-appointment-modal.modal").css("max-height", "600px");

			}).error(function(error){
				console.log(error) ;
			});

		},
		BookAppointmentViewLayout: JST["app/templates/home2/book_appointment.hbs"],
		render: function() {
			var self = this ;

			localStorage.setItem("fromAppointment", 0) ;
			self.$el.find("#popup-block").html( self.BookAppointmentViewLayout() );
			Utils.openPopup( "book-appointment-modal" ) ;

			var category = {};
        	$.ajax({
            	method: "GET",
            	url: Utils.contextPath()+'/category?include_faq=false'
        	}).done(function(response){

        		_.each(response, function(elem){
        			$("#book-app-area").append('<option value="'+elem.id+'">'+elem.name+'</option>');
        		})

				$('select').material_select();

        	}).fail(function(error){});

			/*if( !Utils.isMobileDevice() )
					CKEDITOR.replace( 'book-app-msg' );*/

			var currentDate = new Date() ;
			$("#start-slot").datetimepicker({
				minDate :  new Date(currentDate.setDate(currentDate.getDate() +1)),
				step : 30 ,
				format : "d M Y H:i",
				defaultDate : new Date(currentDate.setDate(currentDate.getDate() )) ,
				todayButton : false,
				//value : defaultTime,
			    //startDate : defaultTime,
				
				//closeOnDateSelect : true,
				/*onSelectDate : function(ct){
					$("#end-slot").datetimepicker("show");
				},*/
				onSelectTime : function(ct){
					var currentDate = new Date();
					var selectedDate = new Date(ct.setHours(ct.getHours()) );
					var ritDate = new Date();
					var currentDate = new Date(ritDate.setHours( ritDate.getHours() + 24 ));
					if(selectedDate < currentDate){
						$("#app-time-error").html("Please book your appointment atleast 24 hrs in advance.");
						$("#app-time-error").removeClass("hide");
						return false;
					}else{
						$("#app-time-error").html("");
						$("#app-time-error").addClass("hide");
					}
					//$("#end-slot").datetimepicker("show");
				},
				/*onShow:function( ct ){
				   var endSlot = $('#end-slot').val() || currentDate ;
				   endSlot = new Date(endSlot);
				   var endDefaultTime = new Date(endSlot.setHours( endSlot.getHours() + 1 )) ;
				   this.setOptions({
				    minDate     : endDefaultTime ,
				    startDate : endDefaultTime
				   });
				   }		*/
			});


			/*$("#end-slot").datetimepicker({
				minDate : defaultEndTime ,
				//minTime : defaultEndTime,
				step : 30 ,
				format : "d M Y H:i",
				todayButton : false ,
				//closeOnDateSelect : true ,
				onShow:function( ct ){
				   var startSlot = $('#start-slot').val() || currentDate ;
				   startSlot = new Date(startSlot);
				   var endDefaultTime = new Date(startSlot.setHours( startSlot.getHours() + 1 )) ;
				   this.setOptions({
				    minDate     : endDefaultTime ,
				    defaultTime : endDefaultTime
				   });
				   }
				});

			setTimeout( function(){
				$("#book-appointment-modal.modal").animate({scrollTop:0},0);
			},1000);*/

		}

	});

	BookAppointmentView.prototype.remove = function() {

	};

	BookAppointmentView.prototype.clean = function() {

	};

	return BookAppointmentView;
});
