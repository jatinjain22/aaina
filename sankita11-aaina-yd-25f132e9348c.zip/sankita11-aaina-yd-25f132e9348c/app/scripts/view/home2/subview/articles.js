define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'jcarousellite',
	'config'
	//'jquery-swipe'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var ArticlesView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {},
		events: {
			'click .home-articles' : 'redirectToBlog' ,
			'click .article-cat-title a' : 'stopParentClick',
			'click .article-author a' : 'stopParentClick',
		},
		stopParentClick : function(e){
			e.stopPropagation();
		},
		redirectToBlog : function(e){
			e.preventDefault();
			e.stopPropagation();
			var url = $(e.currentTarget).attr("data-href");
			window.open(url, "_self");
		},	
		ArticlesViewLayout: JST['app/templates/home2/articles.hbs'],
		render: function() {

			var self = this ;
			$.ajax({
				method : "GET",
				dataType: 'jsonp',
				url : Utils.blogJson()//'/scripts/json/blog.json'//Utils.blogJson()//'/scripts/json/blog.json'// 
			}).done(function(response){
				console.log(response.posts);
				$(".articles-block").html(self.ArticlesViewLayout({ post : response.posts }));

				$('.article-jcarousel').jCarouselLite({
				  btnNext: '.article-scroll-right',
				  btnPrev: '.article-scroll-left',
				  autoCSS: false,
				});
			}).error(function(error){
					console.log(error);
			});

		}
	});

	ArticlesView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	ArticlesView.prototype.clean = function() {
		this.remove() ;
	};

	return ArticlesView;
});
