define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousellite'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) { 

	var FeaturedExpertsView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		events: {},
		FeaturedExpertsViewLayout: JST['app/templates/home2/featured_experts.hbs'],
		render: function() {

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			var self = this ;
			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/"
			}).done(function(response){
				var counselorToPrint =  response.slice(0,20) ;
				var header = "Featured Experts";
				$(".featured-experts-block").html(self.FeaturedExpertsViewLayout({ counselor : counselorToPrint , header : header}));

				$('.experts-jcarousel').jCarouselLite({
				  btnNext: '.experts-scroll-right',
				  btnPrev: '.experts-scroll-left',
				  autoCSS: false,
				});

 				$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){
						
					_.each(response, function(value, key){
						
						if( value.status == "true" && $("#chat-home2-" + key).length ){
							$("#chat-home2-" + key).removeClass("hide");
							$("#chat-home2-" + key).attr("data-href", value.url);

						}
					});
				}).error(function(error){

				});
				}).error(function(error){
				console.log(error);
			});

		}
	});

	FeaturedExpertsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.stopListening();

	};

	FeaturedExpertsView.prototype.clean = function() {
		this.remove() ;
	};

	return FeaturedExpertsView;
});
