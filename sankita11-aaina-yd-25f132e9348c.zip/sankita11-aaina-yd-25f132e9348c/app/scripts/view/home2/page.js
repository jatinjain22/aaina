define([
	'jquery',
	'underscore',
	'backbone',
	'event/dispatcher',
	'view/home2/subview/articles',
  	'view/home/subview/outside_form_links',
  	'view/home2/subview/start_chat',
  	'view/home2/subview/featured_experts',
  	'view/home/subview/user_review',
	'view/home/subview/be_savior',
	'view/home/subview/share_experience',
	'view/home/subview/become_volunteer',
	'view/home2/subview/featured_in',
	'view/home2/subview/stats',
	'view/home2/subview/book_appointment',
	'view/leaveMessage/page' ,
	'model/users',
	'../../precompiled-templates',
	'smooth-scroll',
	'utils',
], function($,_, Backbone, EventBus, ArticlesView, OutsideFormLinksView, StartChatView, FeaturedExpertsView,
	UserReviewView, BeSaviorView, ShareExperienceView, BecomeVolunteerView, FeaturedInView, StatsView, BookAppointmentView, LeaveMessageView, UserModel, JST, SmoothScroll, Utils) {

	var HomePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.startChatView = new StartChatView();
			this.featuredExpertsView = new FeaturedExpertsView();
			this.articlesView = new ArticlesView();
	      	this.outsideFormLinksView = new OutsideFormLinksView();
	      	this.beSaviorView = new BeSaviorView();
	      	this.userReviewView = new UserReviewView();
	      	this.shareExperienceView = new ShareExperienceView();
	      	this.becomeVolunteer = new BecomeVolunteerView() ;
	      	this.featuredInView  = new FeaturedInView() ;
	      	this.statsView       = new StatsView();
	      	this.userModel       = new UserModel();
	      	this.iInterval = null;
	      	this.iStart = 0;
			this.bookAppointmentView = new BookAppointmentView();
			this.leaveMessage = new LeaveMessageView();
	      	window.clearInterval(this.iInterval);
		},
		events: {
      		'click .smoothscroll': 'smoothScroll',
      		'click #be-savior' : 'showBeSaviorForm' ,
      		'click #share-experience' : 'showShareExperienceForm' ,
      		'click #become-volunteer' : 'showBecomeVolunteerForm',
      		'click .go-down': 'goDown',
      		"click .go-to-testimonials": "goToTestimonials",
      		'click #chat-online-home2' : 'openSignUpNowModal' ,
			'click #book-appointment-home2' : 'openBookAppModal',
			'click .fexp-chat' : "chatCounselor",
			'click .fexp-msg'  : "msgCounselor",
			'click #home-start-chat-btn-header' : 'openSignUpNowModal' ,
    	},
		openBookAppModal : function (e) {
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home","book_appointment") ;
			}else{
				//this.bookAppointmentView.render();
				//location.href = "/bookAppointment" ;
				Backbone.history.navigate("/bookAppointment", {trigger: true});
			}
		},
		openSignUpNowModal : function (e) {
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "home_chat") ;
			}else{
				var username = this.userModel.getUserName() ;
				location.href = Utils.chatUrl() + username;
			}
		},
		msgCounselor : function(e){

			var counselorIdName = $(e.currentTarget).attr("data-attr");

			var counselorInfo = {
				id : counselorIdName.split("_")[0] ,
				name : counselorIdName.split("_")[1] ,
			};

			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "message", JSON.stringify(counselorInfo)) ;
			}else{

				if(!counselorIdName || counselorIdName == undefined || counselorIdName == null ){
					this.leaveMessage.render() ;
				}else{
					this.leaveMessage.render( counselorInfo ) ;
				}
				
			}

		},
		chatCounselor : function(e){
			
			var chatURL = $(e.currentTarget).attr("data-href") ;
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL ) ;
			}else{
				var username =  this.userModel.getUserName() ;
			location.href = chatURL + "&username=" + username;
			}
		},

    	goToTestimonials: function(e){
			//location.href = "/testimonials";
			Backbone.history.navigate("/testimonials", {trigger: true});
			return true;
		},
    	showBecomeVolunteerForm : function(e){
    		this.becomeVolunteer.render() ;
    		$('select').not('.disabled').material_select();
    	},
    	showShareExperienceForm : function (e) {
    		this.shareExperienceView.render();
    	},
    	showBeSaviorForm : function (e) {
    		this.beSaviorView.render() ;
    	},
		template: JST['app/templates/home2/layout.hbs'],
		render: function() {


			this.$el.html(this.template());

			//anonymous user view rendering
			this.startChatView.render();

			this.featuredExpertsView.render();

			this.articlesView.render();

			//user review slider rendering
	      	this.userReviewView.render();

	      	this.featuredInView.render();

	      	//survey monkey form links
	      	this.outsideFormLinksView.render();

	      	this.statsView.render();

	      	var self = this;

	      	if( self.iInterval ){
	      		self.iInterval = null;
	      		self.iStart = 0;
	      		window.clearInterval(self.iInterval);
	      	}

	      	var tickerArr = ["build healthy personal relationships?", "have a more productive work-life?", "work towards your goal with enthusiasm?", "build a more confident self?", "fight societal pressure?", "improve your inner self?", "lead from within?", "share your grief?"];

	      	self.iInterval = window.setInterval(function(){

	      		self.iStart++;

				$('.text-carousel div p').animate({top:"-13px", opacity:0}, 1000, function(){
					$('.text-carousel div p').css("top", "13px");

	 				$('.text-carousel div p').html(tickerArr[self.iStart]);
	 				$('.text-carousel div p').animate({top:0,opacity:1},'slow');						
				});	      		
	 		

	      		if( self.iStart >= tickerArr.length ){
	      			self.iStart = 0;
	      		}
	      	},3000);


			return this;
		},
    	smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
	    goDown: function(e){
	      $('html, body').stop().animate({
	      scrollTop: $("#home2-featured-block").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    }
	});

	HomePage.prototype.remove = function() {
		window.clearInterval(this.iInterval);
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.undelegateEvents();
    	//this.stopListening();
	};

	HomePage.prototype.clean = function() {
		window.clearInterval(this.iInterval);
		this.remove() ;
	};

	return HomePage;
});
