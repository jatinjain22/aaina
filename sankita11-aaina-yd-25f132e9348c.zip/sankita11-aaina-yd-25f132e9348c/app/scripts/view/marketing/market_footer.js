define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function($,_, Backbone, JST, Dispatcher, Utils) {

	var MarketFooterView = Backbone.View.extend({

		el : 'footer' ,
		initialize: function() {},
		events: {},
		MarketFooterLayout: JST['app/templates/footer/market_footer.hbs'],
		render: function() {

			this.$el.html(this.MarketFooterLayout());

			return this;
		}
	});

	MarketFooterView.prototype.clean = function() {
		
	};

	return MarketFooterView;
});
