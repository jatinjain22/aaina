define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function( $, _, Backbone, JST, Utils ) {

	var TeamsPage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {},
		TeamsLayout : JST['app/templates/teams/layout.hbs'],
		render: function() {

			document.title="YourDOST Team";
			$('meta[name=description]').attr('content', "Get to know the dynamic team members of YourDOST");
			$('meta[name=title]').attr('content',"YourDOST Team");
			$('meta[property="og:description"]').attr('content', "Get to know the dynamic team members of YourDOST");
			$('meta[property="og:title"]').attr('content',"YourDOST Team");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/team');

			var self = this ;

			$.ajax({
				url : Utils.scriptPath() + "/teams.json" ,
			}).done(function(response){
				console.log("teams", response);
			//	response = JSON.parse(response);
				self.$el.html(self.TeamsLayout( {advisorInfo: response.advisors, teamInfo : response.team, camAmbassadors : response.campusAmbassadors, teams : response.teams }));
				var mySwiper = new Swiper ('.team-swiper', {
				    
	        		pagination: '.team-swiper-pagination',
	        		paginationClickable: true,
	        		autoplay: 15000,
	        		keyboardControl: true,
	        		slidesPerView: '1',
	        		loop : true,
			        nextButton: '.swiper-button-next',
			        prevButton: '.swiper-button-prev',
				});
			}).error(function(error){
				console.log(error) ;
			});

			return this;

		}
	});

	TeamsPage.prototype.remove = function() {};

	TeamsPage.prototype.clean = function() {};

	return TeamsPage;
});
