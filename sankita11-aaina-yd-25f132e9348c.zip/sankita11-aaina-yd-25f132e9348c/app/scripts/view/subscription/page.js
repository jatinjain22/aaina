define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'backbone',
    'utils',
	'../../precompiled-templates',
    'model/users',
], function($, _, EventBus, Backbone, Utils, JST, userModel) {
	var subscriptionPage = Backbone.View.extend({
		el: "main",
		initialize: function() { this.userModel = new userModel()},
		events: {
            "click .renew-btn" : "renewSubscription",
            "click .buy"       : "renewSubscription",
            "click .cp-c-txt"  : "directToDashboard",
            "click .cp-c-btn"  : "directToChat",
			"click .plan-box"  : "selectPlan"
        },
		selectPlan : function(e){
			var trgt = $(e.currentTarget)
			if(trgt.hasClass("selected")){
				return;
			}
			$(".plan-box").removeClass("selected")
			trgt.addClass("selected")
			this.amount = trgt.attr("data-price")
			this.planId = trgt.attr("data-plan-id")
			this.registerMixpanel({"action_type": "Selceted a plan", "planId" : this.planId});
			$(".renew-btn").removeClass("disable").addClass("enable")
		},
        directToDashboard : function(e){
			this.registerMixpanel({"action_type" : "Clicked on Dashboard"})
            location.href = "/dashboard"
        },
        directToChat : function(e){
            if($(e.currentTarget).hasClass("demo")){
				this.registerMixpanel({"action_type" : "Clicked Chat Redirect", "action_data" : "demo_chat"})
                location.href = Utils.chatUrl() +this.userModel.getUserName()
                return;
            }
			this.registerMixpanel({"action_type" : "Clicked Chat Redirect", "action_data" : "one_on_one_chat"})
            location.href = $(e.currentTarget).attr("data-href")
        },
        getContent : function(options){
			var defer = $.Deferred();
			$.ajax(options).done(function(response){
				defer.resolve(response)
			}).fail(function(error){
				defer.reject(error)
			})
			return defer.promise();
		},
        updateCount: function (url) {
            var options = {}
            var self = this;
            options["url"] = Utils.contextPath()+'/v2/user/account';
            options["method"] = "GET"
            this.getContent(options)
            .then(function (res) {
               self.counterRef.push({
                'user'          : self.userModel.getUserName(),
                'price'         : res.plan.price,
                'purchasedOn'   : res.plan.purchased_on,
                'renewCount'    : res.count || 0
               }).then(function (res) {
                   // body...
               }, function (err) {
                   // body...
               });
               window.open(url, "_self");
            });
        },
        buySubscription : function(e) {
    		var options = {};
			var self = this;
            options["url"] = Utils.contextPath() + '/v1/user/transaction/initiatePayment';
            options["method"] = "POST"
			options["contentType"] = "application/json"
			options["data"] = JSON.stringify({ "plan_id" : this.planId })
			//this.registerMixpanel({"action_type" : "Buy Subscription", "planId" : this.planId})
    		this.getContent(options).then(function(res){
                if(!res.error) {
                    var userDetails = JSON.parse(localStorage.getItem("user"));
                    var transactionId = res.uri;
                    var amount = self.amount;
                    var options = {
                          "key": Utils.paymentGatewayKey(),
                          external: {
                            wallets: ['paytm'],
                            handler: function(data) {

                                var obj = {};
                                obj["transaction_id"] = transactionId;
                                obj["mobile_no"] = data.contact;
                                obj["email"] = data.email;

                                $.ajax({
                                    method : 'POST',
                                    url : Utils.contextPath() + '/v1/user/transaction/paytm/user-details',
                                    data : JSON.stringify(obj),
                                    contentType: "application/json",
                                }).done(function (response) {
                                    if(!response.error) {
                                        var paytmCheckSum = response.checksum;
                                        var paytmConfig = Utils.paytmTransactionDetails();
                                        var paytmRequestOptions  = {
                                            "REQUEST_TYPE" : "DEFAULT",
                                            "MID" : paytmConfig.merchantId,
                                            "ORDER_ID" : transactionId,
                                            "CUST_ID" : userDetails.id + "",
                                            "TXN_AMOUNT" : self.amount,
                                            "CHANNEL_ID" : paytmConfig.channelId,
                                            "INDUSTRY_TYPE_ID" : paytmConfig.industryTypeId,
                                            "WEBSITE" : paytmConfig.website,
                                            "CHECKSUMHASH": paytmCheckSum,
                                            "MOBILE_NO" : data.contact,
                                            "EMAIL" : data.email,
                                            "CALLBACK_URL" : Utils.contextPath() + '/v1/user/transaction/verify/paytm'
                                        };

                                        var form = document.createElement("form");
                                        form.setAttribute("method", "POST");
                                        form.setAttribute("action", paytmConfig.transactionURL);

                                        for(var key in paytmRequestOptions) {
                                            if(paytmRequestOptions.hasOwnProperty(key)) {
                                                var hiddenField = document.createElement("input");
                                                hiddenField.setAttribute("type", "hidden");
                                                hiddenField.setAttribute("name", key);
                                                hiddenField.setAttribute("value", paytmRequestOptions[key]);

                                                form.appendChild(hiddenField);
                                             }
                                        }

                                        form.style.display = "none";
                                        document.body.appendChild(form);
                                        form.submit();
                                    }

                                }).fail(function (err) {
                                    console.log(err);
                                });

                             }

                          },
                          "amount": amount * 100, // we take amount in paise
                          "name": "Your Dost",
                          "description": "Buy Subscription",
                          "image": "https://d1hny4jmju3rds.cloudfront.net/main-logo/yd-logo.png",
                          "handler": function (response){
                            var requestOptions  = {
                                "amount" : amount,
                                "transaction_id": transactionId,
                                "source":"subscription",
                                "razorpay_payment_id":response.razorpay_payment_id
                            };
                            $.ajax({
                                method : 'POST',
                                url : Utils.contextPath() + '/v1/user/transaction/razorpay/subscription',
                                data : JSON.stringify(requestOptions),
                                contentType: "application/json; charset=utf-8"
                            }).done(function (response) {
                               self.updateCount(response.url);
                            }).fail(function (err) {
                                console.log(err);
                            });
                          },
                          "notes": {
                            "user_id": userDetails.id,
                            "transaction_id": transactionId
                          },
                          "prefill": {
                              "name": userDetails.firstName || userDetails.username,
                              "email": userDetails.email,
                              "contact": userDetails.phone,
                          },
                          "theme": {
                              "color": "#2fa59a"
                          },
                          "modal": {

                          }
                    };
                    new Razorpay(options).open();
                }
            }, function(error){ console.log("Error: ",error)})
    	},
        checkForPayment : function(options){
            if(options && !options.type == 'buy_subscription') return;
            var options = {}
            var self = this;
			options["url"] = Utils.contextPath()+'/v2/user/account';
            options["method"] = "GET"
			this.getContent(options).then(function(res){
				if(res.is_chat_allowed && res.plan.name=="PAID"){
					$(".cp-content").html('')
					self.registerMixpanel({"action_type" : "Already Subscribed", "username" : self.userModel.getUserName()})
					var date = new Date(res.plan.expiry_date)
					var dateArr = (date + "").split(" ");
					var expDate =  dateArr[1] + " " + dateArr[2] + ", " + dateArr[3]
					$(".cp-info").html(self.infoLayout({expDate : expDate}))
					self.checkFamiliarExperts()
				}
				if(!res.is_chat_allowed || (res.is_chat_allowed && res.plan.name == "FREE")){
					self.buySubscription()
				}
            },function(err){
                console.log("Error: ",err)
            })
        },
        checkFamiliarExperts : function(){
            var self = this;
            var expertsPromise = this.getContent({url : Utils.contextPath()+'/v1/counselor?familiar=true&user='+this.userModel.getUserID(), method:"GET"})
            var statusPromise = this.getContent({url : Utils.contextPath() + "/v1/counselor/status", method: "GET"})
            $.when(expertsPromise, statusPromise).then(function(experts,status){
                    self.parseMyExperts(experts,status)
            },function(err){ consloe.log("Error: ",err); self.showDemoCard() })
        },
        showDemoCard : function(){
            var self = this;
            this.getContent({'url': Utils.contextPath()+'/v1/dashboard/ongoingCnt', method : "GET"})
            .then(function(res){
                $(".cp-c-card").html(self.demoCardLayout({count : parseInt(res) + 20}))
            })
        },
        parseMyExperts : function(experts,status){
            if(experts.length){
                var counselorDetails;
                var self = this;
                _.each(experts, function(counselor){
                    if(status[counselor.id] && status[counselor.id].status == "true"){
                        counselorDetails = counselor
                        counselorDetails["chatUrl"] = status[counselor.id].url
                        $(".cp-c-card").html(self.counselorCardLayout({counselor : counselorDetails}))
                        return;
                    }
                })
                if(!counselorDetails) this.showDemoCard()
            }else{ this.showDemoCard();}
        },
		mainLayout: JST['app/templates/subscription/layout.hbs'],
        subscriptionLayout: JST['app/templates/subscription/subscription.hbs'],
        counselorCardLayout : JST['app/templates/subscription/counselor_card.hbs'],
        demoCardLayout : JST['app/templates/subscription/demo_card.hbs'],
        infoLayout  : JST['app/templates/subscription/info_card.hbs'],
        testimonialsLayout: JST['app/templates/subscription/testimonials.hbs'],
        purchaseAlertTemplate: JST['app/templates/subscription/purchase.hbs'],
        renewSubscription : function(e){
            var trgt = $(e.currentTarget);
            this.amount = trgt.attr("data-price");
            this.planId = trgt.attr("data-plan-id");
			if(trgt.hasClass("disable")){
				return;
			}
            //$(".renew-btn").html("please wait...").addClass("clicked")
			this.registerMixpanel({"action_type" : "Clicked Buy Subscription", "planId" : this.planId, "loggedIn" : Utils.isLoggedIn()})
            if(!Utils.isLoggedIn()){
                EventBus.trigger("renderLogin", "buy_subscription", "buy_subscription", "buy_subscription",
                { options : { type: 'buy_subscription'},callback: this.checkForPayment.bind(this) } ) ;
                $(".renew-btn").html("buy care plan").removeClass("clicked")
                return;
            }
            this.checkForPayment()
        },
		registerMixpanel : function(options){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				mixpanel.track("Buy Subscription Page", options);
			}
		},
		showPlans : function(data){
            this.registerMixpanel({
                'planName': data
            });
			var self = this;
			this.getContent({url: Utils.contextPath()+'/v1/product/4', method : 'GET'})
			.then(function(res){
				if(!data || (data && data == 'allPlans')){
					self.showallPlans(res)
				}
				if(data != 'allPlans'){
					self.showLimitedPlans(data,res)
				}
			})
		},
		showLimitedPlans : function(data, response){
			var self = this;
			var singleplan = false
			var plansFound = false
			var singlePlan = []
			if(data == 'singlePlan') singleplan = true
			if(data == 'doublePlan') singleplan = false
			response.forEach(function(plan){
				if(plan.recommended && !plansFound) {
					self.amount = plan.amount
					self.planId = plan.id
					plansFound = true
					singlePlan.push(plan);
				}
			    if(data == 'doublePlan') {
				   if(plan.planName == 'SUB_2') singlePlan.push(plan)
			    }
			})
			$(".cp-content").html(self.subscriptionLayout({
                plans:singlePlan,
                planType : data,
                totalCount: self.planCount,
                lastHourCount: self.lastHourCount,
                title: self.title,
				planExpired : self.planExpired,
                mobile: self.isMobileDevice
            }));
            self.renderReviews();
            setTimeout(function () {
                self.showPurchaseAlert();
            }, 5000);
		},
        renderReviews: function () {
            var self = this;
            $.ajax({
                'method': 'GET',
                'url': "/scripts/json/care_plan_testimonials.json",
                'contentType': 'text/plain'
            })
            .done(function (response) {
                $(".cp-content .reviews").html(self.testimonialsLayout({'details' : response}));

                var hlSwiper = new Swiper ('.cp-testimonials-swiper', {

                    pagination: '.cp-testimonials-pagination',
                    paginationClickable: true,
                    autoplay: 10000,
                    keyboardControl: true
                });
            });
        },
		showallPlans : function(res){
			var self = this;
			var plansFound = false
			res.forEach(function(plan){
				if(plan.recommended && !plansFound) {
					self.amount = plan.amount
					self.planId = plan.id
					plansFound = true
				}
			})
			$(".cp-content").html(this.subscriptionLayout({
                plans:res,
                planType : 'allPlans',
                totalCount: self.planCount,
                lastHourCount: self.lastHourCount,
                title: self.title,
				planExpired : self.planExpired,
                mobile: self.isMobileDevice
            }));
		    self.renderReviews();
            setTimeout(function () {
                self.showPurchaseAlert();
            }, 10000);
        },
        showPurchaseAlert: function () {
            if (this.isMobileDevice) return;
            $(".alert-container").html(this.purchaseAlertTemplate(this.purchaseOptions));
            $(".alert-container").removeClass('hide');
            setTimeout(function () {
                $(".alert-container").addClass('hide');
            }, 5000);
        },
        renderVariant: function () {
            var self = this;
            Utils.getVariantType({
                'name': 'SubscriptionExperiment',
                'alternatives': ['singlePlan','doublePlan','allPlans']
            })
            .then(function (res) {
                self.showPlans(res);
            }, function (err) {
                self.showPlans('allPlans');
            });
        },
        mask: function (user) {
            var length = user.length;
            var maskString  = '';
            for (var i=0; i<length-3; i++) {
                maskString += '*';
            }
            var maskedUserName = (user.substr(0,3) + maskString).substr(0,10);
            return maskedUserName;
        },
        registerPurchaseAlertHandler: function (options) {
            var self = this;
            self.counterRef = options.firebaseRef;
            self.counterRef.limitToLast(1).on('child_added', function (data) {
                var hash = data.val();
                var purchase = Utils.getDateDiff(hash.purchasedOn);
                purchase = purchase.split(" ")[0] == 0 ? 'just now' : purchase;
                self.planCount++;
                var renewCount = hash.renewCount;
                renewCount = renewCount - 1;
                self.purchaseOptions = {
                    'user'      : self.mask(hash.user),
                    'price'     : hash.price,
                    'count'     : renewCount,
                    'purchase'  : purchase
                };
                if (parseInt(renewCount) > 1) {
                    if (renewCount == 2) {
                        self.purchaseOptions.text = 'nd';
                    } else if (renewCount == 3) {
                        self.purchaseOptions.text = 'rd';
                    } else {
                        self.purchaseOptions.text = 'th';
                    }
                }
                if (!self.carePlanStats) {
                    //last 1 hour records
                    self.counterRef.orderByChild('purchasedOn').startAt(Date.now() - 3600000).on('value', function (data) {
                        self.lastHourCount  = data.val() && Object.keys(data.val()).length;
                        Utils.setCarePlanStats({
                            'planCount': self.planCount,
                            'lastHourCount': self.lastHourCount,
                            'counterRef': self.counterRef
                        });
                        self.renderVariant();
                    });
                }
            });

        },
		render: function() {
			var self = this;
            self.isMobileDevice = Utils.isMobileDevice();
            self.title = "YourDOST Care Plan";
			self.planExpired = false
            $("#main-header").hide();
            this.registerMixpanel({"action_type" : "Rendered"})
            this.$el.html(this.mainLayout({}));
            $(".feedback-form-btn").addClass("hide");
            if (Utils.isLoggedIn()){
                var options = {}
                options["url"] = Utils.contextPath()+'/v2/user/account';
                options["method"] = "GET"
                this.getContent(options)
                .then(function (res) {
                   if (!res.is_chat_allowed) {
                        self.title = res.plan.name == 'PAID' ? 'Your Care Plan has expired' : 'Your Free Trial has expired';
						self.planExpired = res.plan.name == 'PAID' ? true : false;
						if(res.plan.name == "FREE"){
							var chatsRemaining = res.plan.total_chats - res.report.total_chats_used;
							if(parseInt(chatsRemaining) === 0){
								self.planExpired = false;
								self.title = "YourDOST Care Plan";
							}
						}
                   }
                });
            }
            self.carePlanStats = Utils.carePlanStats;
            if (self.carePlanStats) {
                self.planCount = self.carePlanStats.planCount;
                self.lastHourCount = self.carePlanStats.lastHourCount;
                self.renderVariant();
                self.registerPurchaseAlertHandler({
                    'firebaseRef': self.carePlanStats.counterRef
                });
            } else {
                var firebaseConfig = Utils.getFirebaseConfig();
                firebase.initializeApp({
                    apiKey: firebaseConfig.apiKey,
                    authDomain: firebaseConfig.authDomain,
                    databaseURL: firebaseConfig.databaseURL,
                    storageBucket: firebaseConfig.storageBucket
                });
                self.database = firebase.database();
                self.counterRef = self.database.ref('count');
                self.counterRef.once('value', function (data) {
                    var list = data.val();
                    self.planCount = 935 + Object.keys(list).length - 1;
                    self.registerPurchaseAlertHandler({
                        'firebaseRef': self.counterRef
                    });
                });
            }
		}
	});

	subscriptionPage.prototype.remove = function() {
        $("#main-header").show();
        $(".feedback-form-btn").removeClass("hide")
        $('body').css("overflow","auto");
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    };
	subscriptionPage.prototype.clean = function() {
        this.remove()
    };
	return subscriptionPage;
});
