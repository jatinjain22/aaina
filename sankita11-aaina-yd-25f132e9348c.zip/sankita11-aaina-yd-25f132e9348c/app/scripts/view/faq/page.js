define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher'
], function($,_, Backbone, JST, Utils, Dispatcher) {

	var FaqPage = Backbone.View.extend({
		el: "main",
		FaqPageLayout: JST['app/templates/faq/layout.hbs'],
		initialize: function() {
			sessionStorage.setItem("hasClosedPopup", 0);
		},
		events: {
			"click .faq-question": "openQuestion",
			"click #qnext": "nextQuestion",
			"click #qprev": "prevQuestion",
			"click .fc-nav-btn-bar-back": "backToCategory",
			"click .expert-guidance-card-button": "chatNow",
			"click .close-expert-card": "closeChatPopUp"
		},
		showChatPopUp: function(e) {
			
			var hasClosedPopup = sessionStorage.getItem("hasClosedPopup");
			console.log( "session storage " + hasClosedPopup );

			if ( hasClosedPopup === "0" ) {
				if ( !Utils.isLoggedIn() ) {
					console.log( "hello1 ");
					if ( !$("#faq-qblock").hasClass( 'hide' ) ) {
						console.log( "hello" );
						setTimeout(function(){
	          				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){ 

	            				mixpanel.track('Prompt', { 'mediumSource' : 'website',  'itemName' : "prompt chatnow faq", 'buttonDesc' : 'prompt chatnow faq', 'desc' : 'prompt chatnow faq'});

			          		}
	        			}, 2000);
					
						$('.talk-to-expert-div').addClass( 'show' );
					}
				}
			}
		},
		closeChatPopUp: function(e) {
			
			sessionStorage.setItem( "hasClosedPopup", "1" );
			if ( !$('.talk-to-expert-div').hasClass( 'hide' ) ) {
					$('.talk-to-expert-div').removeClass( 'show' );
			}
		},
		chatNow: function(e) {
			/*
			setTimeout(function(){
          		if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){ 

            		mixpanel.track('Button Click', { 'medium' : 'website',  'itemName' : "click #Prompt Chat Now FAQ", 'buttonDesc' : 'click #Prompt Chat Now FAQ', 'desc' : 'click #Prompt Chat Now FAQ'});
          
          		}
        	}, 2000);			
			*/
			if ( !Utils.isLoggedIn() ) {
         
         		Dispatcher.trigger("renderLogin", "Chat Now Button", "Faq Pop Up", "home_chat") ;          


        	}
		},
		backToCategory: function(e){
			var self = this;
			self.closeChatPopUp();
			$("#faq-qblock").addClass("hide");
			$(".faq-cat").removeClass("hide");
			$('html, body').stop().animate({
	      	scrollTop: $("body").offset().top}, 1000,'easeInOutExpo');
		},
		nextQuestion: function(e){

			var qno = $(e.currentTarget).attr("qno");
			var cno = $("#faq-qblock").attr("cno");
			$("#"+qno).next(".faq-question").trigger('click');
			if( $("#"+qno).next(".faq-question").length < 1 ){
				if( cno == 5 ){
					cno = 1;
				}else{
					++cno;
				}
				$("#c_"+cno).find("li.faq-question:first").trigger("click");
			}
		},
		prevQuestion: function(e){

			var qno = $(e.currentTarget).attr("qno");
			var cno = $("#faq-qblock").attr("cno");
			$("#"+qno).prev(".faq-question").trigger('click');
			if( $("#"+qno).prev(".faq-question").length < 1 ){
				
				if( cno == 1 ){
					cno = 5;
				}else{
					cno--;
				}
				$("#c_"+cno).find("li.faq-question:last").trigger("click");
			}
		},
		openQuestion: function(e){
			var self = this;
			
			var qno = $(e.currentTarget).attr("data-fid");
			var cno = $(e.currentTarget).parents().attr("data-cid");

			var imageDetails = $("#fcimg"+cno).html();
			var qnoDetails = $("#q_"+qno).find(".qdesc").html();
			var anoDetails = $("#q_"+qno).find(".adesc").html();

			$("#qnext").attr("qno","q_"+qno);
			$("#qprev").attr("qno","q_"+qno);
			$("#faq-qblock").attr("cno",cno);

			$("#faq-qblock").find(".qimg-details").html( imageDetails );			
			$("#faq-qblock").find(".q-details").html( qnoDetails );
			$("#faq-qblock").find(".a-details").html( anoDetails.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&') );

			$("#faq-qblock").removeClass("hide");
			$(".faq-cat").addClass("hide");
			
			setTimeout(function() {
				console.log('hello');
				self.showChatPopUp();

			}, 5000);


			
			$('html, body').stop().animate({
	      	scrollTop: $("body").offset().top}, 1000,'easeInOutExpo');
		},
		render: function() {

			document.title="FAQs regarding Career, Family, Love Relationship | YourDOST";
			$('meta[name=description]').attr('content', "Know the most frequently asked questions related to career, family, love relationship,etc and also the experts answers to these questions");
			$('meta[name=title]').attr('content',"FAQs regarding Career, Family, Love Relationship | YourDOST");
			$('meta[property="og:description"]').attr('content', "Know the most frequently asked questions related to career, family, love relationship,etc and also the experts answers to these questions");
			$('meta[property="og:title"]').attr('content',"FAQs regarding Career, Family, Love Relationship | YourDOST");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/faq');
			var self = this;
			$.ajax({
  				method: "GET",
  				url: Utils.contextPath()+'/category'
			}).done(function(response){
				self.$el.html(self.FaqPageLayout(response));
				$('html, body').stop().animate({
	      		scrollTop: $("body").offset().top}, 1000,'easeInOutExpo');
	      		if( Utils.isMobileDevice() )
	      			self.$el.find(".page-title").addClass("hide");
	      		
	      		$(".side-explore-btn").addClass("clicked");
	      		$(".side-explore-menu").removeClass("hide").find(".faq-mli").addClass("active");

	      		if(typeof $.cookie("donationClosed") == 'undefined'){

					Dispatcher.trigger("DonationSpreadPage") ;
				}

			}).fail(function(error){
				
			});

		}
	});

	FaqPage.prototype.remove = function() {

	};

	FaqPage.prototype.clean = function() {

	};

	return FaqPage;
});