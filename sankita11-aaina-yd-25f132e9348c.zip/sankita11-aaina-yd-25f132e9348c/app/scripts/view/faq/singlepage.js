define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function($,_, Backbone, JST, Utils) {

	var FaqSinglePage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {
			"click .faq-question": "openQuestion",
			"click #qnext": "nextQuestion",
			"click #qprev": "prevQuestion",
			"click .fc-nav-btn-bar-back": "backToCategory"
		},
		backToCategory: function(e){

			$("#faq-qblock").addClass("hide");
			$(".faq-cat").removeClass("hide");
	      	Utils.scrollTo();
		},
		nextQuestion: function(e){

			var qno = $(e.currentTarget).attr("qno");
			var cno = $("#faq-qblock").attr("cno");
			$("#"+qno).next(".faq-question").trigger('click');
			if( $("#"+qno).next(".faq-question").length < 1 ){
				if( cno == 5 ){
					cno = 1;
				}else{
					++cno;
				}
				$("#c_"+cno).find("li.faq-question:first").trigger("click");
			}
		},
		prevQuestion: function(e){

			var qno = $(e.currentTarget).attr("qno");
			var cno = $("#faq-qblock").attr("cno");
			$("#"+qno).prev(".faq-question").trigger('click');
			if( $("#"+qno).prev(".faq-question").length < 1 ){
				
				if( cno == 1 ){
					cno = 5;
				}else{
					cno--;
				}
				$("#c_"+cno).find("li.faq-question:last").trigger("click");
			}
		},
		openQuestion: function(e){

			var qno = $(e.currentTarget).attr("data-fid");
			var cno = $(e.currentTarget).parents().attr("data-cid");

			var imageDetails = $("#fcimg"+cno).html();
			var qnoDetails = $("#q_"+qno).find(".qdesc").html();
			var anoDetails = $("#q_"+qno).find(".adesc").html();

			$("#qnext").attr("qno","q_"+qno);
			$("#qprev").attr("qno","q_"+qno);
			$("#faq-qblock").attr("cno",cno);

			$("#faq-qblock").find(".qimg-details").html( imageDetails );			
			$("#faq-qblock").find(".q-details").html( qnoDetails );
			$("#faq-qblock").find(".a-details").html( anoDetails.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&') );

			$("#faq-qblock").removeClass("hide");
			$(".faq-cat").addClass("hide");

			Utils.scrollTo();
		},
		FaqPageLayout:JST['app/templates/faq/layout.hbs'],
		render: function() {
			var self = this;

			$.ajax({
  				method: "GET",
  				url: Utils.contextPath()+'/category'
			}).done(function(response){
				self.$el.html(self.FaqPageLayout(response));
				$("#q_"+self.id).trigger("click");
				if( Utils.isMobileDevice() )
	      			self.$el.find(".page-title").addClass("hide");
	      		$(".side-explore-btn").addClass("clicked");
	      		$(".side-explore-menu").removeClass("hide").find(".faq-mli").addClass("active");
			}).fail(function(error){
				
			});			
		}
	});

	FaqSinglePage.prototype.remove = function() {

	};

	FaqSinglePage.prototype.clean = function() {

	};

	return FaqSinglePage;
});