define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    'raygun' ,
    'purl', 
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, UserModel ) {

	var UpdatedTermsModalPage = Backbone.View.extend({
		el: "main",
		initialize: function() {	
			
			var url = window.location.href ;	
			this.userModel       = new UserModel();
			this.fromAction = url.replace(/^.*?=/, "");
		},
		events: {
			
			'click .agree-update-terms-btn' : 'agreeUpdateTerms',
		},
		
	    updatedTermsLayout : JST["app/templates/tos/modal_tos.hbs"],

	    agreeUpdateTerms : function(e){

	    	var self = this ;
	    	var user_id = this.userModel.getUserID();
	    	var userType = this.userModel.getUserType();
	    	
	    	$.ajax({

	    		url: Utils.contextPath() + '/v2/users/terms',
	    		method: 'POST',
	            contentType: "application/json"
	        }).done(function(response){

	        		Utils.closePopup('termsUpdateModal');

	        		var username = self.userModel.getUserName();

    				console.log(self.redirectTo) ;
					if(self.fromAction == 'home_chat'){
						location.href = Utils.chatUrl() + username;
					}else if(self.fromAction == 'message'){

						Backbone.history.navigate("/talkItOut?from=message&counselorID=",{trigger:true}) ;

					}else if(self.fromAction == 'book_appointment'){

						Backbone.history.navigate("/bookAppointment",{trigger:true}) ;						

					}else if ( self.fromPage == "landingpage2" ) {

						Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{triger:true});
						
					}
					else if ( self.fromAction.indexOf("/tips-counselor-page") > -1 ) {
						Backbone.history.navigate( "/tips-counselor-page?fromPage=hiddenTips", {trigger: true} );
					}  
					else if ( self.fromAction.indexOf("/tips-spouse-communication") > -1 ) {
						Backbone.history.navigate( "/tips-spouse-communication?fromPage=hiddenTips", {trigger: true} );
					}
					else if ( self.fromAction.indexOf("result") >= 0 ){

						Backbone.history.navigate( self.fromAction, {trigger: true} );

					} 
					else{
						if ( userType == 'VICTIM' ) {
							Backbone.history.navigate("/talkItOut",{trigger:true});
						} else {
							Backbone.history.navigate("/friend/messages", {trigger: true});
						}
						
					   localStorage.setItem("fromChat", 0) ;
					}


	        }).error(function(error){

	        	console.log(error);
	        })
	    },
		render: function() {

			var self = this ;
			self.$el.append(self.updatedTermsLayout());		

			Utils.openPopup('termsUpdateModal') ;	
		},

	});

	UpdatedTermsModalPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	UpdatedTermsModalPage.prototype.clean = function() {
		this.remove();
	};

	return UpdatedTermsModalPage;
});