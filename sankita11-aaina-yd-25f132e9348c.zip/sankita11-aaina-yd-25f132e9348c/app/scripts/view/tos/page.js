define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'backbone',
	'../../precompiled-templates'
], function($, _, EventBus, Backbone, JST) {
	
	var TOSPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
		},
		events: {},
		TOSLayout: JST['app/templates/tos/layout.hbs'],
		render: function() {

	        document.title="Terms of Service | YourDOST";
	        $('meta[name=description]').attr('content', "Use of the Website is available only to people over the age of eighteen (18). If your age is below 18, you shall not register as a member of the Website");
	        $('meta[name=title]').attr('content',"Terms of Service | YourDOST");
	        $('meta[property="og:description"]').attr('content', "Use of the Website is available only to people over the age of eighteen (18). If your age is below 18, you shall not register as a member of the Website");
	        $('meta[property="og:title"]').attr('content',"Terms of Service | YourDOST");	       
            $('link[rel="canonical"]').attr('href', 'https://yourdost.com/termsOfService');
			this.$el.html(this.TOSLayout({}));

			EventBus.trigger("renderUpdatedTerms") ;
		}
	});

	TOSPage.prototype.remove = function() {};

	TOSPage.prototype.clean = function() {};

	return TOSPage;
});