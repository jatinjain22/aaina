define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {
	var mentalHealthQuiz = Backbone.View.extend({
		el: "main",
		initialize: function() {
			//Math.abs(Math.floor(Math.random() * 40) + 1);
			this.questions = {};
			this.mappingObj = {};
			this.mappingScoreObj = {};
			this.optionIndex = -1;
			this.finalScore = 0;
			this.score = 0;
      this.noOfQues = 1;
		},
		mentalHealthLayout: JST['app/templates/mentalHealthQuiz/layout.hbs'],
		startmentalHealthLayout : JST['app/templates/mentalHealthQuiz/start.hbs'],
		questionsLayout : JST['app/templates/mentalHealthQuiz/questions.hbs'],
		events: {
			'click .mhq-start-quiz' : 'startQuiz',
			'click .mhq-next' : 'nextQuestion',
			'click .mhq-prev' : 'prevQuestion',
			'click .mhq-options' : 'selectOption',
			'click .mhq-show-result' : 'showResult',
      'keyup .inputPhone' : 'enterText',
		},
		trackMixpanelEvents : function(identifier, itemName, itemType){
	      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	        mixpanel.track(identifier, { "itemName" : itemName, "itemType" : itemType});
	      }
	  },
		startQuiz : function(){
      this.startQuizTime = new Date()
			this.trackMixpanelEvents("BUtton Click", "start Mental Health quiz", "clicked start Mental Health quiz")
			this.renderQuestions()
		},
		findSelectedOption : function( option, className ){
			this.optionIndex = $("."+className).index($(option.currentTarget))+1
			this.score = $(option.currentTarget).attr("data-score")
		},
		selectOption : function( evt ){
			var className = "mhq-options"
      if($(evt.currentTarget).hasClass("input")){
        className = "inputText"
      }
			$("."+className).removeClass("option-selected")
			$(evt.currentTarget).addClass("option-selected")
			$(".mhq-next").removeClass("disabled")
			this.findSelectedOption( evt, className )
			if(this.noOfQues == 10){
				$(".mhq-next").removeClass("mhq-next").removeClass("disabled").addClass("mhq-show-result").html("<b>SHOW RESULT &gt;</b>")
			}
		},
    mapInputText : function(evt){
      this.optionIndex = $(evt.currentTarget).parents(".mhq-inner").find(".inputPhone").val()
      $(".mhq-next").removeClass("mhq-next").removeClass("disabled").addClass("mhq-show-result").html("<b>SHOW RESULT &gt;</b>")
      this.score = 0;
    },
    enterText : function(evt){
      var number = $(evt.currentTarget).val()
      var regEx = /[0-9]/
      if(regEx.test(number) && number.length == 10){
        this.mapInputText(evt)
        return;
      }
      $(".mhq-show-result").addClass("mhq-next").addClass("disabled").removeClass("mhq-show-result").html("<b>NEXT &gt;</b>")
    },
		generateRandomArray : function(){
			var k = 1;
			var rArr = []
			for(i=0;i<20;i++){
				var rNo = Math.abs(Math.floor(Math.random() * 40) + 1);
				if(rArr.indexOf(rNo) == -1 && k != 11){
					k++;
					rArr.push(rNo)
				}
			}
			return rArr;
		},
		nextQuestion : function(evt){
      if($(evt.currentTarget).parents(".ew-sub-inner").find(".inputText").length){
        this.mapInputText(evt)
      }
			this.trackMixpanelEvents("Button Click", "Clicked Next Question", this.questionNo)
			this.mappingObj[this.questionNo] = this.optionIndex;
			this.mappingScoreObj[this.questionNo] = this.score;
			if(this.noOfQues != 10) this.questionNo = this.noArr[this.noOfQues]//Math.abs(Math.floor(Math.random() * 40) + 1);
      //if(this.mappingObj[this.questionNo]) this.questionNo = Math.abs(Math.floor(Math.random() * 40) + 1);
      this.noOfQues++;
			this.renderQuestions(false)
		},
		prevQuestion : function(evt){
			this.noOfQues--;
			this.renderQuestions(true)
		},
		renderQuestions : function( option ){
      var questionsObj = this.questions;
			var self = this;
			var question = questionsObj[self.questionNo]
			question["qNo"] = this.noOfQues;
      if( this.noOfQues == 11 ){
        question = questionsObj["phone"]
        question["qNo"] = this.noOfQues;
			}
			this.$el.find(".mhq-inner").html(this.questionsLayout({question : question, totalQues : Object.keys(this.questions).length}))
			if( this.questionNo > 1){
				$(".mhq-prev").removeClass("disabled")
			}
		},
		showResult : function(evt){
      if($(evt.currentTarget).parents(".mhq-inner").find(".inputPhone").length){
        this.mapInputText(evt)
      }
			var resultArr = Object.values(this.mappingScoreObj)
			this.finalScore = resultArr.reduce(function(prev,curr){
				return parseInt(prev) + parseInt(curr)
			})
			this.trackMixpanelEvents("BUtton Click", "show result mental health quiz", "clicked show result Mental Health Quiz")
			localStorage.setItem("mentalHealthQuiz", this.finalScore);
      this.updateToFirebase()
			Backbone.history.navigate("/mental-health-quiz/result",{trigger:true});
		},
    updateToFirebase : function(){
      var self = this;
      this.getContent({method:'GET', url : Utils.contextPath()+'/v2/users/organisation'})
      .then(function(res){
        self.updateFirebase(res)
      }, function(err){
        console.log("Error: ",err)
      })
    },
    updateFirebase : function(orgId){
      var endQuizTime = new Date()
      var timeTaken = new Date( endQuizTime - this.startQuizTime )
      var firebaseObj = Utils.updateEmotionalWellness("mentalHealthQuiz");
			var today = new Date().toLocaleString();
			var userObj = {
        "userId" : -1,
        "answers" : this.mappingObj || {},
        "result" : this.finalScore || 0,
        "orgId" : orgId,
        "phone" : this.optionIndex,
        "userName" : "",
        "timeTaken" : timeTaken.getSeconds()+' seconds',
				"created" : today
      }
			if(Utils.isLoggedIn()){
				var userObject = JSON.parse(localStorage.getItem("user"))
				userObj["userId"] = userObject['id'],
				userObj["orgId"] = userObject['loggableUser']['orgId'],
				userObj["userName"] = userObject['username']
			}
      firebaseObj.set(userObj)
    },
		getContent : function( options ){
			var deferred = $.Deferred();
			$.ajax(options)
      .done(function(response){
				deferred.resolve(response);
			}).error(function(error){
				deferred.reject(error);
			})
			return deferred.promise();
		},
		render: function() {
			document.title="Welcome To YourDOST's Mental Health Quiz";
    	$('meta[name=description]').attr('content', "We won't quiz you about your favorite color; we won't ask you questions about odd-looking shapes and how they make you feel. We won't even ask you obscure questions that reveal details about your past life, details such as what kind of a bear you were in that life... No, none of that will happen here.");
    	$('meta[name=title]').attr('content',"Welcome To YourDOST's Mental Health Quiz");
    	$('meta[property="og:url"]').attr('content',"https://yourdost.com/mental-health-quiz");
    	$('meta[property="og:description"]').attr('content', "We won't quiz you about your favorite color; we won't ask you questions about odd-looking shapes and how they make you feel. We won't even ask you obscure questions that reveal details about your past life, details such as what kind of a bear you were in that life... No, none of that will happen here.");
    	$('meta[property="og:title"]').attr('content',"Welcome To YourDOST's Mental Health Quiz");
    	$('meta[property="og:image"]').attr('content',"https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
    	$('meta[property="og:url"]').attr('content',"https://yourdost.com/mental-health-quiz ");
    	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/mental-health-quiz');

			this.$el.html( this.mentalHealthLayout() );
			this.$el.find(".mhq-inner").html(this.startmentalHealthLayout())
			this.noArr = this.generateRandomArray()
			this.questionNo = this.noArr[0];
			var Questions = this.getContent({ method : 'GET', url : Utils.scriptPath() + "/mentalHealthQuiz/questions.json" });
			this.trackMixpanelEvents("Mental Health Quiz", "Mental Health Quiz Rendered", " ")
			var self = this;
			$.when(Questions)
			.then(function(response){
				self.questions = response.questions;
			}, function(error){
				console.log("Error ", error);
			})
		}
	});
	mentalHealthQuiz.prototype.remove = function() {
		$(".dost-main").css({"background" : "#fff"})
	  this.$el.empty();
  	this.$el.off();
  	this.stopListening();
  	this.undelegateEvents();
  	this.unbind();
	};
	mentalHealthQuiz.prototype.clean = function() {
		this.remove();
	};
	return mentalHealthQuiz;
});
