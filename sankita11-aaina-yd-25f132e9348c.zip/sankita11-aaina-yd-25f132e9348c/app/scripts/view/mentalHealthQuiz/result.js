define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, Masonry, imagesLoaded ) {

	var mentalHealthQuizResult = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.userModel = new UserModel()
		},
    events : {
      "click .mhr-chat-btn" : "initiateChat",
    },
    ResultLayout: JST['app/templates/mentalHealthQuiz/result.hbs'],
    mainLayout: JST['app/templates/mentalHealthQuiz/layout.hbs'],
    redirect: function () {
			Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {});
		},
		initiateChat: function () {
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat'
					},
					callback: this.redirect
				} ) ;
			} else {
				this.redirect();
			}
    },
    getContent : function( url ){
			var deferred = $.Deferred();
			$.ajax({method : 'GET',url : url})
      .done(function(response){
				deferred.resolve(response);
			}).error(function(error){
				deferred.reject(error);
			})
			return deferred.promise();
		},
    postSignup : function(options){
      console.log(options)
      if(options.result){
        this.$el.html(this.ResultLayout( { score : options.result , loggedIn : Utils.isLoggedIn()} ) )
      }
      this.updateFirebase(false)
    },
    updateFirebase : function(loggedIn){
			if(!loggedIn){
	      var firebaseObj = Utils.updateEmotionalWellness("mentalHealthQuiz");
	      var userObject = JSON.parse(localStorage.getItem("user"))
	      firebaseObj.update({
	        "userId" : userObject['id'],
	        "orgId" : userObject['loggableUser']['orgId'],
	        "userName" : userObject['username']
	      })
			}
			setTimeout(function(){
				localStorage.removeItem("testID");
				localStorage.removeItem("mentalHealthQuiz")
			}, 1000)
    },
    showResult : function(){
      if(Utils.isLoggedIn()){
        this.$el.html(this.ResultLayout( { score : this.result , loggedIn : Utils.isLoggedIn()} ) )
        this.updateFirebase(true)
      }else{
        $('.header-right-section .login-clicked').addClass('hide')
        this.$el.html(this.ResultLayout( { score : this.result, loggedIn : Utils.isLoggedIn()} ) )
        Dispatcher.trigger("renderLoginToDiv", "", "mentalHealthQuiz", "mhq_test", "ew_signup", {
					options : {
						result: this.result
					},
					callback: this.postSignup.bind(this)
				});
        $(".login-modal-close").addClass("hide");
      }
    },
		render: function() {
			document.title="Welcome To YourDOST's Mental Health Quiz Result";
    	$('meta[name=description]').attr('content', "We won't quiz you about your favorite color; we won't ask you questions about odd-looking shapes and how they make you feel. We won't even ask you obscure questions that reveal details about your past life, details such as what kind of a bear you were in that life... No, none of that will happen here.");
    	$('meta[name=title]').attr('content',"Welcome To YourDOST's Mental Health Quiz Result");
    	$('meta[property="og:url"]').attr('content',"https://yourdost.com/mental-health-quiz/result");
    	$('meta[property="og:description"]').attr('content', "We won't quiz you about your favorite color; we won't ask you questions about odd-looking shapes and how they make you feel. We won't even ask you obscure questions that reveal details about your past life, details such as what kind of a bear you were in that life... No, none of that will happen here.");
    	$('meta[property="og:title"]').attr('content',"Welcome To YourDOST's Mental Health Quiz Result");
    	$('meta[property="og:image"]').attr('content',"https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
    	$('meta[property="og:url"]').attr('content',"https://yourdost.com/mental-health-quiz/result");
    	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/mental-health-quiz/result');
      var self = this;
      var url = Backbone.history.getFragment();
      if ( !localStorage.hasOwnProperty( "mentalHealthQuiz" ) ) {
        Backbone.history.navigate("/mental-health-quiz",{trigger:true});
        return;
      }
      this.result = parseInt(localStorage.getItem("mentalHealthQuiz"))

      // $.when(this.getContent( Utils.scriptPath() + "/mentalHealthQuiz/result.json" ))
      // .then(function(res){
      this.showResult()
      // }, function(err){
      //   console.log("Error: ",err)
      // })
    }
  });
	mentalHealthQuizResult.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind();
  };
	mentalHealthQuizResult.prototype.clean = function() {
    this.remove();
  };
	return mentalHealthQuizResult;
});
