define([
	'jquery',
	'underscore',
	'backbone',
	'event/dispatcher',
  	'view/home/subview/outside_form_links',
  	'view/careerCounselor/subview/main_banner',
  	'view/careerCounselor/subview/career_experts',
  	'view/home/subview/user_review',
  	'view/home2/subview/stats',
  	'view/home2/subview/book_appointment',
	'view/leaveMessage/page' ,
	'model/users',
	'../../precompiled-templates',
	'smooth-scroll',
	'utils',
], function($,_, Backbone, EventBus, OutsideFormLinksView, MainBannerView, CareerExpertsView, UsersRevieView, StatsView,
	
	 BookAppointmentView, LeaveMessageView, UserModel, JST, SmoothScroll, Utils) {

	var CareerPageView = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.mainBannerView = new MainBannerView();
	      	this.outsideFormLinksView = new OutsideFormLinksView();
	      	this.CareerExpertsView = new CareerExpertsView();
	      	this.statsView = new StatsView();
	      	this.userReviewView = new UsersRevieView();
	      	this.userModel       = new UserModel();
	      	this.bookAppointmentView = new BookAppointmentView();
			this.leaveMessage = new LeaveMessageView();
		},
		events: {
      		'click .smoothscroll': 'smoothScroll',
      		'click .go-down': 'goDown',
      		"click .go-to-testimonials": "goToTestimonials",
      		'click .relation-chat-btn' : 'openSignUpNowModal' ,
			'click .app-btn' : 'openBookAppModal',
			'click .fexp-chat' : "chatCounselor",
			'click .fexp-msg'  : "msgCounselor",
			'click #home-start-chat-btn-header' : 'openSignUpNowModal' ,
			'click .relationshipCounselors' : 'gotoRelationshipCounselors',
			'click .yd-logo-relationship' : 'taketoHome',
    	},
    	onScroll : function(ev){

    		if($(window).scrollTop > 200){

    			$(".relationship-scroll").removeClass("hide");
    		}else{

    			$(".relationship-scroll").addClass("hide");
    		}
    	},
    	taketoHome : function(e){

    		e.preventDefault();
    		var url = "/?fromPage=careerpage&amp;from=header" ;
			window.open(url, "_self");

    	},
    	gotoRelationshipCounselors : function(e){

    		e.preventDefault();
    		var url = "#talkItOut?category=1" ;
			window.open(url, "_self");
    	},
		openBookAppModal : function (e) {
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home","book_appointment") ;
			}else{
				//this.bookAppointmentView.render();
				//location.href = "/bookAppointment" ;
				Backbone.history.navigate("/bookAppointment", {trigger: true});
			}
		},
		openSignUpNowModal : function (e) {
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "home_chat") ;
			}else{
				var username = this.userModel.getUserName() ;
				location.href = Utils.chatUrl() + username;
			}
		},
		msgCounselor : function(e){

			var counselorIdName = $(e.currentTarget).attr("data-attr");

			var counselorInfo = {
				id : counselorIdName.split("_")[0] ,
				name : counselorIdName.split("_")[1] ,
			};

			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "message", JSON.stringify(counselorInfo)) ;
			}else{

				if(!counselorIdName || counselorIdName == undefined || counselorIdName == null ){
					this.leaveMessage.render() ;
				}else{
					this.leaveMessage.render( counselorInfo ) ;
				}
				
			}

		},
		chatCounselor : function(e){
			
			var chatURL = $(e.currentTarget).attr("data-href") ;
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				EventBus.trigger("renderLogin", buttonDesc, "home", "counselorChat", chatURL ) ;
			}else{
				location.href = chatURL + "&username=" + username;
			}
		},

    	goToTestimonials: function(e){
			//location.href = "/testimonials";
			Backbone.history.navigate("/testimonials", {trigger: true});
			return this;
		},
    	showBecomeVolunteerForm : function(e){
    		this.becomeVolunteer.render() ;
    		$('select').not('.disabled').material_select();
    	},
    	showShareExperienceForm : function (e) {
    		this.shareExperienceView.render();
    	},
    	showBeSaviorForm : function (e) {
    		this.beSaviorView.render() ;
    	},
		template: JST['app/templates/home2/layout.hbs'],
		render: function() {

			this.$el.html(this.template());

			//anonymous user view rendering
			this.mainBannerView.render();

			this.CareerExpertsView.render();

			this.userReviewView.render();

			this.statsView.render();

			return this;
		},
    	smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
	    goDown: function(e){
	      $('html, body').stop().animate({
	      scrollTop: $("#home2-featured-block").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    }
	});

	CareerPageView.prototype.remove = function() {
		window.clearInterval(this.iInterval);
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
    	//this.undelegateEvents();
    	//this.stopListening();
	};

	CareerPageView.prototype.clean = function() {
		window.clearInterval(this.iInterval);
		this.remove() ;
	};

	return CareerPageView;
});
