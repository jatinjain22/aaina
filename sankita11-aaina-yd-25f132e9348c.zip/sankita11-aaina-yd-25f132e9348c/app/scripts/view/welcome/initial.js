define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'utils',
], function($,_, Backbone, JST, Utils ) {

    var InitialView = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        window.isSkipped = false;        
      },
      
      events: {
        'click .skip-to-site' : 'redirectTo',
        'click .app_page' : 'takeToplayStore'
      },

      takeToplayStore : function(){

        sessionStorage.setItem("skipped", "true");

        var macos = navigator.userAgent.match(/(Mac|iPhone|iPod|iPad)/i) ? true : false;

       
        
        if(!macos){
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
            mixpanel.track('LANDING PAGE', {'itemType':'MACOS', 'mediumSource' : 'website' });
          }
          Backbone.history.navigate('https://play.google.com/store/apps/details?id=co.yourdost.app&hl=en',{trigger:true});
        }
        else{
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
            mixpanel.track('LANDING PAGE', {'itemType':'ANDROID', 'mediumSource' : 'website' });
          }
          Backbone.history.navigate('https://geo.itunes.apple.com/us/app/yourdost/id1053917659?mt=8',{trigger:true});
        }


      },

      redirectTo : function(e){

        e.stopPropagation();

        sessionStorage.setItem("skipped", "true");

        var url = $(".skip-to-site").data("href");
        
        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
            
            mixpanel.track('LANDING PAGE', {'itemType':'GOING-TO_SITE', 'mediumSource' : 'website' });
        }

        if (window.location.href == url){
        
          location.reload();
        
        }else{
        
          window.open(url, "_self");
        
        }


      },

      InitialLayoutTemplate : JST['app/templates/welcome/initial.hbs'],

      render: function(redirect) {

        this.$el.html( this.InitialLayoutTemplate({redirect : redirect}) );

        $("main").parents().find(".navbar-fixed").hide();

        if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 
            
            mixpanel.track('LANDING PAGE', {'itemType':'LANDING PAGE SHOWN', 'mediumSource' : 'website' });
        }
        return this;
      }
    });

  InitialView.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind(); 
	};

	InitialView.prototype.clean = function() {

      this.remove();

	};

    return InitialView;
});
