define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates'

] , function( $, _, Backbone, JST) {

	var announcement = Backbone.View.extend({

		el: "main",

		initialize : function(){
		},

		layout : JST['app/templates/announcement/page.hbs'],

		render : function(options){
			this.$el.html(this.layout());
		}		
	});

	announcement.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	announcement.prototype.clean = function() {

		this.remove() ;
	};

	return announcement;
});
