define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'backbone',
	'../../precompiled-templates'
], function($, _, EventBus, Backbone, JST) {
	
	var NYRPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
		},
		events: {},
		NYRLayout: JST['app/templates/newYearResolution2017/layout.hbs'],
		
		render: function() {

	        document.title="How To Succeed In Your New Year's Resolution";
	        $('meta[name=description]').attr('content', "Do your New Year Resolution fizzle very soon? The key to success is the right resolution, right plan and right mentor. Get the combination right to succeed in your resolutions.");
	        $('meta[name=title]').attr('content',"How To Succeed In Your New Year's Resolution");
	        $('meta[property="og:description"]').attr('content', "Do your New Year Resolution fizzle very soon? The key to success is the right resolution, right plan and right mentor. Get the combination right to succeed in your resolutions.");
	        $('meta[property="og:title"]').attr('content',"How To Succeed In Your New Year's Resolution");	       
            $('link[rel="canonical"]').attr('href', 'https://yourdost.com/termsOfService');
			this.$el.html(this.NYRLayout({}));

			EventBus.trigger("renderUpdatedTerms") ;
		}
	});

	NYRPage.prototype.remove = function() {};

	NYRPage.prototype.clean = function() {};

	return NYRPage;
});