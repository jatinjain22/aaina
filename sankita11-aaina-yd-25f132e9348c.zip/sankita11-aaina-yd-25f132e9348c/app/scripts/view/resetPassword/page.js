define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/paymentPending/payment_pending',
	'utils',
	'purl'
], function( $, _, Backbone, JST, PaymentPendingView, Utils ) {

	var ResetPasswordPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			var url = window.location.href ;
    		url = url.replace("/resetPassword", "" );
			var vCode = $.url( url ).param('_v') ;
			var token = $.url( url ).param('_t') ;
			this.paymentPendingView = new PaymentPendingView() ;
			this.vCode = vCode ;
			this.token = token ;
		},
		events: {
			'submit #reset-password-form' : 'resetPassword'
		},
		disableSubmit : function(e){
			$("#reset-password").addClass("disabled");
			$("#reset-password").attr("disabled", true);
		},
		enableSubmit : function(e){
			$("#reset-password").removeClass("disabled");
			$("#reset-password").attr("disabled", false);
			$("#form-error-password").html("") ;
			$("#form-error-confirm_password").html("") ;
		},
		checkForConfirmPassword : function(e){

			var password        = $("#password").val() ;
			var confirmPassword = $("#confirm_password").val() ;

			if( confirmPassword.length <= 0 ){
				$("#form-error-password").html("Please enter a valid password");
				this.disableSubmit();
				return 0 ;
			}

			if( confirmPassword.length >0){

				//var pattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$/;
                var pattern = /\s/g ;
                if( pattern.test(confirmPassword) ){

					$("#form-error-confirm_password").html("Password should not have whitespaces in between");
					this.disableSubmit();
					return 0 ;
				}
			}

			if( password != confirmPassword ){
				$("#form-error-confirm_password").html("The password and confirm password do not match");
				this.disableSubmit();
				return 0 ;
			}
			this.enableSubmit() ;
			return 1 ;

		},
		checkForPassword : function(e){

			var password        = $("#password").val() ;
			var confirmPassword = $("#confirm_password").val() ;

			if( password.length <= 0 ){
				$("#form-error-password").html("Please enter a valid password");
				this.disableSubmit();
				return 0 ;
			}

			if( password.length >0){

				//var pattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$/;
                var pattern = /\s/g ;
				if( pattern.test(password) ){

					//$("#form-error-password").html("Password must contain atleast 8 characters, an Alphabet, 1 Number and 1 Special Character (!,@,#,$,&,*,_,-)");
                    $("#form-error-password").html("Password should not have whitespaces in between");
                    this.disableSubmit();
					return 0 ;
				}
			}

			if( password.length && confirmPassword.length  && password != confirmPassword ){
				$("#form-error-confirm_password").html("The password and confirm password do not match");
				this.disableSubmit();
				return 0 ;
			}
			this.enableSubmit() ;
			return 1 ;
		},

		resetPassword : function(){

			var isValid = this.checkForPassword();
			if(!isValid){
				this.disableSubmit();
				return 0;
			}

			$("#step2-progress").removeClass("hide");
			$("#reset-password").addClass("hide");

			var password = $("#password").val();

			var dataToSend = {
				"password" : password ,
			};

			$.ajax({
				url : Utils.contextPath() + "/v2/users/resetpassword?_v=" + this.vCode ,
				method : "POST" ,
				dataType : "json" ,
				contentType: "application/json",
				data : JSON.stringify(dataToSend),
				headers :{
					"X-DOST-ZION-AUTH" : this.token ,
				}
			}).done(function(response){
				console.log(response) ;
				$(".step2-cointaner").addClass("hide");
				$(".reset-success-msg").removeClass("hide");
			}).error(function(error){
                console.log(error) ;
                $(".step2-cointaner").addClass("hide");
                $(".reset-failure-msg").removeClass("hide");
			});

		},
		ResetPasswordLayout: JST['app/templates/resetPassword/layout.hbs'],
		render: function() {
			this.$el.html(this.ResetPasswordLayout());

			$('.parallax').parallax();

			var self = this ;
			$("#password").keystop( function(event){
				self.checkForPassword(event) ;
			}, 1000 ) ;
			$("#confirm_password").keystop( function(event){
				self.checkForConfirmPassword(event) ;
			}, 1000 ) ;

			if(Utils.isLoggedIn()){

				this.paymentPendingView.render() ;
			}
		}
	});

	ResetPasswordPage.prototype.remove = function() {
				this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	ResetPasswordPage.prototype.clean = function() {
		this.remove() ;
	};

	return ResetPasswordPage;
});
