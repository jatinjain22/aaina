define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
], function($, _, Backbone, Utils, JST ) {

	var UnsubscribePage = Backbone.View.extend({
		el: "main",
		initialize: function() {},
		events: {},
		template: JST['app/templates/unsubscribe/layout.hbs'],
		render: function() {
			this.$el.html(this.template());
		},
	});

	UnsubscribePage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	UnsubscribePage.prototype.clean = function() {

    	this.remove();

	};

	return UnsubscribePage;
});
