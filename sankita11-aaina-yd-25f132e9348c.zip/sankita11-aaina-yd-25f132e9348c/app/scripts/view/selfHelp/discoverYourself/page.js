define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

	var DiscoverYourselfPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.questions = [];
			this.currentQuestion = 1 ;
			this.answers = [];
			this.thatsmeCnt = 0 ;
			this.userModel = new UserModel();
			this.optionsSelected = {};
			this.answeredCombination = {};
			this.socialShareResponse = {};
            this.url = "";
		},
		events: {
			"click .sh-ps-start-test" : "showQuestions",
			"click .sh-ps-next" : "showNextQuestion",
			"click .sh-ps-question-card" : "selectOption",
			"click .sh-ps-question-card-mobile" : "showNextQuestion",
			"click .prev-question" : "showPrevQuestion",
			"click .next-question" : "showNextQuestion"
		},
		StartLayout : JST['app/templates/selfHelp/discoverYourself/start.hbs'],
		PageLayout : JST['app/templates/selfHelp/discoverYourself/layout.hbs'],
		QuestionnaireLayout : JST['app/templates/selfHelp/discoverYourself/questionnaire.hbs'],


		trackMixpanel : function( mixpanelEvent ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
		      mixpanel.track( mixpanelEvent, { "mediumSource" : "website", "itemName" : "Discover Yourself"} );
		    }

		},


		selectOption : function(e){
			$(e.currentTarget).addClass("selected");
			$(".sh-ps-question-card .sh-ps-question-tick i" ).removeClass("teal-text").addClass("tick-disabled");
			$(e.currentTarget).find(".sh-ps-question-tick i" ).removeClass("tick-disabled").addClass("teal-text");
		},
		showPrevQuestion : function(e){
			var self = this ;

			this.currentQuestion -= 1 ;
			questionNo = this.currentQuestion ;

			var optionsSelected = this.optionsSelected[this.currentQuestion] - 1;

			$(".sh-ps-pagination ul li").removeClass("mq-selected");
			$("#mq" + this.currentQuestion).addClass("mq-selected");

			$(".yd-self-test-holder").html(this.QuestionnaireLayout({ "question" : self.questions[this.currentQuestion-1]}));

			$("#qtick-" + optionsSelected + " i").removeClass("tick-disabled").addClass("teal-text");
			$("#qtick-" + optionsSelected).parent().addClass("selected")

		},
		showNextQuestion : function(e){

			var self = this ;

			var questionOptionSelected
			if($(e.currentTarget).hasClass("sh-ps-question-card-mobile")){
				$(e.currentTarget).addClass("selected");
				questionOptionSelected = $(".sh-ps-question-card-mobile.selected").attr("option-no");
			}else{
				questionOptionSelected = $(".sh-ps-question-card.selected").attr("option-no");
			}

			if(questionOptionSelected == undefined){
				$(".test-error").removeClass("hide");
				return true ;
			}

			$(".test-error").addClass("hide");

			if( self.questions.length <= this.currentQuestion){
				this.showAnswer();
				return true ;
			}

			var nextQuestionNo = this.currentQuestion + 1;

			$(".yd-self-test-holder").html(this.QuestionnaireLayout({ "question" : self.questions[nextQuestionNo-1]}));
			//if($(e.currentTarget).hasClass("sh-ps-question-card-mobile")){
				$(".sh-ps-pagination ul li").removeClass("mq-selected");
				$("#mq" + nextQuestionNo).addClass("mq-selected");
			//}
			$(".sh-ps-question-no").html(nextQuestionNo);

			var alreadyOptionSelected = this.optionsSelected[nextQuestionNo];
			if(alreadyOptionSelected != undefined){
				alreadyOptionSelected -= 1 ;
				$("#qtick-" + alreadyOptionSelected + " i").removeClass("tick-disabled").addClass("teal-text");
				$("#qtick-" + alreadyOptionSelected).parent().addClass("selected")	;
			//	$(".sh-ps-pagination ul li").removeClass("mq-selected");
			//	$("#mq" + nextQuestionNo).addClass("mq-selected");
			}
			this.optionsSelected[this.currentQuestion] = parseInt(questionOptionSelected) + 1 ;

			this.currentQuestion += 1 ;

		},
		showAnswer : function(){
/*			var shareHTML = $(".yd-hom-share-container");
			$(".yd-hom-content").html(shareHTML);

			var shareHTMLMobile = $(".yd-hom-share-container-mobile");
			$(".yd-hom-content").append(shareHTMLMobile);

			$(".yd-hom-share-container").removeClass("hide");
			$(".yd-hom-share-container-mobile").removeClass("hide");
*/
			var answerCombination = {
				1 : {
					1 : "c1",
					2 : "c2",
					3 : "c3"
				},
				2 : {
					1 : "c1",
					2 : "c2",
					3 : "c3"
				},
				3 : {
					1 : "c1",
					2 : "c2",
					3 : "c3"
				},
				4 : {
					1 : "c2",
					2 : "c3",
					3 : "c1"
				},
				5 : {
					1 : "c1",
					2 : "c3",
					3 : "c2"
				},
				6 : {
					1 : "c3",
					2 : "c2",
					3 : "c1"
				},
				7 : {
					1 : "c1",
					2 : "c2",
					3 : "c3"
				},
				8 : {
					1 : "c1",
					2 : "c3",
					3 : "c2"
				},
				9 : {
					1 : "c1",
					2 : "c3",
					3 : "c2"
				},
				10 : {
					1 : "c2",
					2 : "c3",
					3 : "c1"
				}

			};





			var self = this ;


			var combinationArr = {};
			combinationArr[3] = {};
			combinationArr[4] = {};
			var answerText = "" ;
			$.each( self.optionsSelected, function(key, value){

				if( key <= 2 ){
					answerText += self.answers[key]["c" + value];
					answerText += '<p class="center"><img src="https://d1hny4jmju3rds.cloudfront.net/personality_test/element.png"></p>';
					self.answeredCombination[key] =  "c" + value ;
				}

				if(key > 2 && key <= 6 ){
					var combinationSelected = answerCombination[key][value]

					if(combinationArr[3][combinationSelected] == undefined){
						combinationArr[3][combinationSelected] = 1
					}else{
						combinationArr[3][combinationSelected] += 1
					}

				}

				if(key > 6 && key <= 10 ){
					var combinationSelected = answerCombination[key][value]

					if(combinationArr[4][combinationSelected] == undefined){
						combinationArr[4][combinationSelected] = 1
					}else{
						combinationArr[4][combinationSelected] += 1
					}

				}
			});
			console.log(answerText);

			answerText += self.getAnswersTextByCombination(combinationArr[3], 3);
			answerText += self.getAnswersTextByCombination(combinationArr[4], 4);

			localStorage.discoverYourselfResult = answerText;


			var questionCombination = JSON.stringify(self.optionsSelected);



		    Backbone.history.navigate("discoverYourself/result",{trigger:true});


		},
		getAnswersTextByCombination : function(combinationAnswered, answerKey){

			var self = this ;

			var combinationsCnt = 0 ;
			var combinatonToTake = "" ;
			var answerText = "" ;
			$.each( combinationAnswered, function(key,value){
				if(value >= 2 ){
					combinationsCnt += 1 ;
					combinatonToTake = key;
				}
			});

			if(combinationsCnt == 0 || combinationsCnt > 1){
				answerText = self.answers[answerKey]["c4"];
				self.answeredCombination[answerKey] =  "c4" ;
			}else{
				answerText = self.answers[answerKey][combinatonToTake];
				self.answeredCombination[answerKey] =  combinatonToTake ;
			}

			answerText += '<p class="center"><img src="https://d1hny4jmju3rds.cloudfront.net/personality_test/element.png"></p>';

			return answerText;
		},
		showQuestions : function(){

			var self = this ;
			$('.discover-yourself-main-homePage-title').addClass( 'discover-yourself-main-title container' );

			$(".sh-ps-pagination").removeClass("hide");
			$(".yd-self-test-holder").removeClass("sh-ps-background");
			$(".yd-self-test-holder").html(this.QuestionnaireLayout({ "question" : self.questions[0]}));
			$("html, body").animate({ scrollTop: 0 }, "slow");

			self.trackMixpanel("Self Test begin");



		},
		render: function() {
			
                        document.title="Discover your True Personality | YourDOST Psychology Tests";
                        $('meta[name=description]').attr('content', "Know more about your true personality from this simple test. Also at the end of the test you can chat with experts online for personality development tips");
                        $('meta[name=title]').attr('content',"Discover your True Personality | YourDOST Psychology Tests");
                        $('meta[property="og:description"]').attr('content', "Know more about your true personality from this simple test. Also at the end of the test you can chat with experts online for personality development tips");
                        $('meta[property="og:title"]').attr('content',"Discover your True Personality | YourDOST Psychology Tests");
                 		    $('link[rel="canonical"]').attr('href', 'https://yourdost.com/discoverYourself');

			var self = this 
			
			var url = Backbone.history.getFragment();

			self.url = url;
			self.$el.html( self.PageLayout() );
			$(".yd-self-test-holder").html(self.StartLayout({}));
			self.trackMixpanel("Self Test Viewed");
			
			if(screen.width <= 600){
				$("main").css("min-height", "60vh");
			}

			$.ajax({
				url : Utils.scriptPath() + "/selfHelp/discoverYourself/question.json",
			}).done(function(response){
				console.log(response);
				self.questions = response;
			}).error(function(error){
				console.log(error)
			});

			$.ajax({
				url : Utils.scriptPath() + "/selfHelp/discoverYourself/answer.json",
			}).done(function(response){
				console.log(response);
				self.answers = response;
			}).error(function(error){
				console.log(error)
			});
			

			return this;
		}
	});

	DiscoverYourselfPage.prototype.remove = function() {};

	DiscoverYourselfPage.prototype.clean = function() {};

	return DiscoverYourselfPage;
});
