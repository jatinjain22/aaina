define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
      'view/packages/custompackage_modal',
      'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, customPackageModalView, Masonry, imagesLoaded ) {

	var DiscoverYourselfResultPage = Backbone.View.extend({
		
		el: "main",
            PageLayout : JST['app/templates/selfHelp/discoverYourself/layout.hbs'],
            AnswerLayout : JST['app/templates/selfHelp/discoverYourself/answer.hbs'],

            MobileDeviceSignInLayout: JST["app/templates/selfHelp/mobileDeviceSignIn.hbs"],
            packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],
            
		initialize: function() {
                  this.userModel = new UserModel() ;	
                  this.customPackageModalView = new customPackageModalView();		
		},

            events: {
                  "click .discover-yourself-facebook-share": "shareOnFacebook",
                  "click .sh-ps-chat" : "redirectToChat",
                  "click .yd-hom-talkItOut-mobile" : "redirectToChat",
                  "click .result-report-sign-in em": "showSignUp",
                  "click .build-custom-plan":"redirectToCustomPlan"
            },
            redirectToCustomPlan:function(){
                  var self = this;
                  
              
                        //console.log(response)
                        //console.log(response[self.result]);
                         
                        //var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
                        if(typeof mixpanel !== 'undefined'){
                             mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'discoverYourself' ,"upsellFrom":"discoverYourself","packageName":"Custom Plan"});
                         }
                        
                        var str = "1. Learn to be more organized and focused \n"+"2. Learn decision making skills \n"+"3. Learn ways to express my emotions \n"+"4. Coping with Stress"
                         self.customPackageModalView.render(str,'discoverYourself');
                         

            },
            replaceWithFalseData: function() {

                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/discoverYourself/falseAnswer.json",
                        cache: false
                  }).done(function(data){
                        var response = data["falseDiscovery"];
                        $( "p.blurredText" ).html( response );

                  }).error(function(error){
                        console.log(error)
                  });

            },
            showSignUp: function(e){


                  var url = Backbone.history.getFragment();;

                  console.log( url );
                  var buttonDesc = "show discover yourself signup";
                  Dispatcher.trigger("renderLogin", buttonDesc, "discoverYourself", "show_result_post_signup",  url) ;

            },
            trackMixpanel : function(mixpanelIdentifier){
                  
                  if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

                        mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Discover Yourself"}); 
                  }

            },
            changeCSS: function() {

                  // $("#signup-form-discover-yourself #login-modal").css({"display": "block", "width": "60%", 'top': '30%', "position": "absolute", "z-index": "10" });
                  $( ".discover-yourself-result-overlay" ).addClass("discover-yourself-result-overlay-show");
                  $( ".sh-ps-answer-container p" ).addClass( "blurredText" );
                  $( ".sh-ps-answer-footer" ).addClass( "blurredText" );
                  $( ".sh-ps-answer-container p:nth-child(1)" ).removeClass( "blurredText" );
                  $( ".sh-ps-answer-container p:nth-child(2)" ).removeClass( "blurredText" );
                  $("#modal-signupform").css("overflow", "visible");
            
            },
            shareOnFacebook: function(e) {
                  
                  var self = this;
                  console.log("hello");
                  var url = Backbone.history.getFragment();
                  var targetElement = $(".discover-yourself-social-share");
                  var loaderElement = $(".selfhelp-share-on-facebook-loader");
                  var mixpanelEvent = "Self Help Test Shared";
                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  $.ajax({
                        url : Utils.scriptPath() + "/socialShare.json",
                        cache: false
                  }).done(function(response){
                        console.log( url );
                        var socialShareResponse = response[ url ];
                    
                        console.log( 'socialShareResponse ' + JSON.stringify( socialShareResponse ) );
                        Utils.shareOnFacebook( socialShareResponse, targetElement, loaderElement, mixpanelEvent ); 

                  }).error(function(error){
                        console.log(error)
                  });
                  
            
            },
            redirectToChat : function(e){

                  var self = this;
                  
                  var buttonDesc = $(e.currentTarget).attr("data-desc");
                  if(!Utils.isLoggedIn()){
                        Dispatcher.trigger("renderLogin", buttonDesc, "discoverYourSelfselfTest", "home_chat") ;
                  }else{
                        
                        if ( !$(e.currentTarget).hasClass("disabled") ) {
                              
                              if (  ( typeof fbq != 'undefined' ) ){
                                    fbq('track', 'Lead');                           
                              }

                              var fromText = btoa("Came from Discover Your Innate Nature");

                              var username = this.userModel.getUserName() ;
                              location.href = Utils.chatUrl() + username + "&from=" + fromText;
                              $(e.currentTarget).addClass("disabled");
                        }
                  }

            },
		render: function() {

                  var self = this;
                  console.log( "enter" );

                  var url = Backbone.history.getFragment();

                  if ( !localStorage.hasOwnProperty( "discoverYourselfResult" ) ) {


                        Backbone.history.navigate("/discoverYourself",{trigger:true});
                        
                  }
                  self.$el.html( self.PageLayout() );
                  self.$el.append( self.packageBannerLayout());
                  $('.discover-yourself-main-homePage-title').addClass( 'discover-yourself-main-result-title' );
                  $(".sh-ps-pagination").addClass("hide");
                  $(".yd-self-test-holder").html(this.AnswerLayout({}));

                  $(".yd-self-test-holder").addClass("sh-ps-answer-main-container");

                  var answerText = localStorage.discoverYourselfResult;
                  $( ".sh-ps-answer-container" ).html(answerText);
                  
                  
                  if ( !Utils.isLoggedIn() ) {

                        //overlay the css
                        //show the signup
                        
                        var buttonDesc = "show discover yourself signup";
                         $('.header-right-section .login-clicked').addClass('hide')
                        if (window.matchMedia("(min-width: 601px)").matches) {

                              Dispatcher.trigger("renderLoginToDiv", buttonDesc, "discoverYourself", "show_result_post_signup", "signup-form-discover-yourself", url) ;
                              $(".login-modal-close").addClass("hide");
                              

                        } else {
                              
                              $("#signup-form-discover-yourself").html( self.MobileDeviceSignInLayout() );

                        }

                        self.changeCSS();
                        self.replaceWithFalseData();
                        Utils.trackMixPanelForSelfTestResultPage( "Self Test End", "Discover Yourself", "unseen-signup" );
                  } else  {
                        Utils.trackMixPanelForSelfTestResultPage( "Self Test End", "Discover Yourself" );
                          $('.header-right-section .login-clicked').removeClass('hide')
                        var username = self.userModel.getUserID();
                        var testName = "Discover Yourself";
                        var answer = answerText;
                              
                        Utils.storeSelfHelpResult( username, testName, answer );  
                  }
                   setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)     
                  

            }
      });

	DiscoverYourselfResultPage.prototype.remove = function() {

            this.$el.empty();
            this.$el.off();
            this.unbind(); 
      
      };

	DiscoverYourselfResultPage.prototype.clean = function() {
            this.remove();
      };

	return DiscoverYourselfResultPage;
});
