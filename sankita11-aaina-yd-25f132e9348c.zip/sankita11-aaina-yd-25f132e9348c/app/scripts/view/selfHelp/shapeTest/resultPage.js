define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
      'view/packages/custompackage_modal',
      'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel,customPackageModalView, Masonry, imagesLoaded ) {

	var ShapeTestResultPage = Backbone.View.extend({
		
		el: "main",
            
            ResultLayout: JST['app/templates/selfHelp/trueColor/result.hbs'],
             packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],
		initialize: function() {
			this.userModel = new UserModel() ;
                  this.customPackageModalView = new customPackageModalView();
                  this.result = "";

		},
            events : {
                  "click .shape-test-facebook-share": "shareOnFacebook",
                  "click .shape-test-talk-to-expert .btn": "redirectToChat",
                  "click .result-report-sign-in em": "showSignUp",
                  "click .build-custom-plan":"redirectToCustomPlan"
            },
            ShapeTestLayout: JST['app/templates/selfHelp/shapeTest/layout.hbs'],
            ShapeTestResultLayout: JST['app/templates/selfHelp/shapeTest/result.hbs'],
            MobileDeviceSignInLayout: JST["app/templates/selfHelp/mobileDeviceSignIn.hbs"],
           
            redirectToCustomPlan:function(){
                  var self = this;
                  console.log(self.result);

                  
                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/shapeTest/custom_package_prefill.json",
                  }).done(function(response){
                        
                        //console.log(response)
                        //console.log(response[self.result]);
                        
                        //var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
                        if(typeof mixpanel !== 'undefined'){
                             mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'shapeTest' ,"upsellFrom":"shapeTest","packageName":"Custom Plan"});
                         }  
                         
                         var str = response[self.result][1]+"\n"+ response[self.result][2]+"\n" +response[self.result][3];
                         self.customPackageModalView.render(str,'shapeTest');

                                             // $('.custompackage-achieve').text(str);
                        //$('#custompackage-category').val(5)


                  }).error(function(error){

                        console.log("Error ", error);
                  });

            },
            replaceWithFalseData: function() {

                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/shapeTest/falseResult.json",
                        cache: false
                  }).done(function(data){
                        var response = data["falseShape"];
                        $(".first-header").html( response["header"] );
                        $(".second-header").html( response["header2"] );
                        $(".first-shape-description").html( response["first"] );
                        $(".first-shape-description").addClass( "blurredText" );
                        $(".second-shape-description").html( response["second"] );
                        $(".second-shape-description").addClass( "blurredText" );
                        $(".riddle-result-second-sentence").html( response["riddleAnswer"] );

                  }).error(function(error){
                        console.log(error)
                  });

            },
            showSignUp: function(e){

                  var url = Backbone.history.getFragment();

                  console.log( url );
                  var buttonDesc = "show shape test signup";
                  Dispatcher.trigger("renderLogin", buttonDesc, "shapetest", "show_result_post_signup",  url) ;

            },
            changeCSS: function() {

                  $(".shape-test-result-overlay").addClass("shape-test-result-overlay-show");
                  $(".shape-description").css({"margin-left": "0rem", "margin-right": "0rem"});
                  $(".shape-test-riddle-result").css({"margin-left": "0rem", "margin-right": "0rem"});
                  $(".shape-test-result-talk-to-counselor").css({"margin-left": "0rem", "margin-right": "0rem"});
                  $(".shape-test-shape-card").addClass( "blurredText" );
                  $( ".first-header" ).addClass("blurredText");
                  $( ".second-header" ).addClass("blurredText");
                  $( ".first-shape-description li>span" ).addClass( "blurredText" );
                  $( ".second-shape-description li>span" ).addClass( "blurredText" );
                  $( ".riddle-result-first-sentence" ).addClass( "blurredText" );
                  $( ".riddle-result-second-sentence" ).addClass( "blurredText" );
                  $( ".shape-test-talk-to-counselor-first-sentence" ).addClass( "blurredText" );
                  $( ".shape-test-talk-to-counselor-second-sentence" ).addClass( "blurredText" );
                  $( ".shape-test-talk-to-expert a").addClass( "blurredText" );
            
            },

            trackMixpanel : function(mixpanelIdentifier, type){
                  
                  if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

                        if (type !== undefined) {
                              mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test", "type": type});       
                        }
                        else {
                              mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test"});       
                        }
                        
                  }

            },
            shareOnFacebook: function(e) {
                  
                  var self = this;
                  var url = Backbone.history.getFragment();;
                  var targetElement = $(".shape-test-social-share");
                  var loaderElement = $(".selfhelp-share-on-facebook-loader");
                  var mixpanelEvent = "Self Help Test Shared";
                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  $.ajax({
                        url : Utils.scriptPath() + "/socialShare.json",
                        cache: false
                  }).done(function(response){
                        console.log( url );
                        socialShareResponse = response[ url ];
                        console.log( 'socialShareResponse ' + JSON.stringify( socialShareResponse ) );
                        
                        Utils.shareOnFacebook( socialShareResponse, targetElement, loaderElement, mixpanelEvent );
                  }).error(function(error){
                        console.log(error)
                  });

                   
            
            },
            redirectToChat : function(e) {

                  var self = this;
                  var buttonDesc = $(e.currentTarget).attr("data-desc");
                  if(!Utils.isLoggedIn()){
                    Dispatcher.trigger("renderLogin", buttonDesc, "shapeselfTest", "home_chat") ;
                  }else{

                        if ( !$(e.currentTarget).hasClass("disabled") ) {
                              if (  ( typeof fbq != 'undefined' ) ){
                                    fbq('track', 'Lead');                           
                              }

                              var fromText = btoa("Came from What's Your Shape");

                              var username = this.userModel.getUserName() ;
                              location.href = Utils.chatUrl() + username + "&from=" + fromText;
                              $(e.currentTarget).addClass("disabled");
                        }   
                  }

            },
		render: function() {

                  var self = this;
                  console.log( "enter" );
                  var url = Backbone.history.getFragment();
                  

                  
                  if ( !localStorage.hasOwnProperty( "shapeTestResult" ) ) {

                        Backbone.history.navigate("/whats-your-shape",{trigger:true});
                  }
                  

                  $.ajax({
     
                        url : Utils.scriptPath() + "/selfHelp/shapeTest/result.json"

                  }).done(function(response){
                        console.log( "another hello" );

                        var riddleAnswer = response[ "RiddleAnswer" ];
                        var talkToCounselor = response[ "TalkToCounselor" ];
                        var bothShapeSame = 0;
                        var userSelectedShapesArr = localStorage.shapeTestResult.split(",");
                        var userSelectedShapes = userSelectedShapesArr;
                        var firstShapeChoice =  userSelectedShapesArr[0];
                        var secondShapeChoice = userSelectedShapesArr[1];
                        console.log( firstShapeChoice );
                        console.log( secondShapeChoice );
                        self.result = firstShapeChoice +' and '+ secondShapeChoice;
                        var responseShapes;
                        if ( firstShapeChoice === secondShapeChoice ) {
                        responseShapes = [ response[firstShapeChoice] ];  
                        userSelectedShapes = [firstShapeChoice];
                        bothShapeSame = 1;
                        }
                        else {
                        responseShapes = [ response[firstShapeChoice], response[secondShapeChoice]  ];
                        }

                        console.log( "response shapes",responseShapes );  
                        self.$el.html( self.ShapeTestLayout() );

                        $(".shape-test-inner-container").html( self.ShapeTestResultLayout( {shapes: userSelectedShapes, bothShapeSame: bothShapeSame, shapesDescription:responseShapes, riddleAnswer: riddleAnswer, talkToCounselor: talkToCounselor} ) );
                        
                        self.$el.append( self.packageBannerLayout());

        
                        Utils.scrollTo(".dost-main", 0);

                        if ( !Utils.isLoggedIn() ) {

                              localStorage.shapeTestResult = userSelectedShapesArr;
                              var buttonDesc = "show shape test signup";
                                $('.header-right-section .login-clicked').addClass('hide')
                              if (window.matchMedia("(min-width: 601px)").matches) {

                                    Dispatcher.trigger("renderLoginToDiv", buttonDesc, "shapetest", "show_result_post_signup", "signup-form-shapetest", url) ;
                                    $(".login-modal-close").addClass("hide");
                                   

                              } else {
                                    
                                    $("#signup-form-shapetest").html( self.MobileDeviceSignInLayout() );

                              }

                              self.changeCSS();
                              self.replaceWithFalseData();
                              Utils.trackMixPanelForSelfTestResultPage("Self Test End", "Shape Test", "unseen-signup");
                        } 
                        else {
                              
                              Utils.trackMixPanelForSelfTestResultPage("Self Test End", "Shape Test");  
                                $('.header-right-section .login-clicked').removeClass('hide')
                              var username = self.userModel.getUserID();
                              var testName = "Shape Test";
                              console.log( responseShapes );
                              var answer = userSelectedShapesArr.toString();
                              
                              Utils.storeSelfHelpResult( username, testName, answer );  
                        }
                        
                        

                  }).error(function(error){
                        console.log( "error" );
                        console.log(error)
                  });

                   setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)           	
            }
      });

	ShapeTestResultPage.prototype.remove = function() {

            this.$el.empty();
            this.$el.off();
            this.unbind(); 
      
      };

	ShapeTestResultPage.prototype.clean = function() {
            this.remove();
      };

	return ShapeTestResultPage;
});
