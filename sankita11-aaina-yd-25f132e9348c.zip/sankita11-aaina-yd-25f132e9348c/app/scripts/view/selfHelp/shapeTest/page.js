define([
  'jquery',
  'underscore',
  'backbone',
  '../../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

    var ShapeTestPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        this.questionText = {};
        this.selectedShapes = [];
        this.selectedShapeCount = 0;
        this.riddleAnswer = '';
        this.socialShareResponse = {};
        this.timerInterval = undefined;
        this.timerTimeout = undefined;

      },

      ShapeTestLayout: JST['app/templates/selfHelp/shapeTest/layout.hbs'],
      ShapeTestHomePage: JST['app/templates/selfHelp/shapeTest/homePage.hbs'],
      ShapeTestQuestionLayout : JST['app/templates/selfHelp/shapeTest/questionLayout.hbs'],
      ShapeTestQuestionOptionLayout : JST['app/templates/selfHelp/shapeTest/questionOptions.hbs'],
      ShapeTestRiddleLayout : JST['app/templates/selfHelp/shapeTest/riddle.hbs'],
      ShapeTestNoteLayout: JST['app/templates/selfHelp/shapeTest/testTakeNote.hbs'],


      events: {
        "click .back-to-selfHelp": "renderSelfHelp",
        "click .shape-test-start-quiz": "getFirstQuestion",
        "click .shape-test-submit-riddle .btn.enabled": "getThirdQuestion",
        "click .shape-test-note-button .btn": "renderResultPage",
        "click .shape-test-card-option": "selectShape"
      },

      trackMixpanel : function(mixpanelIdentifier, pageNo){

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

              if ( pageNo != undefined) {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test", "pageNo": pageNo});
              }
              else {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test"});
              }


        }

      },

      shareOnFacebook: function(e) {

        var self = this;
        Utils.shareOnFacebook( self.socialShareResponse, self.url );

      },

      renderSelfHelp: function() {
         Backbone.history.navigate("/selfhelp",{trigger:true});
      },

      redirectToChat : function(e) {

        var self = this;
        self.trackMixpanel( "Talk to Expert from result screen" );
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

          if ( !$(e.currentTarget).hasClass("disabled") ) {
              var username = this.userModel.getUserName() ;
             location.href = Utils.chatUrl() + username;
              $(e.currentTarget).addClass("disabled");
          }
        }

      },

      renderResultPage: function(e) {

        var self = this;
        clearInterval(self.timerInterval);
        clearTimeout(self.timerTimeout);
        console.log( "hello" );
        var userSelectedShapes = self.selectedShapes;
        localStorage.shapeTestResult = userSelectedShapes;

        Backbone.history.navigate("/whats-your-shape/result",{trigger:true});

      },

      renderTestTakerNote: function() {

          var self = this;
          clearInterval(self.timerInterval);
          clearTimeout(self.timerTimeout);
          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/shapeTest/testTakerNote.json",

          }).done(function(response){
            var title = response["title"];
            var notes = response["notes"];
            $(".shape-test-inner-container").html( self.ShapeTestNoteLayout( {title: title, notes: notes} ) );
            Utils.scrollTo(".dost-main", 0);
            self.trackMixpanel( "Step No", "4" );

          }).error(function(error){
            console.log( "error" );
            console.log(error)
          });
      },

      checkForAnswerToRiddle: function() {

          var self = this;

          var riddleAnswer = $("#answer").val();
          if ( riddleAnswer ) {
              $(".shape-test-submit-riddle .btn").removeClass("disabled").addClass("enabled");
          }
          else {
            $(".shape-test-submit-riddle .btn").addClass( "disabled" );
          }

      },

      getAnswerToRiddle: function() {

          var self = this;
          var riddleAnswer = $("#answer").val();
          this.riddleAnswer = riddleAnswer;

      },

      startCountDownTimer: function() {

          var self = this;
          var totaltime = 30;
          // clearInterval(myCounter);


          function update(percent){
            var deg;
            if(percent<(totaltime/2)){
              deg = 90 + (360*percent/totaltime);
                $('.pie').css('background-image',
                          'linear-gradient('+deg+'deg, transparent 50%, white 50%),linear-gradient(90deg, white 50%, transparent 50%)'
                         );
            } else if(percent>=(totaltime/2)){
              deg = -90 + (360*percent/totaltime);
              $('.pie').css('background-image',
                    'linear-gradient('+deg+'deg, transparent 50%, #FDE581 50%),linear-gradient(90deg, white 50%, transparent 50%)'
              );
            }
          }
          var count = parseInt($('#time').text());
          if ( typeof(self.timerInterval) === 'undefined'  && typeof(self.timerTimeout) === 'undefined' ) {

              self.timerInterval = setInterval(function () {

                count-=1;
                $('#time').html(count);
                  update(count);

              }, 1000);

              self.timerTimeout = setTimeout(function(){

                clearInterval(self.timerInterval);
                clearTimeout(self.timerTimeout);
                self.getThirdQuestion();

              }, 30000);

          }
          


      },

      renderRiddle: function() {

          var self = this;
          clearInterval(self.timerInterval);
          clearInterval(self.timerTimeout);
          questionCount = 1;
          var questionText = self.questionText[questionCount];
          var title = questionText[ "title" ];
          var description = questionText[ "description" ];
          var questionNo = questionCount + 1;

          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/shapeTest/riddle.json",

          }).done(function(response){

            var riddleFirstDescription = response["first-description"];
            var riddleSecondDescription = response["second-description"];
            $( ".shape-test-inner-container" ).html( self.ShapeTestQuestionLayout({title: title, description: description, questionNo: questionNo}) );
            $( ".shape-test-next-quiz" ).addClass( "hide" );
            $( ".shape-test-question-option-container" ).html( self.ShapeTestRiddleLayout( {firstDescription:riddleFirstDescription, secondDescription: riddleSecondDescription} ) );
            Utils.scrollTo(".dost-main", 0);
            self.trackMixpanel( "Step No", "2" );
            self.startCountDownTimer();
            $("#answer").keystop( function(event){
                self.checkForAnswerToRiddle(event) ;
            }, 1000 ) ;

          }).error(function(error){

            console.log(error)
          });


      },

      selectShape: function(e) {
        var self = this;
        $(e.currentTarget).find( 'input[name="selected-shape"]' ).prop( "checked", true );
        var selectedShape = $('input[name="selected-shape"]:checked', '#shape-test-form').val();

        if ( selectedShape ) {

            self.selectedShapes[ self.selectedShapeCount ] = selectedShape;
            $( ".shape-test-next-quiz .btn" ).removeClass( "disabled" ).addClass("enabled");
            setTimeout(function(){

              if ( self.selectedShapeCount == 0) {
                self.renderRiddle();
              }
              else if (self.selectedShapeCount == 1){
                self.renderTestTakerNote();
              }

            }, 100);

        }

      },

      renderShapeQuestion: function( questionCount ) {

          var self = this;
          clearInterval(self.timerInterval);
          clearTimeout(self.timerTimeout);
          var questionText = self.questionText[questionCount];
          var title = questionText[ "title" ];
          var description = questionText[ "description" ];
          var questionNo = questionCount + 1;
          $(".shape-test-inner-container").html( self.ShapeTestQuestionLayout({title: title, description: description, questionNo: questionNo }) );
          $(".shape-test-question-option-container").html( self.ShapeTestQuestionOptionLayout() );
      },

      getThirdQuestion: function() {

          var self = this;
          console.log( 'timer '+ self.timer );
          clearInterval(self.timerInterval);
          clearTimeout(self.timerTimeout);
          questionCount = 2;
          self.selectedShapeCount = 1;
          self.renderShapeQuestion( questionCount );
          Utils.scrollTo(".dost-main", 0);
          self.trackMixpanel( "Step No", "3" );
          console.log( "hello" );
      },

      getFirstQuestion: function() {

          var self = this;
          clearInterval(self.timerInterval);
          clearTimeout(self.timerTimeout);
          self.trackMixpanel("Self Test begin");
          questionCount = 0;
          self.selectedShapeCount = 0;
          $(".shape-test-top-title").addClass("shape-test-main-pages-top-title");
          self.renderShapeQuestion( questionCount );
          Utils.scrollTo(".dost-main", 0);
          self.trackMixpanel( "Step No", "1" );
      },


      render: function() {

          document.title="Simple Personality & Self Help Tests | YourDOST";
          $('meta[name=description]').attr('content', "Take this shape test to know if you have a square, rectangle, or triangle type personality & also you can chat with experts to know more & develop personality");
          $('meta[name=title]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
          $('meta[property="og:description"]').attr('content', "Take this shape test to know if you have a square, rectangle, or triangle type personality & also you can chat with experts to know more & develop personality");
          $('meta[property="og:title"]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
          $('link[rel="canonical"]').attr('href', 'https://yourdost.com/whats-your-shape');
          var self = this;
          clearInterval(self.timerInterval);
          clearTimeout(self.timerTimeout);
          var url = window.location.hash;
          self.url = url;
          self.trackMixpanel( "Self Test Viewed" );
          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/shapeTest/homePage.json",

          }).done(function(response){

            self.$el.html( self.ShapeTestLayout() );

            console.log( "response " + JSON.stringify(response) );
            console.log( response["title"] );
            var title = response[ "title" ];
            var description = response[ "description" ]
            $(".shape-test-inner-container").html( self.ShapeTestHomePage( {title: title, description: description} ) );

          }).error(function(error){
            console.log(error)
          });

          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/shapeTest/questionText.json",

          }).done(function(response){

            self.questionText = response;
            console.log( self.questionText );

          }).error(function(error){
            console.log( "error" );
            console.log(error)
          });


      }

    });

  ShapeTestPage.prototype.remove = function() {

      clearInterval(this.timerInterval);
      clearTimeout(this.timerTimeout);
      this.$el.empty();
      this.$el.off();
      this.unbind();
	};

	ShapeTestPage.prototype.clean = function() {

      this.remove();

	};

    return ShapeTestPage;
});
