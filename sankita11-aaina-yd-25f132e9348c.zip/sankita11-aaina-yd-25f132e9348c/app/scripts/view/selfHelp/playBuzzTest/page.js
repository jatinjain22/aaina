define([
  'jquery',
  'underscore',
  'backbone',
  '../../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users',
  'iframeResizer'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, iFrameResize ) {

    var PlayBuzzTestPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      
      // PlayBuzzTestPageLayoutTemplate : JST['app/templates/selfHelp/playBuzzTest/layout.hbs'],
      PlayBuzzTestIFrameTemplate: JST['app/templates/selfHelp/playBuzzTest/iframe_layout.hbs'],

      events: {
        "click .back-to-selfHelp": "renderSelfHelp"
      }, 
      renderSelfHelp: function() {
        Backbone.history.navigate("/selfhelp",{trigger:true});
      },
      
      playGame: function(e) {
        var self = this;
        console.log( "hello" );
        console.log( "currentTarget" );
        console.log( $(e.currentTarget) );
        var dataSet = $(e.currentTarget).context.dataset;
        console.log( dataSet );
        var url = dataSet.url;
        var content = dataSet.content;
        var title = dataSet.title;
        self.$el.html( self.PlayBuzzTestIFrameTemplate({url:url, content:content, title: title}) );
      },
      
      // onLoad: function(obj) {
      //   console.log('onLoad');
      //   console.log( obj );
      //   console.log( obj.target.clientHeight );
      //   obj.currentTarget.clientHeight=600;
      //   console.log( 'resizing' );
      //   obj.style.height = obj.target.contentWindow.document.body.scrollHeight + 'px';
      //   console.log( obj.target.contentWindow );
                
      // },
      onLoad: function() {
        // var self = this;
        $('.iframe-loader').addClass('hide');
        $('.pb_feed_iframe').removeClass('hide');
      },
      render: function() {

        var self = this;
        var url = window.location.href ;
        url = url.replace("/playbuzztest", "" );
        var id    = $.url( url ).param('id');
        var intId = parseInt(id);
        setTimeout(function(){
          if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
            console.log( 'inside mixpanel' );
            if (intId === 1) {
              mixpanel.track('PlayBuzz Test Page', {'mediumSource' : 'website', 'itemtype': 'PlayBuzz Test Page', 'itemName': 'Deepest Secrets'});

        document.title="Subconscious Personality Test | YourDOST Psychology Tests";
        $('meta[name=description]').attr('content', "Take this personality test to know more about your subconcious personality & also to know more about your personality, chat with experts online");
        $('meta[name=title]').attr('content',"Subconscious Personality Test | YourDOST Psychology Tests");
        $('meta[property="og:description"]').attr('content', "Take this personality test to know more about your subconcious personality & also to know more about your personality, chat with experts online");
        $('meta[property="og:title"]').attr('content',"Subconscious Personality Test | YourDOST Psychology Tests");
        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/playbuzztest?fromPage=selfhelp&id=1');
            }
            else {
             mixpanel.track('PlayBuzz Test Page', {'mediumSource' : 'website', 'itemtype': 'PlayBuzz Test Page', 'itemName': 'Know Your True Personality'}); 

        document.title="Test that Revals your True Personality | YourDOST";
        $('meta[name=description]').attr('content', "Take this test to know your true personality. You can also chat online with experts for personality devlopment tips");
        $('meta[name=title]').attr('content',"Test that Revals your True Personality | YourDOST");
        $('meta[property="og:description"]').attr('content', "Take this test to know your true personality. You can also chat online with experts for personality devlopment tips");
        $('meta[property="og:title"]').attr('content',"Test that Revals your True Personality | YourDOST");
        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/playbuzztest?fromPage=selfhelp&id=2');
            }
          
          } 
        }, 2000);

        $.ajax({
        
          url: Utils.scriptPath() + "/selfHelp/playBuzzTest/selfCtrl.json",
        
        }).done( function( data ) {

            // self.$el.html( self.PlayBuzzTestPageLayoutTemplate({playBuzzGames: data}) );
            // self.$el.find('iframe').on('load', _.bind(self.onLoad, this))
            console.log( "data" );
            console.log( data );

            var url = data[intId-1].url;
            var title = data[intId-1].title;

            self.$el.html( self.PlayBuzzTestIFrameTemplate({url:url, title: title}) );
            self.$el.find('iframe').on('load', _.bind(self.onLoad, this));
            // Utils.checkFromPageIsSelfHelp( "#personalitytest" );
            // self.$el.find('iframe').on('load', _.bind(self.onLoad, this));
            // self.$el.find('iframe').iFrameResize({sizeHeight: true});

            /*
            function resizeIframe(obj) {
              obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
            }
            */
        
        }).error(function(error){
        
          console.log(error)
        
        });

        

      }

    });

  PlayBuzzTestPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind(); 
	};

	PlayBuzzTestPage.prototype.clean = function() {

      this.remove();

	};

    return PlayBuzzTestPage;
});
