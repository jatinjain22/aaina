define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel,Masonry, imagesLoaded ) {

	var newYearQ2ResultPage = Backbone.View.extend({
		
		el: "main",

    newYearQ2Layout: JST['app/templates/selfHelp/newYearQ2/layout.hbs'],
    newYearQ2ResultLayout : JST['app/templates/selfHelp/newYearQ2/result.hbs'],
    
    initialize: function() {
      
      this.result = 0;
    },
    
    events : {
      
      "click .newYearQ2-description .btn":"redirectToPackages",
    },

    redirectToPackages: function(){

      if( parseInt(localStorage.newYearQ2Result) == 7 ){

        this.trackMixpanelEvents("Button Click", "newYearQ2", "Redirecting to Chat") ;
        
        if(!Utils.isLoggedIn()){
        
          Dispatcher.trigger("renderLogin", "new year quiz2", "newYearQ2", "home_chat") ;
        }else{
    
          Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "newYearQ2");
        }

      }else{

        this.trackMixpanelEvents("Button Click", "newYearQ2", "Direct to Packages")
        Backbone.history.navigate("/new-year-resolution",{trigger:true});
      }
    },

    trackMixpanelEvents : function(identifier, itemName, itemType){

      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

        mixpanel.track(identifier, { "itemName" : itemName, "itemType" : itemType});
      }

    },

    getContent : function( url ){

      var deferred = $.Deferred();
      $.ajax({
        method : 'GET',
        url : url,

      }).done(function(response){

        deferred.resolve(response);

      }).error(function(error){

        deferred.reject(error);
      })

      return deferred.promise();
    },
               
    render: function() {
      
      if ( !localStorage.hasOwnProperty( "newYearQ2Result" ) ) {

        Backbone.history.navigate("/will-you-succeed-in-your-resolution",{trigger:true});

      }

      document.title="Will you succeed in your New Year Resolution? | YourDOST";
        
      $('meta[name=description]').attr('content', "Take this test and find out if you can really achieve your resolution in 2017");
      $('meta[name=title]').attr('content'," Will you succeed in your New Year Resolution? | YourDOST");
      $('meta[property="og:url"]').attr('content',"https://yourdost.com/will-you-succeed-in-your-resolution"); 
      $('meta[property="og:description"]').attr('content', "Take this test and find out if you can really achieve your resolution in 2017");
      $('meta[property="og:title"]').attr('content'," Will you succeed in your New Year Resolution? | YourDOST");
      $('meta[property="og:image"]').attr('content',"https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearQ2/quiz2-thumb-350x250.png");
      $('meta[property="og:url"]').attr('content',"https://yourdost.com/will-you-succeed-in-your-resolution");
      $('link[rel="canonical"]').attr('href', 'https://yourdost.com/will-you-succeed-in-your-resolution');

      this.result = parseInt(localStorage.newYearQ2Result);

      var resultPromise = this.getContent( Utils.scriptPath() + "/selfHelp/newYearQ2/answer_mapping.json" );
      
      this.trackMixpanelEvents("newYearQ2-Result", "","");

      var self = this;

      self.$el.html( this.newYearQ2Layout());

      $.when(resultPromise)
      .then(function(response){

        if( self.result < 5 ){

          self.result = response.low;
        }else if( self.result >= 5 && self.result < 7 ){

          self.result = response.moderate
        }else{

          self.result = response.high;
        }

        self.$el.find(".newYearQ2-inner").html(self.newYearQ2ResultLayout( { result : self.result } ) )

      }, function(error){

        console.log("Error ", error);
      })
    }

  });

	newYearQ2ResultPage.prototype.remove = function() {

    this.$el.empty();
    this.$el.off();
    this.unbind(); 
  
  };

	newYearQ2ResultPage.prototype.clean = function() {

    this.remove();
  };

	return newYearQ2ResultPage;
});
