define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

	var newYearQ2Page = Backbone.View.extend({

		el: "main",

		initialize: function() {
			
			this.questions = [];
			this.yesCount = 0;
			this.noCount = 0;
		},

		newYearQ2Layout: JST['app/templates/selfHelp/newYearQ2/layout.hbs'],
		newYearQ2Start : JST['app/templates/selfHelp/newYearQ2/start.hbs'],
		newYearQ2Questions : JST['app/templates/selfHelp/newYearQ2/questions.hbs'],

		events: {
			
			'click .newYearQ2-start-quiz' : 'startQ2',
			'click .newYearQ2-submit-btn' : 'selectAnswer',
			'click .newYearQ2-submit .submit' : 'showResult'
		},

		getInt : function( val ){

			return parseInt(val);
		},

		changeCount : function(){


		},
		trackMixpanelEvents : function(identifier, itemName, itemType){

	      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

	        mixpanel.track(identifier, { "itemName" : itemName, "itemType" : itemType});
	      }

	    },

		selectAnswer : function(evt){

			var current = $(evt.currentTarget);
			var parent = $(evt.currentTarget).parents('.newYearQ2-question');

			if( current.hasClass("selected")){

				return ;
			}

			var ans = current.attr("data-answer");

			if( parent.find(".selected").length > 0 ){

				var prevAns = parent.find(".selected").attr("data-answer");

				if( prevAns == "yes" && ans == "no" && this.yesCount > 0){

					this.yesCount = this.getInt(this.yesCount) -1; 
				}
				if(  prevAns == "no" && ans == "yes" && this.noCount > 0){

					this.noCount = this.getInt(this.noCount) - 1; 
				}

				parent.find(".newYearQ2-submit-btn").removeClass("selected");
			}

			current.addClass("selected");

			if( ans == "yes" ){

				this.yesCount = this.getInt(this.yesCount) + 1; 
			}
			if( ans == "no" ){

				this.noCount = this.getInt(this.noCount) + 1; 
			}


			if( this.noCount + this.yesCount == this.questions.length ){

				$(".newYearQ2-submit .submit").attr("disabled", false).removeClass("disabled")
			}else{

				$(".newYearQ2-submit .submit").attr("disabled", true).addClass("disabled")
			}
		},

		startQ2 : function(){

			this.trackMixpanelEvents("Button Click", "newYearQ2-start", " ")

			this.$el.find(".newYearQ2-inner").html( this.newYearQ2Questions( { questions : this.questions} ) );
		},

		showResult : function(){

			localStorage.newYearQ2Result = this.yesCount;

			Backbone.history.navigate("/will-you-succeed-in-your-resolution/result",{trigger:true});
		},

		getContent : function( url ){

			var deferred = $.Deferred();
			$.ajax({
				method : 'GET',
				url : url,

			}).done(function(response){

				deferred.resolve(response);

			}).error(function(error){

				deferred.reject(error);
			})

			return deferred.promise();
		},
		
		render: function() {

			//$(".dost-main").css({"background" : "#f2f2f2"})
			document.title="Will you succeed in your New Year Resolution? | YourDOST";
        
          	$('meta[name=description]').attr('content', "Take this test and find out the chances of your success in achieving your resolution!");
          	$('meta[name=title]').attr('content'," Will you succeed in your New Year Resolution? | YourDOST");
          	$('meta[property="og:url"]').attr('content',"https://yourdost.com/will-you-succeed-in-your-resolution"); 
          	$('meta[property="og:description"]').attr('content', "Take this test and find out the chances of your success in achieving your resolution!");
          	$('meta[property="og:title"]').attr('content'," Will you succeed in your New Year Resolution? | YourDOST");
          	$('meta[property="og:image"]').attr('content',"https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearQ2/quiz2-thumb-350x250.png");
          	$('meta[property="og:url"]').attr('content',"https://yourdost.com/will-you-succeed-in-your-resolution");
          	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/will-you-succeed-in-your-resolution');

			this.$el.html( this.newYearQ2Layout() );
			this.$el.find(".newYearQ2-inner").html( this.newYearQ2Start() );

			var Questions = this.getContent( Utils.scriptPath() + "/selfHelp/newYearQ2/questions.json" );
			
			this.trackMixpanelEvents("newYearQ2-page", "newYearQ2-questions", " ")

			var self = this;

			$.when(Questions)
			.then(function(response){

				self.questions = response.questions;

			}, function(error){

				console.log("Error ", error);
			})
		}

	});

	newYearQ2Page.prototype.remove = function() {

		$(".dost-main").css({"background" : "#fff"})
	};

	newYearQ2Page.prototype.clean = function() {};

	return newYearQ2Page;
});
