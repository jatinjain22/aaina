define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function ($, _, Backbone, JST, Utils, Dispatcher, UserModel) {
	var stressTestPro = Backbone.View.extend({
		el: "main",
		initialize: function () {
			this.questionNo = 1;
			this.questions = {};
			this.mappingObj = {};
			this.mappingScoreObj = {};
			this.optionIndex = -1;
			this.finalScore = 0;
			this.score = 0;
		},
		emotionalWellnessLayout: JST['app/templates/selfHelp/stressTestProfessional/layout.hbs'],
		startemotionalWellnessLayout: JST['app/templates/selfHelp/stressTestProfessional/start.hbs'],
		questionsLayout: JST['app/templates/selfHelp/stressTestProfessional/questions.hbs'],
		events: {
			'click .ew-start-quiz': 'startQuiz',
			'click .ew-next': 'nextQuestion',
			'click .ew-prev': 'prevQuestion',
			'click .ew-options': 'selectOption',
			'click .ew-img-box': 'selectOption',
			'click .ew-show-result': 'showResult',
			'keyup .inputText': 'enterText',
		},
		trackMixpanelEvents: function (identifier, itemName, itemType) {
			if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
				mixpanel.track(identifier, { "itemName": itemName, "itemType": itemType });
			}
		},
		startQuiz: function () {
			this.trackMixpanelEvents("BUtton Click", "start Stress test for professionals quiz", "clicked start Stress test for professionals quiz")
			this.renderQuestions()
		},
		findSelectedOption: function (option, className) {
			this.optionIndex = $("." + className).index($(option.currentTarget)) + 1
			this.score = $(option.currentTarget).attr("data-score")
		},
		selectOption: function (evt) {
			var className = "ew-options"
			if ($(evt.currentTarget).hasClass("input")) {
				className = "inputText"
			}
			$("." + className).removeClass("option-selected")
			$(evt.currentTarget).addClass("option-selected")
			$(".ew-next").removeClass("disabled")
			this.findSelectedOption(evt, className)
			if (this.questionNo == Object.keys(this.questions).length) {
				$(".ew-next").removeClass("ew-next").addClass("ew-show-result").html("<b>SHOW RESULT &gt;</b>")
			}
		},
		mapInputText: function (evt) {
			this.optionIndex = $(evt.currentTarget).parents(".ew-sub-inner").find(".inputText").val()
			this.score = 0;
		},
		enterText: function (evt) {
			var inputDiv = $(evt.currentTarget).parents(".ew-sub-inner").find(".inputText")
			if (inputDiv.val() == "") {
				$(evt.currentTarget).parents(".ew-sub-inner").find(".ew-next").addClass("disabled")
				if (this.questionNo == Object.keys(this.questions).length)
					$(".ew-show-result").removeClass("ew-show-result").addClass("ew-next").addClass("disabled").html("<b>NEXT &gt;</b>")
				return;
			}
			$(evt.currentTarget).parents(".ew-sub-inner").find(".ew-next").removeClass("disabled")
			if (this.questionNo == Object.keys(this.questions).length) {
				$(".ew-next").removeClass("ew-next").addClass("ew-show-result").html("<b>SHOW RESULT &gt;</b>")
			}
		},
		nextQuestion: function (evt) {
			if ($(evt.currentTarget).parents(".ew-sub-inner").find(".inputText").length) {
				this.mapInputText(evt)
			}
			this.trackMixpanelEvents("Button Click", "Clicked Next Question", this.questionNo)
			this.mappingObj[this.questionNo] = this.optionIndex;
			this.mappingScoreObj[this.questionNo] = this.score;
			//this.finalScore += parseInt(this.score)
			this.questionNo++;
			this.renderQuestions(false)
		},
		prevQuestion: function (evt) {
			this.questionNo--;
			this.renderQuestions(true)
		},
		renderQuestions: function (option) {
			var questionsObj = this.questions;
			var self = this;
			var question = questionsObj[self.questionNo]
			question["qNo"] = this.questionNo;
			this.$el.find(".ew-sub-inner").html(this.questionsLayout({ question: question, totalQues: Object.keys(this.questions).length }))
			if (option) {
				if (question.type == "input") {
					$(".ew-sub-inner").find(".inputText").val(this.mappingObj[this.questionNo])
				} else {
					$(".ew-options:nth-child(" + this.mappingObj[this.questionNo] + ")").addClass("option-selected")
				}
				$(".ew-next").removeClass("disabled")
			}
			if (Utils.isMobileDevice()) {
				$("body").animate({ scrollTop: 0 }, '1000')
			}
			if (this.questionNo > 1) {
				$(".ew-prev").removeClass("disabled")
			}
		},
		showResult: function (evt) {
			if ($(evt.currentTarget).parents(".ew-sub-inner").find(".inputText").length) {
				this.mapInputText(evt)
			}
			this.mappingObj[this.questionNo] = this.optionIndex;
			this.mappingScoreObj[this.questionNo] = this.score;
			//this.finalScore += parseInt(this.score)
			var resultArr = Object.values(this.mappingScoreObj)
			this.finalScore = resultArr.reduce(function (prev, curr) {
				return parseInt(prev) + parseInt(curr)
			})
			this.trackMixpanelEvents("BUtton Click", "show result Stress test for professionals", "clicked show result Stress test for professionals")
			localStorage.setItem("stressTestProfessionalScore", this.finalScore);
			this.updateToFirebase()
			Backbone.history.navigate("/stress-test-working-professionals/result", { trigger: true });
		},
		updateToFirebase: function () {
			var self = this;
			this.getContent({ method: 'GET', url: Utils.contextPath() + '/v2/users/organisation' })
				.then(function (res) {
					self.updateFirebase(res)
				}, function (err) {
					console.log("Error: ", err)
				})
		},
		updateFirebase: function (orgId) {
			var firebaseObj = Utils.updateEmotionalWellness("stressTestProfessionals");
			var today = new Date().toLocaleString();
			var userObj = {
				"userId": -1,
				"answers": this.mappingObj || {},
				"result": this.finalScore || 0,
				"orgId": orgId,
				"userName": "",
				"created": today
			}
			if (Utils.isLoggedIn()) {
				var userObject = JSON.parse(localStorage.getItem("user"))
				userObj["userId"] = userObject['id'],
					userObj["orgId"] = userObject['loggableUser']['orgId'],
					userObj["userName"] = userObject['username']
			}
			firebaseObj.set(userObj)
		},
		getContent: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				}).error(function (error) {
					deferred.reject(error);
				})
			return deferred.promise();
		},
		render: function () {
			document.title = "Stress test for working professionals";
			$('meta[name=description]').attr('content', "In an age, where work-life balance is hard to find, and deadlines seem to be the only thing everyone's chasing, it's obvious that anyone will be stressed. But the more important question is, are you the one who's stressed a lot? Find out now.");
			$('meta[name=title]').attr('content', "Stress test for working professionals");
			$('meta[property="og:url"]').attr('content', "https://yourdost.com/stress-test-working-professionals");
			$('meta[property="og:description"]').attr('content', "In an age, where work-life balance is hard to find, and deadlines seem to be the only thing everyone's chasing, it's obvious that anyone will be stressed. But the more important question is, are you the one who's stressed a lot? Find out now.");
			$('meta[property="og:title"]').attr('content', "Stress test for working professionals");
			$('meta[property="og:image"]').attr('content', "https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
			$('meta[property="og:url"]').attr('content', "https://yourdost.com/stress-test-working-professionals ");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/stress-test-working-professionals');

			this.$el.html(this.emotionalWellnessLayout());
			this.$el.find(".ew-sub-inner").html(this.startemotionalWellnessLayout())
			var Questions = this.getContent({ method: 'GET', url: Utils.scriptPath() + "/selfHelp/stressTestProfessional/questions.json" });
			this.trackMixpanelEvents("Stress test for professionals", "Stress test for professionals", " ")
			var self = this;
			$.when(Questions)
				.then(function (response) {
					self.questions = response.questions;
				}, function (error) {
					console.log("Error ", error);
				})
		}
	});
	stressTestPro.prototype.remove = function () {
		$(".dost-main").css({ "background": "#fff" })
		this.$el.empty();
		this.$el.off();
		this.stopListening();
		this.undelegateEvents();
		this.unbind();
	};
	stressTestPro.prototype.clean = function () {
		this.remove();
	};
	return stressTestPro;
});
