define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, Masonry, imagesLoaded ) {

	var stressTestProResult = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.userModel = new UserModel()
		},
    events : {
      "click .ewr-chat-btn" : "initiateChat",
    },
    ResultLayout: JST['app/templates/selfHelp/stressTestProfessional/result.hbs'],
    mainLayout: JST['app/templates/selfHelp/stressTestProfessional/layout.hbs'],
    redirect: function () {
			Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {});
		},
		initiateChat: function () {
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat'
					},
					callback: this.redirect
				} ) ;
			} else {
				this.redirect();
			}
    },
    getContent : function( url ){
			var deferred = $.Deferred();
			$.ajax({method : 'GET',url : url})
      .done(function(response){
				deferred.resolve(response);
			}).error(function(error){
				deferred.reject(error);
			})
			return deferred.promise();
		},
    postSignup : function(options){
      console.log(options)
      if(options.result){
        this.$el.html(this.ResultLayout( { result : options.result[this.result] , loggedIn : Utils.isLoggedIn()} ) )
      }
      this.updateFirebase(false)
    },
    updateFirebase : function(loggedIn){
			if(!loggedIn){
	      var firebaseObj = Utils.updateEmotionalWellness("stressTestProfessionals");
	      var userObject = JSON.parse(localStorage.getItem("user"))
	      firebaseObj.update({
	        "userId" : userObject['id'],
	        "orgId" : userObject['loggableUser']['orgId'],
	        "userName" : userObject['username']
	      })
			}
			setTimeout(function(){
				localStorage.removeItem("testID");
				localStorage.removeItem("stressTestProfessionalScore")
			}, 1000)
    },
    showResult : function(res){
      if(Utils.isLoggedIn()){
        this.$el.html(this.ResultLayout( { result : res[this.result] , loggedIn : Utils.isLoggedIn()} ) )
        this.updateFirebase(true)
      }else{
        $('.header-right-section .login-clicked').addClass('hide')
        this.$el.html(this.ResultLayout( { result : res[this.result], loggedIn : Utils.isLoggedIn()} ) )
        Dispatcher.trigger("renderLoginToDiv", "", "stressTestProfessionalScore", "ew_test", "ew_signup", {
					options : {
						result: res
					},
					callback: this.postSignup.bind(this)
				});
        $(".login-modal-close").addClass("hide");
      }
    },
		render: function() {
      document.title = "Stress test for working professionals result";
			$('meta[name=description]').attr('content', "In an age, where work-life balance is hard to find, and deadlines seem to be the only thing everyone's chasing, it's obvious that anyone will be stressed. But the more important question is, are you the one who's stressed a lot? Find out now.");
			$('meta[name=title]').attr('content', "Stress test for working professionals");
			$('meta[property="og:url"]').attr('content', "https://yourdost.com/stress-test-working-professionals");
			$('meta[property="og:description"]').attr('content', "In an age, where work-life balance is hard to find, and deadlines seem to be the only thing everyone's chasing, it's obvious that anyone will be stressed. But the more important question is, are you the one who's stressed a lot? Find out now.");
			$('meta[property="og:title"]').attr('content', "Stress test for working professionals");
			$('meta[property="og:image"]').attr('content', "https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
			$('meta[property="og:url"]').attr('content', "https://yourdost.com/stress-test-working-professionals/result");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/stress-test-working-professionals/result');
      var self = this;
      var url = Backbone.history.getFragment();
      if ( !localStorage.hasOwnProperty( "stressTestProfessionalScore" ) ) {
        Backbone.history.navigate("/stress-test-working-professionals",{trigger:true});
        return;
      }
      this.result = parseInt(localStorage.stressTestProfessionalScore)
      if(this.result > -1 && this.result < 15){
        this.result = "low"
      }else if(this.result > 14 && this.result < 31){
        this.result = "moderate"
      }else if(this.result > 30 && this.result < 55){
        this.result = "high"
      }else{
        this.result = "veryHigh"
      }
      $.when(this.getContent( Utils.scriptPath() + "/selfHelp/stressTestProfessional/result.json" ))
      .then(function(res){
        self.showResult(res)
      }, function(err){
        console.log("Error: ",err)
      })
    }
  });
  stressTestProResult.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind();
  };
  stressTestProResult.prototype.clean = function() {
    this.remove();
  };
	return stressTestProResult;
});
