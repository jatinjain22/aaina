define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, Masonry, imagesLoaded ) {

	var emotionalWellnessResult = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.userModel = new UserModel()
		},
    events : {
      "click .ewr-chat-btn" : "initiateChat",
    },
    ResultLayout: JST['app/templates/selfHelp/emotionalWellness/result.hbs'],
    mainLayout: JST['app/templates/selfHelp/emotionalWellness/layout.hbs'],
    redirect: function () {
			Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {});
		},
		initiateChat: function () {
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat'
					},
					callback: this.redirect
				} ) ;
			} else {
				this.redirect();
			}
    },
    getContent : function( url ){
			var deferred = $.Deferred();
			$.ajax({method : 'GET',url : url})
      .done(function(response){
				deferred.resolve(response);
			}).error(function(error){
				deferred.reject(error);
			})
			return deferred.promise();
		},
    postSignup : function(options){
      console.log(options)
      if(options.result){
        this.$el.html(this.ResultLayout( { result : options.result[this.result] , loggedIn : Utils.isLoggedIn()} ) )
      }
      this.updateFirebase(false)
    },
    updateFirebase : function(loggedIn){
			if(!loggedIn){
	      var firebaseObj = Utils.updateEmotionalWellness("emotionalWellnessTest");
	      var userObject = JSON.parse(localStorage.getItem("user"))
	      firebaseObj.update({
	        "userId" : userObject['id'],
	        "orgId" : userObject['loggableUser']['orgId'],
	        "userName" : userObject['username']
	      })
			}
			setTimeout(function(){
				localStorage.removeItem("testID");
				localStorage.removeItem("emotionalWellnessTest")
			}, 1000)
    },
    showResult : function(res){
      if(Utils.isLoggedIn()){
        this.$el.html(this.ResultLayout( { result : res[this.result] , loggedIn : Utils.isLoggedIn()} ) )
        this.updateFirebase(true)
      }else{
        $('.header-right-section .login-clicked').addClass('hide')
        this.$el.html(this.ResultLayout( { result : res[this.result], loggedIn : Utils.isLoggedIn()} ) )
        Dispatcher.trigger("renderLoginToDiv", "", "emotionalWellnessTest", "ew_test", "ew_signup", {
					options : {
						result: res
					},
					callback: this.postSignup.bind(this)
				});
        $(".login-modal-close").addClass("hide");
      }
    },
		render: function() {
			document.title="Emotional Wellness Test For Students Result";
    	$('meta[name=description]').attr('content', "As a student, you would agree that tests are a major stress-inducers. But all tests don't have to be that way. Here's a test that won't stress you but will tell you just how stressed you are.");
    	$('meta[name=title]').attr('content',"Emotional Wellness Test For Students Result");
    	$('meta[property="og:description"]').attr('content', "As a student, you would agree that tests are a major stress-inducers. But all tests don't have to be that way. Here's a test that won't stress you but will tell you just how stressed you are.");
    	$('meta[property="og:title"]').attr('content',"Emotional Wellness Test For Students Result");
    	$('meta[property="og:image"]').attr('content',"https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
    	$('meta[property="og:url"]').attr('content',"https://yourdost.com/emotional-wellness-test/result ");
    	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/emotional-wellness-test/result');
      var self = this;
      var url = Backbone.history.getFragment();
      if ( !localStorage.hasOwnProperty( "emotionalWellnessTest" ) ) {
        Backbone.history.navigate("/emotional-wellness-test",{trigger:true});
        return;
      }
      this.result = parseInt(localStorage.emotionalWellnessTest)
      if(this.result > -1 && this.result < 15){
        this.result = "low"
      }else if(this.result > 14 && this.result < 31){
        this.result = "moderate"
      }else if(this.result > 30 && this.result < 55){
        this.result = "high"
      }else{
        this.result = "veryHigh"
      }
      $.when(this.getContent( Utils.scriptPath() + "/selfHelp/emotionalWellness/result.json" ))
      .then(function(res){
        self.showResult(res)
      }, function(err){
        console.log("Error: ",err)
      })
    }
  });
	emotionalWellnessResult.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind();
  };
	emotionalWellnessResult.prototype.clean = function() {
    this.remove();
  };
	return emotionalWellnessResult;
});
