define([
  'jquery',
  'underscore',
  'backbone',
  '../../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users',
  'masonry',
  'imagesloaded'
], function ($, _, Backbone, JST, Utils, Dispatcher, UserModel, Masonry, imagesLoaded) {

  var kickTheButtResult = Backbone.View.extend({
    el: "main",
    initialize: function () {
      if (Utils.isLoggedIn()) {
        this.userModel = new UserModel()
      } else {
        Backbone.history.navigate("/dashboard", { trigger: true });
      }

    },
    events: {
      "click .ewr-chat-btn": "initiateChat",
    },
    ResultLayout: JST['app/templates/selfHelp/kickthebutt/result.hbs'],
    mainLayout: JST['app/templates/selfHelp/kickthebutt/layout.hbs'],
    redirect: function () {
      Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {});
    },
    initiateChat: function () {
      if (!Utils.isLoggedIn()) {
        Dispatcher.trigger("renderLogin", "", "", "free_chat", {
          options: {
            type: 'chat'
          },
          callback: this.redirect
        });
      } else {
        this.redirect();
      }
    },
    getContent: function (url) {
      var deferred = $.Deferred();
      $.ajax({ method: 'GET', url: url })
        .done(function (response) {
          deferred.resolve(response);
        }).error(function (error) {
          deferred.reject(error);
        })
      return deferred.promise();
    },
    postSignup: function (options) {
      console.log(options)
      if (options.result) {
        this.$el.html(this.ResultLayout({ result: options.result[this.result], loggedIn: Utils.isLoggedIn() }))
      }
      this.updateFirebase(false)
    },
    updateFirebase: function (loggedIn) {
      if (!loggedIn) {
        var firebaseObj = Utils.updateKickTheButt("kickthebutt");
        var userObject = JSON.parse(localStorage.getItem("user"))
        firebaseObj.update({
          "userId": userObject['id'],
          "orgId": userObject['loggableUser']['orgId'],
          "userName": userObject['username']
        })
      }
      setTimeout(function () {
        localStorage.removeItem("testID");
        localStorage.removeItem("emotionalWellnessTest")
      }, 1000)
    },
    showResult: function (res, result) {
      console.log('res-_-_-_-', res[result]);
      console.log('this.result', result);
      if (Utils.isLoggedIn()) {
        var finalPercent = localStorage.getItem('kickTheButtResult')
        this.$el.html(this.ResultLayout({ result: res[result], loggedIn: Utils.isLoggedIn(), finalPercent }))
        this.updateFirebase(true)
      } else {
        console.log("this.$el.html", this.$el.html);
        $('.header-right-section .login-clicked').addClass('hide')
        this.$el.html(this.ResultLayout({ result: res[result], loggedIn: Utils.isLoggedIn() }))
        Dispatcher.trigger("renderLoginToDiv", "", "kickTheButt", "ew_test", "ew_signup", {
          options: {
            result: res[result]
          },
          callback: this.postSignup.bind(this)
        });
        $(".login-modal-close").addClass("hide");
      }
    },
    render: function () {
      document.title = "Kick the butt result";
      $('meta[name=description]').attr('content', "As a student, you would agree that tests are a major stress-inducers. But all tests don't have to be that way. Here's a test that won't stress you but will tell you just how stressed you are.");
      $('meta[name=title]').attr('content', "Kick the butt Result");
      $('meta[property="og:description"]').attr('content', "As a student, you would agree that tests are a major stress-inducers. But all tests don't have to be that way. Here's a test that won't stress you but will tell you just how stressed you are.");
      $('meta[property="og:title"]').attr('content', "Kick the butt result");
      $('meta[property="og:image"]').attr('content', "https://d1hny4jmju3rds.cloudfront.net/emotionalWellness/thumb.png");
      $('meta[property="og:url"]').attr('content', "https://yourdost.com/kickthebutt/result ");
      $('link[rel="canonical"]').attr('href', 'https://yourdost.com/kickthebutt/result');
      var self = this;
      var url = Backbone.history.getFragment();
      // if (!localStorage.hasOwnProperty("emotionalWellnessTest")) {
      //   Backbone.history.navigate("/emotional-wellness-test", { trigger: true });
      //   return;
      // }
      this.result = parseInt(localStorage.kickTheButtResult)
      if (this.result >= 0 && this.result < 30) {
        this.result = "verybad"
      } else if (this.result >= 30 && this.result < 50) {
        this.result = "bad"
      } else if (this.result >= 50 && this.result < 70) {
        this.result = "average"
      } else if (this.result >= 70 && this.result < 90) {
        this.result = 'good'
      } else {
        this.result = "excellent"
      }
      $.when(this.getContent(Utils.scriptPath() + "/selfHelp/kickthebutt/result.json"))
        .then(function (res) {
          self.showResult(res, self.result)
          //console.log('result json',res.this.result);
        }, function (err) {
          console.log("Error: ", err)
        })
    }
  });
  kickTheButtResult.prototype.remove = function () {
    this.$el.empty();
    this.$el.off();
    this.unbind();
  };
  kickTheButtResult.prototype.clean = function () {
    this.remove();
  };
  return kickTheButtResult;
});
