define([
    'jquery',
    'underscore',
    'backbone',
    '../../../precompiled-templates',
    'utils',
    'event/dispatcher',
    'model/users'
], function ($, _, Backbone, JST, Utils, Dispatcher, UserModel) {
    var kickTheButt = Backbone.View.extend({
        el: "main",
        initialize: function () {
            if (Utils.isLoggedIn()) {
                this.questionNo = 1;
                this.questions = {};
                this.mappingObj = {};
                this.mappingScoreObj = {};
                this.optionIndex = -1;
                this.finalScore = 0;
                this.score = 0;
                this.index = 0;
                this.selectedDayScore = [],
                    this.total = 0;
                this.week = '';
            } else {
                Backbone.history.navigate("/dashboard", { trigger: true });
            }
        },
        kickTheButtLayout: JST['app/templates/selfHelp/kickthebutt/layout.hbs'],
        startkickTheButtLayout: JST['app/templates/selfHelp/kickthebutt/start.hbs'],
        questionsLayout: JST['app/templates/selfHelp/kickthebutt/questions.hbs'],
        events: {
            'click .ew-start-quiz': 'startQuiz',
            'click .ew-next': 'nextQuestion',
            'click .ew-prev': 'prevQuestion',
            'click .ew-options': 'selectOption',
            'click .ew-img-box': 'selectOption',
            'click .ew-show-result': 'showResult',
            'click .ktb-options-multi': 'multiSelectOption',
        },
        trackMixpanelEvents: function (identifier, itemName, itemType) {
            if (typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function") {
                mixpanel.track(identifier, { "itemName": itemName, "itemType": itemType });
            }
        },
        startQuiz: function () {
            $('#shMessage').addClass('hide');
            this.trackMixpanelEvents("BUtton Click", "start kick the butt quiz", "clicked start kick the butt quiz")
            this.renderQuestions()
            //alert('start quiz');
        },
        findSelectedOption: function (option, className) {
            this.optionIndex = $("." + className).index($(option.currentTarget)) + 1
            this.score = $(option.currentTarget).attr("data-score")
        },
        selectOption: function (evt) {
            var className = "ew-options";
            $("." + className).removeClass("option-selected")
            $(evt.currentTarget).addClass("option-selected")
            $(".ew-next").removeClass("disabled")
            this.findSelectedOption(evt, className)
            if (this.questionNo == Object.keys(this.questions).length) {
                $(".ew-next").removeClass("ew-next").addClass("ew-show-result").html("<b>SHOW RESULT &gt;</b>")
            }
        },
        multiSelectOption: function (evt) {
            var selectedDays = evt.currentTarget.innerText;
            var a = $('.ktb-options-multi').attr('data-score');
            var dayIndex = this.selectedDayScore.indexOf(selectedDays);
            //var multiQuestionNo = $('.ktb-options-multi').attr('data-qno');
            var multiSelectClass = $(evt.currentTarget).hasClass("option-selected");
            if (selectedDays) {
                console.log('inside if');
                if (dayIndex === -1) {
                    this.selectedDayScore.push(selectedDays);
                    $(evt.currentTarget).addClass("option-selected");
                } else {
                    this.selectedDayScore.splice(dayIndex, 1);
                    $(evt.currentTarget).removeClass("option-selected");
                }
            } else {
                console.log('inside else');
                this.selectedDayScore.push('NA');
            }
            console.log("selectedDayScore", this.selectedDayScore);
            //this.score = this.selectedDayScore.length;
            $(".ew-next").removeClass("disabled");

            console.log('selected', this.score);
        },
        nextQuestion: function (evt) {
            this.trackMixpanelEvents("Button Click", "Clicked Next Question", this.questionNo);
            var isMultiQuestion = $('.ktb-options-multi').attr('data-qtype');
            var isBoolQuestion = $('.ew-options').attr('data-qtype');
            console.log('isMultiQuestion', isMultiQuestion);
            if (isBoolQuestion === 'bool') {
                console.log('inside multi');
                this.mappingObj[this.questionNo] = this.optionIndex;
                this.mappingScoreObj[this.questionNo] = this.score;
                console.log("this.mappingObj", this.mappingObj);
                console.log("this.mappingScoreObj", this.mappingScoreObj);
            }
            if (isMultiQuestion === 'multi') {
                console.log('inside multi');
                if (!this.selectedDayScore.length) {
                    this.mappingObj[this.questionNo] = 0;
                    this.mappingScoreObj[this.questionNo] = 0;
                } else {
                    this.mappingObj[this.questionNo] = this.selectedDayScore;
                    this.mappingScoreObj[this.questionNo] = this.selectedDayScore.length;
                }
                this.selectedDayScore = [];
                console.log("this.mappingObj", this.mappingObj);
                console.log("this.mappingScoreObj", this.mappingScoreObj);
            }

            //this.finalScore += parseInt(this.score)
            this.questionNo++;
            this.index++;
            this.renderQuestions(false)
        },
        prevQuestion: function (evt) {
            this.questionNo--;
            this.index--;
            this.renderQuestions(true)
        },
        renderQuestions: function (option) {
            var questionsObj = this.questions;
            var self = this;
            var question = questionsObj[self.index];
            console.log('self', self);
            console.log('question', question);
            question["qNo"] = this.questionNo;

            this.$el.find(".ew-sub-inner").html(this.questionsLayout({ question: question, totalQues: Object.keys(this.questions).length }))
            var isMultiQuestions = $('.ktb-options-multi').attr('data-qtype');
            var isTextQuestion = $('.ktb-count').attr('data-qtype');
            console.log('isMultiQuestions', isMultiQuestions);
            if (option) {
                if (question.type == "input") {
                    $(".ew-sub-inner").find(".inputText").val(this.mappingObj[this.questionNo])
                } else {
                    $(".ew-options:nth-child(" + this.mappingObj[this.questionNo] + ")").addClass("option-selected")
                }
                $(".ew-next").removeClass("disabled")
            }
            if (Utils.isMobileDevice()) {
                $("body").animate({ scrollTop: 0 }, '1000')
            }
            if (this.questionNo > 1) {
                $(".ew-prev").removeClass("disabled")
            }
            if (this.questionNo == Object.keys(this.questions).length && isTextQuestion === 'text') {
                console.log('inside iffffffffff')
                $(".ew-next").removeClass("disabled")
                $(".ew-next").removeClass("ew-next").addClass("ew-show-result").html("<b>SHOW RESULT &gt;</b>")
            }
        },
        showResult: function (evt) {
            var isMultiQuestion = $('.ktb-options-multi').attr('data-qtype');
            var isBoolQuestion = $('.ew-options').attr('data-qtype');
            var oldCount = document.getElementById('oldCount').value;
            var newCount = document.getElementById('newCount').value;
            if (oldCount && newCount) {
                localStorage.setItem('oldCount', oldCount);
                localStorage.setItem('newCount', newCount);
                if (isBoolQuestion === 'bool') {
                    console.log('inside multi');
                    this.mappingObj[this.questionNo] = this.optionIndex;
                    this.mappingScoreObj[this.questionNo] = this.score;
                    console.log("this.mappingObj", this.mappingObj);
                    console.log("this.mappingScoreObj", this.mappingScoreObj);
                }
                if (isMultiQuestion === 'multi') {
                    console.log('inside multi');
                    if (!this.selectedDayScore.length) {
                        console.log('inside if')
                        this.mappingObj[this.questionNo] = 0;
                        this.mappingScoreObj[this.questionNo] = 0;
                    } else {
                        this.mappingObj[this.questionNo] = this.selectedDayScore;
                        this.mappingScoreObj[this.questionNo] = this.selectedDayScore.length;
                    }
                    this.selectedDayScore = [];
                    console.log("this.mappingObj", this.mappingObj);
                    console.log("this.mappingScoreObj", this.mappingScoreObj);
                }
                console.log("this.mappingObj", this.mappingObj);
                console.log("this.mappingScoreObj", this.mappingScoreObj);
                //this.finalScore += parseInt(this.score)
                var resultArr = Object.values(this.mappingScoreObj)

                this.finalScore = resultArr.reduce(function (prev, curr) {
                    return parseInt(prev) + parseInt(curr)
                })
                //Calculate percentage
                var percentageScore = (this.finalScore / this.total) * 100;
                console.log("percentageScore", percentageScore);
                this.trackMixpanelEvents("BUtton Click", "show result kick the butt test", "clicked show result kick the butt")
                localStorage.setItem("kickTheButtResult", Math.round(percentageScore));
                console.log('Final score', this.finalScore);

                this.updateToFirebase()
                Backbone.history.navigate("/kickthebutt/result", { trigger: true });
            } else {
                $('#shMessage').show();
            }
        },
        updateToFirebase: function () {
            var self = this;
            this.getContent({ method: 'GET', url: Utils.contextPath() + '/v2/users/organisation' })
                .then(function (res) {
                    self.updateFirebase(res)
                }, function (err) {
                    console.log("Error: ", err)
                })
        },
        updateFirebase: function (orgId) {
            var self = this;
            if (Utils.isLoggedIn()) {
                var userObject = JSON.parse(localStorage.getItem("user"))
                var scoreInPercentage = localStorage.getItem("kickTheButtResult")
                var firebaseObj = Utils.updateKickTheButt("kickthebutt", userObject.id);
                var answerWeek = this.week;
                var today = new Date().toLocaleString();
                var updateCountOld = localStorage.getItem('oldCount');
                var updateCountNew = localStorage.getItem('newCount');
                var answerObject = firebaseObj.once('value', function (value) {
                    console.log('value', value.val());
                    var updateAnswerObj = value.val() || {};
                    var answersObj = updateAnswerObj.answers || {};
                    answersObj[answerWeek] = { "answers": self.mappingObj || {}, "percentageScore": scoreInPercentage, "oldCount": updateCountOld, "newCount": updateCountNew }
                    firebaseObj.update({
                        "answers": answersObj
                    })
                })
                console.log("ansObject", answerObject);
                //userObj["answers"] = answerWeek
                //userObj[answerWeek].push({answerWeek :{"answers": this.mappingObj || {}}});
            }
        },
        getContent: function (options) {
            var deferred = $.Deferred();
            $.ajax(options)
                .done(function (response) {
                    deferred.resolve(response);
                }).error(function (error) {
                    deferred.reject(error);
                })
            return deferred.promise();
        },
        render: function () {
            this.$el.html(this.kickTheButtLayout());
            //this.$el.find(".ew-sub-inner").html(this.startkickTheButtLayout({ 'coverImage': coverImg }))
            var weekAssessment = window.location.pathname.split('-');
            var jsonToLoad = weekAssessment[1];
            var Questions = this.getContent({ method: 'GET', url: Utils.scriptPath() + "/selfHelp/kickthebutt/week" + jsonToLoad + ".json" });
            this.trackMixpanelEvents("Kick the butt", "Kick the butt", " ")
            var self = this;
            var coverImg;
            var title;
            var desc;
            $.when(Questions)
                .then(function (response, status) {
                    self.questions = response.questions;
                    coverImg = response.coverImage;
                    self.total = response.total;
                    self.week = response.week;
                    title = response.title;
                    desc = response.desc;
                    $(".ew-sub-inner").html(self.startkickTheButtLayout({ 'coverImage': coverImg }));
                    document.title = title;
                    $('meta[name=description]').attr('content', desc);
                    $('meta[name=title]').attr('content', title);
                    $('meta[property="og:url"]').attr('content', "https://yourdost.com/kickthebutt/"+self.week);
                    $('meta[property="og:description"]').attr('content', desc);
                    $('meta[property="og:title"]').attr('content', title);
                    $('meta[property="og:image"]').attr('content', coverImg);
                    //$('meta[property="og:url"]').attr('content', "https://yourdost.com/emotional-wellness-test ");
                    $('link[rel="canonical"]').attr('href', 'https://yourdost.com/kickthebutt/'+self.week);
                }, function (error) {
                    console.log("Error ", error);
                })
        }
    });
    kickTheButt.prototype.remove = function () {
        $(".dost-main").css({ "background": "#fff" })
        this.$el.empty();
        this.$el.off();
        this.stopListening();
        this.undelegateEvents();
        this.unbind();
    };
    kickTheButt.prototype.clean = function () {
        this.remove();
    };
    return kickTheButt;
});
