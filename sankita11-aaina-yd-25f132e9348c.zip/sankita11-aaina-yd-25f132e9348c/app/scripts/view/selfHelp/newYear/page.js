define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'view/packages/custompackage_modal',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher,customPackageModalView, UserModel ) {

	var NewYearSelfHelp = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.questions = [];
			self.questionType="";
			this.currentQuestion = 0 ;
			this.answerCount=[0,0,0,0,0,0]

			this.answerMapping=[]
			this.userModel = new UserModel();
			this.socialShareResponse = {};
            this.url = "";
            this.answers = [];
            this.questionMapping=[-1,-1,-1,-1,-1,-1];
            this.customPackageModalView = new customPackageModalView();

		},

		newYearTestLayout: JST['app/templates/selfHelp/newYear/layout.hbs'],
		newYearTestHomePage: JST['app/templates/selfHelp/newYear/start.hbs'],
		newYearTestQuestionLayout : JST['app/templates/selfHelp/newYear/question.hbs'],
		newYearTestQuestionOptionLayout : JST['app/templates/selfHelp/newYear/questionOptions.hbs'],
		newYearTestRiddleLayout : JST['app/templates/selfHelp/newYear/riddle.hbs'],
		//ShapeTestNoteLayout: JST['app/templates/selfHelp/shapeTest/testTakeNote.hbs'],

		 events: {
	        "click .back-to-selfHelp": "renderSelfHelp",
	        "click .redirect-to-selfHelp":"renderSelfHelp",
	        "click .newyear-test-start-quiz": "getNextQuestion",
	        "click #newyear-test-next-quiz" :"getNextQuestion",
	        "click .newyear-question-img-box .sh-ps-question-img" : "selectOption",
	        "click .newyear-options" :"selectOption",
	        "click #newyear-test-prev-quiz":"getPrevQuestion",
      },

      trackMixpanel : function(mixpanelIdentifier, pageNo){

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

              if ( pageNo != undefined) {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "NewYear Resolution", "pageNo": pageNo});
              }
              else {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "NewYear Resolution"});
              }


        }

      },

      shareOnFacebook: function(e) {

        var self = this;
        Utils.shareOnFacebook( self.socialShareResponse, self.url );

      },

      renderSelfHelp: function() {
         Backbone.history.navigate("/selfhelp",{trigger:true});
      },

      redirectToChat : function(e) {

        var self = this;
        self.trackMixpanel( "Talk to Expert from result screen" );
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

          if ( !$(e.currentTarget).hasClass("disabled") ) {
              var username = this.userModel.getUserName() ;
             location.href = Utils.chatUrl() + username;
              $(e.currentTarget).addClass("disabled");
          }
        }

      },

      renderResultPage: function(e) {

        var self = this;
              var answerCount = self.answerCount;
              var resolution ='';
              var max_count = 0;
              var index = -1;
              for(var i=0;i<6;i++){
              	if(max_count < self.answerCount[i]){
              		max_count = self.answerCount[i];
              		index = i;
              	}
              }
              resolution = this.answerMapping[index+1];
              console.log('resolution'+resolution);
        localStorage.resolution = resolution;

        Backbone.history.navigate("/decide-your-new-year-resolution/result",{trigger:true});

      },
      selectOption : function(e){
      	var self = this;

      	var selectedCard = $(e.currentTarget);
      	var classToAdd= '';
      	var classCheck = '';
      	if(self.questionType == 'image'){
      		classToAdd = 'resolution-answer-selected-image';
      		classCheck = 'newyear-check-img';
      	}else{
      		classToAdd = 'resolution-answer-selected';
      		classCheck = 'newyear-check';
      	}
      	var previousCard = $('.'+classToAdd);
      	var prevId = previousCard.attr('option-id');
      	var currId = selectedCard.attr('option-id');
      		if(prevId){
      			self.answerCount[prevId] --;
      		}
      	self.answerCount[currId] ++;
      	self.questionMapping[self.currentQuestion-1] = currId;
      	$('.newyear-options').removeClass('resolution-answer-selected');
		$('.newyear-question-img-box .sh-ps-question-img').removeClass('resolution-answer-selected-image');
		$('.'+classCheck).addClass('hide');
      	selectedCard.addClass(classToAdd);
      	selectedCard.find('.'+classCheck).removeClass('hide')
      	$('#newyear-test-next-quiz').removeClass('disabled');
      	console.log(self.answerCount + " and " + self.questionMapping);

      },
      getPrevQuestion : function(){
      		var self = this;
      		var classToAdd= '';
      		var classCheck = ''

      		if(self.questionMapping[self.currentQuestion-1]!= -1){


		      	if(self.questionType == 'image'){
		      		classToAdd = 'resolution-answer-selected-image';
		      		classCheck = 'newyear-check-img';
		      	}else{
		      		classToAdd = 'resolution-answer-selected';
		      		classCheck = 'newyear-check';
		      	}
		      	var id = $('.'+classToAdd).attr('option-id');
		      	self.answerCount[id] --;
		      	self.questionMapping[self.currentQuestion-1] = -1;
	    	  }
	      	self.currentQuestion --;
	      	self.questionType = self.questions[self.currentQuestion].type;
	      	if(self.questionType == 'image'){
		      		classToAdd = 'resolution-answer-selected-image';
		      		classCheck = 'newyear-check-img';
		      	}else{
		      		classToAdd = 'resolution-answer-selected';
		      		classCheck = 'newyear-check';
		      	}
      		$(".newyear-test-inner-container").html( self.newYearTestQuestionLayout({questionNo : self.currentQuestion,title:self.questions[self.currentQuestion].question,options : self.answers[self.currentQuestion], type: self.questionType}));
     		$('.newyear-options').append('<i class="mdi mdi-checkbox-marked-circle newyear-check hide font-30"></i>');
     		$('.newyear-question-img-box').append('<i class="mdi mdi-checkbox-marked-circle newyear-check-img hide font-30"></i>');
     		var card = $('div[option-id = '+self.questionMapping[self.currentQuestion-1]+']');
     		card.addClass(classToAdd);
      		card.find('.'+classCheck).removeClass('hide')
			if(self.currentQuestion == 1){
     			$('#newyear-test-prev-quiz').addClass('redirect-to-selfHelp');
     		}else{
     			$('#newyear-test-prev-quiz').removeClass('redirect-to-selfHelp');
     		}

      },
      getNextQuestion : function(){
      		var self = this;
      		this.currentQuestion ++;
      		if(self.currentQuestion == 8){
     			self.renderResultPage();
     		}else{
	      		self.questionType = self.questions[self.currentQuestion].type;
	      		$(".newyear-test-inner-container").html( self.newYearTestQuestionLayout({questionNo : self.currentQuestion,title:self.questions[self.currentQuestion].question,options : self.answers[self.currentQuestion], type: self.questionType}));
	     		if(self.currentQuestion == 1){
		     			$('#newyear-test-prev-quiz').addClass('redirect-to-selfHelp');
		     		}else{
		     			$('#newyear-test-prev-quiz').removeClass('redirect-to-selfHelp');
		     		}

	     		$('#newyear-test-next-quiz').addClass('disabled');
	     		$('.newyear-options').append('<i class="mdi mdi-checkbox-marked-circle newyear-check hide font-30"></i>');
	     		$('.newyear-question-img-box').append('<i class="mdi mdi-checkbox-marked-circle newyear-check-img hide font-30"></i>');
	     	}

      },
      render: function() {
          document.title="Discover Your New Year Resolution | YourDOST";

          $('meta[name=description]').attr('content', "This new year, don\'t end up making resolutions which are lofty. Use this Resolution Tool designed by our Experts, and find a resolution that is not only perfect for you but also helps you unleash your best self in 2018.");
          $('meta[name=title]').attr('content'," Discover Your New Year Resolution | YourDOST");
          $('meta[property="og:url"]').attr('content',"https://yourdost.com/decide-your-new-year-resolution");
          $('meta[property="og:description"]').attr('content', "This new year, don\'t end up making resolutions which are lofty. Use this Resolution Tool designed by our Experts, and find a resolution that is not only perfect for you but also helps you unleash your best self in 2018.");
          $('meta[property="og:title"]').attr('content'," Discover Your New Year Resolution | YourDOST");
          $('meta[property="og:image"]').attr('content',"https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearSelfHelp/quiz1-fb-ogtag-img.jpg");
          $('meta[property="og:url"]').attr('content',"https://yourdost.com/decide-your-new-year-resolution");
          $('link[rel="canonical"]').attr('href', 'https://yourdost.com/decide-your-new-year-resolution');

          var self = this;
          var url = window.location.pathname;
          self.url = url;
          self.trackMixpanel( "New Year Resolution Viewed" );

            self.$el.html( self.newYearTestLayout() );
            $(".newyear-test-inner-container").html( self.newYearTestHomePage( {title: 'Discover Your New Year Resolution', description: 'This new year, don\'t end up making resolutions which are lofty. Use this Resolution Tool designed by our Experts, and find a resolution that is not only perfect for you but also helps you unleash your best self in 2018.'} ) );



          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/newYear/questions.json",

          }).done(function(response){

            self.questions = response;


          }).error(function(error){
            console.log( "error" );
            console.log(error)
          });
          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/newYear/answers.json",

          }).done(function(resp){

            self.answers = resp;


          }).error(function(error){
            console.log( "error" );
            console.log(error)
          });
          $.ajax({

            url : Utils.scriptPath() + "/selfHelp/newYear/answer_mapping.json",

          }).done(function(r){

            self.answerMapping = r;


          }).error(function(error){
            console.log( "error" );
            console.log(error)
          });


      }

    });

	NewYearSelfHelp.prototype.remove = function() {};

	NewYearSelfHelp.prototype.clean = function() {};

	return NewYearSelfHelp;
});
