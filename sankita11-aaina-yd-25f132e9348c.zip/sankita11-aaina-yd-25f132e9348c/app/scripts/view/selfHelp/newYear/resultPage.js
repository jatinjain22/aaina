define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  	'view/packages/custompackage_modal',
    'masonry',
  	'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, customPackageModalView,Masonry, imagesLoaded ) {

	var NewYearSelfHelpResultPage = Backbone.View.extend({

		el: "main",

            ResultLayout: JST['app/templates/selfHelp/trueColor/result.hbs'],
             packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],
              initialize: function() {
                 this.userModel = new UserModel() ;
                  this.customPackageModalView = new customPackageModalView();
                  this.result = "";
                  this.resolution= localStorage.resolution;

              },
              events : {
                  "click .newyear-test-facebook-share": "shareOnFacebook",
                  "click .newyear-test-talk-to-expert .btn": "redirectToChat",
                  "click .result-report-sign-in em": "showSignUp",
                  "click .build-custom-plan":"redirectToCustomPlan",
                  "click .newyear-test-redirect-to-newyear-package":"redirectToPackages",
            },
            NewYearTestLayout: JST['app/templates/selfHelp/newYear/layout.hbs'],
            NewYearTestResultLayout: JST['app/templates/selfHelp/newYear/result.hbs'],
            MobileDeviceSignInLayout: JST["app/templates/selfHelp/mobileDeviceSignIn.hbs"],

            redirectToCustomPlan:function(){
              /*   var self = this;
                  console.log(self.result);


                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/shapeTest/custom_package_prefill.json",
                  }).done(function(response){

                        //console.log(response)
                        //console.log(response[self.result]);

                        //var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
                        if(typeof mixpanel !== 'undefined'){
                             mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'NewYearResolution' ,"upsellFrom":"NewYearResolution","packageName":"Custom Plan"});
                         }

                         var str = response[self.result][1]+"\n"+ response[self.result][2]+"\n" +response[self.result][3];
                         self.customPackageModalView.render(str,'shapeTest');

                                             // $('.custompackage-achieve').text(str);
                        //$('#custompackage-category').val(5)


                  }).error(function(error){

                        console.log("Error ", error);
                  });
          */
            },

            showSignUp: function(e){

                  var url = Backbone.history.getFragment();

                  console.log( url );
                  var buttonDesc = "show resolution test signup";
                  Dispatcher.trigger("renderLogin", buttonDesc, "NewYearResolution", "show_result_post_signup",  url) ;

            },
            changeCSS: function() {

                  $('.newyear-test-result-overlay').addClass('newyear-test-result-overlay-show');
                  $('#signup-form-newyear #login-modal').addClass('login-newyear');

            },

            trackMixpanel : function(mixpanelIdentifier, type){

                  if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

                        if (type !== undefined) {
                              mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "NewYearResolution Test", "type": type});
                        }
                        else {
                              mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "NewYearResolution Test"});
                        }

                  }

            },
            shareOnFacebook: function(e) {

                  var self = this;
                  var url = Backbone.history.getFragment();;
                  var targetElement = $(".newyear-test-social-share");
                  var loaderElement = $(".selfhelp-share-on-facebook-loader");
                  var mixpanelEvent = "Self Help Test Shared";
                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  $.ajax({
                        url : Utils.scriptPath() + "/socialShare.json",
                        cache: false
                  }).done(function(response){
                        console.log( url );
                        socialShareResponse = response[ url ];
                        console.log( 'socialShareResponse ' + JSON.stringify( socialShareResponse ) );

                        Utils.shareOnFacebook( socialShareResponse, targetElement, loaderElement, mixpanelEvent );
                  }).error(function(error){
                        console.log(error)
                  });



            },
            redirectToChat : function(e) {

                  var self = this;
                  var buttonDesc = $(e.currentTarget).attr("data-desc");
                  if(!Utils.isLoggedIn()){
                    Dispatcher.trigger("renderLogin", buttonDesc, "newYearselfTest", "home_chat") ;
                  }else{

                        if ( !$(e.currentTarget).hasClass("disabled") ) {
                              if (  ( typeof fbq != 'undefined' ) ){
                                    fbq('track', 'Lead');
                              }

                              var fromText = btoa("came from My New Year Resolution In 2017")

                              var username = this.userModel.getUserName() ;
                              location.href = Utils.chatUrl() + username + "&from=" + fromText;
                              $(e.currentTarget).addClass("disabled");
                        }
                  }

            },
            redirectToPackages: function(){

               Backbone.history.navigate("/new-year-resolution",{trigger:true});

            },
			postSignup : function(options){
				$('.header-right-section .login-clicked').addClass('hide')
		      	if(options){
		        	$(".newyear-test-inner-container").html(this.NewYearTestResultLayout( { resolution : options.result, loggedIn : Utils.isLoggedIn()} ) )
					Utils.storeSelfHelpResult( username, testName, options.result );
		      	}
		    },
           render: function() {
			   document.title="Discover Your New Year Resolution | YourDOST";

			   $('meta[name=description]').attr('content', "This new year, don\'t end up making resolutions which are lofty. Use this Resolution Tool designed by our Experts, and find a resolution that is not only perfect for you but also helps you unleash your best self in 2018.");
			   $('meta[name=title]').attr('content'," Discover Your New Year Resolution | YourDOST");
			   $('meta[property="og:url"]').attr('content',"https://yourdost.com/decide-your-new-year-resolution");
			   $('meta[property="og:description"]').attr('content', "This new year, don\'t end up making resolutions which are lofty. Use this Resolution Tool designed by our Experts, and find a resolution that is not only perfect for you but also helps you unleash your best self in 2018.");
			   $('meta[property="og:title"]').attr('content'," Discover Your New Year Resolution | YourDOST");
			   $('meta[property="og:image"]').attr('content',"https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearSelfHelp/quiz1-fb-ogtag-img.jpg");
			   $('meta[property="og:url"]').attr('content',"https://yourdost.com/decide-your-new-year-resolution");
			   $('link[rel="canonical"]').attr('href', 'https://yourdost.com/decide-your-new-year-resolution');
                  var self = this;
                  var url = Backbone.history.getFragment();
                  $(".dost-main").css({"background" : "#fafafa"})

                if ( !localStorage.hasOwnProperty( "resolution" ) ) {
                    Backbone.history.navigate("/decide-your-new-year-resolution",{trigger:true});
					return false;
                }
				self.$el.html( self.NewYearTestLayout() );
                if ( !Utils.isLoggedIn() ) {
                    $('.header-right-section .login-clicked').addClass('hide')
					$(".newyear-test-inner-container").html(this.NewYearTestResultLayout( { resolution : self.resolution, loggedIn : Utils.isLoggedIn()} ) )
			        Dispatcher.trigger("renderLoginToDiv", "", "emotionalWellnessTest", "ew_test", "ny_signup", {
						options : {
							result: self.resolution
						},
						callback: this.postSignup.bind(this)
					});
			        $(".login-modal-close").addClass("hide");
                }else{
                    $('.header-right-section .login-clicked').removeClass('hide')
                    $(".newyear-test-inner-container").html( self.NewYearTestResultLayout( {resolution : self.resolution, loggedIn : Utils.isLoggedIn()} ) );
                    self.$el.append( self.packageBannerLayout());
                    self.resolution =  localStorage.resolution;
                    Utils.scrollTo(".dost-main", 0);
					Utils.trackMixPanelForSelfTestResultPage("Self Test End", "NewYear Test");
	              	var username = self.userModel.getUserID();
	              	var testName = "NewYear";
	              	Utils.storeSelfHelpResult( username, testName, self.resolution );
                }
				$(document).keydown(function(e){
					var charCode = e.charCode || e.keyCode || e.which;
					if( charCode === 27 ) {
						return false;
					}
				})
            }
      });
	NewYearSelfHelpResultPage.prototype.remove = function() {


            this.$el.empty();
            this.$el.off();
            this.unbind();

      };

	NewYearSelfHelpResultPage.prototype.clean = function() {
            this.remove();
      };

	return NewYearSelfHelpResultPage;
});
