define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'view/packages/custompackage_modal',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher,customPackageModalView, UserModel ) {

	var HabitOMeterPage = Backbone.View.extend({

		el: "main",

		initialize: function() {
			this.questions = [];
			this.currentQuestion = 0 ;
			this.thatsmeCnt = 0 ;
			this.userModel = new UserModel();
			this.socialShareResponse = {};
            this.url = "";
            this.answers = [];
             this.customPackageModalView = new customPackageModalView();

		},
		events: {

			"click .yd-hom-start" : "showQuestions",
			"click .yd-hom-answer-btn" : "showNextQuestion",
			"click .yd-hom-talkItOut" : "redirectToChat",
			"click .yd-hom-talkItOut-mobile" : "redirectToChat",
			"click .back-to-selfHelp": "renderSelfHelp",
			"click .habitometer-facebook-share": "shareOnFacebook",
			"click .build-custom-plan":"redirectToCustomPlan"
		},

		StartLayout : JST['app/templates/selfHelp/habitometer/start.hbs'],
		PageLayout : JST['app/templates/selfHelp/habitometer/layout.hbs'],
		QuestionnaireLayout : JST['app/templates/selfHelp/habitometer/questionnaire.hbs'],
		AnswerLayout : JST['app/templates/selfHelp/habitometer/answer.hbs'],
		packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],

		redirectToCustomPlan:function(){
                  
          	var self = this;
           	// var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
            var str = "1. Cut down on my time on Internet \n"+"2. Increase social Interaction \n"+"3. Being more productive/constructive (Daily routine) \n"+"4. Getting over loneliness \n"+"5. Procrastination \n"
            //$('.custompackage-achieve').text(str);
            //$('#custompackage-category').val(5)
            self.customPackageModalView.render(str,'habitometer');
            if(typeof mixpanel !== 'undefined'){
                 mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'habitometer' ,"upsellFrom":"habitometer","packageName":"Custom Plan"});
            }

        },
        redirectToChat : function(e){

		
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "habitselfTest", "home_chat") ;
			}else{
			
				if ( !$(e.currentTarget).hasClass("disabled") ) {
					if (  ( typeof fbq != 'undefined' ) ){
					    fbq('track', 'Lead');                           
					}
                    
                    var fromText = btoa("Came from Your Internet HABIT-O-METER");

					var username = this.userModel.getUserName() ;
					location.href = Utils.chatUrl() + username + "&from=" + fromText;
					$(e.currentTarget).addClass("disabled");
				}
			}

		},
		shareOnFacebook: function(e) {
                  
                  var self = this;
                  var targetElement = $(".habitometer-social-share");
                  var loaderElement = $(".selfhelp-share-on-facebook-loader");
                  var mixpanelEvent = "Self Help Test Shared";
                  
                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  Utils.shareOnFacebook( self.socialShareResponse, targetElement, loaderElement, mixpanelEvent ); 
            
        },
		renderSelfHelp: function() {
        	Backbone.history.navigate("/selfhelp",{trigger:true});
      	},
		showNextQuestion : function(e){

			this.currentQuestion += 1 ;

			questionNo = this.currentQuestion + 1;
			$(".yd-hom-qno").html( questionNo );
			$(".yd-hom-qtext").html(this.questions[this.currentQuestion]);

			if($(e.currentTarget).hasClass("yd-hom-thats-me")){
				this.thatsmeCnt += 1 ;
			}

			if(this.currentQuestion >= this.questions.length){
				this.showAnswer();
			}



		},
		showAnswer : function(){
			
			$( ".yd-hom-content" ).html(this.AnswerLayout({}));
			  this.$el.append(this.packageBannerLayout());
			$( ".yd-hom-content" ).addClass( "yd-hom-content-answer" );
			
			
			
			var thatsmeCnt = this.thatsmeCnt;

			if( thatsmeCnt <= 4){
				$(".yd-hom-answer-heading").html(this.answers[0].heading);
				$(".yd-hom-answer-desc").html(this.answers[0].description);
				$(".yd-hom-img").attr('src',this.answers[0].photo);
				$(".yd-hom-img-mobile").attr('src',this.answers[0].mobilephoto);
			}

			if( thatsmeCnt >= 5 && thatsmeCnt <= 10 ){
				$(".yd-hom-answer-heading").html(this.answers[1].heading);
				$(".yd-hom-answer-desc").html(this.answers[1].description);
				$(".yd-hom-img").attr('src',this.answers[1].photo);
				$(".yd-hom-img-mobile").attr('src',this.answers[1].mobilephoto);
			}
			
			if( thatsmeCnt >= 11 && thatsmeCnt <= 15 ){
				$(".yd-hom-answer-heading").html(this.answers[2].heading);
				$(".yd-hom-answer-desc").html(this.answers[2].description);
				$(".yd-hom-img").attr('src',this.answers[2].photo);
				$(".yd-hom-img-mobile").attr('src',this.answers[2].mobilephoto);
			}

			if( thatsmeCnt >= 16 ){
				$(".yd-hom-answer-heading").html(this.answers[3].heading);
				$(".yd-hom-answer-desc").html(this.answers[3].description);
				$(".yd-hom-img").attr('src',this.answers[3].photo);
				$(".yd-hom-img-mobile").attr('src',this.answers[3].mobilephoto);
			}

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
		      mixpanel.track("Self Test End", {"mediumSource" : "website", "itemName" : "Habit O Meter"});
		    }

		},
		showQuestions : function(){
			
			$('.habitometer-main-homePage-title').addClass("habitometer-main-title");
			$(".yd-hom-content").html(this.QuestionnaireLayout({}));

			$(".yd-hom-qno").html("1");
			$(".yd-hom-qtext").html(this.questions[0]);

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
		      mixpanel.track("Self Test begin", {"mediumSource" : "website", "itemName" : "Habit O Meter"});
		    }


		},
		render: function() {


            document.title="Internet Addiction Test | YourDOST Psychology Tests";
            $('meta[name=description]').attr('content', "Take this simple test to know whether you are addicted to internet. You can also chat with experts for de-addiction help");
            $('meta[name=title]').attr('content',"Internet Addiction Test | YourDOST Psychology Tests");
            $('meta[property="og:description"]').attr('content', "Take this simple test to know whether you are addicted to internet. You can also chat with experts for de-addiction help");
            $('meta[property="og:title"]').attr('content',"Internet Addiction Test | YourDOST Psychology Tests");
    	    $('link[rel="canonical"]').attr('href', 'https://yourdost.com/habitometer');
			var self = this ;


			var url = Backbone.history.getFragment() ;
			self.url = url;

			self.$el.html( self.PageLayout() );
			$(".yd-hom-content").html(self.StartLayout({}));
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
		      mixpanel.track("Self Test Viewed", {"mediumSource" : "website", "itemName" : "Habit O Meter"});
		    }
			
			$.ajax({
				url : Utils.scriptPath() + "/socialShare.json",
				cache: false
			}).done(function(response){
				console.log( url );
				self.socialShareResponse = response[ url ];
                        
                console.log( 'socialShareResponse ' + JSON.stringify( self.socialShareResponse ) );

			}).error(function(error){
				console.log(error)
			});			
			

			$.ajax({
				url : Utils.scriptPath() + "/selfHelp/habitometer/question.json",
			}).done(function(response){
				console.log(response);
				self.questions = response;
			}).error(function(error){
				console.log(error)
			});

			$.ajax({
                url : Utils.scriptPath() + "/selfHelp/habitometer/answer.json",
            }).done(function(response){
            	self.answers = response;
            }).error(function(error) {
            	console.log( error );
            });
             setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)  
			// Utils.checkFromPageIsSelfHelp("#habitometer");
			return this;
		}
	});

	HabitOMeterPage.prototype.remove = function() {};

	HabitOMeterPage.prototype.clean = function() {};

	return HabitOMeterPage;
});
