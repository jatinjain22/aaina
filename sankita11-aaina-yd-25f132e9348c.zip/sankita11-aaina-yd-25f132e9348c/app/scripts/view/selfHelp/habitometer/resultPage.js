define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
      'view/packages/custompackage_modal',
      'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, customPackageModalView,Masonry, imagesLoaded ) {

	var HabitOMeterResultPage = Backbone.View.extend({
		
		el: "main",
            
            PageLayout : JST['app/templates/selfHelp/habitometer/layout.hbs'],
            AnswerLayout : JST['app/templates/selfHelp/habitometer/answer.hbs'],
            packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],
		initialize: function() {
			
                  this.customPackageModalView = new customPackageModalView();
                 
		},
            events:{

                  "click .build-custom-plan":"redirectToCustomPlan"
            },
            redirectToCustomPlan:function(){
                  var self = this;
                 
                  
                        //var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
                        
                         if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
                             mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'habitometer' ,"upsellFrom":"habitometer","packageName":"Custom Plan"});
                         }

                        var str = "1. Cut down on my time on Internet \n"+"2. Increase social Interaction \n"+"3. Being more productive/constructive (Daily routine) \n"+"4. Getting over loneliness \n"+"5. Procrastination \n"
                        //$('.custompackage-achieve').text(str);
                        //$('#custompackage-category').val(5)
                         self.customPackageModalView.render(str,'habitometer');
                         

            },
		render: function() {

                  var self = this;
                  console.log( "enter" );
                  var url = window.location.hash;
                  
                  if ( !localStorage.hasOwnProperty( "habitometerResult" ) ) {

                       Backbone.history.navigate("/habitometer",{trigger:true});

                  }
                  
                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/habitometer/answer.json",
                  }).done(function(response){
                        console.log(response);
                        var answers = response;
                        var thatsmeCnt = localStorage.habitometerResult;

                        self.$el.html( self.PageLayout() );

                       
                        $( ".yd-hom-content" ).addClass( "yd-hom-content-answer" );
                        var divStr = '<div class="habitometer-result-overlay"></div>' +
                                     '<div id="signup-form-habitometer"></div>';
                        
                        $( ".yd-hom-content-answer" ).append(divStr)
                         $( ".yd-hom-content" ).append(self.AnswerLayout({}));
                         self.$el.append(self.packageBannerLayout());

                        if (Utils.isMobileDevice()) {

                              $( ".habitometer-social-share-mobile-container" ).html( $( ".habitometer-social-share" ) );     
                        }
                        else {
                              $( ".habitometer-social-share-container" ).html( $( ".habitometer-social-share" ) );      
                        }
                        $( ".habitometer-social-share" ).removeClass( "hide" );
                        
                        if( thatsmeCnt <= 4){
                              $(".yd-hom-answer-heading").html(answers[0].heading);
                              $(".yd-hom-answer-desc").html(answers[0].description);
                              $(".yd-hom-img").attr('src', answers[0].photo);
                              $(".yd-hom-img-mobile").attr('src',answers[0].mobilephoto);
                        }

                        if( thatsmeCnt >= 5 && thatsmeCnt <= 10 ){
                              $(".yd-hom-answer-heading").html(answers[1].heading);
                              $(".yd-hom-answer-desc").html(answers[1].description);
                              $(".yd-hom-img").attr('src',answers[1].photo);
                              $(".yd-hom-img-mobile").attr('src',answers[1].mobilephoto);
                        }
                        
                        if( thatsmeCnt >= 11 && thatsmeCnt <= 15 ){
                              $(".yd-hom-answer-heading").html(answers[2].heading);
                              $(".yd-hom-answer-desc").html(answers[2].description);
                              $(".yd-hom-img").attr('src',answers[2].photo);
                              $(".yd-hom-img-mobile").attr('src',answers[2].mobilephoto);
                        }

                        if( thatsmeCnt >= 16 ){
                              $(".yd-hom-answer-heading").html(answers[3].heading);
                              $(".yd-hom-answer-desc").html(answers[3].description);
                              $(".yd-hom-img").attr('src',answers[3].photo);
                              $(".yd-hom-img-mobile").attr('src',answers[3].mobilephoto);
                        }

                        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
                              mixpanel.track("Self Test end", {"mediumSource" : "website", "itemName" : "Habit O Meter"});
                        }

                         if ( !Utils.isLoggedIn() ) {
                  
                              //overlay the css
                              //show the signup
                              localStorage.habitometerResult = thatsmeCnt;
                              
                              var buttonDesc = "show habitometer signup";
                              Dispatcher.trigger("renderLoginToDiv", buttonDesc, "habitometer", "show_result_post_signup", "signup-form-habitometer", url) ;
                              $("#signup-form-habitometer #login-modal").css({"display": "block", "width": "60%", 'top': '-4%', "position": "relative", "z-index": "10" });
                              $(".login-modal-close").addClass("hide");
                              $('.header-right-section .login-clicked').addClass('hide')
                              $(".habitometer-result-overlay").addClass("habitometer-result-overlay-show");
                    
                        } 
                        else {
                          $('.header-right-section .login-clicked').removeClass('hide')
                              delete localStorage.habitometerResult;
                        }


                  }).error(function(error){
                        console.log(error)
                  });
                   setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)     
            

			
		}
	});

	HabitOMeterResultPage.prototype.remove = function() {

      
            this.$el.empty();
            this.$el.off();
            this.unbind(); 
      
      };

	HabitOMeterResultPage.prototype.clean = function() {
            this.remove();
      };

	return HabitOMeterResultPage;
});
