define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
  'masonry',
  'imagesloaded',
	'purl'
], function($,_, Backbone, JST, Utils, UserModel, Dispatcher, Masonry, imagesLoaded) {

	var SelfHelpPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;


      },
      
      SelfHelpPageLayoutTemplate : JST['app/templates/selfHelp/layout.hbs'],
      

      events: {
        "click .letsTest": "playGame",
        "click .selfHelpTestColumn" : "trackMixpanel",
        
      }, 
      trackMixpanel : function(e){

        var url = $(e.currentTarget).find(".selfHelpTestCard").attr("href");
        var itemName = $(e.currentTarget).find( ".selfHelpTestCard" ).attr( "data-itemName" );
        console.log("in track");
        console.log(url);
        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Test card click", { "mediumSource" : "website", "itemName" : itemName });
        }
      },
      playGame: function(e) {
        var self = this;
        console.log( "hello" );
        console.log( "currentTarget" );
        console.log( $(e.currentTarget) );
        var dataSet = $(e.currentTarget).context.dataset;
        console.log( dataSet );
        var url = dataSet.url;
        var content = dataSet.content;
        var title = dataSet.title;
        self.$el.html( self.PlayBuzzTestIFrameTemplate({url:url, content:content, title: title}) );
      },
      
      onLoad: function(obj) {
        console.log('onLoad');
        console.log( obj );
        console.log( obj.target.clientHeight );
        console.log( obj.target.contentWindow );
        
      },
      render: function() {
   
        document.title="Simple Personality & Self Help Tests | YourDOST";
        $('meta[name=description]').attr('content', "Diferent types of personality & self-imporvement tests which includes, colour, shape, internet addiction test & more. Chat with experts to know more");
        $('meta[name=title]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
        $('meta[property="og:description"]').attr('content', "Diferent types of personality & self-imporvement tests which includes, colour, shape, internet addiction test & more. Chat with experts to know more");
        $('meta[property="og:title"]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/selfhelp');

        var self = this;
        
        setTimeout(function(){
          if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
            console.log( 'inside mixpanel' );
            mixpanel.track('Self Help Home Page', {'mediumSource' : 'website', 'itemtype': 'Self Help Home Page', 'itemName': 'Self Help Home Page'});
          
          } 
        }, 2000);

        $.ajax({
        
          url: Utils.scriptPath() + "/selfHelp/selfHelp.json",
        
        }).done( function( data ) {
            
            self.$el.html( self.SelfHelpPageLayoutTemplate({ selfTest: data }) );
            
            /*var elem = document.querySelector('.selfHelpTest-row');
            var imageLoad = new imagesLoaded( elem, function(){
              var msnry = new Masonry(elem, {
            
                columnWidth: '.col',
                itemSelector: '.col',
                percentPosition: true,
                originLeft: true
            
              });
            });*/
            

 
        }).error(function(error){
        
          console.log(error)
        
        });
         setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)     

        

      }

    });

  	SelfHelpPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind(); 
	};

	SelfHelpPage.prototype.clean = function() {

      this.remove();

	};

    return SelfHelpPage;
});