define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
  'masonry',
  'imagesloaded'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel,Masonry, imagesLoaded ) {

	var loveCompatibilityResult = Backbone.View.extend({
		
		el: "main",

    loveCompatibilityLayout: JST['app/templates/selfHelp/loveCompatibility/layout.hbs'],
    loveCompatibilityResultLayout : JST['app/templates/selfHelp/loveCompatibility/result.hbs'],
    
    initialize: function() {
      
      this.result = 0;
    },
    
    events : {
      
      "click .lcr-chat-btn":"directToChat",
    },

    directToChat: function(){

      this.trackMixpanelEvents("Button Click", "chat-loveCompatibility", "Redirecting to Chat") ;
        
      if(!Utils.isLoggedIn()){
      
        Dispatcher.trigger("renderLogin", "love-compatibility", "selfTest", "home_chat") ;
      }else{
  
        Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "love-compatibility");
      }
    },

    trackMixpanelEvents : function(identifier, itemName, itemType){

      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

        mixpanel.track(identifier, { "itemName" : itemName, "itemType" : itemType});
      }

    },

    getContent : function( url ){

      var deferred = $.Deferred();
      $.ajax({
        method : 'GET',
        url : url,

      }).done(function(response){

        deferred.resolve(response);

      }).error(function(error){

        deferred.reject(error);
      })

      return deferred.promise();
    },
               
    render: function() {
      
      if ( !localStorage.hasOwnProperty( "loveCompatibilityResult" ) ) {

        Backbone.history.navigate("/love-compatibility-quiz",{trigger:true});
      }

      this.result = parseInt(localStorage.loveCompatibilityResult);

      var resultPromise = this.getContent( Utils.scriptPath() + "/selfHelp/loveCompatibility/answers_mapping.json" );
      
      this.trackMixpanelEvents("loveCompatibility Result Served", "Result Page","result-"+this.result);

      var self = this;

      self.$el.html( this.loveCompatibilityLayout());

      $.when(resultPromise)
      .then(function(response){

        if( self.result <= 7 ){

          self.result = response.low;
        }else if( self.result > 7 && self.result <= 13 ){

          self.result = response.moderate
        }else{

          self.result = response.high;
        }

        self.$el.find(".lc-sub-inner").html(self.loveCompatibilityResultLayout( { result : self.result } ) )

      }, function(error){

        console.log("Error ", error);
      })
    }

  });

	loveCompatibilityResult.prototype.remove = function() {

    this.$el.empty();
    this.$el.off();
    this.unbind(); 
  
  };

	loveCompatibilityResult.prototype.clean = function() {

    this.remove();
  };

	return loveCompatibilityResult;
});
