define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

	var loveCompatibility = Backbone.View.extend({

		el: "main",

		initialize: function() {
			
			this.questionNo = 1;
			this.questions = {};
			this.mappingObj = {};
			this.optionIndex = -1;
			this.finalScore = 0;
			this.score = 0;
		},

		loveCompatibilityLayout: JST['app/templates/selfHelp/loveCompatibility/layout.hbs'],
		startloveCompatibilityLayout : JST['app/templates/selfHelp/loveCompatibility/start.hbs'],
		questionsLayout : JST['app/templates/selfHelp/loveCompatibility/questions.hbs'],

		events: {
			
			'click .lc-start-quiz' : 'startQuiz',
			'click .lc-next' : 'nextQuestion',
			'click .lc-prev' : 'prevQuestion',
			'click .newyear-options' : 'selectOption',
			'click .lc-img-box' : 'selectOption',
			'click .show-result' : 'showResult'
		},

		trackMixpanelEvents : function(identifier, itemName, itemType){

	      if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

	        mixpanel.track(identifier, { "itemName" : itemName, "itemType" : itemType});
	      }

	    },

		startQuiz : function(){

			this.trackMixpanelEvents("BUtton Click", "start love compatibility quiz", "clicked start love compatibility quiz")
			this.renderQuestions()
		},

		findSelectedOption : function( option, className ){

			this.optionIndex = $("."+className).index($(option.currentTarget))+1
			this.score = $(option.currentTarget).attr("data-score")
		},

		selectOption : function( evt ){

			var className = "newyear-options"
			if( $(evt.currentTarget).hasClass("image")){

				className =  "lc-img-box"
			}

			$("."+className).removeClass("option-selected")
			$(evt.currentTarget).addClass("option-selected")
			$(".lc-next").removeClass("disabled")
			this.findSelectedOption( evt, className )
			
			if( this.questionNo == Object.keys(this.questions).length ){

				$(".lc-next").removeClass("lc-next").addClass("show-result").html("<b>SHOW RESULT &gt;</b>")
			}
		},

		nextQuestion : function(){

			this.mappingObj[this.questionNo] = this.optionIndex;
			this.finalScore += parseInt(this.score)
			this.questionNo++;
			this.renderQuestions(false)
		},

		prevQuestion : function(){

			this.questionNo--;
			this.renderQuestions(true)
		},

		renderQuestions : function( option ){

			var questionsObj = this.questions;
			var self = this;
			var question = questionsObj[self.questionNo]
			question["qNo"] = this.questionNo;
			this.$el.find(".lc-sub-inner").html(this.questionsLayout({question : question}))
			
			if(option){

				if( question.type == "image"){

					$(".lc-img-box:nth-child("+this.mappingObj[this.questionNo]+")").addClass("option-selected")
				}else{

					$(".newyear-options:nth-child("+this.mappingObj[this.questionNo]+")").addClass("option-selected")
				}
				$(".lc-next").removeClass("disabled")
			}
			if(Utils.isMobileDevice()){

				$("body").animate({scrollTop:0}, '1000')
			}
			if( this.questionNo > 1){

				$(".lc-prev").removeClass("disabled")
			}
		},

		showResult : function(){

			this.trackMixpanelEvents("BUtton Click", "show result love compatibility quiz", "clicked show result love compatibility quiz")
			localStorage.loveCompatibilityResult = this.finalScore;

			Backbone.history.navigate("/love-compatibility-quiz/result",{trigger:true});
		},

		getContent : function( url ){

			var deferred = $.Deferred();
			$.ajax({
				method : 'GET',
				url : url,

			}).done(function(response){

				deferred.resolve(response);

			}).error(function(error){

				deferred.reject(error);
			})

			return deferred.promise();
		},
		
		render: function() {

			document.title="Are You & Your Partner Compatible?";
        
          	$('meta[name=description]').attr('content', "Compatibility is important to be happy in a relationship. Take this quiz and find out how compatible you and your partner are.");
          	$('meta[name=title]').attr('content',"Are You & Your Partner Compatible?");
          	$('meta[property="og:url"]').attr('content',"https://yourdost.com/will-you-succeed-in-your-resolution"); 
          	$('meta[property="og:description"]').attr('content', "Compatibility is important to be happy in a relationship. Take this quiz and find out how compatible you and your partner are.");
          	$('meta[property="og:title"]').attr('content',"Are You & Your Partner Compatible?");
          	$('meta[property="og:image"]').attr('content',"https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearQ2/quiz2-thumb-350x250.png");
          	$('meta[property="og:url"]').attr('content',"https://yourdost.com/love-compatibility-quiz ");
          	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/love-compatibility-quiz');

			this.$el.html( this.loveCompatibilityLayout() );
			this.$el.find(".lc-sub-inner").html(this.startloveCompatibilityLayout())

			var Questions = this.getContent( Utils.scriptPath() + "/selfHelp/loveCompatibility/questions.json" );
			
			this.trackMixpanelEvents("Love Compatibility Page", "love compatibility-questions", " ")

			var self = this;

			$.when(Questions)
			.then(function(response){

				self.questions = response.questions;

			}, function(error){

				console.log("Error ", error);
			})
		}

	});

	loveCompatibility.prototype.remove = function() {

		$(".dost-main").css({"background" : "#fff"})
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
	};

	loveCompatibility.prototype.clean = function() {

		this.remove();
	};

	return loveCompatibility;
});
