define([
      'jquery',
      'underscore',
      'backbone',
      '../../../precompiled-templates',
      'utils',
      'event/dispatcher',
      'model/users',
      'helpers/selfHelpTestUtils/trueColorUtils'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, TrueColorUtils ) {

      var TrueColorPage = Backbone.View.extend({

            el: "main",

            initialize: function() {
                  this.questions = {};
                  this.setCount = 0;
                  this.optionClickedCount = 0;
                  this.answers = {};
                  this.userModel = new UserModel();
                  this.optionClickedValue = {1:4, 2:3, 3:2, 4:1};
                  this.colorCodes = {};
                  this.result = {};
                  this.socialShareResponse = {};
                  this.url = "";

            },


            events: {

                  "click .back-to-selfHelp" : "renderSelfHelp",
                  "click .true-color-option-card" : "selectOption",
                  "click .true-color-take-test" : "showNextSet",
                  "click .true-color-set-redo-button" : "redoTheSet",
                  "click .true-color-take-retest": "reTakeTest", 
                  "click .landing-page-true-color-take-test": "showNextSet",
                  "click .login-clicked": "showLogin",
                  'click .user-dropdown' : 'userPersonalMenu'
            },

            QuestionOptionLayout : JST['app/templates/selfHelp/trueColor/questionOptions.hbs'],
            ResultLayout: JST['app/templates/selfHelp/trueColor/result.hbs'],
            HomePageLayout: JST['app/templates/selfHelp/trueColor/homePage.hbs'],
            ErrorPageLayout: JST['app/templates/selfHelp/trueColor/error.hbs'],
            LandingPageHomeLayout: JST['app/templates/trueColorLandingPage/layout.hbs'],
            LandingPageHeaderLayout: JST['app/templates/landingPage/landingPageHeader.hbs'],

            userPersonalMenu : function(e){

                  console.log("hello");
                  var dropDownEl = $("#loggedin-dropdown5");
                  if ( dropDownEl.hasClass("hide") ) {
                        dropDownEl.removeClass("hide").addClass("fadeInDown animated");
                  } else {
                        dropDownEl.addClass("hide").addClass("fadeInDown animated");
                  }
            
            },
            showLogin: function(e) {

                  e.preventDefault();
                  e.stopPropagation();
                  console.log( "login" );
                  if(!Utils.isLoggedIn()){
                        Dispatcher.trigger("renderLogin", "click Landing Home Page", "login", "loginButton") ;
                  }

            },
            renderSelfHelp: function() {

               Backbone.history.navigate("/selfhelp",{trigger:true});
            
            },
            redirectToResultPage: function() {

                  var url = Backbone.history.getFragment();
                  if ( url == "truecolour" ) {

                        Backbone.history.navigate("truecolour/result",{trigger:true});
                  
                  } else if ( url == "truecolourpage" ) {
                        Backbone.history.navigate( "truecolourpage/result", {trigger: true} );
                  }

            },
            showResult: function() {

                  var self = this;
                  
                  var arrayColorValue = TrueColorUtils.getArrayOfColorValues( self.colorCodes );
                  var anyDuplicateColorValArr = Utils.getDuplicateValuesFromArray( arrayColorValue );

                  var blueVal = arrayColorValue[0];
                  var orangeVal = arrayColorValue[1];
                  var greenVal = arrayColorValue[2];
                  var goldVal = arrayColorValue[3];
                  var sum = arrayColorValue[4];

                  var maxValue = Math.max( orangeVal, blueVal, greenVal, goldVal );
                  console.log( maxValue );

                  if ( _.contains(anyDuplicateColorValArr, maxValue) ) {

                        self.$el.find(".true-color-test-page-holder").html( self.ErrorPageLayout() );
                        return;

                  }

      		var resultColor  = sum[maxValue];
      		console.log( 'your color is '+ resultColor );

                  localStorage.trueColorResult = resultColor;


                  console.log( localStorage.trueColorResult );
                  self.redirectToResultPage();
                  


            },
            getTheNotSelectedOptionInASet: function() {

                  var notSelectedCard = $( '.true-color-option-card' ).not( '.true-color-option-card-selected' );
                  console.log( "notSelectedCard ");
                  console.log( notSelectedCard[0].dataset.key );
                  var notSelectedCardKey = notSelectedCard[0].dataset.key.toString();
                  return notSelectedCardKey;

            },
            redoTheSet: function(e) {

                  var self = this;
                  console.log( ' redo ' );
                  console.log( $('.true-color-option-card') );
                  $('.true-color-option-card').removeClass( 'true-color-option-card-selected' );
                  self.optionClickedCount = 0;
                  self.showQuestion( self.optionClickedCount );
                  TrueColorUtils.trackMixpanel( "Step No Revisited", self.setCount );

            },
            showQuestion: function( optionClickedCount ) {

                  var self= this;
                  var questions = self.questions[ self.setCount.toString() ][ self.optionClickedCount.toString() ];
                  if ( questions ) {
                        var questionHTML = "";
                        for(var i=0; i<questions.length; i++) {
                              questionHTML += '<div>' + questions[i] + '</div>';
                        }
                        $('.true-color-question').html( questionHTML ).fadeIn(1500);
                  }

            },
            selectOption: function(e) {

                  var self = this;
                  var currentTarget = $(e.currentTarget);

                  if( !currentTarget.hasClass('true-color-option-card-selected') ) {

                        currentTarget.addClass('true-color-option-card-selected');
                        var key = currentTarget.data("key").toString();
                        ++self.optionClickedCount;

                        if ( self.optionClickedCount === 1 ) {

                              $(".true-color-set-redo-button").removeClass("hide");

                        }
                        self.showQuestion( self.optionClickedCount );

                        if ( self.optionClickedValue.hasOwnProperty( self.optionClickedCount ) ) {
                              self.colorCodes['"'+key+'"'] = self.optionClickedValue[ self.optionClickedCount ];
                        }

                  }


                  if ( self.optionClickedCount === 3 ) {

                        $(".true-color-set-redo-button").addClass("hide");
                        $( ".true-color-loader" ).removeClass( "hide" );
                        ++self.optionClickedCount;
                        key = self.getTheNotSelectedOptionInASet();
                        self.colorCodes['"'+key+'"'] = self.optionClickedValue[ self.optionClickedCount ];

                        setTimeout(function(){
                           self.showNextSet();
                        }, 1000);

                  }

            },
            reTakeTest: function(e) {

                  var self = this;
                  self.setCount = 0;
                  self.showNextSet();

            },
            showNextSet : function(e){


                  var self= this;
                  self.optionClickedCount = 0;
                  console.log( self.setCount );
                  TrueColorUtils.trackMixpanel( "Step No", self.setCount );
                  ++self.setCount;

                  if ( self.setCount == 6) {
                        self.showResult();
                        return 1;
                  }
                  var options = self.answers[ self.setCount.toString() ];
                  var defaultQuestion = self.questions[ self.setCount.toString() ][ self.optionClickedCount.toString() ];

                  self.$el.find(".true-color-test-page-holder").html( self.QuestionOptionLayout({setNo:self.setCount, options:options, defaultQuestion: defaultQuestion}) );

                  if ( Utils.isMobileDevice() ) {
                        Utils.scrollTo(".dost-main", 0);
                  }

                  $( ".true-color-set-no-" + self.setCount ).removeClass( "hide" );
                  for ( var i=1; i <= self.setCount; i++ ) {
                        $( ".circle-true-color-"+ i ).addClass('circle-true-color-visited');
                  }


            },

            
            checkForLogin: function() {


                  var self = this;
                  
                  var username    = "" ;
                  var userAvatar  = "" ;
                  var firstName   = "" ;
                  var userType = "VICTIM";
                  var picUrl = "" ;
                  var user_id = '';
                  
                  if( Utils.isLoggedIn() ){  
                        
                        username = this.userModel.getUserName() ;
                        firstName = this.userModel.getFirstName() ;
                        picUrl = this.userModel.getPicUrl();
                        user_id = this.userModel.getUserID() ; 
                        if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){
                              username = firstName ;
                        }
                        if(picUrl){
                              userAvatar = picUrl ;
                        }else{
                              userAvatar = this.userModel.getUserAvatar() ;
                              userAvatar = Utils.avatarToImage(userAvatar) ;
                        }
                        
                        userType = this.userModel.getUserType();
                  }
                  
                  $(".true-color-landing-page").prepend( self.LandingPageHeaderLayout({  userAvatar: userAvatar, user_id : user_id, username : username , isLoggedIn : Utils.isLoggedIn,  userType: userType } ) );
                  console.log( "isLoggedIn", Utils.isLoggedIn() );
                  
                  
                                    
            },

            renderHomePage: function( url ) {

                  var self = this;

                  if ( url == "truecolour" ) {
                  
                        document.title="Simple Personality & Self Help Tests | YourDOST";

                        $('meta[name=description]').attr('content', "Take this shape test to know your personality color & also you can chat with experts to know more & develop your personality");
                        $('meta[name=title]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
                        $('meta[property="og:description"]').attr('content', "Take this shape test to know your personality color & also you can chat with experts to know more & develop your personality");
                        $('meta[property="og:title"]').attr('content',"Simple Personality & Self Help Tests | YourDOST");
                        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/truecolour');
                        
                        self.$el.html( self.HomePageLayout() );
                             
                        

                  }else if( url == "truecolourpage" ){

                        self.$el.html( self.LandingPageHomeLayout() );
                        self.checkForLogin();
                        
                  }
                  TrueColorUtils.trackMixpanel( "Self Test Viewed" ); 
                  
            },
            render: function() {
                        
                  
                  var self = this ;
                  var url = Backbone.history.getFragment();
                  
                  self.renderHomePage( url );

                  
                  var elem = document.querySelector('.true-color-home-images-holder-row');

                  TrueColorUtils.arrangeColorPatch( elem );

                  TrueColorUtils.getQuestions().done(function(response){
                        console.log(response);
                        self.questions = response;
                  }).error(function(error){
                        console.log(error)
                  });


                  TrueColorUtils.getQuestionOptions().done(function(response){
                        self.answers = response;

                  }).error(function(error){
                        console.log(error)
                  });
                   setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)  

                  return this;
            }
      });

      TrueColorPage.prototype.remove = function() {};

      TrueColorPage.prototype.clean = function() {};

      return TrueColorPage;
});
