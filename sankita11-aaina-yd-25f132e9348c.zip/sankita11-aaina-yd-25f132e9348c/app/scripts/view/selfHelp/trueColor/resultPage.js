define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
      'view/packages/custompackage_modal',
      'masonry',
      'imagesloaded',
      'helpers/selfHelpTestUtils/trueColorUtils'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel,customPackageModalView,Masonry, imagesLoaded, TrueColorUtils ) {

	var TrueColorResultPage = Backbone.View.extend({
		
		el: "main",
            
            ResultLayout: JST['app/templates/selfHelp/trueColor/result.hbs'],
            LoginModalPageLayout : JST["app/templates/login/login_modal.hbs"],
            MobileDeviceSignInLayout: JST["app/templates/selfHelp/mobileDeviceSignIn.hbs"],
            LandingPageHeaderLayout: JST['app/templates/landingPage/landingPageHeader.hbs'],
            packageBannerLayout: JST["app/templates/selfHelp/packagesBanner.hbs"],

		initialize: function() {
			this.userModel = new UserModel() ;
                  this.customPackageModalView = new customPackageModalView();
                  this.result ="";

		},
            events:{

                  "click .true-color-hom-talkItOut": "redirectToChat",
                  "click .true-color-facebook-share": "shareOnFacebook",
                  "click .result-report-sign-in em": "showSignUp",
                  "click .login-clicked": "showLogin",
                  'click .user-dropdown' : 'userPersonalMenu',
                  "click .build-custom-plan":"redirectToCustomPlan"
            },
            redirectToCustomPlan:function(){
                  var self = this;
                  console.log(self.result);

                  
                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/trueColor/custom_package_prefill.json",
                  }).done(function(response){
                       
                        console.log(response)
                        //var  str= "Based on your test results, we have suggested some outcomes. Feel free to modify as you wish:-\n\n"
                        
                         if(typeof mixpanel !== 'undefined'){
                             mixpanel.track("Upsell served - Packages - Tests", { "mediumSource" : "website", "itemName" : 'trueColor' ,"upsellFrom":"trueColor","packageName":"Custom Plan"});
                         }
                         var str = response[self.result][1]+"\n"+ response[self.result][2]+"\n" +response[self.result][3];
                         self.customPackageModalView.render(str,'trueColor');
                         
                        

                  }).error(function(error){

                        console.log("Error ", error);
                  });

            },

            userPersonalMenu : function(e){

                  console.log("hello");
                  var dropDownEl = $("#loggedin-dropdown5");
                  if ( dropDownEl.hasClass("hide") ) {
                        dropDownEl.removeClass("hide").addClass("fadeInDown animated");
                  } else {
                        dropDownEl.addClass("hide").addClass("fadeInDown animated");
                  }
            
            },
            showLogin: function(e) {

                  e.preventDefault();
                  e.stopPropagation();
                  console.log( "login" );
                  if(!Utils.isLoggedIn()){
                        Dispatcher.trigger("renderLogin", "click Landing Home Page", "login", "loginButton") ;
                  }

            },

            replaceWithFalseData: function() {

                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/trueColor/falseResult.json",
                        cache: false
                  }).done(function(data){
                        var response = data["falseColor"];
                        $(".true-color-result-childhood-row .font-14").html( response["childhood"] );
                        $(".true-color-result-relationships-row .font-14").html( response["relationships"] );
                        $(".true-color-result-work-row ").html( response["work"] );
                        $(".true-color-leadership-style-col div").html( response["leadership-style"] );
                        $(".true-color-badday-style-col div").html( response["bad-day"] );
                        $(".true-color-famous-style-col div").html( response["famous-people"] );

                  }).error(function(error){
                        console.log(error)
                  });

            },
            showSignUp: function(e){

                  var url = Backbone.history.getFragment();

                  console.log( url );
                  var buttonDesc = "show true color signup";
                  Dispatcher.trigger("renderLogin", buttonDesc, "trueColor", "show_result_post_signup",  url) ;

            },
            changeCSS: function() {

                  $(".true-color-result-overlay").addClass("true-color-result-overlay-show");
                  $( ".true-color-result-middle-col" ).addClass( "blurredText" );
                  $( ".true-color-result-last-section" ).addClass( "blurredText" );
                  $( ".true-color-result-last-button-col" ).addClass( "blurredText" );
            
            },
            removeChangeCSS: function() {
                  $(".true-color-result-overlay").removeClass("true-color-result-overlay-show");
                  $( ".true-color-result-middle-col" ).removeClass( "blurredText" );
                  $( ".true-color-result-last-section" ).removeClass( "blurredText" );
                  $( ".true-color-result-last-button-col" ).removeClass( "blurredText" );
            },
            shareOnFacebook: function(e) {
                  
                  var self = this;
                  var url = Backbone.history.getFragment();;
                  var targetElement = $(".true-color-social-share");
                  var loaderElement = $(".selfhelp-share-on-facebook-loader");
                  var mixpanelEvent = "Self Help Test Shared";
                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  $.ajax({
                        url : Utils.scriptPath() + "/socialShare.json",
                        cache: false
                  }).done(function(response){
                        console.log( url );
                        var socialShareResponse = response[ url ];
                        
                        console.log( 'socialShareResponse ' + JSON.stringify( socialShareResponse ) );
                        
                        Utils.shareOnFacebook( socialShareResponse, targetElement, loaderElement, mixpanelEvent ); 
                        
                  }).error(function(error){
                        console.log(error)
                  });
                 
            
            },
            redirectToChat : function(e) {

                  var self = this;

                  
                  var buttonDesc = $(e.currentTarget).attr("data-desc");
                  if(!Utils.isLoggedIn()){
                        Dispatcher.trigger("renderLogin", buttonDesc, "trueColorselfTest", "home_chat") ;
                  }else{

                        if ( !$(e.currentTarget).hasClass("disabled") ) {

                              if (  ( typeof fbq != 'undefined' ) ){
                                    fbq('track', 'Lead');                           
                              }

                              var fromText = btoa("Came from What's Your Color");

                              var username = this.userModel.getUserName() ;
                              location.href = Utils.chatUrl() + username + "&from=" + fromText;
                              $(e.currentTarget).addClass("disabled");
                        }
                  }

            },
            
            checkForLogin: function() {

                  var self = this;
                  
                  var username    = "" ;
                  var userAvatar  = "" ;
                  var firstName   = "" ;
                  var userType = "VICTIM";
                  var picUrl = "" ;
                  var user_id = '';
                  
                  if( Utils.isLoggedIn() ){  
                        
                        username = this.userModel.getUserName() ;
                        firstName = this.userModel.getFirstName() ;
                        picUrl = this.userModel.getPicUrl();
                        user_id = this.userModel.getUserID() ; 
                        if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){
                              username = firstName ;
                        }
                        if(picUrl){
                              userAvatar = picUrl ;
                        }else{
                              userAvatar = this.userModel.getUserAvatar() ;
                              userAvatar = Utils.avatarToImage(userAvatar) ;
                        }
                        
                        userType = this.userModel.getUserType();
                  }
                  
                  $(".true-color-result-container").prepend( self.LandingPageHeaderLayout({  userAvatar: userAvatar, user_id : user_id, username : username , isLoggedIn : Utils.isLoggedIn,  userType: userType } ) );
                  $(".true-color-result-container").addClass( "white" );
                  console.log( "isLoggedIn", Utils.isLoggedIn() );
                  
                  
                                    
            },

            addHeaderForLandingPage: function( url ) {
                  
                  var self = this;

                  if ( url == "truecolourpage/result" ) {
                        self.checkForLogin();
                  }

            },

		render: function() {

                  var self = this;
                  console.log( "enter" );
                  var url = Backbone.history.getFragment();;
                  self.url = url;
                  
                  
                  
                  if ( !localStorage.hasOwnProperty( "trueColorResult" ) ) {

                      Backbone.history.navigate("/truecolour",{trigger:true});
                  }
                  

                  $.ajax({
                        url : Utils.scriptPath() + "/selfHelp/trueColor/result.json",
                  }).done(function(response){
                        console.log( response );
                        this.result = response;
                        
                        var resultColor = localStorage.trueColorResult;

                        var resultColorValue = this.result[resultColor];
                        self.result = resultColor;
                        console.log( 'resultColorValue ');
                        console.log( resultColorValue );
                        console.log(self.$el);
                        self.$el.html( self.ResultLayout({color: resultColor, resultColorValue: resultColorValue}) );
                        self.$el.append(self.packageBannerLayout());
                        self.addHeaderForLandingPage( self.url );
                       
                        if ( !Utils.isLoggedIn() ) {
                  
                              localStorage.trueColorResult = resultColor;
                              
                              var buttonDesc = "show true color signup";
                                $('.header-right-section .login-clicked').addClass('hide')

                              if (window.matchMedia("(min-width: 601px)").matches) {

                                    Dispatcher.trigger("renderLoginToDiv", buttonDesc, "trueColor", "show_result_post_signup", "signup-form-trueColor", url) ;
                                    $(".login-modal-close").addClass("hide");
                                    

                              } else {
                                    
                                    $("#signup-form-trueColor").html( self.MobileDeviceSignInLayout() );

                              }
                              self.changeCSS();
                              self.replaceWithFalseData();                
                              TrueColorUtils.trackMixpanelForResultPage("Self Test End", "unseen-signup");
                              
                        }else {
                              TrueColorUtils.trackMixpanelForResultPage("Self Test End");
                                $('.header-right-section .login-clicked').removeClass('hide')
                              var username = self.userModel.getUserID();
                              var testName = "True Color";
                              var answer = resultColor.toString();
                              self.removeChangeCSS();
                              
                              Utils.storeSelfHelpResult( username, testName, answer );  
                        } 

                        
                        

                  }).error(function(error){
                        console.log(error)
                  });
                   setTimeout(function(){

                        $( window ).scroll(function() {                       
                     
                       
                        var pos =  $(window).scrollTop();
                                   
                           if(pos>=75){
                              $( ".banner-package-upsell-container" ).removeClass('hide');

                              $( ".banner-package-upsell-container" ).fadeIn( "slow", function() {
                                              // Animation complete
                                            });
                              
                             
                        }
                        if(pos < 75){
                             // $('.footer-app').addClass('hide');
                             $( ".banner-package-upsell-container" ).fadeOut( "slow", function() {
                                              // Animation complete
                                            });
                            
                            
                          }
                      });

                  }, 1000)  

			
		}
	});

	TrueColorResultPage.prototype.remove = function() {

           
            this.$el.empty();
            this.$el.off();
            this.unbind(); 
      
      };

	TrueColorResultPage.prototype.clean = function() {
            this.remove();
      };

	return TrueColorResultPage;
});
