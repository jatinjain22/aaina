define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'event/dispatcher',
	'../../precompiled-templates',
], function($, _, Backbone, Utils, Dispatcher, JST ) {

	var Error403Page = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.listenTo(Dispatcher, 'renderError403', this.render);
		},
		events: {
			'click .error403-close' : 'redirectToHome' , 
		},
		redirectToHome : function(e){
			Utils.closePopup("error403-modal");
			//sessionStorage.clear() ;
			localStorage.removeItem("user");
	 	    //localStorage.removeItem("isLoggedIn");
			//location.href = "/!" ;
			Backbone.history.navigate("/!", {trigger: true});
		},
		Error403Layout: JST['app/templates/error403/layout.hbs'],
		render: function() {
			this.$el.append(this.Error403Layout()) ;
			Utils.openPopup("error403-modal") ;
		},
	});

	Error403Page.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	Error403Page.prototype.clean = function() {

    	this.remove();

	};

	return Error403Page;
});