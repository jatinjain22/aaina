define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'utils',
], function($,_, Backbone, JST, Utils ) {

    var DownloadAppPage = Backbone.View.extend({

      el: 'main',

      DownloadAppPageTemplate : JST['app/templates/mobileApps/layout.hbs'],

     
      render: function() {

        this.$el.html( this.DownloadAppPageTemplate() );

        return this;

      }


    });

  DownloadAppPage.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind();
	};

	DownloadAppPage.prototype.clean = function() {

      this.remove();

	};

    return DownloadAppPage;
});
