define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'view/packages/ask_email',
	'view/packages/packages_faq',
	'purl'
], function($,_,Backbone, JST, Utils, UserModel, Dispatcher, AskEmailModal, FaqPage){

	var SchedulePage = Backbone.View.extend({

		el : "main",
		
		initialize : function(){

			this.userModel = new UserModel();
		},

		events : {

			"click .talk" : "talkToExpert",
			'click .package-payment-try-again' : 'tryPaymentAgain',
		},

		talkToExpert : function(e){

			var chatUrl = Utils.justChatUrl();
			var chatWorkgroup = Utils.chatWorkgroup();

			var counselorId = $(e.currentTarget).attr("data-id")
			var counselorName = $(e.currentTarget).attr("data-name")

			this.registerMixPanelEvents("Button Click", "NY_WP_Chat_Clicked");

			if(counselorName == ""){

				counselorName = "demo";
				chatWorkgroup = chatWorkgroup.split("yd")[1];
			}else{

				counselorName = counselorName+"__"
			}

			var userName = this.userModel.getUserName();

			location.href = chatUrl+"/?workgroup="+counselorName+chatWorkgroup+"&username="+userName;

		},
		tryPaymentAgain : function(e){

			$(".package-payment-try-again").html("Redirecting to PayU...")
			
			var userID = this.userModel.getUserID();

			var packageId = $(e.currentTarget).attr("data-packageId")
			var amount = $(e.currentTarget).attr("data-amount");

			this.registerMixPanelEvents("Button Click", packageId, userID, "payment try again");

	    	$.ajax({
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				url : Utils.contextPath()+ "/v1/user/"+userID+"/package/"+packageId+"/amount/"+amount,
			}).done(function(response){

				$(".package-payment-try-again").html("Try Again")
				
				if(!response.error){

					location.href = response.uri;
				}
			}).error(function(error){

				$(".package-payment-try-again").html("Try Again")
				console.log("Error: ", error)
			})
		},

		Layout : JST['app/templates/newYearPackages/schedule_page.hbs'],
		StandardPlanLayout : JST['app/templates/newYearPackages/standard_plan.hbs'],
		StandardPlanFooterLayout : JST['app/templates/newYearPackages/standard_plan_footer.hbs'],
		PaymentLayout : JST['app/templates/newYearPackages/payment.hbs'],
		PremiumPlanLayout : JST['app/templates/newYearPackages/premium_plan.hbs'],
		WeeklyPlanLayout : JST['app/templates/newYearPackages/weekly_plan.hbs'],
		PaymentFailedLayout : JST['app/templates/newYearPackages/payment_failure.hbs'],
		
		registerMixPanelEvents : function(eventName, itemName, itemType, itemStatus){

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track(eventName, {"itemName" : itemName, "itemType" : itemType, "itemStatus" : itemStatus});
			}
		},

		render : function(){
			$("#main-header").hide();
			var packageId = window.location.href.split("packageId=")[1];
			var self = this;

			this.$el.html(this.Layout());
			$.ajax({
				method: "GET",
				//url : "https://yourdost.com/zion/packages/2/schedule",
				url : Utils.contextPath() + "/packages/" + packageId + "/schedule1",
				contentType: "application/json",
			}).done(function(response){
				
				if( window.location.href.search("failure") > -1){

					self.$el.find(".ny-plan-container").html(self.PaymentFailedLayout({response : response}));
					self.registerMixPanelEvents("NY_WP_Served", response.title, self.userModel.getUserID(), "payment failure");
				}else{

					self.$el.find(".schedule-container").html(self.WeeklyPlanLayout({details:response.scheduleDetails}));
					self.$el.find(".standard-footer").html(self.StandardPlanFooterLayout({details:{
							expert: response.expert
						}}));
					if (window.location.href.indexOf("success") > -1) {

						self.$el.find(".expert-container-main").html(self.PremiumPlanLayout({details:{
							expert: response.expert,
							description: response.description
						}}));
						self.$el.find(".ny-payment-details-main").html(self.PaymentLayout({details: {
							date: response.purchasedOn,
							amount: response.amount,
							id: window.location.href.split("success=")[1].split("&packageId")[0]
						}}));

						self.registerMixPanelEvents("NY_WP_Served", response.title, self.userModel.getUserID(), "payment success");

					} else {

						self.$el.find(".standard-header").html(self.StandardPlanLayout());
					}
				}
			}).error(function(error){

				//window.location.href = "https://yourdost.com/new-year-resolution";
			})
		}
	});

	SchedulePage.prototype.remove = function() {
		$("#main-header").show();
	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	SchedulePage.prototype.clean = function() {		
		this.remove();
	};

    return SchedulePage;

})

