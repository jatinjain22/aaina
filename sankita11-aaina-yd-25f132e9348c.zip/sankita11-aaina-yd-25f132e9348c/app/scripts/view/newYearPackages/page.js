define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'purl',
	'ajax-chosen',
	'Swiper'
], function($,_,Backbone, JST, Dispatcher, Utils){

	var NewYearPackagesPage = Backbone.View.extend({

		el : "main",
		
		initialize : function(){

		},

		events : {
			"click .banner" : "redirectPackage",
			"click .cta" : "redirectPackage",
			"click .swiper-button-prev" : "registerMixpanelEvents",
			"click .swiper-button-next" : "registerMixpanelEvents",
			"click .swiper-pagination-bullet" : "registerMixpanelEvents"
		},

		Layout : JST['app/templates/newYearPackages/layout.hbs'],
		CardsLayout : JST['app/templates/newYearPackages/card.hbs'],
		LoadingLayout : JST['app/templates/packages/loader.hbs'],
		testimonailsLayout:JST['app/templates/newYearPackages/user_testimonials.hbs'],

		registerMixpanelEvents : function(evt){

			if($(evt.currentTarget).hasClass("swiper-button-prev")){

				this.registerEvent("slide-previous")
			}else if( $(evt.currentTarget).hasClass("swiper-button-next") ){

				this.registerEvent("slide-next")
			}else{

				var rank = $(evt.currentTarget).index();
				this.registerEvent("slide-next - "+ rank)
			}
		},

		registerEvent : function(itemtype){

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("Button Click", {"itemName" : "NY_Testimonial_Slide", "itemType" : itemType});
			}
		},

		redirectPackage: function (evt) {

			var loc = evt.currentTarget.getAttribute('data-location');

			if( loc == "talk-to-expert"){

				if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
					mixpanel.track("Button Click", {"itemName" : "New Year Packages Talk to Experts"});
				}

				if(!Utils.isLoggedIn()){
				
					Dispatcher.trigger("renderLogin", "new year packages", "home", "home_chat") ;
				}else{
		
					Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "PACKAGE_NEW_YEAR");
				}
			}else{

				var buttonDesc = evt.currentTarget.getAttribute('data-name');

				if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
					mixpanel.track("Button Click", {"itemName" :"NY_Package_Clicked", "itemType" : buttonDesc});
				}
				window.location.href = loc;
			}
		},

		getParsedResponse : function(response) {

			var parsedList = {
				row0: [],
				row1: []
			};
			var details = {};
			var package = {};
			for (var i=0; i<5; i++) {
				details = {};
				package = response[i];
				details.title = package['title'];
				details.cta = package['cta'];
				details.image = package['image'];
				details.keyOutcomes = package['keyOutcomes'];
				details.location = package['location'];
				parsedList["row" + parseInt(i/3)].push(details);
			}
			parsedList["row1"].push({
				title: "Custom resolution",
				cta: "TALK TO AN EXPERT NOW",
				location: "talk-to-expert",
				image: "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearPackages/Custom.png",
				keyMessage: "If we missed YOUR resolution, our expert will create a plan that suits right now."
			});
			return parsedList;
		},

		getUserTestimonials : function(){

			var self = this;

			$.ajax({
				method : "GET",
				url : '/scripts/json/user_testimonials.json',
				contentType: 'text/plain',
			}).done(function(response){

				$(".testimonials-content").html(self.testimonailsLayout({testimonials : response}));
				
				var mySwiper = new Swiper ('.hv-testimonials-swiper', {
				    
				   	pagination: '.ny-testimonials-pagination',
	        		paginationClickable: true,
	        		autoplay: 15000,
	        		keyboardControl: true,
			        nextButton: '.swiper-button-next',
			        prevButton: '.swiper-button-prev',
				});

			}).error(function(error){
				
				console.log(error);
			});
		},

		render : function(){
			
			$("#main-header").hide();

			document.title="How To Succeed In Your New Year's Resolution";
			
			$('meta[name=description]').attr('content', "Do your New Year Resolution fizzle very soon? The key to success is the right resolution, right plan and right mentor. Get the combination right to succeed in your resolutions.");
			$('meta[name=title]').attr('content',"How To Succeed In Your New Year's Resolution");
			
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/new-year-resolution');
			
			$('meta[property="og:url"]').attr('content',"https://yourdost.com/new-year-resolution");	
			$('meta[property="og:description"]').attr('content', "Do your New Year Resolution fizzle very soon? The key to success is the right resolution, right plan and right mentor. Get the combination right to succeed in your resolutions.");
			$('meta[property="og:title"]').attr('content',"How To Succeed In Your New Year's Resolution");
			$('meta[property="og:image"]').attr('content', "https://s3-ap-southeast-1.amazonaws.com/yourdost-images/newYearPackages/nylp-fb-ogtag-img.jpg");

			var self = this;

			this.$el.html(this.Layout());


			Utils.fetchNewYearPackages()
			.then(function (response) {
				self.$el.find(".cards-container").html(self.CardsLayout({cardsList:self.getParsedResponse(response)}));
			});

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){ 
						
				mixpanel.track("NY_LP_Served", {"itemName" : "New Year Packages Landing Page"});
			}

			this.getUserTestimonials();
		}
	});

	NewYearPackagesPage.prototype.remove = function() {
		$("#main-header").show();
	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	NewYearPackagesPage.prototype.clean = function() {

	    this.remove();

	};

    return NewYearPackagesPage;

})