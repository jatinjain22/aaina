define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'model/users' ,
	'event/dispatcher',
	'view/packages/ask_email',
	'view/packages/packages_faq',
	'purl'
], function($,_,Backbone, JST, Utils, UserModel, Dispatcher, AskEmailModal, FaqPage){

	var SingleNewYearPage = Backbone.View.extend({

		el : "main",

		initialize : function(){

			this.userModel = new UserModel();
			this.packageName = '';
		},

		events : {
			'click .enroll' : 'enrollPremium',
			'click .enquiry' : 'startFreeSession',
			'click .standard-plan-container .started' : 'enroll',
			'click .premium-plan-container .started' : 'enrollPremium',
			// "click .plan-types" : "showPlan",
			"click .collapsible-header" : 'registerFaqEvents'
		},

		Layout : JST['app/templates/newYearPackages/single_page.hbs'],
		BannerLayout : JST['app/templates/newYearPackages/banner_layout.hbs'],
		LodingLayout : JST['app/templates/packages/loader.hbs'],

		startFreeSession : function(){

			this.registerMixPanelEvents("Button Click", "Chat Initiated", this.packageName, "");

			if(!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "new year packages", "home", "home_chat") ;
			}else{

				Dispatcher.trigger('chatQuickCheck', 'demo', 0);
			}
		},

		showPlan : function( evt ){


			var parent = $(evt.currentTarget).parent(".plan-container");

			if(parent.hasClass("active")){

				$(".plan-container").removeClass("active");
			}else{

				$(".plan-container").removeClass("active");
				$(evt.currentTarget).parent(".plan-container").addClass("active");
			}
		},

		enroll: function (evt, options) {

			var status = "login";
			if( !Utils.isLoggedIn() ){

				status = "logout";
			}

			if($(evt.currentTarget).hasClass("enroll")){

				this.registerMixPanelEvents("Button Click", "NY_PD_Enroll_Clicked", this.packageName, status);
			}else{

				this.registerMixPanelEvents("Button Click", "NY_PD_Plan_Clicked", this.packageName, status);
			}

			var amount = 0;
			if (options && options.amount) amount = options.amount;
			var callback = this.buyPackage.bind(this);
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "Package Buy Now", "Package Detail Page", "buy_ny_package", {
					options : {
						packageId: this.packageId,
						amount: amount
					},
					callback: callback
				} ) ;
			}else{
				this.buyPackage({
					packageId: this.packageId,
					amount: amount
				});
			}
		},

		enrollPremium: function (evt) {
			this.enroll(evt, {
				amount: 200//499
			});
		},

		buyPackage: function (options) {

			var userID = this.userModel.getUserID();
			$(".ny-loader").css('visibility', 'visible');
	    	$.ajax({
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				url : Utils.contextPath()+ "/v1/user/"+userID+"/package/"+options.packageId+"/amount/"+options.amount,
			}).done(function(response){
				if(!response.error){
					if (options.amount == 0) {
						location.href = location.href + "/plan?packageId=" + response.uri;
					} else {
						location.href = response.uri;
					}

				}
			}).error(function(error){

			})
		},
		registerFaqEvents : function( evt ){


			this.registerMixPanelEvents("Button CLick", "NY_PD_FAQ_Clicked", this.packageName, $(evt.currentTarget).text(), "")
		},

		registerMixPanelEvents : function(eventName, itemName, itemType, itemStatus){

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

				mixpanel.track(eventName, {"itemName" : itemName, "itemType" : itemType, "itemStatus" : itemStatus});
			}
		},

		render : function(){

			// $("#main-header").hide();
			var urlFragment = Backbone.history.location.pathname.split("/")[2];
			this.packageId = Utils.getNewYearPackageId(urlFragment);
			this.packageName = urlFragment.replace(/-/g, " ");
			this.registerMixPanelEvents("NY_PD_Served", this.packageName, "", "");

			var self = this;

			//this.$el.html(this.Layout());

			$.ajax({
				method: "GET",
				url : Utils.contextPath()+ "/packages/"+this.packageId,
				contentType: "application/json",
			}).done(function(response){
				self.$el.html(self.Layout({recommendedTime : response.reccomendedTime}))
				self.$el.find(".ny-details").html(self.BannerLayout({response:response}));
				document.title=response.metaTitle;
				$('meta[name=description]').attr('content', response.metaDescription);
				$('meta[name=title]').attr('content',response.metaTitle);

				$('link[rel="canonical"]').attr('href', 'https://yourdost.com/new-year-resolution/'+urlFragment);

				$('meta[property="og:url"]').attr('content',"https://yourdost.com/new-year-resolution/"+urlFragment);

				$('meta[property="og:description"]').attr('content', response.metaDescription);
				$('meta[property="og:title"]').attr('content',response.metaTitle);
				$('meta[property="og:image"]').attr('content', response.image);

			}).error(function(error){
			})
			$('.collapsible').collapsible({

				    });
		}
	});

	SingleNewYearPage.prototype.remove = function() {
		$("#main-header").show();
	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	SingleNewYearPage.prototype.clean = function() {
		this.remove();
	};

    return SingleNewYearPage;

})
