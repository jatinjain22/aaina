define([
    'jquery',
    'underscore',
    'backbone',
    '../../precompiled-templates',
    'utils',
    'event/dispatcher',
    'model/users',
], function($,_, Backbone, JST, Utils, Dispatcher, UserModel){

    var HeaderView = Backbone.View.extend({
        el: 'header',
        initialize: function() {
          this.userModel = new UserModel();
          this.listenTo(this.userModel, 'change', function(model) {
              model.fetch();
          });
        },
        events: {
            'click #search-msg-nav-btn' : 'showSearchBar',
            'click #search-client-nav-btn' : 'showSearchBar',
            'click #search-client-msg-nav-btn' : 'showSearchBar',
            'click #search-msg-back-btn' : 'hideSearchBar',
            'click #search-client-back-btn' : 'hideClientSearchBar',
            "click #search-client-msg-back-btn": "hideClientMsgSearchBar",
            'click .search-close-btn-mobile' : 'clearSearch',
            'click #discussion-url' : 'redirectToDiscussion',
            "keyup #search-msg-mobile": "searchMessageByEnter",
            "keyup #search-client-mobile": "searchClientByEnter",
            "keyup #search-client-msg-mobile": "searchClientMsgByEnter",
            "click .ch-single-back": "renderMList"
        },
        renderMList: function(e){
          $(".msg-back").trigger("click");
          $(".mmsg-single-view-header").addClass("hide");
          $(".mmsg-list-view-header").removeClass("hide");
        },
        searchClientMsgByEnter: function(e){

            var code = e.keyCode || e.which;
            if(code == 13) {
              $("#msg-search-txt").val( $("#search-client-msg-mobile").val() );
              $("#msg-search-btn").trigger("click");
              window.device = "mobile";
            }

            if( $("#search-client-msg-mobile").val().trim() == "" ){
              $("#msg-search-txt").val( $("#search-client-msg-mobile").val() );
              $("#msg-search-txt").trigger("keyup");
            }
        },
        searchClientByEnter: function(e){
            var code = e.keyCode || e.which;
            if(code == 13) {
              $("#client-search-txt").val( $("#search-client-mobile").val() );
              $("#client-search-btn").trigger("click");
              window.device = "mobile";
            }

            if( $("#search-client-mobile").val().trim() == "" ){
              $("#client-search-txt").val( $("#search-client-mobile").val() );
              $("#client-search-txt").trigger("keyup");
            }
        },
        searchMessageByEnter: function(e){
            var code = e.keyCode || e.which;
            if(code == 13) {
              $("#msg-search-txt").val( $("#search-msg-mobile").val() );
              $("#msg-search-btn").trigger("click");
              window.device = "mobile";
            }

            if( $("#search-msg-mobile").val().trim() == "" ){
              $("#msg-search-txt").val( $("#search-msg-mobile").val() );
              $("#msg-search-txt").trigger("keyup");
            }
        },
        redirectToDiscussion : function(e){
          if( Utils.isLoggedIn() && ($.cookie("_t") == "" || !$.cookie("_t") || $.cookie("_t") == undefined ) ){
           location.href = Utils.discussionUrl() + "/session/sso?return_path=%2F" ;
          }else{
           location.href = Utils.discussionUrl();
          }
        },
        clearSearch : function(e){
          $("#search-counselor-mobile").val("") ;
          $(".search-close-btn-mobile").hide();
          Dispatcher.trigger('reRender', '') ;
        },
        searchCounselors : function(e){
          var searchTerm = $("#search-counselor-mobile").val() ;
          var searchQuery = "name=" + searchTerm ;
          Dispatcher.trigger('reRender', searchQuery) ;
        },

        showHideCloseBtn: function(e){
          if( $("#search-counselor-mobile").val().length > 0 ){
            $(".search-close-btn-mobile").show();
          }else{
            $(".search-close-btn-mobile").hide();
          }
        },
        hideSearchBar : function(e){
            $("#search-bar").css("left", '105%');
            $(".msg-back-inbox").trigger("click");
            $("#search-msg-mobile").trigger("keyup");
            $("#msg-search-txt").val("");
            $("#search-msg-mobile").val("");
        },
        hideClientSearchBar : function(e){
            $("#search-bar").css("left", '105%');
            $("#client-search-txt").val("");
            $("#search-client-mobile").val("");
            $("#client-search-btn").trigger("click");
        },
        hideClientMsgSearchBar: function(e){
            $("#search-bar").css("left", '105%');
            $("#msg-search-txt").val("");
            $("#search-client-msg-mobile").val("");
            $("#msg-search-txt").trigger("keyup");
        },
        sendRequest: function (method, url, dataType, contentType) {
    			var deferred = $.Deferred();
    			$.ajax({
    				'method' : method,
    				'url' : url,
    				'dataType': dataType,
    				'contentType': contentType
    			}).done(function (response) {
    				deferred.resolve(response);
    			}).fail(function (error) {
    				deferred.reject(error);
    			})
    			return deferred.promise();
    		},
        attachNav : function(){
          $(".button-collapse").off('click').sideNav({
            menuWidth: "280",
            edge: 'left',
            closeOnClick: true
          });
        },
        showSearchBar : function(e){
            $("#search-bar").css("left", 0);
            $("#search-bar").find("input").focus();
        },
        headerLayoutTemplate : JST['app/templates/header/layout.hbs'],
        render: function() {
          document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
        $('meta[name=description]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
        $('meta[name=title]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
        $('meta[property="og:description"]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
        $('meta[property="og:title"]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
        $('link[rel="canonical"]').attr('href', 'https://yourdost.com/');

            var username = "" ;
            var userAvatar = "" ;
            var firstName = "" ;
            var userType = "VICTIM";
            var picUrl = "" ;
            var self = this;
            if(Utils.isLoggedIn() ){
              username = this.userModel.getUserName() ;
              firstName = this.userModel.getFirstName() ;
              picUrl = this.userModel.getPicUrl() ;
              if(firstName != "" && firstName != null ){
                username = firstName ;
              }

              userAvatar = this.userModel.getUserAvatar() || "avatar7";
              userAvatar = Utils.avatarToImage(userAvatar) ;
              userType = this.userModel.getUserType();
            }

            var layout = "message" ;
            if(( window.location.pathname.indexOf("/clientHistory") > -1 )){
              layout = "clientHistory" ;
            }else if(( window.location.pathname.indexOf("/client") > -1 )){
              layout = "client" ;
            }
            var showDiscussion = true;
            var showOrgId = false;
            if(Utils.isLoggedIn()){
  				var userObj = JSON.parse(localStorage.getItem("user"))
  				var orgId = userObj['loggableUser']['orgId']
                if( orgId == -1) showOrgId = true
                this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
                .then(function(res){
                    if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed =="0") showDiscussion = false
                    }
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, showOrgId:showOrgId, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                }, function(err){
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, showOrgId:showOrgId, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                })
            }else{
  				this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
  				.then(function(res){
                    if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed =="0") showDiscussion = false
                    }
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                }, function(err){
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                })
      		}

            if( !sessionStorage.getItem("unread") && Utils.isLoggedIn() ){

              var userObject = JSON.parse(localStorage.getItem("user"));
              $.ajax({
                method: "GET",
                  url: Utils.contextPath()+'/v1/users/'+userObject.id+'/messages/count?type=unread'
              }).done(function(response){
                sessionStorage.setItem("unread",response.count);
                $(".iheader-msg-badge,.mobile-msg-badge").text( response.count );
                if( response.count > 0 ){
                  $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
                }
              }).fail(function(error){});
            }else{
              $(".iheader-msg-badge,.mobile-msg-badge").text( sessionStorage.getItem("unread") );
              if( sessionStorage.getItem("unread") > 0 )
                $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
            }
            this.userModel.setUnreadCount();
            $('#filter-msg-nav-btn').sideNav({'edge': 'right'});

            $(document).mouseup(function (e){

                var container = $("#msg-mobile-view");

                if (!container.is(e.target) // if the target of the click isn't the container...
                    && container.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    $('#filter-msg-nav-btn').sideNav("hide");
                  }

                var container1 = $(".explore-menu");
                if (!container1.is(e.target) // if the target of the click isn't the container...
                    && container1.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    $(".explore-menu").addClass("hide");
                    $(".menu-explore").removeClass("active");
                  }

                var cont3 = $("#tag_list_chosen");
                if (!cont3.is(e.target) // if the target of the click isn't the container...
                    && cont3.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    $(".right-tag-list").addClass("hide");
                    $(".left-tag-list").removeClass("hide");
                    $("#tag-list").trigger('chosen:close');
                    $("#tag-list").off('change');
                  }
            });

            $('.dropdown-button').dropdown({
              belowOrigin: true,
              //constrain_width: false,
            });

            if( Utils.isMobileDevice() && $("header").hasClass("hide") ){
              $("header").removeClass("hide");
            }

        //    Utils.trackHeaderLinks() ;

            return this;
        }
    });

  HeaderView.prototype.remove = function() {
    	this.$el.empty();
      this.$el.off();
      this.stopListening();
	};

	HeaderView.prototype.clean = function() {
		  this.remove();
	};

    return HeaderView;
});
