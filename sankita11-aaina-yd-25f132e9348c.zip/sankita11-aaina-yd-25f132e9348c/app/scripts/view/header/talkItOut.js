define([
    'jquery',
    'underscore',
    'backbone',
    '../../precompiled-templates',
    'smooth-scroll',
    'utils',
    'event/dispatcher',
    'model/users',
    'introjs'
], function($,_, Backbone, JST, SmoothScroll, Utils, Dispatcher, UserModel) {

    var HeaderView = Backbone.View.extend({
        el: 'header',
        initialize: function() {
          this.userModel = new UserModel() ;
        },
        events: {
            'click #filter-nav-btn' : 'showHideFilter',
            'click #search-nav-btn' : 'showSearchBar',
            'click #search-back-btn' : 'hideSearchBar' ,
            'keyup #search-counselor-mobile' : 'showHideCloseBtn',
            'keydown #search-counselor-mobile' : 'showHideCloseBtn',
            'submit #search-form-mobile' : 'searchCounselors',
            'click .search-close-btn-mobile' : 'clearSearch',
            'click #discussion-url' : 'redirectToDiscussion'
        },
        redirectToDiscussion : function(e){
          if( Utils.isLoggedIn() && ($.cookie("_t") == "" || !$.cookie("_t") || $.cookie("_t") == undefined ) ){
          location.href = Utils.discussionUrl() + "/session/sso?return_path=%2F" ;
          }else{
          location.href = Utils.discussionUrl();
          }
        },
        clearSearch : function(e){
          $("#search-counselor-mobile").val("") ;
          $(".search-close-btn-mobile").hide();
          Dispatcher.trigger('reRender', '') ;
        },
        searchCounselors : function(e){
          var searchTerm = $("#search-counselor-mobile").val() ;
          var searchQuery = "name=" + searchTerm ;
          Dispatcher.trigger('reRender', searchQuery) ;
          localStorage.setItem("searchClicked", 1 ) ;
        },

        showHideCloseBtn: function(e){
          if( $("#search-counselor-mobile").val().length > 0 ){
            $(".search-close-btn-mobile").show();
          }else{
            $(".search-close-btn-mobile").hide();
            if(localStorage.getItem("searchClicked" )  == 1){
              Dispatcher.trigger('reRender', "") ;
              localStorage.setItem("searchClicked", 0 ) ;
            }
          }
        },
        hideSearchBar : function(e){
            $("#search-bar").css("left", '105%') ;
            if(localStorage.getItem("searchClicked" )  == 1){
              Dispatcher.trigger('reRender', "") ;
              localStorage.setItem("searchClicked", 0 ) ;
            }
        },
        showSearchBar : function(e){
            $("#search-bar").css("left", 0) ;
        },
        showHideFilter : function(e){
          $("#filter-mobile").animate({'top': 0}, "slow") ;
          $("body").css("overflow-y", "hidden");
/*          if($(".filter-category input:checked").length > 0 ){
*/            $(".talkItOutV2-filter-mob-reset-apply").removeClass("hide");
/*          }else{
            $(".talkItOutV2-filter-mob-reset-apply").addClass("hide");
          }
*/
        },
        sendRequest: function (method, url, dataType, contentType) {
    			var deferred = $.Deferred();
    			$.ajax({
    				'method' : method,
    				'url' : url,
    				'dataType': dataType,
    				'contentType': contentType
    			}).done(function (response) {
    				deferred.resolve(response);
    			}).fail(function (error) {
    				deferred.reject(error);
    			})
    			return deferred.promise();
    		},
        attachNav : function(){
          $(".button-collapse").off('click').sideNav({
            menuWidth: "280",
            edge: 'left',
            closeOnClick: true
          });
        },
        headerLayoutTemplate : JST['app/templates/header/layout.hbs'],
        render: function() {

            var username = "" ;
            var userAvatar = "" ;
            var firstName = "" ;
            var userType = "VICTIM";
            var picUrl = "" ;
            var self = this;
            if( Utils.isLoggedIn() ){
              username = this.userModel.getUserName() ;
              firstName = this.userModel.getFirstName() ;
              picUrl = this.userModel.getPicUrl() ;
              if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){
                username = firstName ;
              }
              userAvatar = this.userModel.getUserAvatar() ;
              userAvatar = Utils.avatarToImage(userAvatar) ;
              if(!userAvatar){

                userAvatar = picUrl;
              }

              userType = this.userModel.getUserType();
            }

            var layout = "chat" ;
            var showDiscussion = true;
            var showOrgId = false;
            if(Utils.isLoggedIn()){
      				var userObj = JSON.parse(localStorage.getItem("user"))
      				var orgId = userObj['loggableUser']['orgId']
                    if( orgId == -1) showOrgId = true
                    this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
                    .then(function(res){
                        if( Object.keys(res).length !== 0){
                            if(res.discussions_allowed =="0") showDiscussion = false
                        }
                        self.$el.html( self.headerLayoutTemplate({ layout: "chat", showOrgId:showOrgId, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                        self.attachNav()
                    }, function(err){
                        self.$el.html( self.headerLayoutTemplate({ layout: "chat", showOrgId:showOrgId, userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                        self.attachNav()
                    })
            }else{
  				this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
  				.then(function(res){
                    if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed =="0") showDiscussion = false
                    }
                    self.$el.html( self.headerLayoutTemplate({ layout: "chat", userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                }, function(err){
                    self.$el.html( self.headerLayoutTemplate({ layout: "chat", userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin, showDiscussion : showDiscussion}));
                    self.attachNav()
                })
      		}
            //this.$el.html(this.headerLayoutTemplate({ layout: "chat", userAvatar: userAvatar, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , userType: userType, blogOrigin : blogOrigin}));

          if( !sessionStorage.getItem("unread") && Utils.isLoggedIn() ){
              var userObject = JSON.parse(localStorage.getItem("user"));
              $.ajax({
                method: "GET",
                  url: Utils.contextPath()+'/v1/users/'+userObject.id+'/messages/count?type=unread'
              }).done(function(response){
                sessionStorage.setItem("unread",response.count);
                $(".iheader-msg-badge,.mobile-msg-badge").text( response.count );
                if( response.count > 0 ){
                  $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
                }
              }).fail(function(error){});
            }else{
              $(".iheader-msg-badge,.mobile-msg-badge").text( sessionStorage.getItem("unread") );
              if( sessionStorage.getItem("unread") > 0 )
                $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
            }

            $('.dropdown-button').dropdown({
              belowOrigin: true,
             // constrain_width: false,
            });

            $(document).mouseup(function (e){

                var container1 = $(".explore-menu");
                if (!container1.is(e.target) // if the target of the click isn't the container...
                    && container1.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    $(".explore-menu").addClass("hide");
                    $(".menu-explore").removeClass("active");
                  }

            });


           // Utils.trackHeaderLinks() ;

            return this;
        }
    });

    HeaderView.prototype.remove = function() {
    	this.$el.empty();
      this.$el.off();
      this.unbind();
      //this.stopListening();
	};

	HeaderView.prototype.clean = function() {

      this.remove();

	};

    return HeaderView;
});
