define([
    'jquery',
    'underscore',
    'backbone',
    '../../precompiled-templates',
    'utils',
    'event/dispatcher',
    'model/users',
    'smooth-scroll',
    'jCookie',
    'purl',
], function($,_, Backbone, JST, Utils, EventBus, UserModel){

    var HeaderView = Backbone.View.extend({
        el: 'header',
        initialize: function() {
          this.userModel = new UserModel() ;
          this.listenTo(EventBus, 'removeChatScroll', this.removeChatScroll);
          this.listenTo(EventBus, 'redirectToDiscussion', this.redirectToDiscussion);

          if(window.location.pathname.indexOf("/relationshipCounselor") > -1){
            this.layoutType = "marketing";
          }
          if(window.location.hash.indexOf("/habitometer") > -1){
            this.layoutType = "selfTest";
          }


          _.bindAll(this)
          this.listenTo(EventBus, 'renderHeader', this.renderHTML);

        },
        events: {
            'click .menu-explore' : 'exploreMenu',
            'click .menu-blog' : 'blogMenu',
            'click .em-txt': 'openMenuItem',
            'click #filter-nav-btn' : 'showHideFilter',
            'click #discussion-url' : 'redirectToDiscussion',
            'click #home-start-chat-btn-header' : 'startChatting' ,
            'click .side-explore-btn' : 'toggleExploreMenu',
            'click .android-app-redirect':'androidTrackLinks',
            'click .ios-app-redirect':'iosTrackLinks',
            'click .landing-signup' : 'showSignup',
            'click .user-dropdown' : 'userPersonalMenu',
            'click .login-clicked' : 'showLoginModal',
            'click .mob-login-clicked' : 'showLoginModal',
            'click .header-track-link' : 'trackHeaderLink',
            "click .business-offerings" : "loadUrl",
            'click .side-login-btn' : 'showLoginModal'
        },
        loadUrl: function(e){

          e.preventDefault()
          window.open("/business-offerings", "_self")
        },
        startChatting : function(e){
          if(!Utils.isLoggedIn()){

            EventBus.trigger("renderLogin", "click CHAT Header Home Page", "scroll-header", "home_chat") ;
          }else{
            var username  = this.userModel.getUserName() ;
            location.href = Utils.chatUrl() + username  ;
          }
        },
        showLoginModal : function(e){

          e.preventDefault();
          e.stopPropagation();
          if(!Utils.isLoggedIn()){
            EventBus.trigger("renderLogin", "click Landing Home Page", "login", "loginButton") ;
          }
        },
        showSignup : function(e){

          e.preventDefault();
          e.stopPropagation();
          if(!Utils.isLoggedIn()){
            EventBus.trigger("renderLogin", "click Landing Home Page", "header", "landing Page") ;
          }
        },
        trackHeaderLink : function(e){
            var href = $(e.currentTarget).attr('href');
              var url = href.replace(/^\//,'').replace('\#\!\/','');

          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

              mixpanel.track( 'Header', {'itemName': url, 'mediumSource' : 'website' });


        }
      },
        androidTrackLinks : function(e){
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
            mixpanel.track('Header', {'itemName':'ANDROID', 'mediumSource' : 'website' });
          }
        },
        iosTrackLinks : function (e) {
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
            mixpanel.track('Header', {'itemName':'IOS', 'mediumSource' : 'website' });
          }
        },

       trackHeaderLinks : function(e){

          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

          mixpanel.track( "#logo-container", "Header", {"itemName": "Logo"});

                mixpanel.track( ".header-track-link", "Header" ,{'itemName': this.getlinkName, 'mediumSource' : 'website' });


        }else{

          setTimeout(function(){

            console.log( "trying after one second :)" );
            //that.trackHeaderLinks();
          }, 1000)

        }

      },
        toggleExploreMenu: function(e){

          e.preventDefault();
          e.stopPropagation();
          var $this = $(e.currentTarget);
          if( $this.hasClass("clicked") ){
            $this.removeClass("clicked").find(".mdi").removeClass("mdi-chevron-up").addClass("mdi-chevron-down");
            $(".side-explore-menu").addClass("hide");
          }else{
            $this.addClass("clicked").find(".mdi").removeClass("mdi-chevron-down").addClass("mdi-chevron-up");
            $(".side-explore-menu").removeClass("hide");
          }

          e.stopPropagation();
        },
        redirectToDiscussion : function(e){
          if( Utils.isLoggedIn() && ( $.cookie("_t") == "" || !$.cookie("_t") || $.cookie("_t") == undefined) ) {
            location.href = Utils.discussionUrl() + "/session/sso?return_path=%2F" ;
          }else{
           location.href = Utils.discussionUrl();
          }
        },
        showHideFilter : function(e){
          $("#filter-mobile").animate({'top': 0}, "slow") ;
        },
        headerLayoutTemplate : JST['app/templates/header/layout.hbs'],

        renderHTML : function(){

            this.setElement($("header")).render();

        },

        sendRequest: function (method, url, dataType, contentType) {
    			var deferred = $.Deferred();
    			$.ajax({
    				'method' : method,
    				'url' : url,
    				'dataType': dataType,
    				'contentType': contentType
    			})
    			.done(function (response) {
    				deferred.resolve(response);
    			})
    			.fail(function (error) {
    				deferred.reject(error);
    			})
    			return deferred.promise();
    		},
        attachNav : function(){
          $(".button-collapse").off('click').sideNav({
            menuWidth: "280",
            edge: 'left',
            closeOnClick: true
          });
        },

        render: function() {

            var username    = "" ;
            var userAvatar  = "" ;
            var firstName   = "" ;
            var userType = "VICTIM";
            var picUrl = "" ;
            var user_id = '';
            var self = this;
            if( Utils.isLoggedIn() ){
              username = this.userModel.getUserName() ;
              firstName = this.userModel.getFirstName() ;
              picUrl = this.userModel.getPicUrl();
              user_id = this.userModel.getUserID() ;
              if(typeof firstName != 'undefined' && firstName != null && firstName.trim() != "" ){
                username = firstName ;
              }
              userAvatar = this.userModel.getUserAvatar() ;
              userAvatar = Utils.avatarToImage(userAvatar) ;
              if(!userAvatar){

                userAvatar = picUrl;
              }
              userType = this.userModel.getUserType();
            }

            var layout = "home" ;
            if(( window.location.pathname.indexOf("profile") > -1 )){
                layout = "profile" ;
            }else if(( window.location.pathname.indexOf("/counselor") > -1 )){
                layout = "chatExpanded" ;
            }else if(( window.location.pathname.indexOf("/faq") > -1  )){
                layout = "faq" ;
            }

            var currentPage = window.location.pathname;
            currentPage     = currentPage.replace("/", "") ;
            if(!currentPage || currentPage == "!"){
              currentPage = "home";
            }

            var layoutType = this.layoutType;
            var showDiscussion = true;
            var showOrgId = false;
            if(Utils.isLoggedIn()){
  				var userObj = JSON.parse(localStorage.getItem("user"))
  				var orgId = userObj['loggableUser']['orgId']
                if( orgId == -1) showOrgId = true
                this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
  				.then(function(res){
  					if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed =="0") showDiscussion = false
                    }
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, showOrgId:showOrgId, layoutType : layoutType, userAvatar: userAvatar, user_id : user_id, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , showDiscussion : showDiscussion, userType: userType, currentPage: currentPage, blogOrigin : blogOrigin}));
                    self.attachNav()
                }, function(err){
      				self.$el.html( self.headerLayoutTemplate({ layout: layout, showOrgId:showOrgId, layoutType : layoutType, userAvatar: userAvatar, user_id : user_id, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , showDiscussion : showDiscussion, userType: userType, currentPage: currentPage, blogOrigin : blogOrigin}));
                    self.attachNav()
                })
            }else{
  				this.sendRequest("GET", Utils.contextPath() + '/v2/users/organisation')
  				.then(function(res){
                    if( Object.keys(res).length !== 0){
                        if(res.discussions_allowed =="0") showDiscussion = false
                    }
                    self.$el.html( self.headerLayoutTemplate({ layout: layout, layoutType : layoutType, userAvatar: userAvatar, user_id : user_id, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , showDiscussion : showDiscussion, userType: userType, currentPage: currentPage, blogOrigin : blogOrigin}));
                    self.attachNav()
                }, function(err){
      				self.$el.html( self.headerLayoutTemplate({ layout: layout, layoutType : layoutType, userAvatar: userAvatar, user_id : user_id, username : username ,discussionURL : Utils.discussionUrl(), isLoggedIn : Utils.isLoggedIn, messageURL : Utils.getMessageURL() , showDiscussion : showDiscussion, userType: userType, currentPage: currentPage, blogOrigin : blogOrigin}));
                    self.attachNav()
                })
      		}

            if(layoutType == "selfTest"){
              $(".selftest-active").css({"border" : '1px solid #00bfa5'});
            }

            $(document).mouseup(function (e){

                var container = $(".explore-menu");

                if (!container.is(e.target) // if the target of the click isn't the container...
                    && container.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    container.addClass("hide").removeClass("fadeInDown animated");
                    $(".menu-explore").removeClass("active");
                  }
            });

            $(document).mouseup(function (e){

                var container = $("#loggedin-dropdown1");

                if (!container.is(e.target) // if the target of the click isn't the container...
                    && container.has(e.target).length === 0) // ... nor a descendant of the container
                  {
                    container.addClass("hide").removeClass("fadeInDown animated");
                    $(".user-dropdown").removeClass("active");
                  }
            });

            // $('.dropdown-button').dropdown({
            //   belowOrigin: true,
            //   //constrain_width: false,
            // });

            if( !sessionStorage.getItem("unread") && Utils.isLoggedIn() ){
              var userObject = JSON.parse(localStorage.getItem("user"));
              $.ajax({
                method: "GET",
                  url: Utils.contextPath()+'/v1/users/'+userObject.id+'/messages/count?type=unread'
              }).done(function(response){
                sessionStorage.setItem("unread",response.count);
                $(".iheader-msg-badge,.mobile-msg-badge").text( response.count );
                if( response.count > 0 ){
                  $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
                }
              }).fail(function(error){});
            }else{
              $(".iheader-msg-badge,.mobile-msg-badge").text( sessionStorage.getItem("unread") );
              if( sessionStorage.getItem("unread") > 0 )
                $(".iheader-msg-badge,.mobile-msg-badge").removeClass("hide");
            }

            if( Utils.isLoggedIn() ){
              this.removeChatScroll();
            }

            // Utils.trackHeaderLinks();

        setTimeout(function(){

      $( window ).scroll(function() {

           if( $(window).scrollTop() > 50 ){
            $('#small-logo-container').addClass('hide');
            $('#small-logo-container-scrolled').removeClass('hide');
          }
          else{
            $('#small-logo-container-scrolled').addClass('hide');
            $('#small-logo-container').removeClass('hide');
          }
        });

      }, 1000)

            return this;
        },
        openMenuItem: function(e){

            var link = $(e.currentTarget).attr("data-href");

            if( link ){

              $(".explore-menu").addClass("hide").removeClass("fadeInDown animated");

              if( $(e.currentTarget).hasClass("elink") ){
                window.location = link;
                return false;
              }else{
                //window.location = link;
                Backbone.history.navigate(link, {trigger: true});
              }
            }
        },
        exploreMenu: function(e){
          $(".explore-menu").removeClass("hide").addClass("fadeInDown animated");
          var top = 60;
          var left = $(".menu-explore").addClass("active").offset().left - 90 ;
          $('.explore-menu').css({
            top:top,
            left:left
          });
        },
        blogMenu: function(e) {
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
            mixpanel.track('Home_Blog_Clicked', {'type' : 'NORMAL', 'mediumSource' : 'website',  'itemName' : 'Home Blog Clicked', 'itemMedium' : 'NORMAL'  });
          }
        },
        userPersonalMenu : function(e){
          $("#loggedin-dropdown1").removeClass("hide").addClass("fadeInDown animated");
          var top = 60;
          var left = $(".user-dropdown").addClass("active").offset().left - 75 ;
          $('#loggedin-dropdown1').css({
            top:top,
            left:left
          });
        },
        removeChatScroll: function(){
            setTimeout(function(){$(".start-chat-on-scroll").remove();},100);
        }
    });

  HeaderView.prototype.remove = function() {
       this.$el.empty();
      this.$el.off();
      this.unbind();
      //this.stopListening();
	};

	HeaderView.prototype.clean = function() {

      this.remove();

	};

    return HeaderView;
});
