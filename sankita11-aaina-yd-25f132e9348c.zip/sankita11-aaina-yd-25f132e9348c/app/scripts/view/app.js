define([
  'jquery',
  'underscore',
  'backbone',
  'utils',
  'view/header/page',
  'view/footer/page',
  '../precompiled-templates',
  'view/home/subview/feedback_form',
  'wow',
  //'fb'
], function($,_, Backbone, Utils, HeaderView, FooterView, JST, FeedbackFormView, Wow ){
  var AppView = Backbone.View.extend({

	  layoutTemplate : JST['app/templates/layout.hbs'],
    el: 'body',
    initialize: function () {
    	//console.log(" App View initialized");

      this.feedbackForm    = new FeedbackFormView() ;
    	this.render();
    },
      showFeedbackForm : function (e) {
        this.feedbackForm.render();
      },
    render: function () {

      var self = this ;
        var fbRootHTML = $("#fb-root"); 
console.log(fbRootHTML);
console.log("from APP");
  
        var isMobileDevice = Utils.isMobileDevice() ;

    	  $(this.el).html(self.layoutTemplate({"showZopim" : showZopim, "isMobileDevice" : isMobileDevice}));


        if($("#fb-root").length > 0){
          $("#fb-root").remove();
        }
        $(this.el).append(fbRootHTML) ;        

        $(document).on('keyup', function(e) {
          if (e.keyCode === 27 && window.location.pathname != "/termsUpdateModal" && window.location.pathname != "/bookAppointment") {   // ESC key
            
            $("body").css("overflow-y", "auto") ;
            $(".modal").closeModal();
            $(".modal").remove();
            $(".xdsoft_datetimepicker").hide();
          }
        });

        $(document).on('contextmenu', "img", function(e) {
          
          return false;
        });

        
        wow = new WOW({
        animateClass: 'animated',
        offset:       100
        });
        wow.init();

        

    },
    events: {
          'click .feedback-form-btn' : 'showFeedbackForm',
    },

	});

  AppView.prototype.remove = function() {
    this.$el.empty();
      this.$el.off();
      this.undelegateEvents();
      this.stopListening();
  };

  AppView.prototype.clean = function() {
      this.remove();
  };

  return AppView;
});
