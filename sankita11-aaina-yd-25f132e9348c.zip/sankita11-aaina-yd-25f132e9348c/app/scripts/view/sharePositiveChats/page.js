define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

	var SharePositiveChatsPage = Backbone.View.extend({
		
		el: "main",
            
            Layout: JST["app/templates/sharePositiveChats/layout.hbs"],
            editFacebookShareLayout: JST["app/templates/sharePositiveChats/editFacebookShare.hbs"],
            ThankYouLayout: JST["app/templates/sharePositiveChats/thankYou.hbs"],

		initialize: function() {
			this.userModel = new UserModel() ;
                  this.url = "";
                  this.socialShareResponse = {};

                  var url = window.location.href ;
                  url = url.replace("/share-positive-chats", "" );

                  var sourceFrom = $.url(url).param('from')
                  this.sourceFrom = sourceFrom;

                  var transactionId = $.url( url ).param( 't' );
                  this.transactionId = transactionId;

                  var showTransaction = $.url( url ).param( 'er' );
                  this.showTransaction = showTransaction;
            },
            events: {
                  "click .fb-share-positive-chats a": "shareOnFacebook",
                  "click .share-positive-chats-box .edit": "editSharedTitle",
                  "click .share-positive-chats-share-title-save": "saveSharedTitle"
            },
            
            saveSharedTitle: function(e) {

                  var self = this;
                  var currentTextarea = $("#share-postive-chats-share-title");
                  var currentTextareaVal = currentTextarea.val().replace(/\r?\n/g, '<br />');
                  $( ".share-positive-chats-box .first-line span:first-child" ).html( currentTextareaVal );
                  $( ".share-positive-chats-box .first-line .share-positive-chats-share-title-save" ).removeClass( "share-positive-chats-share-title-save" ).addClass( "edit" );
                  $( ".share-positive-chats-box .first-line .edit" ).text( "Edit" );

            },

            editSharedTitle: function(e) {
                  
                  var self = this;
                  var currentTargetDiv = $(".share-positive-chats-box .first-line span:first-child");
                  var currentTargetDivValue = currentTargetDiv.html().trim().replace(/<br *\/?>/gi, '\n');
                  currentTargetDiv.html( self.editFacebookShareLayout() );
                  $("#share-postive-chats-share-title").val( currentTargetDivValue );
                  $( ".share-positive-chats-box .first-line .edit" ).removeClass("edit").addClass( "share-positive-chats-share-title-save" );
                  $( ".share-positive-chats-box .first-line .share-positive-chats-share-title-save" ).text( "Save" );

            },

            shareOnFacebook: function(e) {

                  var self = this;
                  var targetElement = $(".fb-share-positive-chats");
                  var loaderElement = $(".fb-share-positive-chats-loader");
                  var mixpanelEvent = "Positive Chats Shared";

                  targetElement.addClass("hide");
                  loaderElement.removeClass("hide");

                  self.socialShareResponse["title"] = $( ".share-positive-chats-box .first-line span:first-child" ).text();
                  
                  Utils.shareOnFacebook( self.socialShareResponse, targetElement, loaderElement, mixpanelEvent ).then(function(response) {
                        
                        if(response){

                              $(".share-positive-chats-right").html( self.ThankYouLayout() );
                        }else{

                        }    
                  }, function(error) {

                        console.log("Failed!", error);
                  }); 

            },

            render: function() {

                  var self = this;
                  var url = Backbone.history.getFragment() ;
                  self.url = url;
                  var showTransactionDiv = "no"
                  var showDonatedFrom = false

                  if(self.sourceFrom){

                        showDonatedFrom = true
                  }
                  if(self.transactionId){

                        showTransactionDiv = "yes"
                  }
                  if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
                  
                      mixpanel.track('Donation Thank You Page', {'mediumSource' : 'website', 'itemName': 'Donation Thank You Page Viewed'});
                
                  }
                  self.$el.html( self.Layout({ showDonatedFrom: showDonatedFrom, blogOrigin: blogOrigin , transactionId : self.transactionId , showTransactionDiv : showTransactionDiv}) );

                  $.ajax({
                        url : Utils.scriptPath() + "/socialShare.json",
                        cache: false
                  }).done(function(response){

                        console.log( url );
                        url = url.split("?")[0];
                        self.socialShareResponse = response[ url ];

                  }).error(function(error){
                        console.log(error)
                  });               
                  
            }
            
      });

	SharePositiveChatsPage.prototype.remove = function() {

            this.$el.empty();
            this.$el.off();
            this.unbind(); 
      
      };

	SharePositiveChatsPage.prototype.clean = function() {
            this.remove();
      };

	return SharePositiveChatsPage;
});
