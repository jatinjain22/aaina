define([
  'jquery',
  'underscore',
  'event/dispatcher',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'Swiper',
  'model/users',
  'model/UserMsgModel'
], function($,_, Dispatcher, Backbone, JST, Utils, Swiper, UserModel, UserMsgModel ) {

    var ParentingTipsPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        this.userMsgModel = new UserMsgModel();

      },
      
      ParentingTipsPageLayoutTemplate : JST['app/templates/parentingTips/layout.hbs'],

      events: {
        
      }, 

      

      render: function() {

        var self = this;
        console.log( 'ouside mixpanel' );
        
        setTimeout(function(){
          if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
            console.log( 'inside mixpanel' );
            mixpanel.track('Parenting Tips Landing Page', {'medium' : 'website', 'itemtype': 'landing page', 'itemName': 'Parenting Tips Landing Page'});
          
          } 
        }, 2000);
        var postId = 5872;
        console.log( "render" );
      //   $.ajax({
      //   method : "GET",
      //   url: "/scripts/json/ebooksForPopup.json"
      //   }).done(function( response ) {
      //   // console.log( "hello world" );
      //     console.log( response.posts );
      //     postId = response.posts[0].id;
      //     console.log( "post id " + postId );
        
      // });
        var postId = Utils.getParentingEbookPostId();
        console.log( postId );

        var categoryId = 31;
        var extraParams = [postId, categoryId];
        self.$el.html( self.ParentingTipsPageLayoutTemplate() );
        $('.dost-main').css("height", "100%");
         if ( Utils.isMobileDevice() || $(window).width() < 993 ) {
          Dispatcher.trigger("renderLoginToDiv", "Landing Page SignUp", "ParentingTipsPage", "download_free_ebook", "signup-form", extraParams) ;
         }
         else {
          Dispatcher.trigger("renderLoginToDiv", "Parenting Tips Landing Page SignUp", "ParentingTipsPage", "download_free_ebook", "signup-form-large", extraParams) ;
         }

         

        $("#login-modal").removeClass("modal");
        $("#login-modal").addClass('login-div');
        $("#login-modal > div").removeClass('modal-content');
        $("#modal-signupform").css("overflow", "visible");
        $(".fb-google-login-modal").css("margin-left", "0rem");
        $(".fb-google-login-modal").css("margin-right", "0rem");
        $('.mclose').removeClass('login-modal-close');
        $("i.mdi-content-clear").remove();
         // $("#fb-login-button").css("width", "47%");
         // $("#fb-login-button").css("margin-right", "0.5%");
        // $("#gSignInWrapper").css("margin-left", "0.5%");
         // $("#gSignInWrapper").css("width", "47%");
        $(".login-or-text").css("width", "10%");
        $(".terms-and-services-div").css("margin-bottom", "0px");
        $(".promo-block-div").css("margin-top", "10px");
        $('header').hide();
        $('#footer').hide();

      }

    });

    ParentingTipsPage.prototype.remove = function() {
      this.$el.empty();
      this.$el.off();
      this.unbind(); 
	};

	ParentingTipsPage.prototype.clean = function() {

      this.remove();

	};

    return ParentingTipsPage;
});
