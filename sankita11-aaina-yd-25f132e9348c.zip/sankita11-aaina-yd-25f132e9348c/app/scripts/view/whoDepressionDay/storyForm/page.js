define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function( $, _, Backbone, JST, Utils ) {

	var whoDepressionDayFormPage = Backbone.View.extend({

		el: "main",

		initialize: function() {
			this.imageUrl = "";

		},

		events: {

			"click .wd-form-submit" : "submitStory",
			"click .wd-take-home" : "takeHome",
			"click .wd-submit-another" : "directToStoryForm",
			"click .wd-form-read-stories-btn" : "readStories"
		},

		mainLayout : JST['app/templates/whoDepressionDay/storyForm/layout.hbs'],
		successLayout : JST['app/templates/whoDepressionDay/storyForm/success.hbs'],

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_LetsTalk", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		takeHome : function( evt ){

			Utils.closePopup('wd-success') ;
			$("#wd-success").remove();
			window.open("/lets-talk/stories", "_self")
		},

		readStories : function( evt ){

			this.trackMixpanel("click_read_stories_form", {})
			window.open("http://yourdost.com/blog/tag/letstalkstories", "_blank")
			// window.open("/lets-talk/stories", "_self")
		},

		directToStoryForm : function( evt ){

			Utils.closePopup('wd-success') ;
			$("#wd-success").remove();
			window.open("/lets-talk/share-your-story", "_self")
		},

		showError : function( txt ){

			$(".wd-form-error").html(txt)
			$("wd-form-error").removeClass("hide")
			$(".wd-form-submit").html("SUBMIT YOUR STORY")
		},

		hideError : function(  ){

			$(".wd-form-error").html("")
			$("wd-form-error").addClass("hide")
		},

		generateUploadUrl : function( filename ){

			var s3 = new AWS.S3({

			  accessKeyId: 'AKIAIM44H66YO26ALVYQ',
			  secretAccessKey: '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'
			});

			var uploadPreSignedUrl = s3.getSignedUrl('putObject', {

			    Bucket: 'ydattachments',
			    Key: filename,
			    ACL: 'authenticated-read',
			    ContentType: 'application/octet-stream'

			});

			return uploadPreSignedUrl;
		},


		generateUid : function(){

			function ran(){

				return (Math.random(0,1)*10000).toString(20).substring(4,8);
			}

			return ran()+"-"+ran();
		},

		submitStory : function( ){

			var self = this;

			this.hideError()
			$(".wd-form-submit").html("Submitting...")

			var storyOf = $(".wd-step-1 .wd-a input[type=radio]:checked").attr("id")
			if( typeof storyOf == 'undefined' || storyOf == ""){

				this.showError("Please select whose story")
				return false;
			}

			var name = $("#name").val()
			if(typeof name == 'undefined' || name == ""){

				this.showError("Please enter your name")
				return false;
			}

			/*var file = $(".wd-form input[type='file']").get(0).files[0];
			if( typeof file == 'undefined' || file == ''){

				this.showError("Please choose a picture")
				return false;
			}

			file = this.imageUrl;*/

			var canPublishName = $(".who-step3b .wd-a input[type=radio]:checked").attr("id")
			if( typeof canPublishName == 'undefined' || canPublishName == ""){

				this.showError("Please select whether you allow to publish your name with the story")
				return false;
			}

			var story = $(".step-3").find("textarea").val();
			if( typeof story == 'undefined' || story == ""){

				this.showError("Please enter the story you want to share")
				return false;
			}else{

				story = story.replace(/\s\s+/g, ' ');
				if( story.split(" ").length < 100){

					this.showError("Please enter at least 100 words")
					return false;
				}
			}

			var howSolved = $(".who-step3a").find("textarea").val();
			if( typeof howSolved == 'undefined' || howSolved == ""){

				this.showError("Please enter the story you want to share")
				return false;
			}else{

				howSolved = howSolved.replace(/\s\s+/g, ' ');
				if( howSolved.split(" ").length < 100){

					this.showError("Please enter at least 100 words")
					return false;
				}
			}

			var email = $("#email").val()
			var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;  
						
			if( typeof email == 'undefined' || email == "" ){

				this.showError("Please enter a valid email")
				return false;
			}else{

				if( !pattern.test(email) ){

					this.showError("Please enter a valid email")
					return false;
				}
			}

			var mobile = $("#mobile").val()
			/*if( typeof mobile == 'undefined' || mobile == "" || mobile.length != 10){

				this.showError("Please enter a valid mobile no")
				return false;
			}*/

			this.hideError()

			var dataToSend = {

				"mailTo" : [155387],
				"mailFrom" : 101,
				"mailParams" : {
					"story_of" : storyOf,
					"name" : name,
					"canPublishName" : canPublishName,
					"imageUrl" : this.imageUrl,
					"mobile" : mobile,
					"email" : email,
					"story" : story,
					"solution" : howSolved
				},
				"mailTemplate" : "WHODEPRESSIONDAY_TEMPLATE"
			}

			$.ajax({
				method : "POST",
				url : Utils.contextPath()+"/sendMail",
				data : JSON.stringify(dataToSend),
				contentType : "application/json"
			}).done( function( response){

				self.showSuccesModal()
				$(".wd-form-submit").html("SUBMIT YOUR STORY")

			}).fail( function( error){

				self.showError("Something went wrong. Please try again later")
			})
		},


		showSuccesModal : function( ){

			this.$el.append(this.successLayout());	

			Utils.openPopup('wd-success') ;
		},

		putContent : function(url, options){

			var defer = $.Deferred();
			$.ajax(options).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		attachFile : function( evt ){

			var fileName = $(".wd-form input[type='file']").val().split('/').pop().split('\\').pop();
			fileName = fileName.replace(/ /g, "-")
	        var self = this;
	        $(".file-path").val(fileName)
	        var uploadUrl = this.generateUploadUrl(fileName)

	        var options = {

				type : 'PUT',
		      	url: uploadUrl,
		      	contentType: 'application/octet-stream',
		      	processData: false,
		      	data: $(".wd-form input[type='file']").get(0).files[0]
			}

			this.putContent(uploadUrl, options).then(function(response){

	        	self.imageUrl = "https://s3-ap-southeast-1.amazonaws.com/ydattachments/"+fileName;
	        }, function( error ){

	        	self.imageUrl = "";
	        })
		},

		changeContent : function( evt ){

			if( $(evt.currentTarget).attr("id") != "own"){

				$(".s-name").html("His/Her Name*")
				$(".s-tory").html("Tell us about the time (s)he went through depression. (100 - 600 words)*")
				$(".who-step3b .wd-q").html("Can we publish your response under his/her name?*")
				$(".who-step3a .s-tory").html("How did (s)he deal with it? What helped them? (100 - 600 words)*")
				$(".s-pic").html("High resolution picture of nominee")
			}else{

				$(".s-name").html("Your Name*")
				$(".s-tory").html("Tell us about the time when you went through depression. (100 - 600 words)*")
				$(".who-step3b .wd-q").html("Can we publish your response under your name?*")
				$(".who-step3a .s-tory").html("How did you deal with it? What helped you? (100 - 600 words)*")
				$(".s-pic").html("Your high resolution picture")
			}
		},

		render: function() {

			var self = this;

			this.trackMixpanel("page_load", { key: "whoDepressionDay", value: "form" })
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout({}))


          	$( ".wd-form input[type='file']" ).change(function(event){

            	self.attachFile(event);
          	});

          	$(".wd-step-1 .wd-a input[type='radio']").change( function( evt ){

          		self.changeContent( evt );
          	})

          	document.title="Living with Depression - Share Your Story | YourDOST";
			$('meta[name=description]').attr('content', "Have you or your loved one been through depression? Share your story with us and help many people.");
			$('meta[name=title]').attr('content',"Living with Depression - Share Your Story | YourDOST");
			$('meta[property="og:description"]').attr('content', "Have you or your loved one been through depression? Share your story with us and help many people.");
			$('meta[property="og:title"]').attr('content',"Living with Depression - Share Your Story | YourDOST");
			$('meta[property="og:image"]').attr("content", "https://d1hny4jmju3rds.cloudfront.net/who_depression_day/depression-lp-header-web-555x278.png");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/lets-talk/share-your-story');
			$('meta[property="og:url"]').attr('content', 'https://yourdost.com/lets-talk/share-your-story');
			
		}
	});

	whoDepressionDayFormPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	whoDepressionDayFormPage.prototype.clean = function() {

		this.remove() ;
	};

	return whoDepressionDayFormPage;
});
