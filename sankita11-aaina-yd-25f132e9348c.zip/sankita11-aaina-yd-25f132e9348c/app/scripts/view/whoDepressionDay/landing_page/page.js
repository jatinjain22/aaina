define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'view/whoDepressionDay/subview/stories',
	'utils'
], function( $, _, Backbone, JST, Dispatcher, StoriesPage, Utils ) {

	var whoDepressionDayPage = Backbone.View.extend({

		el: "main",

		initialize: function() {

			this.storiesPage = new StoriesPage()
		},

		events: {

			"click .wd-fb-share" : "trackFbShare",
			"click .wd-tt-share" : "trackTwitShare",
			"click .swiper-button-prev" : "trackQuotesScroll",
			"click .swiper-button-next" : "trackQuotesScroll",
			"click .wholp-submit-story .wholp-submit-story-action_container .wholp-submit-story-submit_btn": "openVideoAudioPostInSelf",
			"click .wholp-top-players-container .wholp-playable-media .wholp-playable-media-title": "openVideoAudioPost",
			"click .wholp-top-players-container .wholp-top-players-show-more-container .wholp-top-players-show-more-button": "loadMoreVideoAudioPost",
			"click .wholp-supporters .wholp-supp-campn-action_container .wholp-supp-campn-support_btn": "supportCampaign",
			"click .wholp-real-stories-container .wholp-real-story .wholp-real-story-image": "openVideoAudioPost",
			"click .wholp-real-stories-container .wholp-real-story .wholp-real-story-title": "openVideoAudioPost",
			"click .wholp-real-stories-container .wholp-real-stories-show-more-button": "openVideoAudioPost",
			"click .wholp-banner-container .wholp-banner-button-lets-talk": "directToChat",
			"click .wholp-chat-container .wholp-chat-content-action-btn": "directToChat",
			"click .wholp-become-expert-container .wholp-become-expert-content-action-btn": "openVideoAudioPost",
			"click .wholp-refer-container .wholp-refer-content-action-btn": "openVideoAudioPost",
			"click #who-support-success .wholp-modal-close": "closeSuccessModal",
			"click #who-video-player-popup .wholp-modal-close": "closeVideoPlayerModal",
			"click #who-support-success .wholp-subscribe-form .wholp-modal-subscrible-send": "subscribeEmail",
			"click .wholp-footer .wholp-subscribe-form .wholp-footer-subscrible-send": "subscribeEmail"
		},

		mainLayout : JST['app/templates/whoDepressionDay/landing_page/layout.hbs'],
		bannerLayout : JST['app/templates/whoDepressionDay/landing_page/banner.hbs'],
		submitStoryLayout : JST['app/templates/whoDepressionDay/landing_page/submit_story.hbs'],
		playerLayout : JST['app/templates/whoDepressionDay/landing_page/players.hbs'],
		cardsLayout : JST['app/templates/whoDepressionDay/landing_page/post_single.hbs'],
		chatNowLayout : JST['app/templates/whoDepressionDay/landing_page/chat_now.hbs'],
		supportCampaignLayout : JST['app/templates/whoDepressionDay/landing_page/support_campaign.hbs'],
		realStoriesLayout : JST['app/templates/whoDepressionDay/landing_page/real_stories.hbs'],
		galleryLayout : JST['app/templates/whoDepressionDay/landing_page/gallery.hbs'],
		referLayout : JST['app/templates/whoDepressionDay/landing_page/refer.hbs'],
		becomeExpertLayout : JST['app/templates/whoDepressionDay/landing_page/become_expert.hbs'],
		footerLayout : JST['app/templates/whoDepressionDay/landing_page/footer.hbs'],
		successLayout : JST['app/templates/whoDepressionDay/landing_page/popup-success.hbs'],
		videoPlayerLayout : JST['app/templates/whoDepressionDay/landing_page/video_player.hbs'],

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				action_data["campaign"] = "Mktg_LetsTalk_LP";

				mixpanel.track(action_type, action_data);
			}
		},

		loadMoreVideoAudioPost: function(e) {

			var self = this,
				$target = $(e.target),
				$section_container = $target.parents(".wholp-top-players-container"),
				section = $section_container.attr("data-section"),
				$player_container = $section_container.find(".wholp-top-players-inner-container"),
				sectionPosts = [],
				total_posts,
				url = $target.attr("data-url"),
				action_type = $target.attr("data-action-type");

			if(section === "posts") {
				sectionPosts = self.trendingPosts.slice(self.trendingPosts.currentStage*3+5, self.trendingPosts.currentStage*3+8);
				self.trendingPosts.currentStage += 1;
				sectionPosts.currentStage = self.trendingPosts.currentStage;
				total_posts = self.trendingPosts.length;
			}
			else {
				sectionPosts = self.videos.slice(self.videos.currentStage*3+5, self.videos.currentStage*3+8);
				self.videos.currentStage += 1;
				sectionPosts.currentStage = self.videos.currentStage;
				total_posts = self.videos.length;
			}

			if(sectionPosts.currentStage >=3 || total_posts > sectionPosts.currentStage *3 +5 ) {
				$target.parent().removeClass("hide");
			}
			else {
				$target.parent().addClass("hide");	
			}

			if(sectionPosts.currentStage > 3) {
				window.open(url, "_blank");
			}
			else {
				$player_container.append(self.cardsLayout({posts : sectionPosts, isMobileDevice: Utils.isMobileDevice()}));
			}

			this.trackMixpanel("Button Click", {
		        						"ItemType": action_type, 
		        						"ItemName": $(e.target).text()
		        					})

		},

		openVideoAudioPostInSelf: function(e){
			var self = this,
				target = $(e.target),
				type = target.attr("data-type"),
				url = target.attr("data-url"),
				action_type = target.attr("data-action-type");

			this.trackMixpanel("Button Click", {
		        						"ItemType": action_type, 
		        						"ItemName": $(e.target).text()
		        					})

			if(type === "video") {

			}
			else if(type === "audio") {

			}
			else {
				window.open(url, "_self");
			}
		},

		openVideoAudioPost: function(e){
			var self = this,
				target = $(e.target),
				type = target.attr("data-type"),
				url = target.attr("data-url"),
				action_type = target.attr("data-action-type");

			this.trackMixpanel("Button Click", {
		        						"ItemType": action_type, 
		        						"ItemName": $(e.target).text()
		        					})

			if(type === "video") {
				var videoURL = target.attr("data-video-url");

				this.$el.append(this.videoPlayerLayout({ "videoURL": videoURL, "url": url, "title": $(e.target).text(), "imageUrl": target.attr("data-image-url") }));	

				Utils.openPopup('who-video-player-popup') ;
			}
			else if(type === "audio") {

			}
			else {
				window.open(url, "_blank");
			}


		},

		closeVideoPlayerModal: function() {
			this.trackMixpanel("Button Click", {
		        						"ItemType": 'Close popup', 
		        						"ItemName": "Close Video Player popup"
		        					})
			Utils.closePopup('who-video-player-popup') ;
			$("#who-video-player-popup").remove();
		},

		subscribeEmail : function(e){

			var self = this,
				$this = $(e.target),
				email = $this.siblings(".subscribe-email").val(),
				type = $this.attr("data-type");
			// $(".subscribe-footer-img").removeClass("hide");
			var isValidEmail = Utils.formEmailCheck(email) ;

			
			if(!isValidEmail){
				if(type === 'modal')
					$(".wholp-modal-subscrible-success-msg").html("Please enter valid email id");
				else 
					$(".wholp-footer-subscrible-success-msg").html("Please enter valid email id");
				// $("#subscribe-email-error").removeClass("hide") ;
				// $(".subscribe-footer-img").addClass("hide");
				return false ;
			}

			$.ajax({
				method: "POST",
				url: Utils.contextPath()+'/subscribe',
				data : email
			}).done(function(response){
				// $("#subscribe-button").hide() ;

				self.trackMixpanel("Button Click", {
		        						"ItemType": "SUBSCRIBE ARTICLES SECTION", 
		        						"ItemName": "Subscribe " +type+ " Email",
		        						"email": email
		        					})
				$(".wholp-subscribe-form").addClass("hide");
				if(type === 'modal')
					$(".wholp-modal-subscrible-success-msg").html("<p class=''>Got it! You'll start receiving our newsletters soon</p>") ;
				else 
					$(".wholp-footer-subscrible-success-msg").html("<p class=''>Got it! You'll start receiving our newsletters soon</p>") ;

			}).fail(function(error){
				console.log(error);
			});

		},

		closeSuccessModal: function() {
			this.trackMixpanel("Button Click", {
		        						"ItemType": 'Close popup', 
		        						"ItemName": "Close subscribe popup"
		        					})
			Utils.closePopup('who-support-success') ;
			$("#who-support-success").remove();
		},

		showSuccesModal : function( ){

			this.$el.append(this.successLayout());	

			Utils.openPopup('who-support-success') ;
		},

		numberWithCommas: function(x) {
		    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		},

		supportCampaign: function() {

			this.trackMixpanel("Button Click", {
		        						"ItemType": 'Support Campaign', 
		        						"ItemName": "WHO Campaign"
		        					});
			var self = this;
			$.ajax({
				method : "POST",
				url : Utils.contextPath()+"/support/who-depression",
			}).done( function( response){
				var count = $(".wholp-supporters .wholp-supp-campn-counts").attr("data-counts");

				self.showSuccesModal()
				$(".wholp-supporters .wholp-supp-campn-counts").attr("data-counts", parseInt(count) + 1).html(self.numberWithCommas(parseInt(count) + 1));
				// $(".wd-form-submit").html("SUBMIT YOUR STORY")

			}).fail( function( error){

				// self.showError("Something went wrong. Please try again later")
			})

		},

		redirect: function (options) {

			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "","", "letsTalkCat");
		},

		directToChat : function( e ){
			var self = this,
				target = $(e.target),
				action_type = target.attr("data-action-type");

			this.trackMixpanel("Button Click", {
		        						"ItemType": action_type, 
		        						"ItemName": "Chat Now"
		        					});
			if (!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat',
						categoryID : 6
					},
					callback: this.redirect
				} ) ;
			}else{
				
				this.redirect({
					"type"	: 'chat',
					categoryID : 6
				});
			}
		},

		directToStoryForm : function( evt ){
			if($(evt.target).hasClass('who-chat-btn')) {
				this.trackMixpanel("click_chat", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
			
				if (!Utils.isLoggedIn()){

					Dispatcher.trigger("renderLogin", "", "", "free_chat", {
						options : {
							type: 'chat',
							categoryID : 6
						},
						callback: this.redirect
					} ) ;
				}else{
					
					this.redirect({
						"type"	: 'chat',
						categoryID : 6
					});
				}
			}
			else {

				this.trackMixpanel("click_submit_story_lp", {key:"whoDepressionDay", value : "lp"})
				window.open("/lets-talk/share-your-story", "_self")
			}
		},

		trackTwitShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("Button Click", {
		        						"ItemType": 'share_whostory_lp', 
		        						"ItemName": "Facebook share",
		        						"title" : title, "url" : url
		        					})
		},

		trackLoadMore : function( evt ){

			this.trackMixpanel("click_loadmore_lp", {key:"whoDepressionDay", value : "lp"})
		},

		trackQuotesScroll : function( evt ){

			this.trackMixpanel("Button Click", {
		        						"ItemType": 'scroll_quotes_lp', 
		        						"ItemName": "Quotes Scroll"
		        					})
		},

		trackFbShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("Button Click", {
		        						"ItemType": 'share_whostory_lp', 
		        						"ItemName": "Facebook share",
		        						"title" : title, "url" : url
		        					})
		},

		directToStory : function( evt ){

			var title = $(evt.currentTarget).attr("data-title")
			this.trackMixpanel("read_story_lp", {key:"content_title", value : title})
		},

		scrollToStories : function( evt ){

			this.trackMixpanel("click_read_more_lp", {key:"whoDepressionDay", value : "lp"})

			// $("body, html").animate({

			// 	scrollTop : $(".wd-stories").offset().top - $(".wd-sticky").height() }, 
			// 'slow');
			window.open("/lets-talk/story/the-depression-epidemic-in-india", "_self")
			
		},

		getContent : function(url){

			var defer = $.Deferred();
			$.ajax({
				url : url,
				method: "GET"
			}).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		stickSubmit : function( evt,h ){

			if( $(document).scrollTop() > h+25){

				$(".wd-sticky").addClass("fixed");
				$(".who-sticky .wd-sticky-outer img").addClass("icon-small");
				var height = $(".wd-sticky").height()
				$(".wd-stories").css({"margin-top" : (height-10)+"px"})
			}else{

				$(".wd-sticky").removeClass("fixed")
				$(".who-sticky .wd-sticky-outer img").removeClass("icon-small");
				$(".wd-stories").css({"margin-top" : "0px"})
			}
		},

		render: function() {

			var self = this;
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout({}))

			$(".wholp-banner").html(this.bannerLayout());
			$(".wholp-submit-story").html(this.submitStoryLayout());

			var aText = new Array(
			"36% of Indians are likely to suffer from major Depression",
			""
			);
			var iSpeed = 100; // time delay of print out
			var iIndex = 0; // start printing array at this posision
			var iArrLength = aText[0].length; // the length of the text array
			var iScrollAt = 20; // start scrolling up at this many lines
			 
			var iTextPos = 0; // initialise text position
			var sContents = ''; // initialise contents variable
			var iRow; // initialise current row
			 
			function typewriter()
			{
				sContents =  ' ';
				iRow = Math.max(0, iIndex-iScrollAt);
				var destination = document.getElementById("typedtext");

				while ( iRow < iIndex ) {
					sContents += aText[iRow++] + '';
				}
				destination.innerHTML = sContents + aText[iIndex].substring(0, iTextPos) + "|";
				if ( iTextPos++ == iArrLength ) {
					destination.innerHTML = sContents + aText[iIndex].substring(0, iTextPos) + "";
					$(".wholp-banner-data-source").removeClass("hide");
					iTextPos = 0;
					iIndex++;
					if ( iIndex != aText.length ) {
						iArrLength = aText[iIndex].length;
						setTimeout(function(){
								typewriter();
							}, 500);
					}
				} else {
				setTimeout(function(){
						typewriter();
					}, iSpeed);
				}
			}


			var isMobileDevice = Utils.isMobileDevice() == true ? true : false;

			$.ajax({
				method : "GET",
				url : Utils.contextPath()+"/support/who-depression",
			}).done( function( response){

				$(".wholp-supporters").html(self.supportCampaignLayout({count: response + 17426, counts: self.numberWithCommas(response + 17426)}));

			}).fail( function( error){

				self.showError("Something went wrong. Please try again later")
			})
			$(".wholp-chat").html(this.chatNowLayout());
			$(".wholp-refer").html(this.referLayout());
			$(".wholp-become-expert").html(this.becomeExpertLayout());
			
			this.getContent(Utils.scriptPath()+"/letsTalk/trending.json")
			.then(function(response){
				self.trendingPosts = response.posts;
				self.trendingPosts.currentStage = 0;

				$(".wholp-trending").html(self.playerLayout(
					{
						posts : response.posts, 
						title: "Trending Posts", 
						type: "posts", 
						class: "wholp-top-videos-container", 
						isMobileDevice: isMobileDevice,
						loadMoreURL: "http://yourdost.com/blog/tag/letstalkcontent"
					}))
			})

			this.getContent(Utils.scriptPath()+"/letsTalk/videos.json")
			.then(function(response){
				self.videos = response.videos;
				self.videos.currentStage = 0;

				$(".wholp-videos").html(self.playerLayout({posts : response.videos, title: "Top Videos", type: "videos", class: "wholp-trending-posts-container"}))

				if(response.videos.length < 6 ) {
					$(".wholp-trending-posts-container .wholp-top-players-show-more-container").addClass("hide");
				}
			})

			this.getContent(Utils.scriptPath()+"/letsTalk/stories.json")
			.then(function(response){

				$(".wholp-real-stories").html(self.realStoriesLayout({stories : response.stories, isMobileDevice: isMobileDevice, windowWidth: $(document).width() }))
				if(isMobileDevice) {
					for(var i in response.stories){
						var el = response.stories[i];
						$(".wholp-real-story-image[data-post-id="+el.id+"]").css("background-image", "url('"+el.mobileImageUrl+"')");
					}
				}
			})

			this.getContent(Utils.scriptPath()+"/letsTalk/gallery.json")
			.then(function(response){
				var space = 20;
				if(Utils.isMobileDevice()){

					space = 5
				}
				$(".wholp-gallery").html(self.galleryLayout({images : response.images}))
				if(!Utils.isMobileDevice()){ 
					var mySwiper = new Swiper ('.wholp-gallery-inner-container', {
				    
		        		autoplay: 15000,
		        		keyboardControl: true,
		        		slidesPerView: '3',
		        		loop : true,
				        nextButton: '.swiper-button-next',
				        prevButton: '.swiper-button-prev',
				        spaceBetween: space,
					    centeredSlides: true,
				        // when window width is <= 640px
						breakpoints: {
							640: {
								slidesPerView: 'auto',
								spaceBetweenSlides: 10
							}
						},
					});
				}
			})

			document.title="World Health Day - Lets Talk About Depression | YourDOST";
			$('meta[name=description]').attr('content', "India is one of the most depressed countries as revealed by WHO. I support the #LetsTalk campaign to break the stigma around mental health.");
			$('meta[name=title]').attr('content',"World Health Day - Lets Talk About Depression | YourDOST");
			$('meta[property="og:description"]').attr('content', "India is one of the most depressed countries as revealed by WHO. I support the #LetsTalk campaign to break the stigma around mental health.");
			$('meta[property="og:title"]').attr('content',"World Health Day - Lets Talk About Depression | YourDOST");
			$('meta[property="og:image"]').attr("content", "https://d1hny4jmju3rds.cloudfront.net/who_depression_day/lp/Depression-share-Banner.png");
			$('link[rel="canonical"]').attr('href', 'http://yourdost.com/depression/lets-talk');
			$('meta[property="og:url"]').attr('content', 'http://yourdost.com/depression/lets-talk');
			
			$(".wholp-footer").html(this.footerLayout());
			typewriter();

			this.trackMixpanel("WHO Depression Microsite Landing Page", {
		        						"ItemType": "Page Load", 
		        						"ItemName": document.title
		        					})
			// var h = $(".wd-sticky").offset().top;
			// $(document).scroll(function( evt ){

			// 	self.stickSubmit.call(self, evt, h)
			// })
		}
	});

	whoDepressionDayPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	whoDepressionDayPage.prototype.clean = function() {

		this.remove() ;
	};

	return whoDepressionDayPage;
});
