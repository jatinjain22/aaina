define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'view/whoDepressionDay/subview/stories',
	'utils'
], function( $, _, Backbone, JST, Dispatcher, StoriesPage, Utils ) {

	var whoDepressionDayPage = Backbone.View.extend({

		el: "main",

		initialize: function() {

			this.storiesPage = new StoriesPage()
		},

		events: {

			"click .wd-btn" : "scrollToStories",
			"click .wd-sticky-btn" : "directToStoryForm",
			"click .wd-story-a" : "directToStory",
			"click .wd-fb-share" : "trackFbShare",
			"click .wd-tt-share" : "trackTwitShare",
			"click .wd-load-more-btn" : "trackLoadMore",
			"click .swiper-button-prev" : "trackQuotesScroll",
			"click .swiper-button-next" : "trackQuotesScroll"
		},

		mainLayout : JST['app/templates/whoDepressionDay/layout.hbs'],
		bannerLayout : JST['app/templates/whoDepressionDay/subview/banner.hbs'],
		stickyLayout : JST['app/templates/whoDepressionDay/subview/sticky.hbs'],
		chatNowLayout : JST['app/templates/whoDepressionDay/subview/chat_now.hbs'],
		quotesLayout : JST['app/templates/whoDepressionDay/subview/quotes.hbs'],
		footerLayout : JST['app/templates/whoDepressionDay/subview/footer.hbs'],

		redirect: function (options) {

			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "","", "whoDayCat");
		},

		directToChat : function( evt ){
		},

		directToStoryForm : function( evt ){
			if($(evt.target).hasClass('who-chat-btn')) {
				this.trackMixpanel("click_chat", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
			
				if (!Utils.isLoggedIn()){

					Dispatcher.trigger("renderLogin", "", "", "free_chat", {
						options : {
							type: 'chat',
							categoryID : 6
						},
						callback: this.redirect
					} ) ;
				}else{
					
					this.redirect({
						"type"	: 'chat',
						categoryID : 6
					});
				}
			}
			else {

				this.trackMixpanel("click_submit_story_lp", {key:"whoDepressionDay", value : "lp"})
				window.open("/lets-talk/share-your-story", "_self")
			}
		},

		trackTwitShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("share_whostory_lp", {key:"channel", value : "twitter", title : title, url : url})
		},

		trackLoadMore : function( evt ){

			this.trackMixpanel("click_loadmore_lp", {key:"whoDepressionDay", value : "lp"})
		},

		trackQuotesScroll : function( evt ){

			this.trackMixpanel("scroll_quotes_lp",{key:"whoDepressionDay", value : "lp"})
		},

		trackFbShare : function( evt ){

			var parent = $(evt.currentTarget).parents(".addthis_toolbox")
			var title = parent.attr("addthis:title")
			var url = parent.attr("addthis:url")

			this.trackMixpanel("share_whostory_lp", {key:"channel", value : "fb", title : title, url : url})
		},

		directToStory : function( evt ){

			var title = $(evt.currentTarget).attr("data-title")
			this.trackMixpanel("read_story_lp", {key:"content_title", value : title})

		},

		scrollToStories : function( evt ){

			this.trackMixpanel("click_read_more_lp", {key:"whoDepressionDay", value : "lp"})

			// $("body, html").animate({

			// 	scrollTop : $(".wd-stories").offset().top - $(".wd-sticky").height() }, 
			// 'slow');
			window.open("/lets-talk/story/the-depression-epidemic-in-india", "_self")
			
		},

		getContent : function(url){

			var defer = $.Deferred();
			$.ajax({
				url : url,
				method: "GET"
			}).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_LetsTalk", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		stickSubmit : function( evt,h ){

			if( $(document).scrollTop() > h+25){

				$(".wd-sticky").addClass("fixed");
				$(".who-sticky .wd-sticky-outer img").addClass("icon-small");
				var height = $(".wd-sticky").height()
				$(".wd-stories").css({"margin-top" : (height-10)+"px"})
			}else{

				$(".wd-sticky").removeClass("fixed")
				$(".who-sticky .wd-sticky-outer img").removeClass("icon-small");
				$(".wd-stories").css({"margin-top" : "0px"})
			}
		},

		render: function() {

			var self = this;
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")
			
			this.$el.html(this.mainLayout({}))

			$(".wd-banner").html(this.bannerLayout());
			$(".wd-sticky").html(this.stickyLayout());
			$(".who-chat-container").html(this.chatNowLayout());
			this.storiesPage.render();

			this.trackMixpanel("page_load", { key: "whoDepressionDay", value: "lp" })

			this.getContent(Utils.scriptPath()+"/quotes-who.json")
			.then(function(response){

				$(".wd-quotes").html(self.quotesLayout({quotes : response.quotes}))
				var mySwiper = new Swiper ('.wd-quotes-content', {
				    
	        		autoplay: 15000,
	        		keyboardControl: true,
	        		slidesPerView: '1',
	        		loop : true,
			        nextButton: '.swiper-button-next',
			        prevButton: '.swiper-button-prev',
				});
			})

			document.title="Real Stories - Winning Over Depression | YourDOST";
			$('meta[name=description]').attr('content', "Draw strength and hope from the stories of real people. Know more about their experiences living with and coming out of depression.");
			$('meta[name=title]').attr('content',"Real Stories - Winning Over Depression | YourDOST");
			$('meta[property="og:description"]').attr('content', "Draw strength and hope from the stories of real people. Know more about their experiences living with and coming out of depression.");
			$('meta[property="og:title"]').attr('content',"Real Stories - Winning Over Depression | YourDOST");
			$('meta[property="og:image"]').attr("content", "https://d1hny4jmju3rds.cloudfront.net/who_depression_day/depression-lp-header-web-555x278.png");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/lets-talk/stories');
			$('meta[property="og:url"]').attr('content', 'https://yourdost.com/lets-talk/stories');
			
			$(".wd-footer").html(this.footerLayout());
			var h = $(".wd-sticky").offset().top;
			$(document).scroll(function( evt ){

				self.stickSubmit.call(self, evt, h)
			})
		}
	});

	whoDepressionDayPage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	whoDepressionDayPage.prototype.clean = function() {

		this.remove() ;
	};

	return whoDepressionDayPage;
});
