define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils'
], function( $, _, Backbone, JST, Dispatcher, Utils ) {

	var whoDaySinglePage = Backbone.View.extend({

		el: "main",

		initialize: function() {

		},

		events: {

			"click .wd-yd-call" : "redirectToAppointment",
			"click .wd-yd-msg" : "openMsg",
			"click .wd-yd-chat" : "directToChat",
			"click .wd-sticky-btn" : "directToStory",
			"click .wd-story-a" : "directToFullStory",
			"click .wd-back a" : "goBack"
		},

		redirectToAppointment : function( evt ){

			this.trackMixpanel("click_appointment", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
			Backbone.history.navigate("/bookAppointment?from=talkItOut&conID=101&catID=Others", {trigger: true});
		},

		goBack : function( evt ){

			this.trackMixpanel("click_back", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
		},

		openMsg : function( evt ){

			var counselorInfo = {}
			counselorInfo.id = 101;
			this.trackMixpanel("click_message", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
			if(!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "", "talkItOut", "quickMessage", counselorInfo ) ;
			}else{

				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorInfo.id	
					}
				});
			}
		},

		directToFullStory : function( ){

			this.trackMixpanel("click_read_story_story", [{key : "page_name", value : "storypage"}])
		},

		directToStory : function( evt ){

			this.trackMixpanel("click_submit_story_storypg", [{key : "page_name", value : "storypage"}])
			window.open("/lets-talk/share-your-story", "_self")
		},


		redirect: function (options) {

			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "","", "whoDayCat");
		},

		directToChat : function( evt ){

			this.trackMixpanel("click_chat", [{key : "content_type", value : "whostory"}, {key : "content_title", value: this.title}])
			
			if (!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: 'chat',
						categoryID : 6
					},
					callback: this.redirect
				} ) ;
			}else{
				
				this.redirect({
					"type"	: 'chat',
					categoryID : 6
				});
			}
		},

		mainLayout : JST['app/templates/whoDepressionDay/single/layout.hbs'],
		storyLayout : JST['app/templates/whoDepressionDay/single/story.hbs'],
		footerLayout : JST['app/templates/whoDepressionDay/subview/footer.hbs'],
		stickyLayout : JST['app/templates/whoDepressionDay/subview/sticky.hbs'],
		cardsLayout : JST['app/templates/whoDepressionDay/single/related_stories.hbs'],
		loaderLayout : JST['app/templates/loader.hbs'],

		getContent : function(url){

			var defer = $.Deferred();
			$.ajax({
				url : url,
				method: "GET"
			}).done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise();
		},

		trackMixpanel : function( action_type, action_data ){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track("Mktg_LetsTalk", { "action_type" : action_type, "action_data" : action_data});
			}
		},

		getRelated : function( id ){

			var self = this;

			$(".wd-story-submit").html(this.stickyLayout())
			
			this.getContent(Utils.scriptPath() + "/stories-who.json")
			.then(function(response){

				self.showRelated(response.stories, id);
			})
		},

		showRelated : function( data, id){

			var stories = [];
			var i = 0;
			var flag = [0];
			_.each(data, function(item, index){

				var ran = Math.floor(Math.random()*(data.length))

				if(item.id != id && i < 6 && flag.indexOf(ran) == -1){

					i = i+1;
					flag.push(ran);
					stories.push(item)
				}
			})

			$(".wd-related-content").html(this.cardsLayout({stories : stories}))
			setTimeout(function () {
				
				addthis.toolbox(".addthis_toolbox");
			}, 1000);
		},

		setMetaData : function( data ){

			this.trackMixpanel("page_load", [{key:"page_load", value:"storypage"}, {key:"story_title",value:data.title}])
			this.title = data.title
			this.desc = data.desc
			document.title=data.title;
			$('meta[name=description]').attr('content', data.excerpt);
			$('meta[name=title]').attr('content',data.title);
			$('meta[property="og:description"]').attr('content', data.excerpt);
			$('meta[property="og:title"]').attr('content', data.title);
			$('meta[property="og:image"]').attr("content", data.imageUrl);
			$('link[rel="canonical"]').attr('href', "https://yourdost.com/lets-talk/story/"+data.url);
			$('meta[property="og:url"]').attr('content', "https://yourdost.com/lets-talk/story/"+data.url);
		},

		render: function() {

			var self = this;

			var url = window.location.pathname.replace(/\/+$/, "")
			url = url.split("/")[url.split("/").length-1];
			
			$("#main-header").hide();
			$(".feedback-form-btn").addClass("hide")

			this.$el.html(this.mainLayout());

			$(".wd-story-content").html(this.loaderLayout());

			$(".wd-related-content").html(this.loaderLayout());

			this.getContent(Utils.scriptPath() + "/story-who-map.json")
			.then(function(response){

				var content = response[url];

				$(".wd-story-content").html(self.storyLayout({content : content}))
				self.setMetaData(content)
				self.getRelated(content.id)

			}, function( error){

				console.log("Error :", error)
			})

			$(".wd-footer").html(this.footerLayout());
		}
	});

	whoDaySinglePage.prototype.remove = function() {

		$("#main-header").show();
		$(".feedback-form-btn").removeClass("hide")
		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	whoDaySinglePage.prototype.clean = function() {

		this.remove() ;
	};

	return whoDaySinglePage;
});
