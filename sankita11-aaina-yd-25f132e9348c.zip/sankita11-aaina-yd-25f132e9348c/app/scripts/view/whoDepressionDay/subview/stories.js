define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function( $, _, Backbone, JST, Utils ) {

	var storiesPage = Backbone.View.extend({

		el: "main",

		initialize: function() {},

		events: {

			"click .wd-load-more-btn" : 'loadMoreStories'
		},

		storiesLayout : JST['app/templates/whoDepressionDay/subview/stories.hbs'],
		cardsLayout : JST['app/templates/whoDepressionDay/subview/story_card.hbs'],
		loaderLayout : JST['app/templates/loader.hbs'],

		getContent : function(url, method){

			var options = {
				url : url,
				method : method
			}

			var defer = $.Deferred();
			$.ajax(options)
			.done(function(response){

				defer.resolve(response)
			}).fail(function(error){

				defer.reject(error)
			})

			return defer.promise()
		},

		loadMoreStories : function ( ){

			$(".wd-load-more-btn").html("loading...")
			this.currentStage += 1;
			this.loadStories()
		},

		renderStories : function( ){


			if( this.stories.length > 6){

				this.loadStories()
				$(".wd-load-more-btn").removeClass("hide")
				
			}else{

				$(".wd-stories-content").html(this.cardsLayout({stories : this.stories}))
			}
		},

		loadStories : function(){

			var storiesArr = this.stories.slice(this.currentStage*6,this.currentStage*6+6)
			
			$(".wd-stories-content").append(this.cardsLayout({stories : storiesArr}))
			
			if(this.stories.length > this.currentStage*6+6){

				$(".wd-load-more-btn").removeClass("hide")
			}else{

				$(".wd-load-more-btn").addClass("hide")
			}

			$(".wd-load-more-btn").html("load more stories")
		},

		render: function() {	

			this.$el.find(".wd-stories").html(this.storiesLayout({}))
			
			var self = this;

			//$(".wd-stories-content").html(this.loaderLayout());

			this.getContent(Utils.scriptPath() + "/stories-who.json", "GET")
			.then(function(response){

				self.currentStage = 0;
				self.stories = response.stories;
				self.renderStories()
				
			})
		}
	});

	storiesPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	storiesPage.prototype.clean = function() {

		this.remove() ;
	};

	return storiesPage;
});

