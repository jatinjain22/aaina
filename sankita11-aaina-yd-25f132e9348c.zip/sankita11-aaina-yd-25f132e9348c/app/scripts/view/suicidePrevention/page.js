define([
	'jquery',
	'underscore',
	'event/dispatcher',
	'backbone',
	'../../precompiled-templates',
	'utils'
], function($, _, EventBus, Backbone, JST,Utils) {
	
	var SuicidePreventionPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
		},
		events: {
			"click #signup-saviour":"signUpSaviour",
			//"focusout #email-div-saviour #email":"validateEmail",
			"click .tweet-btn":"UserTweet",
			"click .tbox #shareBtn":"UserFbShare",
			"click .tweet-btn-2":"TweetSuicide",
			"click #suicideshareBtn":"FbShareSuicide"
		},
		SuicidePreventionLayout: JST['app/templates/suicidePrevention/layout.hbs'],
		TweetSuicide:function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("User Tweet", { "mediumSource" : "website", "itemName" : 'SuicidePreventionPage' });
       				 }
		},
		FbShareSuicide:function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("User FbShare", { "mediumSource" : "website", "itemName" : 'SuicidePreventionPage' });
       				 }
		},
		UserFbShare:function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("User FbShare", { "mediumSource" : "website", "itemName" : 'SuicidePreventionPage' });
       				 }
       				 $('.suicide-feed').removeClass('hide');
       				 $('.tbox').addClass('hide');
		},
		UserTweet:function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("User Tweet", { "mediumSource" : "website", "itemName" : 'SuicidePreventionPage' });
       				 }
       				 $('.suicide-feed').removeClass('hide');
       				 $('.tbox').addClass('hide');

		},
		validateEmail:function(){

			var self = this;
			var email = $("#email-div-saviour #email").val();
			if(email == "" || email == null){
				$('#email-div-saviour#email').addClass('invalid');
				$("#email-div-saviour #error-email-msg").text("Please enter an email id.");
				$('#email-div-saviour #error-email-msg').addClass('red-text');
				$("#signup-saviour").show() ;
						$("#signup-saviour-progress").hide() ;
			}else{
			//$("#appointment-user-info #email-div").append( this.loaderHTML()) ;
			var regex = new RegExp('^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$','i');
			if(email.match(regex) != null){
						$.ajax({
					url : Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
					statusCode:{
	            		404 : function(resp){
	            			console.log(resp);
	    					$("#email-div-saviour #email").removeClass('invalid');
							$("#email-div-saviour #email").addClass('valid');
							$('#email-div-saviour #error-email-msg').text('Important communication will be sent here');
							$('#email-div-saviour #error-email-msg').removeClass('red-text');
							
	            		}
	        		},

					}).done(function(response){
							
						$('#email-saviour').addClass('hide');
							$('#twitter-content-1').removeClass('hide');
							$('#twitter-content-2').removeClass('hide');
							if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				         		 mixpanel.track("Email exists SuicidePrevention", { "mediumSource" : "website", "itemName" : email });
				       				 }
					});
				}else{
					$('#email-div-saviour #email').addClass('invalid');
					$("#email-div-saviour #error-email-msg").text("Please enter a valid email Id!!");
					$('#email-div-saviour #error-email-msg').addClass('red-text');
					$("#signup-saviour").show() ;
						$("#signup-saviour-progress").hide() ;
				}
				}

		},
		signUpSaviour:function(e){
			var self = this;
			e.preventDefault();
			e.stopPropagation();
			$("#signup-saviour").hide() ;
			$("#signup-saviour-progress").show() ;
			self.validateEmail();
			var email = $('#email-div-saviour #email').val();
			if(email!=null && email!=undefined&& email!=''&& $('#email-saviour').is(":visible")){
			
			var dataToSend = {'username':'YDSAVIOUR','email':email};
			console.log(JSON.stringify(dataToSend));
			$.ajax({
			url :   Utils.contextPath() + '/v2/users/saviour/signup',
			method : 'POST',
			dataType : "json" ,
			xhrFields: {
     				 withCredentials: true
			    },
			contentType: "application/json",
			data: JSON.stringify(dataToSend),
			statusCode:{
			    417 : function(response){
			    	var responseText = response.responseText;
					var responseJson = JSON.parse(responseText) ;

					var errorMessage = responseJson.message ;
					var errorType    = responseJson.type ;
					$('#email-div-saviour #error-email-msg').addClass('invalid');
			    	$('#email-div-saviour #error-email-msg').text(errorMessage);
			    	$('#email-div-saviour #error-email-msg').addClass('red-text')
			    	$("#signup-saviour").show() ;
					$("#signup-saviour-progress").hide() ;
			  	  }
				},
		}).done(function(response){

			console.log('signup successful Saviour');
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("Email signup SuicidePrevention", { "mediumSource" : "website", "itemName" : email });
       				 }
			console.log(response);
			//self.model.save(response) ;
				//self.signUpProgress = 1 ;
				sessionStorage.setItem("firstTimeUser" , 1 ) ;
				Raygun.setUser( response.username, false, response.email, response.firstName, response.firstName, response.id ) ;

				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){ 

					mixpanel.register({
						userInfo : response ,
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.alias(response.id, distinct_id);
					mixpanel.track('SIGNUP', {'type' : 'NORMAL',  'itemName' : 'SuicidePage', 'itemMedium' : 'NORMAL'  });
					
					if (  ( typeof fbq != 'undefined' ) ){
						fbq('track', 'CompleteRegistration');						
					}

					if( typeof ga != 'undefined'){
						ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
					}

					mixpanel.people.set({
	    			'username': response.username,
	    			'name' : response.username ,
	    			'$email': response.email,
	    			'id' : response.id,
	    			'src' : 'NORMAL',
	    			'userType' : response["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: response.username
					});
				}
			$('#email-saviour').addClass('hide');
			$('#twitter-content-2').removeClass('hide');
			$('#twitter-content-1').removeClass('hide');

			});
	}
		},
		render: function() {
			document.title= "#NotAnOption";
			$('meta[property="og:description"]').attr('content', "On Suicide Prevention Day, 10th Sep, Lets flood social media with positive words of encouragement. Take the pledge now.");
			$('meta[property="og:title"]').attr('content'," Suicide is #NotAnOptionAnymore");
			$('link[rel="canonical"]').attr('href', 'https://yourdost.com/suicidePrevention');
			$('meta[property="og:url"]').attr('content',"https://yourdost.com/suicidePrevention");		
			$('meta[property="og:image"]').attr('content',"https://d1hny4jmju3rds.cloudfront.net/suicidePrevention/FB_suicide.jpg");
			var self = this ;
			self.$el.html(self.SuicidePreventionLayout({}));	
				setTimeout(function(){
			     twttr.events.bind('.tweet-btn', function (event) {
				     
				   });
			      twttr.events.bind('.tweet-btn-2', function (event) {
				     
				   });
			}, 1000)

		
		//if(Utils.isLoggedIn()){
			$('#email-saviour').addClass('hide');
			$('#twitter-content-2').removeClass('hide');
			$('#twitter-content-1').removeClass('hide');
		//}
		/*else{
			$('#email-saviour').removeClass('hide');
			$('#twitter-content-2').addClass('hide');
			$('#twitter-content-1').addClass('hide');
			
		}
		setTimeout(function(){

			$( window ).scroll(function() {		        	
	         
          		var h= $('.dost-main').height();
          		var pos =  $(window).scrollTop();

	          	if(pos<=h){

		            
		           $( ".suicideFloat" ).fadeIn( "slow", function() {
						   
						  });
	          	}
	          	if(pos > h){
		          
		           $( ".suicideFloat" ).fadeOut( "slow", function() {
						    // Animation complete
						  });
		          
		        }
		    });

		}, 1000)*/
		}
	});

	SuicidePreventionPage.prototype.remove = function() {};

	SuicidePreventionPage.prototype.clean = function() {};

	return SuicidePreventionPage;
});