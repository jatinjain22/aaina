define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/talkItOut',
	'model/users',
	'view/leaveMessage/page' 
], function( $, _, Backbone, JST, Dispatcher, Utils, TalkItOutModel, UserModel, LeaveMessageView ) {

	var ChatModal = Backbone.View.extend({
		el: "main",
		initialize: function() {

			this.model     = new TalkItOutModel() ;
			this.userModel = new UserModel()      ;
			this.leaveMessage       = new LeaveMessageView(); 
			this.familiarCounselors = [] ;

			_.bindAll(this)                                                  ;
			this.listenTo(Dispatcher, 'chatQuickCheck', this.chatQuickCheck) ;	
			this.listenTo(Dispatcher, 'messageQuickCheck', this.messageQuickCheck);		
			//this.listenTo(Dispatcher, 'renderChatModal', this.renderHTML)    ;
		},
		events: {
			"click .quick-check-demo-chat" : "redirectToChat",
			"click .quick-check-demo-message": "renderMessageModal",
			"click #chat-modal .mclose" : "closeModal"
		},
		closeModal : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('chat-modal');
			$("#lean-overlay").remove();
			$('#chat-modal').remove() ;

			if(this.toRedirect == 1){
				Backbone.history.navigate("/talkItOut",{trigger:true});
			}
			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
        	    mixpanel.track('Chat Quick Check', {'mediumSource' : 'website', 'itemName': 'Chat Quick check Closed'});
          
        	}
		},
		redirectToChat : function(e){
			var username = this.userModel.getUserName() ;
			location.href = this.urlToRedirect;
		},
		ChatModalLayout : JST['app/templates/talkItOut/chatModal.hbs'],
		MessageModalLayout: JST['app/templates/talkItOut/messageModal.hbs'],
		ExpertCard     : JST['app/templates/talkItOut/expert_card.hbs'],

		renderMessageHTML: function(msgType, directCounselorName) {

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          		mixpanel.track("Just a quick check popup", { "mediumSource" : "website", 'itemName' : msgType, 'counselor' : directCounselorName });
        	}

			this.$el.append(this.MessageModalLayout({msgType:msgType, directCounselorName:directCounselorName}));
			this.setElement($("main")).render();
		},
		renderHTML : function(chatType, directCounselorName){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

                mixpanel.track("Just a quick check popup", { "mediumSource" : "website", 'itemName' : chatType, 'counselor' : directCounselorName });
            }
			this.$el.append(this.ChatModalLayout({chatType:chatType, directCounselorName:directCounselorName}));
			this.setElement($("main")).render();
		},
		renderMessageModal: function(){
			var self = this;
			if(!self.counselorInfo || self.counselorInfo == undefined || self.counselorInfo == null ){
				self.leaveMessage.render() ;
			}else{
				self.leaveMessage.render( self.counselorInfo ) ;
			}
		},
		messageQuickCheck : function(msgType, counselorInfo){

			var self = this;
			self.counselorInfo = counselorInfo;
			var userID = self.userModel.getUserID();
			var counselorID = counselorInfo["id"];
			var directCounselorName = counselorInfo["name"];

			self.renderMessageModal(counselorInfo);

			return true ;

			//Removing the check for time being 

			$.ajax({
				url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"	
			}).done(function(response){
				var familiarCounselors = response ;

				self.familiarCounselors = familiarCounselors;

				var counselorMatched = 0 ;
				var counselorParsed = 0 ;
				$.each(familiarCounselors, function(index, elem){

					if(counselorID == elem.id){
						counselorMatched = 1 ;
					}

					counselorParsed += 1 ;

					if(msgType != "demo" && counselorID == elem.id){
						// directCounselorName = elem.name ;
					}
				});

				if(counselorMatched == 0 && counselorParsed > 0){
				
					self.renderMessageHTML(msgType, directCounselorName);
				
				} else {
					
					self.renderMessageModal(counselorInfo);
				}
				
			}).error(function(error){

			});

		},

		getFromText : function(fromPage){

			var text = {
				"talkItOut" : "From expert list page", 
				"counselorPage" : "User selected expert from his profile",
				"flames" : "came from Flames marketing campaign",
				"home" : "came from yd homepage",
				"newYearQ2" : "Came from Will you succeed in your New Year Resolution?",
				"love-compatibility" : "came from Are You & Your Partner Compatible?",
				"newYearselfTest" : "came from My New Year Resolution In 2017",
				"shapeselfTest" : "Came from What's Your Shape",
				"trueColorselfTest" : "Came from What's Your Color",
				"discoverYourSelfselfTest" : "Came from Discover Your Innate Nature",
				"habitselfTest" : "Came from Your Internet HABIT-O-METER",
				"homeCat1" : "Came from yd homepage and selected Love & Relationships category",
				"homeCat2" : "Came from yd homepage and selected Career & Academics category",
				"homeCat3" : "Came from yd homepage and selected Sexual Wellness category",
				"homeCat4" : "Came from yd homepage and selected Self-Improvement category",
				"homeCat6" : "Came from yd homepage and selected Others category",
				"talkItOutCat1" : "From expert list page and selected Love & Relationships category",
				"talkItOutCat2" : "From expert list page and selected Career & Academics category",
				"talkItOutCat3" : "From expert list page and selected Sexual Wellness category",
				"talkItOutCat4" : "From expert list page and selected Self-Improvement category",
				"talkItOutCat5" : "From expert list page and selected Friends & Family category",
				"talkItOutCat6" : "From expert list page and selected Others category",
				"womensDayCat" : "From women's Day Campaign"

			};

			return text[fromPage] ;


		},

		chatQuickCheck : function(chatType, counselorID, counselorUrl, toRedirect, fromPage){

			var self = this ;

			if (  ( typeof fbq != 'undefined' ) ){
				fbq('track', 'Lead');					
			}

			var fromText  = "" ;
			fromText = self.getFromText(fromPage) ;
			var userID = self.userModel.getUserID() ;

			var username = self.userModel.getUserName() ;
			if(chatType == "demo"){
				self.urlToRedirect = Utils.chatUrl() + username;
				var selectedFilters = localStorage.getItem("filterQuery");
				if(selectedFilters != null){
					var parentCatFilter = selectedFilters.match(/parent_category=(.*?)(\&|$)/);				
					var parentCategory = "";
					if(parentCatFilter != null){
						parentCategory = parentCatFilter[1];
						self.urlToRedirect += "&category=" + parentCategory ;
						fromText = self.getFromText("talkItOutCat" + parentCategory );
					}					
				}



			}else if(chatType == "demoCat"){
				var selectedCat = counselorID ;
				self.urlToRedirect = Utils.chatUrl() + username + "&category=" + selectedCat;
			}else{
				self.urlToRedirect = counselorUrl + "&username=" + username ;

				var selectedFilters = localStorage.getItem("filterQuery");
				if(selectedFilters != null){
					var parentCatFilter = selectedFilters.match(/parent_category=(.*?)(\&|$)/);				
					var parentCategory = "";
					if(parentCatFilter != null){
						parentCategory = parentCatFilter[1];
						self.urlToRedirect += "&category=" + parentCategory ;
						fromText = self.getFromText("talkItOutCat" + parentCategory );
					}					
				}

			}
				

			if(fromText != null && fromText != undefined){
				self.urlToRedirect += "&from=" + btoa(fromText);	
			}

			location.href =self.urlToRedirect;

			return true ;

			//Removing the check for time being 
			self.toRedirect = toRedirect ;
			var url = self.model.url ;

			if(!url.match("familiar")){
				self.model.url = self.model.url + "?user=" + userID + "&familiar=true";				
			}

			var directCounselorName = '' ;

			$.ajax({
				url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"	
			}).done(function(response){

				var familiarCounselors = response ;

				self.familiarCounselors = familiarCounselors;

				var counselorMatched = 0 ;
				var counselorParsed = 0 ;
				$.each(familiarCounselors, function(index, elem){

					if(counselorID == elem.id){
						counselorMatched = 1 ;
					}

					counselorParsed += 1 ;

					if(chatType != "demo" && counselorID == elem.id){
						directCounselorName = elem.name ;
					}

				});	

				if(chatType != 'demo'){
					directCounselorName = counselorUrl.match(/workgroup=(.*?)__/)[1];
				}

				var username = self.userModel.getUserName() ;
				if(chatType == "demo"){
					self.urlToRedirect = Utils.chatUrl() + username;	
				}else{
					self.urlToRedirect = counselorUrl + "&username=" + username ;
				}
					

				if(counselorMatched == 0 && counselorParsed > 0){
					self.renderHTML(chatType, directCounselorName);
				}else{
					location.href =self.urlToRedirect;
				}

			}).error(function(error){
				console.log(error);
			});

		},
		render: function() {
			var self = this ;

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
        	    mixpanel.track('Chat Quick Check', {'mediumSource' : 'website', 'itemName': 'Chat quick check Shown'});
          
        	}
			
			Utils.openPopup('chat-modal');

			Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 0, self.familiarCounselors, "Just a quick check");


			return this;
		}
	});

	ChatModal.prototype.remove = function() {
				this.$el.empty();
    	this.$el.off();
    	//this.undelegateEvents();
    	this.unbind();
    	//this.stopListening();

	};

	ChatModal.prototype.clean = function() {};

	return ChatModal;
});