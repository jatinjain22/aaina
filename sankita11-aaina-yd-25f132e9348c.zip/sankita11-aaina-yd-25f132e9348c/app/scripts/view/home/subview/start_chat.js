define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) {

	var StartChatView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
		},
		events: {
			'click #home-start-chat-btn' : 'openSignUpNowModal' ,
			'keyup #anonymous-chat-name-txt' : 'openSignUpOnEnter'
		},
		openSignUpOnEnter: function(e){

			if( e.which == 13 ){
				this.openSignUpNowModal();
			}
		},
		openSignUpNowModal : function (e) {
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "click CHAT Home Page", "home", "home_chat") ;
				var username = $("#anonymous-chat-name-txt").val() ;
				$("#sign-up-txt-name #username").val(username) ;
				$("#sign-up-txt-name label").addClass("active") ;
				$(".mdi-social-person").addClass("active") ;
			}else{
				var username = this.userModel.getUserName() ;
				location.href = Utils.chatUrl() + username
			}
		},
		StartChatViewLayout: JST['app/templates/home/start_chat.hbs'],
		render: function() {

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			$(".start-chat-block").html(this.StartChatViewLayout({ "isLoggedIn" : Utils.isLoggedIn(), userType : userType }));
			setTimeout(function(){$('.parallax').parallax();},100);

		}
	});

	StartChatView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	StartChatView.prototype.clean = function() {
		this.remove() ;
	};

	return StartChatView;
});
