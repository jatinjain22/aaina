define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/bloggerModel',
	'utils'
], function($,_, Backbone, JST, BloggerModel, Utils) {

	var ArticlesView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new BloggerModel();
			this.model.url = this.model.getArticlesUrl(4);
		},
		events: {},
		ArticlesViewLayout : JST['app/templates/home/articles.hbs'],
		render: function() {

			this.$el.find(".art-block").html( this.ArticlesViewLayout() );
			this.$el.find(".art-block").find(".card-preloader").removeClass("hide");

			var self = this;
			//dst-list
			this.model.fetch({
				success : function(response){

					_.each(response.attributes.posts, function(post){
						
						var postDate = post.date ;
						postDate = postDate.replace(/-/g,"/") ;

						var time = "<span class='time-tag'> ~" + Utils.getDateDiff(postDate)+"</span>";
						var url = post.url;
						var title = post.title;
						var list = "<li class='ccl'><a href='"+url+"' target='_blank'>"+title+time+"</a></li>";
						self.$el.find(".art-block").find(".dst-list").append( list );
					});
					self.$el.find(".art-block").find(".card-preloader").addClass("hide");
				},
				error : function(error){
					console.log(error) ;
				}
			}) ;
		}
	});

	ArticlesView.prototype.remove = function() {

	};

	ArticlesView.prototype.clean = function() {

	};

	return ArticlesView;
});
