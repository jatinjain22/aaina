define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/ajaxModel'
], function($,_, Backbone, JST, Utils, AjaxModel) {

	var FaqsView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new AjaxModel();
			this.model.url = Utils.contextPath()+'/faq?limit=4';
		},
		events: {},
		FaqsViewLayout: JST['app/templates/home/faqs.hbs'],
		render: function() {

			this.$el.find(".faq-block").html( this.FaqsViewLayout() );

			this.$el.find(".faq-block").find(".card-preloader").removeClass("hide");

			var self = this;
			this.model.fetch({
				success : function(response){

					_.each(response.attributes, function(post){

        				var list = "<li class='faq-list-li' data-fid='"+post.id+"'><a href='#faq/"+post.id+"'>"+post.question+"</a></li>";
        				self.$el.find(".faq-block").find(".faq-list").append( list );
					});

					self.$el.find(".faq-block").find(".card-preloader").addClass("hide");
				},
				error : function(error){
					console.log(error) ;
				}
			});
		}
	});

	FaqsView.prototype.remove = function() {

	};

	FaqsView.prototype.clean = function() {

	};

	return FaqsView;
});
