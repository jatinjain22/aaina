define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function($,_, Backbone, JST, Utils) {

	var BeSaviorView = Backbone.View.extend({

		el: "main",
		initialize: function() {},
		events: {
			'click #be-savior-modal .popup-close'  : 'hideContainer' ,
			'submit #be-savior-form' : 'saveInfo' ,
		},
		checkForEmail : function(e){
			var isValidEmail = Utils.formEmailCheck($("#be-savior-email").val());
			if(!isValidEmail){
				$("#sav-email-error").html("Please enter valid email id");
				$("#sav-email-error").removeClass("hide");
				$("#be-savior-email").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-be-savior');
				return 0 ;
			}else{
				$("#sav-email-error").addClass("hide");
				$("#be-savior-email").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-be-savior');
				return 1 ;
			}
		},
		saveInfo : function(e){

			var self = this ;

			var isValidEmail = this.checkForEmail() ;				
			if( isValidEmail == 0 ){
				return false;
			}

			var email = $("#be-savior-email").val() ;

			var emailRegex = new RegExp("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$") ;

			if($("#form-error-be-savior-email"  ).length == 0){
				$("#be-savior-email").after("<span id='form-error-be-savior-email'  class='margin0 form-error red-text'></span>");
			}

			if(email.length == 0 || !email.match(emailRegex)){
				$("#form-error-be-savior-email" ).html("Please give a valid email id") ;
				return 0 ;
			}


			var dataToSend = { "email" : email } ;

			$.ajax({
				url : Utils.contextPath() + "/saviour",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend)
			}).done(function(){
				self.$el.find("#be-savior-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for sharing, I am sure together we will be able to help our friend.</p>') ;
				self.$el.find("#be-savior-modal .fixed-position-container").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for sharing, I am sure together we will be able to help our friend.</p>') ;
				if(self.$el.find("#be-savior-modal .modal-content").length){
					Utils.openPopup( "be-savior-modal" ) ;
					$("#be-savior-modal.modal").css("max-height", "38%");
				}

			});
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "be-savior-modal"  );
		},
		BeSaviorViewLayout:JST['app/templates/home/be_savior.hbs'],
		render: function() {
			this.$el.find("#popup-block").html( this.BeSaviorViewLayout() );
			Utils.openPopup( "be-savior-modal" ) ;
			$("#be-savior-email").focus() ;
			var self = this ;
			$("#be-savior-email").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;

		}
	});

	BeSaviorView.prototype.remove = function() {

	};

	BeSaviorView.prototype.clean = function() {

	};

	return BeSaviorView;
});
