define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/bloggerModel',
	'utils'
], function($,_, Backbone, JST, BloggerModel, Utils) {

	var DestressingTechniquesView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new BloggerModel();
			this.model.url = this.model.getDestressingUrl(5);
		},
		events: {},
		DestressingTechniquesViewLayout: JST['app/templates/home/destressing_techniques.hbs'],
		render: function() {

			this.$el.find(".dt-block").html( this.DestressingTechniquesViewLayout() );
			this.$el.find(".dt-block").find(".card-preloader").removeClass("hide");

			var self = this;
			//dst-list
			this.model.fetch({
				success : function(response){
					_.each(response.attributes.items, function(post){
						var time = "<span class='time-tag'> ~" + Utils.getDateDiff(post.published)+"</span>";
						var url = post.url;
						var title = post.title;
						var list = "<li class='ccl'><a href='"+url+"' target='_blank'>"+title+time+"</a></li>";
						self.$el.find(".dt-block").find(".dst-list").append( list );
					});
					self.$el.find(".dt-block").find(".card-preloader").addClass("hide");
				},
				error : function(error){
					console.log(error) ;
				}
			}) ;
		}
	});

	DestressingTechniquesView.prototype.remove = function() {

	};

	DestressingTechniquesView.prototype.clean = function() {

	};

	return DestressingTechniquesView;
});
