define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/testimonials'
], function($,_, Backbone, JST, TestimonialModel ) {

	var UserReviewView = Backbone.View.extend({

		el: "#user-review-block",
		initialize: function() {
			this.model = new TestimonialModel();
		},
		events: {},
		UserReviewViewLayout:JST['app/templates/home/user_review.hbs'],
		render: function() {

			$("#user-review-block").html(this.UserReviewViewLayout());

			var self = this ;

			this.model.fetch({
				success : function(response){

					_.each(response.attributes, function(result){
						var list = "<li class='go-to-testimonials cpointer'><div class='pfont tfirst'>"+result.testimonial+"</div><div class='sfont center tsecond'>"+result.userDescription+"</div></li>";
						$("#user-review-block").find(".testimonial-slides").append( list );
						return true;
					});
					$('.testimonial-slide').slider({full_width: true,height:120,interval:12000});
				},
				error : function(error){
					console.log(error) ;
				}
			});
		}
	});

	UserReviewView.prototype.remove = function() {

	};

	UserReviewView.prototype.clean = function() {

	};

	return UserReviewView;
});
