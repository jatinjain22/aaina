define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/ajaxModel',
	'event/dispatcher',
], function($,_, Backbone, JST, Utils, AjaxModel, Dispatcher) {

	var PopularDiscussionsView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new AjaxModel();
			this.model.url = Utils.contextPath()+'/discussion/top?limit=5';
			this.discussion_url = Utils.discussionUrl() + "/t/";
		},
		events: {
			'click #discussion-card-popular' : 'discussionRedirect'
		},
		discussionRedirect : function(){
			Dispatcher.trigger("redirectToDiscussion") ;
		},
		PopularDiscussionsViewLayout: JST['app/templates/home/popular_discussions.hbs'],
		render: function() {

			this.$el.find("#discussion-block").append( this.PopularDiscussionsViewLayout() );

			this.$el.find(".pd-block").find(".card-preloader").removeClass("hide");

			var self = this;

			this.model.fetch({
				success : function(response){

					var discussionPrinted = 0 ;
					_.each(response.attributes, function(post){

						var time = "<span class='time-tag'> ~" + Utils.getDateDiff(post.lastPostedAt)+"</span>";
						var url = self.discussion_url + post.id;
						var title = post.title;
						var list = "<li class='ccl'><a href='"+url+"' target='_blank'>"+title+time+"</a></li>";
						self.$el.find(".pd-block").find(".pd-list").append( list );
						discussionPrinted ++ ;
						if(discussionPrinted >= 5 ){
							return false ;
						}
					});
					self.$el.find(".pd-block").find(".card-preloader").addClass("hide");
				},
				error : function(error){
					console.log(error) ;
				}
			}) ;
		}
	});

	PopularDiscussionsView.prototype.remove = function() {

	};

	PopularDiscussionsView.prototype.clean = function() {

	};

	return PopularDiscussionsView;
});
