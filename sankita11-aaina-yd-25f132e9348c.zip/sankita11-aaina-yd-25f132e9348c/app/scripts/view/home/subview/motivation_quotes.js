define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/bloggerModel',
	'utils'
], function($,_, Backbone, JST, BloggerModel, Utils) {

	var MotivationQuotesView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new BloggerModel();
			this.model.url = this.model.getQuotesUrl();
		},
		events: {},
		MotivationQuotesViewLayout: JST['app/templates/home/motivation_quotes.hbs'],
		render: function() {

			this.$el.find(".mq-block").html( this.MotivationQuotesViewLayout() );

			var quotes = [
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote1.jpg",
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote2.jpg",
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote3.jpg",
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote4.jpg",
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote5.jpg",
			"https://d1hny4jmju3rds.cloudfront.net/cloudinary/quote6.jpg"];

			for( var i = 0; i <= 5; i++){
				var list = "<li><img src='"+quotes[i]+"' width='298px' height='100%'/></li>";
				this.$el.find(".mq-block").find(".quotes-slides").append( list );
			}
		}
	});

	MotivationQuotesView.prototype.remove = function() {

	};

	MotivationQuotesView.prototype.clean = function() {

	};

	return MotivationQuotesView;
});
