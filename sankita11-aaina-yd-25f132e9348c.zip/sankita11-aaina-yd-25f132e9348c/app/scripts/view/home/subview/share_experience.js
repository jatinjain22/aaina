define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'keystop'
], function($,_, Backbone, JST, Utils) {

	var ShareExperienceView = Backbone.View.extend({

		el: "main",
		initialize: function() {},
		events: {
			'submit #share-exp-form' : 'saveUserInfo' ,
			'click #share-experience-modal .popup-close'  : 'hideContainer' ,
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "share-experience-modal"  );
		},
		checkForName : function(e){
			var name = $("#share-experience-name").val();
			if(name.length <= 0){
				$("#exp-name-error").html("Please enter valid name");
				$("#exp-name-error").removeClass("hide");
				$("#share-experience-name").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-exp');
				return 0 ;
			}else{
				$("#exp-name-error").addClass("hide");
				$("#share-experience-name").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-exp');
				return 1 ;
			}

		},
		checkForDesc : function(e){
			var desc = $("#share-experience-story").val();
			if(desc.length <= 0){
				$("#exp-story-error").html("Please enter valid story");
				$("#exp-story-error").removeClass("hide");
				$("#share-experience-story").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-exp');
				return 0 ;
			}else{
				$("#exp-story-error").addClass("hide");
				$("#share-experience-story").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-exp');
				return 1 ;
			}

		},
		checkForEmail : function(e){
			var isValidEmail = Utils.formEmailCheck($("#share-experience-email").val());
			if(!isValidEmail){
				$("#exp-email-error").html("Please enter valid email id");
				$("#exp-email-error").removeClass("hide");
				$("#share-experience-email").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-exp');
				return 0 ;
			}else{
				$("#exp-email-error").addClass("hide");
				$("#share-experience-email").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-exp');
				return 1 ;
			}
		},
		checkForMobile : function(e){
			var isValidMobile = Utils.formMobileCheck($("#share-experience-mobile").val());
			if(!isValidMobile && $("#share-experience-mobile").val().length > 0){
				$("#exp-mobile-error").html("Please enter valid 10 digit mobile number");
				$("#exp-mobile-error").removeClass("hide");
				$("#share-experience-mobile").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-exp');
				return 0 ;
			}else{
				$("#exp-mobile-error").addClass("hide");
				$("#share-experience-mobile").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-exp');
				return 1 ;
			}
		},
		saveUserInfo : function (e) {

			var isValidName = this.checkForName() ;
			var isValidEmail = this.checkForEmail() ;
			var isValidMobile = this.checkForMobile() ;
			var isValidDesc = this.checkForDesc() ;

			if( isValidName == 0  || isValidEmail == 0 || isValidMobile == 0 || isValidDesc == 0 ){
				return false;
			}

			var self = this ;
			var dataToSend = {
				"name"   : $("#share-experience-name").val() ,
				"email"  : $("#share-experience-email").val() ,
				"mobile" : $("#share-experience-mobile").val() ,
				"description" : $("#share-experience-story").val()
			}

			$.ajax({
				url : Utils.contextPath() + "/experience",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend)
			}).done(function(response){
				self.$el.find("#share-experience-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for sharing your story. Someone from the team will soon get in touch with you</p>') ;
				self.$el.find("#share-experience-modal .fixed-position-container").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for sharing your story. Someone from the team will soon get in touch with you</p>') ;
				Utils.openPopup( "share-experience-modal" ) ;
				$("#share-experience-modal.modal").css("max-height", "38%");
			}).error(function(error){
				console.log(error) ;
			});

		},
		ShareExperienceViewLayout: JST["app/templates/home/share_experience.hbs"],
		render: function() {
			var self = this ;
			this.$el.find("#popup-block").html( this.ShareExperienceViewLayout() );
			Utils.openPopup( "share-experience-modal" ) ;
			$("#share-experience-name").focus() ;

			$("#share-experience-name").keystop( function(event){
				self.checkForName(event) ;
			}, 1000 ) ;

			$("#share-experience-story").keystop( function(event){
				self.checkForDesc(event) ;
			}, 1000 ) ;

			$("#share-experience-email").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;

			$("#share-experience-mobile").keystop( function(event){
				self.checkForMobile(event) ;
			}, 1000 ) ;

		}

	});

	ShareExperienceView.prototype.remove = function() {

	};

	ShareExperienceView.prototype.clean = function() {

	};

	return ShareExperienceView;
});
