define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'model/ajaxModel',
	'event/dispatcher',
], function($,_, Backbone, JST, Utils, AjaxModel, Dispatcher) {

	var RecentDiscussionsView = Backbone.View.extend({

		el: "main",
		initialize: function() {
			this.model = new AjaxModel();
			this.model.url = Utils.contextPath()+'/discussion/latest?limit=5';
			this.discussion_url = Utils.discussionUrl()  + "/t/" ;
		},
		events: {
			'click #discussion-card-recent' : 'discussionRedirect'
		},
		discussionRedirect : function(){
			Dispatcher.trigger("redirectToDiscussion") ;
		},
		RecentDiscussionsViewLayout: JST['app/templates/home/recent_discussions.hbs'],
		render: function() {

			this.$el.find("#discussion-block").append( this.RecentDiscussionsViewLayout() );

			this.$el.find(".rd-block").find(".card-preloader").removeClass("hide");

			var self = this;

			this.model.fetch({
				success : function(response){

					var discussionPrinted = 0 ;
					_.each(response.attributes, function(post){

						var time = "<span class='time-tag'> ~" + Utils.getDateDiff(post.lastPostedAt)+"</span>";
						var title = post.title;
						var url = self.discussion_url + post.id;
						var list = "<li class='ccl'><a href='"+url+"' target='_blank'>"+title+time+"</a></li>";
						self.$el.find(".rd-block").find(".rd-list").append( list );

						discussionPrinted ++ ;
						if(discussionPrinted >= 5 ){
							return false ;
						}
					});
					self.$el.find(".rd-block").find(".card-preloader").addClass("hide");
				},
				error : function(error){
					console.log(error) ;
				}
			}) ;
		}
	});

	RecentDiscussionsView.prototype.remove = function() {

	};

	RecentDiscussionsView.prototype.clean = function() {

	};

	return RecentDiscussionsView;
});
