define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils'
], function($,_, Backbone, JST, Utils) {

	var BecomeVolunteerView = Backbone.View.extend({

		el: "main",
		initialize: function() {},
		events: {
			'submit #become-volunteer-form' : 'saveVolunteerInfo' ,
			'click #become-volunteer-modal .popup-close'  : 'hideContainer' ,
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "become-volunteer-modal"  );
		},
		checkForName : function(e){
			var name = $("#volunteer-name").val();
			if(name.length <= 0){
				$("#vol-name-error").html("Please enter valid name");
				$("#vol-name-error").removeClass("hide");
				$("#volunteer-name").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-become-volunteer');
				document.getElementById('volunteer-name').scrollIntoView(true);
				
				return 0 ;
			}else{
				$("#vol-name-error").addClass("hide");
				Utils.formEnableSubmit('submit-become-volunteer');
				$("#volunteer-name").addClass("valid").removeClass("invalid") ;
				return 1 ;
			}

		},
		checkForEmail : function(e){
			var isValidEmail = Utils.formEmailCheck($("#volunteer-email").val());
			if(!isValidEmail){
				$("#vol-email-error").html("Please enter valid email id");
				$("#vol-email-error").removeClass("hide");
				$("#volunteer-email").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-become-volunteer');
				document.getElementById('volunteer-email').scrollIntoView(true);
				
				return 0 ;
			}else{
				$("#vol-email-error").addClass("hide");
				$("#volunteer-email").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-become-volunteer');
				return 1 ;
			}
		},
		checkForMobile : function(e){
			var isValidMobile = Utils.formMobileCheck($("#volunteer-phone").val());
			if(!isValidMobile && $("#volunteer-phone").val().length > 0){
				$("#vol-phone-error").html("Please enter valid 10 digit phone number");
				$("#vol-phone-error").removeClass("hide");
				$("#volunteer-phone").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-become-volunteer');
				document.getElementById('volunteer-phone').scrollIntoView(true);
				
				return 0 ;
			}else{
				$("#vol-phone-error").addClass("hide");
				Utils.formEnableSubmit('submit-become-volunteer');
				return 1 ;
			}
		},
		checkForDesc :  function(e){
			var description = $("#volunteer-desc").val() ;
			if( description.length == 0 ){
				$("#volunteer-desc").addClass("invalid") ;
				$("#form-error-volunteer-desc").removeClass("hide") ;
				document.getElementById('volunteer-desc').scrollIntoView(true);
				return 0;
			}else{
				if($("#volunteer-desc").hasClass("invalid"))
					$("#volunteer-desc").removeClass("invalid");
				if(! $("#form-error-volunteer-desc").hasClass("hide"))
					$("#form-error-volunteer-desc").addClass("hide") ;
				return 1;
			}
		},
		checkForReason : function  (e) {
			var reason      = $("#volunteer-reason").val() ;
			if( reason.length == 0){
				$("#volunteer-reason").addClass("invalid") ;
				$("#form-error-volunteer-reason").removeClass("hide") ;
				return 0;
			}else{
				if($("#volunteer-reason").hasClass("invalid"))
					$("#volunteer-reason").removeClass("invalid") ;
				if(! $("#form-error-volunteer-reason").hasClass("hide"))
					$("#form-error-volunteer-reason").addClass("hide") ;
				return 1;		
			}
		},
		saveVolunteerInfo : function (e) {

			var isValidDesc = this.checkForDesc();
			if(isValidDesc == 0){
				document.getElementById('volunteer-desc').scrollIntoView(true);
				return;
			}
			var isValidReason = this.checkForReason();
			if(isValidReason == 0){
				document.getElementById('volunteer-reason').scrollIntoView(true);
				return;
			}
			var isValidName = this.checkForName() ;
			var isValidEmail = this.checkForEmail() ;
			var isValidMobile = this.checkForMobile() ;
			

			if( isValidName == 0  || isValidEmail == 0 || isValidMobile == 0 ){
				return false;
			}

			var self = this ;
			var dataToSend = {
				"description": $("#volunteer-desc").val() ,
				"expertise" : $("#volunteer-expertise").val(),
				"skills" : $("#volunteer-skill-set").val(),
				"reason" : $("#volunteer-reason").val() ,
				"name" : $("#volunteer-name").val(),
				"city" : $("#volunteer-city").val(),
				"state" : $("#volunteer-state").val(),
				"email" : $("#volunteer-email").val(),
				"phone" : $("#volunteer-phone").val()
			};

			$.ajax({
				url : Utils.contextPath() + "/volunteer",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend)
			}).done(function(){
				self.$el.find("#become-volunteer-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for your interest. We will soon get in touch with you.</p>') ;
				self.$el.find("#become-volunteer-modal .fixed-position-container").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for your interest. We will soon get in touch with you.</p>') ;
				if(self.$el.find("#become-volunteer-modal .modal-content").length){
					Utils.openPopup( "become-volunteer-modal" ) ;
					$("#become-volunteer-modal.modal").css("max-height", "38%");
				}

			});

		},
		BecomeVolunteerViewLayout: JST['app/templates/home/become_volunteer.hbs'],
		render: function() {
			//this.$el.find("#popup-block").html( BecomeVolunteerViewLayout() );
			$('#become-volunteer-modal').remove() ;
			this.$el.append( this.BecomeVolunteerViewLayout() );
			Utils.openPopup( "become-volunteer-modal" ) ;
			$("#volunteer-desc").focus() ;

			var self = this ;
			$("#volunteer-desc").keystop( function(event){
				self.checkForDesc(event) ;
			}, 1000 ) ;
			$("#volunteer-reason").keystop( function(event){
				self.checkForReason(event) ;
			}, 1000 ) ;
			$("#volunteer-name").keystop( function(event){
				self.checkForName(event) ;
			}, 1000 ) ;

			$("#volunteer-email").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;

			$("#volunteer-phone").keystop( function(event){
				self.checkForMobile(event) ;
			}, 1000 ) ;

		}

	});

	BecomeVolunteerView.prototype.remove = function() {

	};

	BecomeVolunteerView.prototype.clean = function() {

	};

	return BecomeVolunteerView;
});
