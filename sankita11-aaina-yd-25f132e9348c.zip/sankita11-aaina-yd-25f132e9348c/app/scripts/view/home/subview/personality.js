define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates'
], function($,_, Backbone, JST) {

	var PersonalityView = Backbone.View.extend({

		el: "main",
		initialize: function() {},
		events: {},
		PersonalityViewLayout: JST['app/templates/home/personality.hbs'],
		render: function() {

			this.$el.find(".person-block").html( this.PersonalityViewLayout() );
		}
	});

	PersonalityView.prototype.remove = function() {

	};

	PersonalityView.prototype.clean = function() {

	};

	return PersonalityView;
});
