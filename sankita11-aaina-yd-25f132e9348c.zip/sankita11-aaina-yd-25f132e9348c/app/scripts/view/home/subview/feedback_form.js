define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'utils',
	'keystop'
], function($,_, Backbone, JST, Utils) {

	var FeedbackFormView = Backbone.View.extend({

		el: "body",
		initialize: function() {},
		events: {
			'submit #share-feedback-form' : 'saveUserInfo' ,
			'click #share-feedback-modal .popup-close'  : 'hideContainer' ,
		},
		hideContainer : function(e){
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup( "share-feedback-modal"  );
		},
		checkForName : function(e){
			var name = $("#share-feedback-name").val();
			if(name.length <= 0){
				$("#feedback-name-error").html("Please enter valid name");
				$("#feedback-name-error").removeClass("hide");
				$("#share-feedback-name").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-feedback');
				return 0 ;
			}else{
				$("#feedback-name-error").addClass("hide");
				$("#share-feedback-name").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-feedback');
				return 1 ;
			}

		},
		checkForEmail : function(e){
			var isValidEmail = Utils.formEmailCheck($("#share-feedback-email").val());
			if(!isValidEmail){
				$("#feedback-email-error").html("Please enter valid email id");
				$("#feedback-email-error").removeClass("hide");
				$("#share-feedback-email").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-feedback');
				return 0 ;
			}else{
				$("#feedback-email-error").addClass("hide");
				$("#share-feedback-email").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-feedback');
				return 1 ;
			}
		},
		checkForDesc : function(e){
			var desc = $("#share-feedback-desc").val();
			if(desc.length <= 0){
				$("#feedback-desc-error").html("Please enter valid description");
				$("#feedback-desc-error").removeClass("hide");
				$("#share-feedback-desc").addClass("invalid").removeClass("valid") ;
				Utils.formDisableSubmit('submit-share-feedback');
				return 0 ;
			}else{
				$("#feedback-desc-error").addClass("hide");
				$("#share-feedback-desc").addClass("valid").removeClass("invalid") ;
				Utils.formEnableSubmit('submit-share-feedback');
				return 1 ;
			}

		},
		saveUserInfo : function (e) {

			var isValidName = this.checkForName() ;
			var isValidEmail = this.checkForEmail() ;
			var isValidDesc = this.checkForDesc() ;

			if( isValidName == 0  || isValidEmail == 0 || isValidDesc == 0  ){
				return false;
			}

			var self = this ;
			var dataToSend = {
				"name"   : $("#share-feedback-name").val() ,
				"email"  : $("#share-feedback-email").val() ,
				"description" : $("#share-feedback-desc").val() ,
			}

			$.ajax({
				url : Utils.contextPath() + "/experience",
				method : "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
            	data : JSON.stringify(dataToSend)
			}).done(function(response){
				self.$el.find("#share-feedback-modal .modal-content").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for your feedback.</p><p class="modal-thank-msg-subtitle">Be rest assured, we read all customer feedback. We may come back to you if we need more clarification or if we have an update on your topic.</p>') ;
				self.$el.find("#share-feedback-modal .fixed-position-container").html( '<div class="popup-close col waves-effect waves-light right"><i class="small font-20 mdi-navigation-close"></i></div><p class="modal-thank-msg">Thank you for your feedback.</p><p class="modal-thank-msg-subtitle">Be rest assured, we read all customer feedback. We may come back to you if we need more clarification or if we have an update on your topic.</p>') ;
				Utils.openPopup( "share-feedback-modal" ) ;
				$("#share-feedback-modal.modal").css("max-height", "38%");
			}).error(function(error){
				console.log(error) ;
			});

		},
		FeedbackFormViewLayout: JST['app/templates/home/feedback_form.hbs'],
		render: function() {
			var self = this ;
			$("#share-feedback-modal").remove() ;

			this.$el.append( this.FeedbackFormViewLayout() );
			Utils.openPopup( "share-feedback-modal" ) ;
			$("#share-feedback-name").focus() ;

			$("#share-feedback-name").keystop( function(event){
				self.checkForName(event) ;
			}, 1000 ) ;

			$("#share-feedback-desc").keystop( function(event){
				self.checkForDesc(event) ;
			}, 1000 ) ;

			$("#share-feedback-email").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;

		}

	});

	FeedbackFormView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	FeedbackFormView.prototype.clean = function() {
		this.remove() ;
	};

	return FeedbackFormView;
});
