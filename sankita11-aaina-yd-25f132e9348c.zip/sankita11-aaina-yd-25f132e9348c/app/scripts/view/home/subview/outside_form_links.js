define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates'
], function($,_, Backbone, JST) {

	var OutsideFormLinksView = Backbone.View.extend({

		el: "main",
		initialize: function() {},
		events: {},
		OutsideFormLinksViewLayout: JST["app/templates/home/outside_form_links.hbs"],
		render: function() {

			this.$el.find("#mpage-links-block").html(
				this.OutsideFormLinksViewLayout() );
		}
	});

	OutsideFormLinksView.prototype.remove = function() {

	};

	OutsideFormLinksView.prototype.clean = function() {

	};

	return OutsideFormLinksView;
});
