define([
	'jquery',
	'underscore',
	'backbone',
	'view/home/subview/articles',
  	'view/home/subview/destressing_techniques',
  	'view/home/subview/faqs',
  	'view/home/subview/motivation_quotes',
  	'view/home/subview/outside_form_links',
  	'view/home/subview/personality',
  	'view/home/subview/popular_discussions',
  	'view/home/subview/recent_discussions',
  	'view/home/subview/start_chat',
  	'view/home/subview/user_review',
	'view/home/subview/be_savior',
	'view/home/subview/share_experience',
	'view/home/subview/become_volunteer',
	'../../precompiled-templates',
	'smooth-scroll',
	'utils'
], function($,_, Backbone, ArticlesView, DestressingTechniquesView, FaqsView, MotivationQuotesView,
	OutsideFormLinksView, PersonalityView, PopularDiscussionsView, RecentDiscussionsView, StartChatView,
	UserReviewView, BeSaviorView, ShareExperienceView, BecomeVolunteerView, JST, SmoothScroll, Utils) {

	var HomePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.startChatView = new StartChatView();
	      	this.userReviewView = new UserReviewView();
	      	this.recentDiscussionsView = new RecentDiscussionsView();
	      	this.popularDiscussionsView = new PopularDiscussionsView();
	      	this.faqsView = new FaqsView();
	      	this.motivationQuotesView = new MotivationQuotesView();
	      	this.articlesView = new ArticlesView();
	      	this.destressingTechniquesView = new DestressingTechniquesView();
	      	this.personalityView = new PersonalityView();
	      	this.outsideFormLinksView = new OutsideFormLinksView();
	      	this.beSaviorView = new BeSaviorView();
	      	this.shareExperienceView = new ShareExperienceView();
	      	this.becomeVolunteer = new BecomeVolunteerView() ;
	      	this.iInterval = null;
	      	this.iStart = 0;
	      	window.clearInterval(this.iInterval);
		},
		events: {
      		'click .smoothscroll': 'smoothScroll',
      		'click #be-savior' : 'showBeSaviorForm' ,
      		'click #share-experience' : 'showShareExperienceForm' ,
      		'click #become-volunteer' : 'showBecomeVolunteerForm',
      		'click .go-down': 'goDown',
      		"click .go-to-testimonials": "goToTestimonials"
    	},
    	goToTestimonials: function(e){
			//location.href = "/testimonials";
			Backbone.history.navigate("/testimonials", {trigger: true});
			return true;
		},
    	showBecomeVolunteerForm : function(e){
    		this.becomeVolunteer.render() ;
    		$('select').not('.disabled').material_select();
    	},
    	showShareExperienceForm : function (e) {
    		this.shareExperienceView.render();
    	},
    	showBeSaviorForm : function (e) {
    		this.beSaviorView.render() ;
    	},
		template: JST['app/templates/home/layout.hbs'],
		render: function() {

			this.$el.html(this.template());

			//anonymous user view rendering
			this.startChatView.render();

			//user review slider rendering
	      	this.userReviewView.render();

	      	//recent discussions view rendering
	      	this.recentDiscussionsView.render();
	      	this.popularDiscussionsView.render();

	      	//faq , motivational quotes slider, articles view
	      	this.faqsView.render();
	      	this.motivationQuotesView.render();
	      	this.articlesView.render();

	      	//destressing techniques views
	      	this.destressingTechniquesView.render();
	      	this.personalityView.render();

	      	//survey monkey form links
	      	this.outsideFormLinksView.render();

	      	var self = this;

	      	if( self.iInterval ){
	      		self.iInterval = null;
	      		self.iStart = 0;
	      		window.clearInterval(self.iInterval);
	      	}

	      	var imgs = [
	      	"https://d1hny4jmju3rds.cloudfront.net/cloudinary/dream1.ppg",
	      	"https://d1hny4jmju3rds.cloudfront.net/cloudinary/dream2.jpg",
	      	"https://d1hny4jmju3rds.cloudfront.net/cloudinary/dream3.jpg"];

	      	self.iInterval = window.setInterval(function(){

	      		$(".start-chat-block").find(".home-images").css("background-image","url('"+imgs[self.iStart]+"')").addClass("home-trans");

	      		setTimeout(function(){
	      			$(".start-chat-block").find(".home-images").removeClass("home-trans");
	      		},5000);

	      		self.iStart++;

	      		if( self.iStart > 2 ){
	      			self.iStart = 0;
	      		}
	      	},10000);

	      	setTimeout(function(){$('.motive-slider').slider();},1000);

			return this;
		},
    	smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
	    goDown: function(e){
	      $('html, body').stop().animate({
	      scrollTop: $("#discussion-block").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    }
	});

	HomePage.prototype.remove = function() {
		window.clearInterval(this.iInterval);
		this.$el.empty();
    	this.$el.off();
    	this.undelegateEvents();
    	this.stopListening();
	};

	HomePage.prototype.clean = function() {
		window.clearInterval(this.iInterval);
		this.remove() ;
	};

	return HomePage;
});
