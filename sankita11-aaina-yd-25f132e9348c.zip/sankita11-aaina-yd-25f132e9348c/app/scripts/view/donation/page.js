define([
	'jquery',
	'underscore',
	'backbone',
	'model/users',
	'event/dispatcher',
	'../../precompiled-templates',
	'utils',
	'keystop'
], function( $, _, Backbone, UserModel, Dispatcher, JST, Utils ) {
	
	var DonationPage = Backbone.View.extend({

		el: "main",
		initialize: function() {
			
			this.userModel       = new UserModel();
			_.bindAll(this);

			this.listenTo(Dispatcher, 'DonationSpreadPage', this.renderHTML);

			//$(window).scroll(this.showDonationHeadStrip);
			this.socialShareResponse = {};
			this.amount = 0;

		},
		events: {
			
			'click .close-donation-layout' : 'hideMainLayout',
			'click .close-donation-head-strip' : 'hideHeadStrip',
			'click .donation-head-donate-btn' : 'showMainLayout',
			'click .mobile-donation-head-donate-btn' : 'showMainLayout',
			'click .donation-head-spread-btn' : 'spreadTheWord',
			'click .donation-amount-span' : 'selectAmount',
			'click .donate-now-btn' : 'donateNow',
			'keyup .donation-input-amount' : 'inputDonationAmount',
			'click .donation-layout-why-donate' : 'clickedOnWhyDonate'
		},

		isInt : function (value) {

		  	return 	!isNaN(value) && parseInt(Number(value)) == value && !isNaN(parseInt(value, 10));
		},
		
		clickedOnWhyDonate : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Why Donate', {'mediumSource' : 'website', 'itemName': 'Clicked why donate Donation Strip'});
	          
	        } 
		},

		selectAmount : function(e){

			if($(e.currentTarget).hasClass("input-donation")){

				return;
			}

			$(".donation-amount-error").addClass("hide").html("")
			
			if($(e.currentTarget).hasClass("selected")){

				$(".donation-amount-span").removeClass("selected")
				$(e.currentTarget).removeClass("selected")
				this.amount = 0;
			}else{

				$(".donation-amount-span").removeClass("selected")
				$(e.currentTarget).addClass("selected")
				this.amount = $(e.currentTarget).attr("data-value");
			}

			if(this.amount == 0){

				this.amount = parseInt($(".donation-input-amount").val());
			}
		},

		inputDonationAmount : function(e){

			jQuery(".donation-amount-span").removeClass("selected")
			this.amount = 0;
			this.amount = parseInt($(".donation-input-amount").val());

			if(!this.isInt(this.amount)){

				jQuery(".donation-amount-error").removeClass("hide").html("Please select or enter amount")
				return false;
			}
			if(this.amount < 50){

				$(".donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}
			$(".donation-amount-error").addClass("hide").html("")
			this.amount = parseInt($(".donation-input-amount").val());
		},

		donateNow : function(){

			$(".donation-amount-error").addClass("hide").html("")

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Strip', {'mediumSource' : 'website', 'itemName': 'Clicked FAQ Donate Now'});
	          
	        } 

			var donationAmount = this.amount;
			console.log("Amount ",donationAmount);

			if(!donationAmount || donationAmount == 0 ){

				$(".donation-amount-error").removeClass("hide").html("Please select or enter amount")
				return false;
			}
			if(this.amount < 50){

				$(".donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}
			$(".donate-now-btn span").html("Redirecting ...")
			$(".donation-amount-error").addClass("hide").html("")

			var userID = this.userModel.getUserID() ; 

			$.ajax({
				url         : Utils.contextPath() + '/v1/user/'+ userID +'/donate/'+ donationAmount+'?source=virality',
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
			}).done(function(response){


				if( !response.error){

					location.href = response.uri;
					$(".donate-now-btn span").html("Redirecting ...")
				}else{

					$(".donate-now-btn span").html("Pay Securely")
					$(".donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
				}

			}).error(function(response){

				$(".donate-now-btn span").html("Pay Securely")
				$(".donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
			})

			// self.donationAmount(Utils.
			//(), userID, donationAmount).then(function(response) {
                        
   //              if(typeof response.error != 'undefined' && !response.error){

   //                  location.href = response.uri;
   //              }else{

			// 		$(".donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
			// 	} 

   //        	}, function(error) {

   //              console.log("Error ", error);
   //        	}); 

		},
		// donatAmountNotLoggedIn : function(loggedIn, userID, donationAmount){

		// 	return new Promise( function( resolve, reject ){

		// 		if(loggedIn){

		//         	$.ajax({
		// 				url         : Utils.contextPath() + '/v1/user/'+ userID +'/donate/'+ donationAmount,
		// 				contentType : "application/json; charset=utf-8",
		// 				xhrFields   : {
		// 			    	withCredentials: true
		// 				},
		// 			}).done(function(response){

		// 				if( !response.error){

	 //      					resolve(response);
	 //    				} else {

	 //                    	reject(false);
	 //    				}
		                	
		//             }).error( function(error) ){

	 //                	reject(false);
		//         	});

		// 		}else{


		// 		}

	 //    	});
		// },
		showDonationHeadStrip : function(e){


			$(window).scroll(function(){

				if($(window).scrollTop() > 100){

					$('.donation-sahre-div').removeClass("hide")
				}else{

					$('.donation-sahre-div').addClass("hide")
				}
			})
		},
		
		DonationPageView:JST['app/templates/donation/layout.hbs'],

		spreadTheWord : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Strip Spread', {'mediumSource' : 'website', 'itemName': 'Clicked FAQ Spread'});
	          
	        } 
			var self = this;

			var targetElement = $(".donation-head-spread-btn");
	        var loaderElement = $(".spread-the-word-loader");
	        var mixpanelEvent = "Spread The Word";

	        targetElement.addClass("hide");
	        loaderElement.removeClass("hide");
	
			self.socialShareResponse["utm_campaign"] = "spread_donationStrip"

	        Utils.shareOnFacebook( self.socialShareResponse, targetElement, loaderElement, mixpanelEvent ).then(function(response) {
	                
	           if(response){

	        		console.log("Response ---", response)
	            	self.updateUserStatusShared(targetElement);
	            	targetElement.hide();
	            	if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
		        	    mixpanel.track('Donation Strip FAQ', {'mediumSource' : 'website', 'itemName': 'Donation Strip FAQ Share Success'});
		          
		        	}
	            }else{

	            	targetElement.removeClass("hide");
	        		loaderElement.addClass("hide");

	            }
	        }, function(error) {

	            console.log("Failed!", error);
	        }); 
		},

		updateUserStatusShared : function(ele){

			if(!Utils.isLoggedIn()){

				$.cookie("shareDone", "yes", {path: '/', expires : 60})
				ele.hide();
			}else{

				var userId = this.userModel.getUserID() ; 
				var dataToSend = {
									"allowed":0,
									 "userId":userId,
									 "type":"SHARE"
								};
				$.ajax({
	                url : Utils.contextPath() + "/v2/users/"+userId+"/intrupts/status",
	                data:JSON.stringify(dataToSend),
	                method : 'POST',
					dataType: "JSON",
	                contentType: "application/json; charset=utf-8",
	          	}).done(function(response){

	          		ele.hide();

	          	}).error(function(error){

	                console.log(error)
	          	});
	        } 	
		},

		showMainLayout : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Layout Showed', {'mediumSource' : 'website', 'itemName': 'Clicked Donation Strip Donate'});
	          
	        } 

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
        	    mixpanel.track('Donation Strip FAQ', {'mediumSource' : 'website', 'itemName': 'FAQ Donation Strip Donate Button'});
          
        	}
			$('.donation-head-strip').addClass('collapsed').removeClass("expanded");
			$('.donation-layout').addClass('expanded').removeClass("collapsed");
		},
		
		hideMainLayout : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Layout Closed', {'mediumSource' : 'website', 'itemName': 'Clicked Donation Layout Close'});
	          
	        } 
			$('.donation-head-strip').addClass('expanded').removeClass("collapsed");
			$('.donation-layout').addClass('collapsed').removeClass("expanded");
		},

		hideHeadStrip : function(e){

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
	            mixpanel.track('Donation Strip Closed', {'mediumSource' : 'website', 'itemName': 'Clicked Donation Strip Close'});
	          
	        } 
			$('.donation-head-strip').addClass('hide').removeClass("expanded");

			$.cookie("donationClosed", "yes", { expires : 10, path : '/' });
		},
		renderHTML : function(){

			var self = this;

			var donateAllowed = true;
			var shareAllowed = true;
			var storyAllowed = true;

			if(!Utils.isLoggedIn() && typeof $.cookie("shareDone") == 'undefined'){

				donateAllowed = false;
				self.$el.append(self.DonationPageView({showDonate : donateAllowed, showSpread : shareAllowed, showStory : storyAllowed}));
		    	self.setElement($("main")).render();
		    }else{
		    	
		    	var userId = this.userModel.getUserID() ; 
				$.ajax({
	                url : Utils.contextPath() + "/v2/users/"+userId+"/intrupts/status",
	                method : 'GET',
	                contentType: "application/json; charset=utf-8",
	          	}).done(function(response){

	          		if(response.length == 0){

	          			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
				            mixpanel.track('Donation Strip Showed', {'mediumSource' : 'website', 'itemName': 'Donation Strip FAQ Page'});
				          
				        } 
				        if(typeof $.cookie("donationClosed") == 'undefined'){

	          				self.$el.append(self.DonationPageView({showDonate : donateAllowed, showSpread : shareAllowed, showStory : storyAllowed}));
							self.setElement($("main")).render();
						}
					}else{
						
		          		$.each(response, function(index){

		          			var intruptsObj = response[index];
		          			if(intruptsObj.type == "DONATE"){

		          				donateAllowed = intruptsObj.allowed;
		          			}else if(intruptsObj.type == "SHARE"){

		          				shareAllowed = intruptsObj.allowed;
		          			}else{

		          				storyAllowed = intruptsObj.allowed;
		          			}
		          		})

		          		if(donateAllowed && shareAllowed){

		          			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
	            
					            mixpanel.track('Donation Strip Showed', {'mediumSource' : 'website', 'itemName': 'Donation Strip FAQ Page'});
					          
					        } 
					        if(typeof $.cookie("donationClosed") == 'undefined'){

				          		self.$el.append(self.DonationPageView({showDonate : donateAllowed, showSpread : shareAllowed, showStory : storyAllowed}));
								self.setElement($("main")).render();
							}
						}
					}

	          	}).error(function(error){

	          		console.log("Error ", error)
	          	})
	        }
		},
		render: function() {	
			
			var self = this ;
			var userId = this.userModel.getUserID() ; 

			var donateAllowed = true;
			var shareAllowed = true;
			var storyAllowed = true;
			//self.$el.append(self.DonationPageView({donateAmount : donateAllowed, spreadWord : shareAllowed, storyShare : storyAllowed}));

			$.ajax({
                url : Utils.scriptPath() + "/socialShare.json",
                cache: false
          	}).done(function(response){

                var url = "donate"
                self.socialShareResponse = response[ url ];

          	}).error(function(error){
                console.log(error)
          	}); 

          	//self.showDonationHeadStrip();
		}
	});

	DonationPage.prototype.remove = function() {
		
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	DonationPage.prototype.clean = function() {
		
		this.remove();
	};

	return DonationPage;
});