define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'Swiper',
	'event/dispatcher',
	'view/homeVariation/variation2/banner',
	'view/homeVariation/promotions',
	'view/homeVariation/variation2/experts',
	'view/homeVariation/testimonials',
	'view/homeVariation/simple_ways',
	'view/homeVariation/variation1/talk_to_experts',
	'view/homeVariation/variation1/banner',
	'view/homeNew/subview/survey'

] , function( $, _, Backbone, Utils, JST, Swiper, Dispatcher, HvBanner, HvPromotions, HvExperts, HvTestimonials, SimpleWays,
			  TalkToExperts, ChatBanner, SurveyView ) {

	var homeVariationPage = Backbone.View.extend({

		el: "main",

		initialize : function(){

			this.hvBanner = new HvBanner();
			this.hvPromotions = new HvPromotions();
			this.hvExperts = new HvExperts();
			this.hvTestimonials = new HvTestimonials();
			this.simpleWays = new SimpleWays();
			this.talkToExperts = new TalkToExperts();
			this.chatBanner = new ChatBanner();
			this.surveyView = new SurveyView();
		},

		events : {


		},

		mainLayout : JST['app/templates/homeVariation/layout.hbs'],
		imageStripLayout : JST['app/templates/homeVariation/imageStrip.hbs'],

		render : function(options){

			this.$el.html(this.mainLayout());
			$(".hv-ydtext").html(this.imageStripLayout());
			//this.hvPromotions.render();
			this.hvTestimonials.render();
			this.simpleWays.render();
			this.surveyView.render();
			if (options.variation == 'v1') {
				this.talkToExperts.render();
				this.chatBanner.render();
			} else {
				this.hvBanner.render();
				this.hvExperts.render();
			}
		}

	});

	homeVariationPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	homeVariationPage.prototype.clean = function() {

		this.remove() ;
	};

	return homeVariationPage;
});
