define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../../precompiled-templates',
	'event/dispatcher',
] , function($, _, Backbone, Utils, JST, Dispatcher) {

	var HomeChatBanner = Backbone.View.extend({

		el: "main",

		initialize : function(){

		},

		events : {
			"click .chat-action" : "checkRedirection"
		},

		redirect: function (options) {
			var msg = $("#home-chat-text")[0].value;
			if (msg) {
				var homePage = {};
				homePage['chatText'] = msg;
				localStorage.setItem("homePage", JSON.stringify(homePage));
			}
			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demo', 0, "", "", "home", {"msg": msg});
		},

		checkRedirection: function () {
			Utils.convert({
				'name': 'homePageNew',
				'kpi' : 'banner_chat'
			});
			this.registerMixpanelEvents("Button Click", "ChatButton_Home_v1");
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "main_banner_v1", "", "free_chat", {
					options : {
						type: 'chat'
					},
					callback: this.redirect
				} ) ;
			}else{
				this.redirect({
					"type"	: 'chat'
				});
			}
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		layout: JST['app/templates/homeVariation/variation1/banner.hbs'],

		render : function(){
			var self = this;
			$(".hv-banner").html(this.layout({mobile: Utils.isMobileDevice()}));
		}
		
	});

	HomeChatBanner.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	HomeChatBanner.prototype.clean = function() {

		this.remove() ;
	};

	return HomeChatBanner;
});
