define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../../precompiled-templates',
	'event/dispatcher',
] , function($, _, Backbone, Utils, JST, Dispatcher) {

	var TalkToExperts = Backbone.View.extend({

		el: "main",

		initialize : function(){

		},

		events : {
			"click .content-container": "checkRedirection"
		},

		redirect: function (options) {
			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "","", "homeCat" + options.categoryID);
		},

		checkRedirection: function (evt) {
			var category = evt.currentTarget.getAttribute("data-category");
			var categoryID = evt.currentTarget.getAttribute("data-category-id");

			Utils.convert({
				'name': 'homePageNew',
				'kpi' : 'category_chat'
			});
			this.registerMixpanelEvents("Button Click", category + "_clicked_v1");
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "category_clicked_v1", category + "_clicked_v1", "free_chat", {
					options : {
						type: 'chat',
						categoryID : categoryID
					},
					callback: this.redirect
				} ) ;
			}else{
				this.redirect({
					"type"	: 'chat',
					categoryID : categoryID
				});
			}
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		layout: JST['app/templates/homeVariation/variation1/talk_to_experts.hbs'],

		render : function(){

			var self = this;

			$(".hv-talk-to-experts").html(this.layout())
		}
		
	});

	TalkToExperts.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	TalkToExperts.prototype.clean = function() {

		this.remove() ;
	};

	return TalkToExperts;
});
