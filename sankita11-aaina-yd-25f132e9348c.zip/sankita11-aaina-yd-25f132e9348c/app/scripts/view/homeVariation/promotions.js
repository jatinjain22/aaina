define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher',
] , function($, _, Backbone, Utils, JST, Dispatcher) {

	var TalkToExperts = Backbone.View.extend({

		el: "main",

		initialize : function(){

		},

		events : {
			// "click .hv-promote-action-btn" : "connectToChat"
		},
		redirect: function (options) {
			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demoCat', options.categoryID, "Fired2FiredUp HomePage_v1","Fired2FiredUp HomePage_v1", "homeCat" + options.categoryID);
		},
		connectToChat : function(){
			if (!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "Fired2FiredUp HomePage_v1",  "Fired2FiredUp HomePage_v1", "free_chat", {options : {type: 'chat',categoryID : 2},callback: this.redirect}) ;
			}else{
				this.redirect({"type"	: 'chat',categoryID : 2});
			}
		},
		registerMixpanelEvents : function( eventName, itemName, itemType){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}
		},
		layout: JST['app/templates/homeVariation/promotions.hbs'],
		render : function(){
			var self = this;
			$(".hv-promotions").html(this.layout())
		}

	});

	TalkToExperts.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	TalkToExperts.prototype.clean = function() {

		this.remove() ;
	};

	return TalkToExperts;
});
