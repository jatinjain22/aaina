define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../../precompiled-templates',
	'event/dispatcher',
] , function($, _, Backbone, Utils, JST, Dispatcher) {

	var v2Banner = Backbone.View.extend({

		el: "main",

		initialize : function(){

			this.iInterval = null;
	      	this.iStart = 0;
	      	window.clearInterval(this.iInterval);
		},

		events : {

			'click .hv-chat-now' : 'redirectTochat'
		},

		redirectTochat : function(){
			Utils.convert({
				'name': 'homePage',
				'kpi' : 'banner_chat'
			});
			this.registerMixpanelEvents("Button Click", "ChatButton_Home_v2", "Home-V2");

			if(!Utils.isLoggedIn()){
				
				Dispatcher.trigger("renderLogin", "Landing Page Variation 2", "home", "home_chat") ;
			}else{
	
				Dispatcher.trigger('chatQuickCheck', 'demo', 0, "","", "home");
			}
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		getMainText : function( url ){

			var defer = $.Deferred();

			$.ajax({

				url : url,
				method : 'GET'

			}).done( function( response ){

				defer.resolve( response );

			}).error( function( error ){

				defer.reject( error )
			})

			return defer.promise();
		},

		bannerLayout: JST['app/templates/homeVariation/variation2/banner.hbs'],

		render : function(){

			var self = this;

			$(".hv-banner").html(this.bannerLayout())

			if( self.iInterval ){

	      		self.iInterval = null;
	      		self.iStart = 0;
	      		window.clearInterval(self.iInterval);
	      	}

			this.getMainText( Utils.scriptPath() + '/hv_bannerText.json' )
			.then( function (response){

				var html ="";

				self.iInterval = window.setInterval(function(){

		      		self.iStart++;
		      		var html = '<span href="/talkItOut?category='+ response[self.iStart].category +'" class="ban-header-link" >'+response[self.iStart].text+'</span>'; 

					$('.hv-main-banner .dynamic').animate({top:"-1rem", opacity:0}, 1000, function(){
						
						$('.hv-main-banner .dynamic').css("top", "1rem");
		 				$('.hv-main-banner .dynamic').html(html);
		 				$('.hv-main-banner .dynamic').animate({top:0,opacity:1},'slow');						
					});	      		
		 		
		      		if( response.length-1 == self.iStart){

		      			self.iStart = 0;
		      		}

		      	},3000);
				
			}, function( error ){

				console.log("Error-", error);
			});
		}
		
	});

	v2Banner.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	v2Banner.prototype.clean = function() {

		this.remove() ;
	};

	return v2Banner;
});
