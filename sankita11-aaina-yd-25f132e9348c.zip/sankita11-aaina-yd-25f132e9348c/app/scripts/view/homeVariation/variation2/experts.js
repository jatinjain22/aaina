define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) { 

	var HvExpertsPage = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;
		},
		events: {
			
			'click .hv-experts-chat' : 'directToChat',
			'click .hv-experts-all' : 'directToAllExperts',
			'click .hv-experts-msg' : 'msgCounselor'
		},

		directToChat : function( evt ){
			Utils.convert({
				'name': 'homePage',
				'kpi' : 'featured_experts'
			});
			var name = $(evt.currentTarget).attr("data-name");
			var url = $(evt.currentTarget).attr("data-href");
			this.registerMixpanelEvents("Button Click", "FeaturedExpert_Chat_v2 ", "Expert-"+name);
			location.href = url;
		},

		msgCounselor : function( evt ){

			var counselorIdName = $(evt.currentTarget).attr("data-attr");

			var counselorInfo = {

				id : counselorIdName.split("_")[0] ,
				name : counselorIdName.split("_")[1] ,
			};


			var buttonDesc = $(evt.currentTarget).attr("data-desc");
			
			if(!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "quickMessage", counselorInfo ) ;
			}else{

				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorInfo.id	
					}
				});
			}
		},

		directToAllExperts : function( evt ){

			this.registerMixpanelEvents("Button Click", "ViewAllExperts_v2", "Home_v2");
			location.href = "/talkItOut"
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}
		},
		
		getCounselor : function( url ){

			var defer = $.Deferred();

			$.ajax({

				method : 'GET',
				url : url

			}).done( function( response ){

				defer.resolve(response);

			}).error( function( error ){

				defer.reject( error )
			})

			return defer.promise();
		},

		setCounselorDetails : function( data ){

			var slicedCounselors = [];
			for (var i=0; i<4; i++) {
				var item = data[i];
				if (item.id != 101) {
					slicedCounselors.push(item);
				}
			}
			slicedCounselors = slicedCounselors.slice(0,3);
			var self = this;
			var counselorsObj = [];

			var status  = self.getCounselor(Utils.contextPath() + "/v1/counselor/status");

			var reviewsList = [];
			var counselorHashList = []

			_.each( slicedCounselors, function(item){

				var counselorHash = {}
				counselorHash = item;
				counselorHashList.push(counselorHash);
				reviewsList.push(self.getCounselor(Utils.contextPath() + "/v1/counselor/rating/" + item.id));

			});

			reviewsList.push(status);

			$.when.apply($, reviewsList)
			.then(function (reviews) {

				var details = [];
				var responseArr = Array.prototype.slice.call(arguments);
				var statusObj = responseArr[responseArr.length-1];

				for( i=0; i< responseArr.length-1; i++ ){

					var statusDetails = statusObj[counselorHashList[i].id];

					if (statusDetails && statusDetails.status == "true") {
						
						counselorHashList[i]["online"] = true;
						counselorHashList[i]["chatUrl"] = statusDetails.url;
					}else{

						counselorHashList[i]["online"] = false;
					}

					counselorHashList[i]["reviewCount"] = responseArr[i].length;
				}

				console.log(counselorHashList);

				self.$el.find('.hv-experts').html(self.FeaturedExpertsViewLayout( { counselors : counselorHashList } ));
			
			}, function( error){

				console.log("Error - ", error);
			})
		},

		FeaturedExpertsViewLayout: JST['app/templates/homeVariation/variation2/experts.hbs'],
		
		fetchFeaturedExperts : function (){

			var self = this;
			var params = '';
			if(Utils.isLoggedIn()){

				params = "&user=" + self.userModel.getUserID();
			}
			var url = Utils.contextPath() + "/v1/counselor/?page_number=1"+params ;

			this.getCounselor(url)
			.then(function(response){
				
					self.setCounselorDetails(response)

			}, function( error ){

				console.log("Error - ", error);
			})
		},

		render: function() {

			var params = '';

			var self = this ;

			var url = Utils.contextPath() + "/v1/counselor"

			if( Utils.isLoggedIn() ){

				params = "?familiar=true&user=" + this.userModel.getUserID()
			}

			url = url+params;

			this.getCounselor(url)
			.then(function(response){

				if( response.length < 3 ){

					self.fetchFeaturedExperts();
				}else{
				
					self.setCounselorDetails(response)
				}

			}, function( error ){

				console.log("Error - ", error);
			})

		}
	});

	HvExpertsPage.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	HvExpertsPage.prototype.clean = function() {

		this.remove() ;
	};

	return HvExpertsPage;
});
