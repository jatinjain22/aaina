define([
	'jquery',
	'underscore',
	'backbone',
	'utils',
	'../../precompiled-templates',
	'event/dispatcher',
] , function($, _, Backbone, Utils, JST, Dispatcher) {

	var SimpleWays = Backbone.View.extend({

		el: "main",

		initialize : function(){

		},

		events : {
			"click .action": "checkRedirection",
		},

		redirect: function (options) {
			if (options.type == 'chat') Dispatcher.trigger('chatQuickCheck', 'demo', 0, "","","home");
		},

		checkRedirection: function (evt) {
			var type = evt.currentTarget.getAttribute("data-type");
			var itemName = '';

			if (type == 'chat') itemName = "ChatButton_Offerings_v1";
			if (type == 'call') itemName = "Appointment_Offerings_v1";
			if (type == 'package') itemName = "Packages_Offerings_v1";

			Utils.convert({
				'name': 'homePageNew',
				'kpi' : 'offering_' + type
			});

			this.registerMixpanelEvents("Button Click", itemName);
			if (type == 'package') {
				Backbone.history.navigate("/online-counseling-programs", {trigger: true});
				return;	
			}
			if (type == 'call') {
				Backbone.history.navigate("/bookAppointment", {trigger: true});
				return;
			}
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "", "", "free_chat", {
					options : {
						type: type
					},
					callback: this.redirect
				} ) ;
			}else{
				this.redirect({
					"type"	: type
				});
			}
		},

		registerMixpanelEvents : function( eventName, itemName, itemType){

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

				mixpanel.track(eventName, { "itemName" : itemName, "itemType" : itemType});
			}

		},

		layout: JST['app/templates/homeVariation/simple_ways.hbs'],

		render : function(){

			var self = this;

			$(".hv-connect").html(this.layout())
		}
		
	});

	SimpleWays.prototype.remove = function() {

		this.$el.empty();
    	this.$el.off();
    	this.unbind();
	};

	SimpleWays.prototype.clean = function() {

		this.remove() ;
	};

	return SimpleWays;
});
