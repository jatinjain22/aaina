define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'Swiper'
], function($,_,Backbone, JST, Dispatcher, Utils){

	var HvTestimonialsPage = Backbone.View.extend({

		el : "main",
		
		initialize : function(){

		},

		testimonialsLayout : JST['app/templates/homeVariation/testimonials.hbs'],

		render : function(){

			var self = this;

			$.ajax({
				method : "GET",
				url : '/scripts/json/user_testimonials.json',
				contentType: 'text/plain',
			}).done(function(response){

				$(".hv-testimonials").html(self.testimonialsLayout({testimonials : response}));
				
				var mySwiper = new Swiper ('.hv-testimonials-swiper', {
				    
				   	pagination: '.hv-testimonials-pagination',
	        		paginationClickable: true,
	        		autoplay: 15000,
	        		keyboardControl: true,
			        nextButton: '.swiper-button-next',
			        prevButton: '.swiper-button-prev',
				});

			}).error(function(error){
				
				console.log(error);
			});
		}
	});

	HvTestimonialsPage.prototype.remove = function() {

	    this.$el.empty();
	    this.$el.off();
	    this.unbind();
	};

	HvTestimonialsPage.prototype.clean = function() {

	    this.remove();

	};

	return HvTestimonialsPage;
});