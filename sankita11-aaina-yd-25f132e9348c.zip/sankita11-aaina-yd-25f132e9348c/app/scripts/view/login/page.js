define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/login',
    'raygun' ,
    'purl',
], function($, _, Backbone, JST, Utils, Dispatcher, jCookie, LoginStatus) {

	var LoginPage = Backbone.View.extend({
		el: "main",
		initialize: function() {

			this.model = new LoginStatus();

			var url = window.location.href ;
    		url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso') ;
			var redirectTo = $.url( url ).param('r') ;
 			if(redirectTo == undefined){
				redirectTo = "" ;
			}

            var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo;

			this.sso = sso ;
			this.redirectTo = redirectTo ;
			this.fromAction = $.url( url ).param('from') ;
			this.extraParams = $.url( url ).param('extraParams') ;
			this.fromPage    = $.url( url ).param('fromPage') ;
			this.sourceDesc  = $.url( url ).param('sourceDesc') ;

			if(this.sourceDesc == undefined){
				this.sourceDesc = "ISSUE " + window.location.href ;
			}


			if(Utils.isLoggedIn() && ( !this.sso || this.sso == undefined ) ){
				//location.href = Utils.getMessageURL(JSON.parse(localStorage.getItem("user"))) ;
				Backbone.history.navigate(Utils.getMessageURL(JSON.parse(localStorage.getItem("user"))), {trigger: true});
			}

		},
		events: {

			'click #signup-now': "openSignUpModal",
			'click #signup-now-mobile': "openSignUpModal",
			"submit .loginForm" : "login",
			'click #fb-login-button' : 'loginFacebook',
			//'click #customBtn' : 'attachSignin'
		},
		statusChangeCallback : function(response){

			var self = this ;

			if (response.status === 'connected') {

			    FB.api('/me', function(response) {
			      console.log('Successful login for: ' + response.name);
			    });

			    var base64 = "FB "+btoa( response.authResponse.userID + ":" + response.authResponse.accessToken );
        		self.loginThroughApp(base64, 'FB');

			} else if (response.status === 'not_authorized') {
			  console.log( 'Please log into this app.' );
			} else {
			  console.log( 'Please try again later. Some error occurred' );
			}
		},

		startGoogleApp : function() {
			var self = this ;
			gapi.load('auth2', function(){

				if( typeof auth2 == 'undefined'){
					auth2 = gapi.auth2.init({
						client_id: Utils.getGoogleApiId(),
					});
				}

				self.attachSignin(document.getElementById('customBtn'));
			});
		},

		attachSignin: function(element) {
		    var self = this ;

		    auth2.attachClickHandler(element, {},
		        function(googleUser) {
		        	window.googleInfo = googleUser ;
		        var gUserID = googleUser.getBasicProfile().getId();
		        var gUserEmail = googleUser.getBasicProfile().getEmail();
		        var oauthToken = "" ;
				for( var key in window.googleInfo ){
					if( typeof window.googleInfo[key].access_token != 'undefined' ) {
						oauthToken = window.googleInfo[key].access_token ;
						console.log( window.googleInfo[key].access_token )
					}
				}

		        var base64 = 'GPLUS '+btoa( gUserID+"__"+gUserEmail + ":" + oauthToken );
		        self.loginThroughApp(base64, 'GPLUS');
		        }, function(error) {
		          console.log(JSON.stringify(error, undefined, 2));
		        });
		},

		loginThroughApp : function(loginHeader, src){

			var self = this ;

			$("#login").hide() ;
			$("#login-progress").show() ;
			$("#signup-now").addClass("disabled") ;
			$("#signup-now-mobile").addClass("disabled") ;


			var loginUrl = Utils.contextPath() + "/auth/login";

 			var source = "website";

			if(this.sso != undefined ){

				loginUrl = loginUrl + "?sso=" + this.sso ; 
				source = "FORUM";
			}else{

				loginUrl = loginUrl ;
			}

			$.ajax({
                type: 'POST',
                url: loginUrl,
                dataType: "JSON",
                data: JSON.stringify({"shouldGenerateCookie": true,"ipSession": false}),
                contentType: "application/json; charset=utf-8",
                xhrFields: {
     				withCredentials: true
			    },
			    beforeSend :function(xhr){
			    	xhr.setRequestHeader( "Authorization", loginHeader );
			    },
			    statusCode:{
			    	417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

			    		$(".login-error").removeClass("hide") ;
			    		$(".login-error").html(errorMessage) ;
			    		$("#login").show() ;
						$("#login-progress").hide() ;
						$("#signup-now").removeClass("disabled");
						$("#signup-now-mobile").removeClass("disabled");
			    	},
			    },
            }).done(function(userInfo) {
				$(".login-error").addClass("hide") ;

				var data = userInfo.user ;
				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : data ,
					});
					//mixpanel.identify(data.id);
					var distinct_id = mixpanel.get_distinct_id();
					var method = "";

					if(data.lastLogin == "null"){

						method = "SIGNUP";
						mixpanel.alias(data.id, distinct_id);

					}else{

						var timediff = Math.abs(data.lastLogin - data.registrationDate);

						if(timediff/60000 < 5){

							method = "SIGNUP";
							mixpanel.alias(data.id, distinct_id);
						}else{
							
							method = "LOGIN";
							mixpanel.identify(data.id);
						}
					}

					if(method == "SIGNUP"){
						if (  ( typeof fbq != 'undefined' ) ){
							fbq('track', 'CompleteRegistration');
						}

						if( typeof ga != 'undefined'){
							ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
						}
					}

					mixpanel.track(method, {'type' : src, 'mediumSource' : 'website', 'itemName' : self.sourceDesc, 'itemMedium' : src  });

					mixpanel.people.set({
	    			'username': data.username,
	    			'name' : data.username ,
	    			'$email': data.email,
	    			'id' : data.id,
	    			'src' : src,
 	    			'userType' : data["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				self.model.save(data) ;

				if( userInfo.uri ){

					Backbone.history.loadUrl(userInfo.uri, {trigger: true});
				}else{
					
					$.ajax({
						url : Utils.contextPath() + "/v1/user/transaction/pending/" + data.id
					}).done(function(response){
						if(response > 0){
							//location.href = "/paymentPending?id=" + response ;
							Backbone.history.navigate("/paymentPending?id=" + response, {trigger: true});
						}else{
							if( data.uri ){
								location.href = data.uri ;
								//Backbone.history.navigate(data.uri, {trigger: true});
							}else{
								console.log(self.redirectTo) ;
								if(self.fromAction == 'home_chat'){
								location.href = Utils.chatUrl() + data.username;
								}else if(self.fromAction == 'counselorChat'){
									var chatUrl = self.extraParams + "&username=" + data.username ;
									location.href = chatUrl ;
								}else if(self.fromAction == 'message'){
									//location.href = "/talkItOut?from=message&counselorID=" + self.extraParams ;
									Backbone.history.navigate("/talkItOut?from=message&counselorID=" + self.extraParams, {trigger: true});
								}else if(self.fromAction == 'book_appointment'){
									//location.href = "/bookAppointment" ;
									Backbone.history.navigate("/bookAppointment", {trigger: true});
								}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
									location.href = self.extredirectTo;
								}else if(self.redirectTo != undefined ){
									//location.href = "/" + self.redirectTo ;
									Backbone.history.navigate("/" + self.redirectTo, {trigger: true});
									localStorage.setItem("fromChat", 0) ;
								}else{
									//location.href = Utils.getMessageURL(data);
									Backbone.history.navigate(Utils.getMessageURL(data), {trigger: true});
									localStorage.setItem("fromChat", 0) ;
								}
							}
						}
					}).error(function(error){
						console.log(error)
					})
				}


            }).error(function(error){
  				console.log(error) ;
  				$("#login").show() ;
				$("#login-progress").hide();
  				$("#signup-now").removeClass("disabled");
				$("#signup-now-mobile").removeClass("disabled");
  			});
		},
		loginFacebook : function(e){

			e.preventDefault();
			var self = this ;

			if( FB.getUserID() && FB.getUserID() != "" ){

				FB.getLoginStatus(function(response) {
console.log(response) ;
					if(response.status != "connected"){
						FB.login(function(response){
							self.statusChangeCallback(response);
						},{scope: 'public_profile,email'});
					}else{
						self.statusChangeCallback(response);
					}

				});
			}else{

				FB.login(function(response){
					self.statusChangeCallback(response);
				},{scope: 'public_profile,email'});
			}
		},
		login: function(e){

			var self = this ;

        	var username = $(".loginForm #username").val().trim();
			var pwd = $(".loginForm #password").val();

			$("#login").hide() ;
			$("#login-progress").show() ;
			$("#signup-now").addClass("disabled") ;
			$("#signup-now-mobile").addClass("disabled") ;

			var loginUrl = Utils.contextPath()+"/v2/users/login" ;
			if(this.sso != undefined ){
				loginUrl = loginUrl + "?sso=" + this.sso ;
			}else{
				loginUrl = loginUrl ;
			}

			$.ajax({
				type: "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
    			url: loginUrl ,
    			xhrFields: {
     				withCredentials: true
			    },

			   beforeSend :function(xhr){
			    	xhr.setRequestHeader( "Authorization", "Basic "+ btoa(username + ":" + pwd) );
			    },

			    statusCode:{
			    	401 : function(response){

			    		var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						if(errorType == "BLOCKED"){
							$(".login-error").html("We have noticed some unusual activites from this account. Please <a href='mailto:customersupport@yourdost.com'>contact us</a> to learn more. ");
						}else{
							$(".login-error").html("The username and password do not match");
						}

			    		$(".login-error").removeClass("hide") ;
			    		$("#login").show() ;
						$("#login-progress").hide() ;
						$("#signup-now").removeClass("disabled");
						$("#signup-now-mobile").removeClass("disabled");
			    	},
			    },
    			data:JSON.stringify({"shouldGenerateCookie": true,"ipSession": false})
			}).done(function( data, status, xhr ) {

				$(".login-error").addClass("hide") ;
				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : data ,
					});

					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.identify(data.id);
					mixpanel.track('LOGIN', {'type' : 'NORMAL', 'mediumSource' : 'website', 'itemName' : self.sourceDesc, 'itemMedium' : 'NORMAL'  });
					mixpanel.people.set({
	    			'username': data.username,
	    			'name' : data.username ,
	    			'$email': data.email,
	    			'id' : data.id,
 	    			'userType' : data["loggableUser"]["userType"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				self.model.save(data) ;

				$.ajax({
					url : Utils.contextPath() + "/v1/user/transaction/pending/" + data.id
				}).done(function(response){
					if(response > 0){
						//location.href = "/paymentPending?id=" + response ;
						Backbone.history.navigate("/paymentPending?id=" + response, {trigger: true});
					}else{
						if( data.uri ){
							location.href = data.uri ;
							// Backbone.history.navigate(data.uri, {trigger: true});

						}else{
							console.log(self.redirectTo) ;
							if(self.fromAction == 'home_chat'){
							location.href = Utils.chatUrl() + data.username;
							}else if(self.fromAction == 'counselorChat'){
								var chatUrl = self.extraParams + "&username=" + data.username ;
								location.href = chatUrl ;
							}else if(self.fromAction == 'message'){
								//location.href = "/talkItOut?from=message&counselorID=" + self.extraParams ;
								Backbone.history.navigate("/talkItOut?from=message&counselorID=" + self.extraParams, {trigger: true});
							}else if(self.fromAction == 'book_appointment'){
								//location.href = "/bookAppointment" ;
								Backbone.history.navigate("/bookAppointment", {trigger: true});
							}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){
								Backbone.history.navigate(self.extredirectTo,{trigger:true});
							}else if(self.redirectTo != undefined ){
								//location.href = "/" + self.redirectTo ;
								Backbone.history.navigate("/" + self.redirectTo, {trigger: true});
								localStorage.setItem("fromChat", 0) ;
							}else{
								//location.href = Utils.getMessageURL(data);
								Backbone.history.navigate(Utils.getMessageURL(data), {trigger: true});
								localStorage.setItem("fromChat", 0) ;
							}
						}
					}
				}).error(function(error){
					console.log(error)
				})

  			}).error(function(error){
  				console.log(error) ;
  				$("#login").show() ;
				$("#login-progress").hide();
  				$("#signup-now").removeClass("disabled");
				$("#signup-now-mobile").removeClass("disabled");
  			});
		},
		openSignUpModal: function(){

			if(this.sso){
				Dispatcher.trigger("renderLogin", "click SIGNUP Login Page", "login", "discussions") ;
			}else{
				Dispatcher.trigger("renderLogin", "click SIGNUP Login Page", "login", "") ;
			}
		},
	    LoginPageLayout : JST["app/templates/login/layout.hbs"],
		render: function() {

			if(Backbone.history.getFragment() == 'login'){

				document.title="Login|YourDOST";
				$('meta[name=description]').attr('content', "Login to YourDOST and chat with psychologists and career experts");
				$('meta[name=title]').attr('content',"Login|YourDOST");
				$('meta[property="og:description"]').attr('content', "Login to YourDOST and chat with psychologists and career experts");
				$('meta[property="og:title"]').attr('content',"Login|YourDOST");
			    $('link[rel="canonical"]').attr('href', 'https://yourdost.com/login');
			

			}else{

				document.title="Online Counselling & Emotional Wellness Coach | YourDOST";
				$('meta[name=description]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
				$('meta[name=title]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
				$('meta[property="og:description"]').attr('content', "Chat Online anonymously with career, relationship, parenting counselors, psychologists for advice on self improvement & relieving stress, anxiety & depression");
				$('meta[property="og:title"]').attr('content',"Online Counselling & Emotional Wellness Coach | YourDOST");
			}

			var self = this ;
			if(this.sso){

				$.ajax({
					method : "GET" ,
					url : Utils.contextPath()+"/v2/users/login?sso=" + this.sso ,
 					statusCode:{
			    	401 : function(){

						self.$el.html(self.LoginPageLayout({}));
						$(".loginForm h5").html("Log in to participate in the discussion");
						$('body').animate({ scrollTop: 0 }, 0);

						$(".parallax-container").css("min-height","100vh");
    					$("#username").focus();
    					$('.login-modal-input label[username]').addClass('active');
    					$('.login-modal-input i').addClass('active');
    					self.startGoogleApp();
			    	},
			    	},
				}).done(function(response){
					if(response.uri){
						location.href = response.uri ;
						//Backbone.history.navigate(response.uri, {trigger: true});
					}else{
						//location.href = Utils.getMessageURL(response);
						Backbone.history.navigate(Utils.getMessageURL(response), {trigger: true});
					}

				}).error(function(error){

				});

			}else{
				self.$el.html(self.LoginPageLayout({}));

				self.startGoogleApp();

      			var fbRootLength = $("#fb-root div");
    			console.log("fbroot length " + fbRootLength.length);

				$('body').animate({ scrollTop: 0 }, 0);

    			$(".parallax-container").css("min-height","100vh");
    			$("#username").focus();
    			$('.login-modal-input label[username]').addClass('active');
    					$('.login-modal-input i').addClass('active');

			}
			setTimeout(function(){$(".m-login").remove();$(".side-login-btn").remove();},10);
		},
	});

	LoginPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	LoginPage.prototype.clean = function() {
		this.remove();
	};

	return LoginPage;
});
