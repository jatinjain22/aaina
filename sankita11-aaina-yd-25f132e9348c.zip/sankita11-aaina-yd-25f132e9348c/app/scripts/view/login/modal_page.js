define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
    'event/dispatcher',
    'jCookie',
    'model/users',
    // 'view/homeNew/page',
    'raygun' ,
    'purl',
], function( $, _, Backbone, JST, Utils, Dispatcher, jCookie, LoginStatus ) {

	var LoginModalPage = Backbone.View.extend({
		el: "body",
		initialize: function() {

			this.model = new LoginStatus();

			var url = window.location.href ;
    		url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso') ;
			var redirectTo = $.url( url ).param('r') ;

            var extredirectTo = $.url( url ).param( 'er' );
            this.extredirectTo = extredirectTo;

			this.sso = sso ;
			this.redirectTo = redirectTo ;
			this.sourceDesc  = '' ;
			this.fromAction  = '' ;
			this.extraParams = '' ;
			this.fromPage    = '' ;
			this.buttonDesc  = '' ;

			_.bindAll(this)
			this.listenTo(Dispatcher, 'renderLogin', this.renderHTML);
			this.listenTo(Dispatcher, 'renderLoginToDiv', this.renderHTMLToDiv);

			this.validateJSON = {
				"fields" : {
					"signupUsername" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z][a-zA-Z0-9-]+$",
						"minLength" : 6 ,
						"messages" : {
							"required" : "Please enter a valid username" ,
							"regexp"   : "Username must start with an alphabet. Special characters are not allowed",
							"minLength": "Username must be minimum 6 characters"
						}
					},
					"postSignupUsername" : {
						"required" : true ,
						"regexp" : "^[a-zA-Z][a-zA-Z0-9]+$",
						"minLength" : 4 ,
						"messages" : {
							"required" : "Please enter a valid username" ,
							"regexp"   : "Username must start with an alphabet. Special characters are not allowed",
							"minLength": "Username must be minimum 4 characters"
						}
					},
					"signupEmail" : {
						//"required" : true ,
						"regexp" : "^[a-zA-Z0-9-_+.]+@[a-zA-Z0-9-_.]+\\.[a-zA-Z]+$",
						"messages" : {
							"required" : "Please enter a valid email id" ,
							"regexp"   : "Please enter a valid email id"
						}
					},
					"signupPassword" : {
						"required" : true ,
						"minLength" : 6,
						"regexp":"/\s/g",
						//"regexp" : "^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$",
						"messages" : {
							"required"    : "Please enter a valid password" ,
							//"regexp"      : "Password must contain atleast 8 characters, an Alphabet, 1 Number and 1 Special Character (!,@,#,$,&,*,_,-)"
							"regexp"      : "Password should not have whitespaces in between",
							"minLength": "Password must be minimum 6 characters"
						}

					},
				}
			}

		},
		events: {

			//"submit .modalLoginForm" : "modalLogin",
			// 'submit .modal-signupform' : 'modalSignup',
			'click .modal-login-btn' : 'modalLogin',
			'click .modal-signup-btn' : 'modalSignup',
			'click #fb-login-button' : 'loginFacebook',
			'click #modalCustomBtn' : 'trackGoogle',
			//'click .openSignupLoginModal' : 'openSignUpModal',
			'click .login-modal-close' : 'hideLoginModal',
			'click .opensignupmodal' : 'chnageToSignup',
			'click .openLoginModal' : 'changeToLogin',
			'focusout #signupEmail' : 'checkForEmail',
			'keyup #username' : 'removeUserNameErrorMsg',
			'keyup #password' : 'removePasswordErrorMsg',
			'click .gotoForgotpassword' : 'gotToForgotPassword',
			'click #show_avatar' : 'showAvatar',
			'click #social_signup_add_promocode' : 'addPromotion',
			'click #social_signup_skip' : 'proceedToHomePage',
			'click #skip_change_avatar' : 'showProfileUpdate',
			'click #change_picture' : 'changePicture',
			'click img.avatar-img-post-signup' : 'selectPicture',
			'click #signup_add_promocode' : 'signupAddPromotion',
			'click #update_profile' : "updateProfile",
			'change #tos-check' : 'checkForTerms',
			'click #tos-redirect' : 'tosRedirect' ,


			//'click #customBtn' : 'attachSignin'
		},
		/*
		downloadEbookCall: function( postId, email ) {

			var emailJSON = {
				"email": email
			};

    		$.ajax({
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + "/ebook/" +postId,
				data: JSON.stringify(emailJSON),
				contentType: "application/json; charset=utf-8",
			}).done(function( response ) {
				// console.log( "hello world" );
				console.log( response );
				Utils.displaySuccessMsg("Thank you. The eBook download link has been sent to your email id");
				setTimeout( function(){
					location.href = "#user/messages";
				}, 3000)

			});

    	},
    	*/
    	removePasswordErrorMsg : function(e){

    		var pswd = $("#password").val();
    		if(pswd != ''){

    			$("#password-form-error").addClass("hide");
    		}
    	},

    	removeUserNameErrorMsg : function(e){

    		var uname = $("#username").val();
    		if(uname != ''){

    			$("#username-form-error").addClass("hide");
    		}
    	},

    	trackGoogle: function () {
    		if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ) mixpanel.track("Button Click", { "itemName" : '#gplus-login-button' });
    	},

    	tosRedirect : function(e){
			// this.hideSignUp() ;
			//location.href = "/termsOfService" ;
			// Backbone.history.navigate("/termsOfService", {trigger: true});
			window.open(
  				'/termsOfService',
  				'_blank' // <- This is what makes it open in a new window.
			);

			e.preventDefault();

		},
		hideSignUp : function(e){
			console.log("hide signup");
			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('signup');
			$("#lean-overlay").remove();
			$('#signup').remove() ;
		},
    	checkForTerms : function(e){

    		if($("#tos-check").is(":checked")){

    			this.enableSubmit("tos-check")
    		}else{

    			this.disableSubmit("tos-check")
    			this.checkForAllFields();
    		}
    	},
    	downloadEbookCall: function( postId, categoryId, successMsg, email ) {

    		var emailJSON = {
				"email": email
			}
			console.log ( postId );
    		$.ajax({
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)
			}).done(function( response ) {
				console.log( response );

				Backbone.history.navigate("/talkItOut?from=showAllExperts&category=", {trigger: true});
				if (categoryId == 100) {
        			Backbone.history.navigate("/talkItOut?from=showAllExperts", {trigger: true});
        		}else {
        			Backbone.history.navigate("/talkItOut?from=showAllExperts&category="+ categoryId, {trigger: true});


        		}
        		Utils.displaySuccessMsgWithDelay(successMsg, 8000);

			});

    	},
    	checkForTerms : function(e){

    		if($("#tos-check").is(":checked")){

    			this.enableSubmit("tos-check")
    		}else{

    			this.disableSubmit("tos-check")
    			this.checkForAllFields();
    		}
    	},
		sendCareerMessage: function(data, isPending) {

			var self = this;
			var msgJSON = {
              "threadID":0,
              "subject":'Career Message',
              "content": self.extraParams,
              "recipients": ['101'],
              "categoryIds": ['1']
            };

            $.ajax({
                method: "POST",
                url: Utils.contextPath()+'/v1/users/'+data.id+'/messages',
                data: JSON.stringify(msgJSON),
                contentType: "application/json",
                statusCode : {
                  417 : function(response){

                  var responseText = response.responseText;
                  var responseJson = JSON.parse(responseText) ;

                  var errorMessage = responseJson.message ;
                  var errorType    = responseJson.type ;

                  $(".iauthentication-error").html(errorMessage);
                  $(".iauthentication-error").show() ;

                  },
                  500 : function(){
                    $(".iauthentication-error").html("Something went wrong. Please try again");
                    $(".iauthentication-error").show() ;
                  },

                }
                }).done(function(response){

                  console.log( "successfull" );
                  //end modal
                  setTimeout( function() {

                  	if ( isPending ) {
                  		//location.href = "#sessions";
                  		Backbone.history.navigate("/sessions", {trigger: true});
                  	}
                  	else {
                  		//location.href = "#welcome";
                  		Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor&sendMessage=true", {trigger: true});
                  	}

                  	location.reload(); }, 2000);
                  return true;
                }).fail(function(error){
                  console.log(error);
                  $("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
              });

		},
		changeToLogin : function(e){

			$("#login-modal").css({"top" : "11%"})
			$('.signup-modal-footer').addClass("hide");
			$('.login-modal-footer').removeClass("hide");
			$('.signupForm').addClass("hide")
			$('.modalLoginForm').removeClass("hide")
			$(".signup-modal-header-div").addClass("hide");
			$(".login-modal-header-div").removeClass("hide");
			$(".login-anonimity-txt").removeClass("hide");
			$(".signup-anonimity-txt").addClass("hide");
		},
		chnageToSignup : function(e){

			$("#login-modal").css({"top" : "6%"})
			$('.signup-modal-footer').removeClass("hide");
			$('.login-modal-footer').addClass("hide");
			$('.signupForm').removeClass("hide")
			$('.modalLoginForm').addClass("hide")
			$(".login-modal-header-div").addClass("hide");
			$(".signup-modal-header-div").removeClass("hide");
			$(".signup-anonimity-txt").removeClass("hide");
			$(".login-anonimity-txt").addClass("hide");
		},
		statusChangeCallback : function(response){

			var self = this ;

			if (response.status === 'connected') {

			    FB.api('/me', function(response) {
			      console.log('Successful login for: ' + response.name);
			    });

			    var base64 = "FB "+btoa( response.authResponse.userID + ":" + response.authResponse.accessToken );
        		self.loginThroughApp(base64, 'FB');

			} else if (response.status === 'not_authorized') {
			  console.log( 'Please log into this app.' );
			} else {
			  console.log( 'Please try again later. Some error occurred' );
			}
		},

		hideLoginModal : function(e){

			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('login-modal');
			$('#login-modal').remove() ;
			console.log("Removed...")
		},
		gotToForgotPassword : function(e){

			$("body").css("overflow-y", "auto") ;
			Utils.closePopup('login-modal');
			$('#login-modal').remove() ;
			console.log("Removed...")
			//location.href = "/forgetPassword";
			Backbone.history.navigate("/forgetPassword", {trigger: true});
		},
		checkForAllFields : function(){
			var self = this;
			var username = $("input[name='signupUsername']").val();
			var password = $("input[name='signupPassword']").val().trim();
			//var confirmPassword = $("input[name='confirm_password']").val().trim();
			var email = $("input[name='signupEmail']").val();

			if( username.length <= 0 || password.length <= 0 || email.length <= 0 ){
				return 0 ;
			}



			if(!$("#tos-check").is(":checked")){
				console.log("hello check");
				return 0 ;
			}

			if($('input[name="user_identity"]:checked').attr("id") == "email-option"){
				var email = $("input[name='signupEmail']").val();
				if(email.length <=0 ){
					return 0 ;
				}
				if ( self.fromAction == "download_free_ebook" || self.fromPage=="landingPage2Message" || self.fromPage=="landingPage2" ) {
					if( email.length <= 0 ){
						return 0 ;
					}
				}

			}else{
				// var securityAnswer = $("#security-answer").val() ;
				// var securityQuestion = $("#security-question").val() ;
				// if( securityAnswer.length <= 0 || securityQuestion == undefined){
				// 	return 0 ;
				// }
			}
			return 1 ;
		},

		startGoogleAppLogin : function() {
			var self = this ;
			gapi.load('auth2', function(){

				if( typeof auth2 == 'undefined'){
					auth2 = gapi.auth2.init({
						client_id: Utils.getGoogleApiId(),
					});
				}

				self.attachGoogleSignin(document.getElementById('modalCustomBtn'));
			});
		},
		enableSubmit : function(targetName){
			$("#modal-validate-" + targetName).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-check green-text prefix'></i>")

    		//	$("#validate-icon-" + targetName ).removeClass('mdi-navigation-close red-text').addClass('mdi-navigation-check green-text');
			$("input[name='"+ targetName +"']").removeClass("invalid").addClass("valid") ;
			$("#form-error-"+ targetName).html("") ;
			$("#form-error-"+ targetName).hide() ;

			var allFieldsValid = this.checkForAllFields();


			if(!allFieldsValid){
				$("#modal-signup-btn").addClass("disabled") ;
				$("#modal-signup-btn").attr("disabled", true) ;
				return 0 ;
			}

			if($(".form-valid i").hasClass("mdi-navigation-close")){
				$("#modal-signup-btn").addClass("disabled") ;
				$("#modal-signup-btn").attr("disabled", true) ;
			}else{
				$("#modal-signup-btn").removeClass("disabled") ;
				$("#modal-signup-btn").attr("disabled", false) ;
			}
			return 1 ;
		},
		disableSubmit : function(targetName){
			$("#modal-validate-" + targetName ).html("<i id='validate-icon-"+ targetName +"' class='mdi-navigation-close red-text prefix'></i>")
    		$("input[name='"+ targetName +"']").removeClass("valid").addClass("invalid") ;
			$("#modal-signup-btn").addClass("disabled") ;
			$("#modal-signup-btn").attr("disabled", true) ;
			$("#form-error-"+ targetName).show() ;
		},
		checkForEmail : function(e){

			var self = this ;
			var email = $("#modal-signupEmail").val() ;
			console.log('hello world');
			console.log( self.fromAction );

			$("#modal-validate-signupEmail").html( this.loaderHTML()) ;
			console.log( "hello download signup");
			var emailValid = this.validateText("signupEmail");
			if( emailValid == 0 || email.trim().length==0 ) {
				console.log ("disabling email");
				this.disableSubmit( "signupEmail" );
				return 0;
			}

			// if (self.fromAction == 'download_free_ebook' || self.fromPage=="landingPage2Message" || self.fromPage=="landingpage2" ) {
			// 	// $("#modal-validate-signupEmail").html( this.loaderHTML()) ;
			// 	console.log( "hello download signup");
			// 	var emailValid = this.validateText("signupEmail");
			// 	if( emailValid == 0 || email.trim().length==0 ) {
			// 		console.log ("disabling email");
			// 		this.disableSubmit( "sigupEmail" );
			// 		return 0;
			// 	}
			// }

			if(email.trim().length == 0){
				// return 1;
			}

			if($('input[name="user_identity"]:checked').attr("id") != "email-option" ){
				// return 1 ;
			}

			// $("#modal-validate-signupEmail").html( this.loaderHTML()) ;
			// var emailValid = this.validateText("signupEmail");
			// if(emailValid == 0 ){
			// 	this.disableSubmit("signupEmail") ;
			// 	return 0 ;
			// }



			// $("#modal-validate-signupEmail").html( this.loaderHTML()) ;
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=email&item=" + encodeURIComponent(email),
				statusCode:{
            		404 : function(){
						$("#modal-validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
            			self.enableSubmit("signupEmail") ;
            		}
        		},

				}).done(function(response){

					if(response == true ){
						if($("#form-error-signupEmail" ).length == 0){
							$("input[name='signupEmail']").after("<div id='form-error-signupEmail'  class='red-text'></div>");
						}

						$("#modal-validate-signupEmail").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
						$("#form-error-signupEmail" ).html("This email already exists") ;
						$("#validate-icon-signupEmail" ).removeClass('mdi-navigation-check green-text').addClass('mdi-navigation-close red-text');
						$("input[name='signupEmail']").removeClass("valid").addClass("invalid") ;
						$("#modal-signup-btn").addClass("disabled") ;
						$("#modal-signup-btn").attr("disabled", true) ;
						$("#form-error-signupEmail").show() ;
					}

				}).error(function(){

				});

		},

		validateText :  function(targetName){
			//var targetName = $(e.currentTarget).attr("name") ;
			var fieldsToValidate = this.validateJSON["fields"][targetName] ;
			if($("#form-error-" + targetName ).length == 0){
				//$("input[name='"+ targetName +"']").before("<i id='validate-icon-"+ targetName +"' class='prefix form-valid'></i>");
				$("input[name='"+ targetName +"']").after("<div id='form-error-"+ targetName +"'  class='form-error red-text'></div>");
				$("#form-error-" + targetName ).hide() ;
			}

			var textValue = $("input[name='"+ targetName +"']").val() ;

			if(targetName == "signupUsername"){

				textValue = textValue.trim() ;
			}

			if(targetName != "signupUsername" && targetName != "signupEmail" && targetName != undefined && targetName != "postSignupUsername"){

				textValue = textValue.trim() ;
			}

			var isValid = 1 ;
			_.each( fieldsToValidate, function(value, key){

				if( key == "required" && textValue.length == 0 ){
					isValid = 0 ;
					$("#form-error-"+ targetName ).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "minLength" && textValue.length < value ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "equalsTo" &&  textValue != $("input[name='"+ value +"']").val() ){
					isValid = 0 ;
					$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
					return false ;
				}else if( key == "regexp" ){

					if (targetName == 'signupEmail') {


    					var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;

						if( !pattern.test(textValue) ){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}

					} else if(targetName == 'signupPassword'){

						var pattern = /\s/g;

						if( pattern.test(textValue) ){

							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}

					}else{
						var regex = new RegExp(value, "i");
						if(!textValue.match(regex)){
							isValid = 0 ;
							$("#form-error-"+ targetName).html(fieldsToValidate["messages"][key]) ;
							return false ;
						}
					}


				}

			});

			return isValid ;
		},
		loaderHTML : function(){

			var html =  '<div class="preloader-wrapper small active" style="width: 20px;height: 20px;">';
    			html += '<div class="spinner-layer spinner-green-only"><div class="circle-clipper left"><div class="circle"></div></div>';
    			html += '<div class="gap-patch"><div class="circle"></div></div>';
    			html += '<div class="circle-clipper right"><div class="circle"></div></div></div></div>' ;

    			return html ;

		},
		checkForPassword : function(e){
			var self = this;
			var targetName = $(e.currentTarget).attr("name") ;
			$("#modal-validate-" + $(e.currentTarget).attr("name") ).html( this.loaderHTML()) ;
			var validPassword = this.validateText( $(e.currentTarget).attr("name")) ;

			if(validPassword == 0){
				this.disableSubmit( $(e.currentTarget).attr("name")) ;
			}else{
				console.log ('check for password' );
				console.log ( self.fromAction );
				console.log ( $(e.currentTarget).attr("name") );
				// else {
				this.enableSubmit( $(e.currentTarget).attr("name")) ;
				// }
			}

			/*if( targetName == 'signupPassword' && $("input[name='confirm_password']").val().trim().length > 0 ){
				var isValid = this.validateText("confirm_password") ;
				if(!isValid){
					this.disableSubmit( "confirm_password") ;
				}else{
					this.enableSubmit( 'confirm_password' ) ;
				}
			}*/

		} ,
		checkForUsername : function(e){

			var self = this ;
			var username = $("#modal-signupUsername").val() ;

			$("#modal-validate-signupUsername").html( this.loaderHTML()) ;
			var usernameValid = this.validateText("signupUsername");
			if(usernameValid == 0 ){
				this.disableSubmit("signupUsername") ;
				return 0 ;
			}

			$("#modal-validate-signupUsername").html( this.loaderHTML()) ;

			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=username&item=" + username,
				statusCode:{
            		404 : function(){
						$("#validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-check green-text prefix'></i>")
						$("#form-error-signupUsername" ).hide() ;
            			self.enableSubmit("signupUsername") ;
            		}
        		},

				}).done(function(response){

					if(response == true ){
						if($("#form-error-signupUsername" ).length == 0){
							$("input[name='signupUsername']").after("<div id='form-error-signupUsername'  class='red-text'></div>");
						}

						$("#modal-validate-signupUsername").html("<i id='validate-icon-signupUsername' class='mdi-navigation-close red-text prefix'></i>")
						$("#form-error-signupUsername" ).html("This username already exists") ;
						$("input[name='signupUsername']").removeClass("valid").addClass("invalid") ;
						$("#modal-signup-btn").addClass("disabled") ;
						$("#modal-signup-btn").attr("disabled", true) ;
						$("#form-error-signupUsername").show() ;
					}

				}).error(function(){

				});

		},

		attachGoogleSignin: function(element) {
		    var self = this ;

		    auth2.attachClickHandler(element, {},
		        function(googleUser) {
		        	window.googleInfo = googleUser ;
		        var gUserID = googleUser.getBasicProfile().getId();
		        var gUserEmail = googleUser.getBasicProfile().getEmail();

		        var oauthToken = "" ;
				for( var key in window.googleInfo ){
					if( typeof window.googleInfo[key].access_token != 'undefined' ) {
						oauthToken = window.googleInfo[key].access_token ;
						console.log( window.googleInfo[key].access_token )
					}
				}

		        var base64 = 'GPLUS '+btoa( gUserID+"__"+gUserEmail + ":" + oauthToken );
		        self.loginThroughApp(base64, 'GPLUS');
		        }, function(error) {
		          console.log(JSON.stringify(error, undefined, 2));
		        });
		},

		loginThroughApp : function(loginHeader, src){

			var self = this ;

			$("#login").hide() ;
			$("#login-progress").show() ;
			$("#signup-now").addClass("disabled") ;
			$("#signup-now-mobile").addClass("disabled") ;
			$("#modal-signup-btn").hide();
 			$("#signup-progress").show() ;
 			var loginUrl = Utils.contextPath() + "/auth/login";

 			var source = "website";

			if(this.sso != undefined && this.sso !=""){

				loginUrl = loginUrl + "?sso=" + this.sso ;
				source = "FORUM";
			}else{

				loginUrl = loginUrl ;
			}

			$.ajax({
                type: 'POST',
                url: loginUrl,
                dataType: "JSON",
                data: JSON.stringify({"shouldGenerateCookie": true,"ipSession": false}),
                contentType: "application/json; charset=utf-8",
                xhrFields: {
     				withCredentials: true
			    },
			    beforeSend :function(xhr){
			    	xhr.setRequestHeader( "Authorization", loginHeader );
			    },
			    statusCode:{
			    	417 : function(response){

						var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

			    		$(".login-error").removeClass("hide") ;
			    		$(".login-error").html(errorMessage) ;
			    		$("#login").show() ;
						$("#login-progress").hide() ;
						$("#signup-now").removeClass("disabled");
						$("#signup-now-mobile").removeClass("disabled");
			    	},
			    },
            }).done(function(userInfo) {
				$(".login-error").addClass("hide") ;

				var data = userInfo.user ;

				var method = "";

				if(data.lastLogin == "null"){
					method = "SIGNUP"
				}else{
					var timediff = Math.abs(data.lastLogin - data.registrationDate);
					if(timediff/60000 < 5){
						method = "SIGNUP";
					}else{
						method = "LOGIN";
					}
				}

				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;

				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : data ,
						orgId : data["loggableUser"]["orgId"]
					});
					//mixpanel.identify(data.id);
					var method = "";
					var distinct_id = mixpanel.get_distinct_id();
					if(data.lastLogin == "null"){
						method = "SIGNUP";
						mixpanel.alias(data.id, distinct_id);
					}else{

						var timediff = Math.abs(data.lastLogin - data.registrationDate);

						if(timediff/60000 < 5){

							method = "SIGNUP";
							mixpanel.alias(data.id, distinct_id);
						}else{

							method = "LOGIN";
							mixpanel.identify(data.id);
						}
					}

					if(method == "SIGNUP"){
						self.trackMixpanelEventForSignupWithCoupon("Signup with coupon success");
					}
					mixpanel.track(method, {'type' : src, 'mediumSource' : 'website', 'itemName' : self.sourceDesc, 'itemMedium' : src  });


					if(method == "SIGNUP"){
						if (  ( typeof fbq != 'undefined' ) ){
							fbq('track', 'CompleteRegistration');
						}

						if( typeof ga != 'undefined'){
							ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
						}
					}


					var aquisitionParams = self.trackAquisition()
					mixpanel.people.set({
		    			'username': data.username,
		    			'name' : data.username ,
		    			'$email': data.email,
		    			'id' : data.id,
		    			'src' : 'NORMAL',
		    			'userType' : data["loggableUser"]["userType"],
						'orgId' : data["loggableUser"]["orgId"],
						'ac_medium' : aquisitionParams['ac_medium'],
						'ac_source' : aquisitionParams['ac_source'],
						'ac_content' : aquisitionParams['ac_content'],
						'ac_campaign' : aquisitionParams['ac_campaign']
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}


				window.userdata = data;

				self.model.save(data) ;

				if( userInfo.uri ){

					Backbone.history.loadUrl(userInfo.uri, {trigger: true});
				}else{

					$.ajax({
						url : Utils.contextPath() + "/v1/user/transaction/pending/" + data.id
					}).done(function(response){

						if(response > 0){
							//location.href = "/sessions" ;

							Backbone.history.navigate("/sessions", {trigger: true});
						}else{

							if( (src == "GPLUS" || src == "FB") && method == "SIGNUP"){

								if ( self.fromAction == "download_free_ebook") {

									console.log( "download ebook postid" );
									console.log( self.extraParams );
									var extraParamArray = self.extraParams;
									var postId = extraParamArray[0];
									var categoryId = extraParamArray[1];
									var successMsg = extraParamArray[2];
									var email = data.email;
									console.log( "redirecting to");

									self.downloadEbookCall( postId, categoryId, successMsg, email );

								}else if ( self.fromPage == "landingpage2" ) {

									Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});

								}else if ( self.fromAction == "show_result_post_signup" ) {

									console.log( "result "+ self.extraParams );
									Backbone.history.loadUrl(self.extraParams);
								}else if ( self.fromAction == "hideFurtherTips" ) {

									Backbone.history.navigate( self.extraParams, {trigger: true} );
								}
								else{
											// location.href = Utils.getMessageURL(data);
									// Backbone.history.navigate("/talkItOut",{trigger:true});
								    localStorage.setItem("fromChat", 0) ;
								}

								if( document.getElementById("post_signup") == null){
									self.$el.append("<div id='post_signup'></div>");
								}

								if(data.picUrl)
									var picUrl = data.picUrl ;
								if(data.avatar)
									var avatar = data.avatar;

								if(picUrl == null || picUrl == ""){
									picUrl = "images/avatar/avatar7.png";
								}

								if(avatar == null || avatar == ""){
									avatar = "avatar7";
								}
								sessionStorage.setItem("firstTimeUser" , 1 ) ;

								$("body").css("overflow-y", "auto") ;
								$('#login-modal').remove() ;
								$("#post_signup").html(self.PostSignupProfileUpdatePageLayout({username : data.username, picUrl : picUrl, avatar : avatar
									, enablePromo : enable_promo}));

								Utils.openPopup('post_signup_modal');

								$("#username_profile_update").keystop( function(event){
									self.usernameExists(event) ;
								}, 1000 ) ;

								$('#username_profile_update').bind("cut copy paste",function(e) {
			    					e.preventDefault();
			 					});
			 					/*$("#promo_code").keystop( function(event){
									self.promoCodeExists(event) ;
								}, 1000 ) ;*/
							}else{

								self.hideLoginModal();

								if( data.uri ){
									//location.href = data.uri ;
									Backbone.history.navigate(data.uri, {trigger: true});
								}else{
									console.log(self.redirectTo) ;
									if(self.fromAction == 'home_chat'){
										Dispatcher.trigger('chatQuickCheck', 'demo', 0, '', 1, self.fromPage);
										//location.href = Utils.chatUrl() + data.username;
									}
									else if (self.fromAction == "free_chat"){
										var params = self.extraParams;
										params.callback(params.options);
									}else if (self.fromAction == "ew_test" || self.fromAction == "mhq_test"){
										var params = self.extraParams;
										params.callback(params.options);
									}
									else if (self.fromAction == "buy_subscription"){
										var params = self.extraParams;
										params.callback(params.options);
									}
									else if (self.fromAction == "flames"){
										var params = self.extraParams;
										params.callback(params.options);
									}
									else if(self.fromAction == 'counselorChat'){

										var counselorChatUrl = self.extraParams ;
										var counselorUrl = counselorChatUrl.split(/BREAKBREAK/)[0];

										var counselorID = counselorChatUrl.split(/BREAKBREAK/)[1];
										Dispatcher.trigger('chatQuickCheck', 'direct', counselorID, counselorUrl,1, self.fromPage);

										//var chatUrl = counselorUrl + "&username=" + data.username ;
										//location.href = chatUrl ;
									}else if(self.fromAction == 'message'){
										//location.href = "/talkItOut?from=message&counselorID=" + self.extraParams ;
										Backbone.history.navigate("/talkItOut?from=message&counselorID=" + self.extraParams, {trigger: true});
									}else if(self.fromAction == 'book_appointment'){
										//location.href = "/bookAppointment" ;
										Backbone.history.navigate("/bookAppointment", {trigger: true});
									}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){

										location.href = self.extredirectTo;

									}else if(self.redirectTo != undefined ){
										//location.href = "/" + self.redirectTo ;
										Backbone.history.navigate("/" + self.redirectTo, {trigger: true});
										localStorage.setItem("fromChat", 0) ;
									}else{

										self.proceedToHomePage();
									}

								}
							}
						}

					}).error(function(error){
		  				console.log(error) ;
		  			});
				}
            }).error(function(error){
  				console.log(error) ;
  				$("#login").show() ;
				$("#login-progress").hide();
  				$("#signup-now").removeClass("disabled");
				$("#signup-now-mobile").removeClass("disabled");
  			});
		},
		loginFacebook : function(e){

			e.preventDefault();
			var self = this ;

			if( FB.getUserID() && FB.getUserID() != "" ){

				FB.getLoginStatus(function(response) {
					if(response.status != "connected"){
						FB.login(function(response){
							self.statusChangeCallback(response);
						},{scope: 'public_profile,email'});
					}else{
						self.statusChangeCallback(response);
					}

				});
			}else{

				FB.login(function(response){
					self.statusChangeCallback(response);
				},{scope: 'public_profile,email'});
			}
		},
		trackAquisition : function(){
			var cookieArr = document.cookie.split(";")
			var acParams = {}
			for(i = 0; i < cookieArr.length; i++){
				 if(cookieArr[i].indexOf("ac_source") > -1){
					 var cookieInfo = cookieArr[i].split("&")
					 for( var j =0 ;j < cookieInfo.length; j++){
						 var item = cookieInfo[j].trim().split('::')
						 if(item) acParams[item[0]] = item[1]
					 }
				 }
			}
			return acParams;
		},
		modalSignup : function(e){

			var self = this ;

			var isValidEmail    = this.checkForEmail();
			var isValidUsername = this.validateText("signupUsername");

			//var isValidSecurityQuestion = this.checkforSecurityQuestion(e) ;

			if(isValidUsername == 0 ){
				this.disableSubmit("signupUsername") ;
				return false ;
			}

			if( isValidEmail == 0 ){
				this.disableSubmit("signupEmail") ;
				return false ;

			}
			// if( isValidSecurityQuestion == 0 ){
			// 	this.disableSubmit("security-answer") ;
			// 	return false ;

			// }

			if($("#signup-btn").hasClass("disabled")){
				return false ;
			}

			/*if($('#signup_promo_code').css("visibility") == "visible"){
				if(!this.promoCodeExists()){
					return false;
				}
			}*/
			var currentDateTime = new Date().toISOString() ;
			var currentDate     = currentDateTime.split("T")[0] ;


 			var dataToSend = {
					"password" : $("input[name='signupPassword']").val().trim() ,
					"username" : $("input[name='signupUsername']").val().trim() ,
    				"avatar"   : "avatar7"                               ,
    				//"confirmPassword" : $("input[name='confirm_password']").val() ,
    				// "securityQuestions" : []
				} ;

			if($("input[type=radio]:checked").attr("id") != 'email-option' ){
 				// var qID     = $("#security-question").val() ;
 				// var qAnswer = $("#security-answer").val() ;

 				// dataToSend[ "securityQuestions" ] = [{
 				// 	"qID" : qID ,
 				// 	"answer" : qAnswer
 				// }] ;
 				dataToSend[ "email" ] = "";

 			}else{
 				dataToSend[ "email" ] = $("#modal-signupEmail").val();
 			}

 			dataToSend["promoCode"] = $('#signup_promo_code').val();

 			var promo_code = $('#signup_promo_code').val() ? $('#signup_promo_code').val() : "";
 			if(promo_code.trim().length > 0){
 				localStorage.setItem("promocode",promo_code);
 			}else{
 				localStorage.removeItem("promocode");
 			}

 			var data = JSON.stringify(dataToSend);

 			$("#modal-signup-btn").hide();
 			$("#signup-progress").show() ;

			var url = window.location.href ;
    		url = url.replace("/login", "" );
			var sso = $.url( url ).param('sso');
 			var loginUrl = Utils.contextPath() + "/v2/users/signup";
 			var source = "website";
			if(sso != undefined ){
				loginUrl = loginUrl + "?sso=" + sso ;
				source = "FORUM";
			}else{
				loginUrl = loginUrl ;
			}

 			$.ajax({
				method : 'POST',
				url : loginUrl,
				dataType : "json" ,
				xhrFields: {
     				 withCredentials: true
			    },
				contentType: "application/json",
				data: data,
				statusCode:{
			    	417 : function(response){

			    		var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;
						console.log( 'errorMessage From Signup' );
						console.log( errorMessage );
						console.log( 'errorType From Signup' );
						console.log( errorType );
						if ( errorType = 'EmailExists' ) {
							console.log('display email error from signup')
							$( "#form-error-signupEmail" ).css( "display", "block" );
							$( "#form-error-signupEmail" ).html("This email already exists") ;
						}
			    	},
			    },
			}).done(function(response, status, xhr){
				self.model.save(response) ;
				self.signUpProgress = 1 ;
				sessionStorage.setItem("firstTimeUser" , 1 ) ;
				window.userdata = response;
				Raygun.setUser( response.username, false, response.email, response.firstName, response.firstName, response.id ) ;
				if(self.fromAction == 'book_appointment'){
					//localStorage.setItem("fromAppointment", 1) ;
				}

				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : response,
						orgId : response["loggableUser"]["orgId"]
					});
					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.alias(response.id, distinct_id);
					mixpanel.track('SIGNUP', {'type' : 'NORMAL', 'mediumSource' : source,  'itemName' : self.buttonDesc, 'itemMedium' : 'NORMAL'  });

					if (  ( typeof fbq != 'undefined' ) ){
						fbq('track', 'CompleteRegistration');
					}

					if( typeof ga != 'undefined'){
						ga('send', 'event', { eventCategory: 'Registration', eventAction: 'website', eventLabel: 'Sign Up'});
					}

					var aquisitionParams = self.trackAquisition()
					mixpanel.people.set({
	    			'username': response.username,
	    			'name' : response.username ,
	    			'$email': response.email,
	    			'id' : response.id,
	    			'src' : 'NORMAL',
	    			'userType' : response["loggableUser"]["userType"],
					'orgId' : response["loggableUser"]["orgId"],
					'ac_medium' : aquisitionParams['ac_medium'],
					'ac_source' : aquisitionParams['ac_source'],
					'ac_content' : aquisitionParams['ac_content'],
					'ac_campaign' : aquisitionParams['ac_campaign']
					});
					mixpanel.name_tag({
						nameTag: response.username
					});

					//self.trackAquisition()
				}


				if ( self.fromPage != "landingPage2Message" ) {
					self.hideLoginModal();
				}

				if( response.uri ){
					//location.href = response.uri;
					Backbone.history.navigate(response.uri, {trigger: true});
				}else{
					console.log( self.fromPage );
					if(self.fromAction == 'book_appointment'){
						//location.href = "/bookAppointment";
						Backbone.history.navigate("/bookAppointment", {trigger: true});
					}else if(self.fromAction == "home_chat"){
						Dispatcher.trigger('chatQuickCheck', 'demo', 0, '', 1, self.fromPage);
						//location.href = Utils.chatUrl() + response.username;
					}
					else if (self.fromAction == "free_chat"){
						var params = self.extraParams;
						params.callback(params.options);
					}else if (self.fromAction == "ew_test" || self.fromAction == "mhq_test"){
						var params = self.extraParams;
						params.callback(params.options);
					}
					else if (self.fromAction == "buy_subscription"){
						var params = self.extraParams;
						params.callback(params.options);
					}
					else if (self.fromAction == "flames"){
						var params = self.extraParams;
						params.callback(params.options);
					}
					else if( self.fromAction == "counselorChat"){
						var counselorUrl = self.extraParams ;
						var counselorChatUrl = counselorUrl.split(/BREAKBREAK/)[0];
						var counselorID = counselorUrl.split(/BREAKBREAK/)[1];

						Dispatcher.trigger('chatQuickCheck', 'direct', counselorID, counselorChatUrl, 1, self.fromPage);

						//location.href = counselorChatUrl + "&username=" + response.username;
					}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){

						location.href = self.extredirectTo;
					}

					else if ( self.fromPage == "landingPage2Message" ) {

						self.sendCareerMessage(response, false);

					}
					else if ( self.fromAction == "download_free_ebook") {

						console.log( "download ebook postid" );
						console.log( self.extraParams );
						var extraParamArray = self.extraParams;
						var postId = extraParamArray[0];
						var categoryId = extraParamArray[1];
						var successMsg = extraParamArray[2];
						console.log( "redirecting to");

						self.downloadEbookCall( postId, categoryId, successMsg, dataToSend[ "email" ]);



					}
					else if ( self.fromPage == "landingpage2" ) {
							Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});

					}
					else if ( self.fromAction == "show_result_post_signup" ) {
								console.log( "result "+ self.extraParams );
								Backbone.history.loadUrl(self.extraParams);
					}
					else if ( self.fromAction === "hideFurtherTips" ) {

						// Backbone.history.loadUrl( self.extraParams );
						Backbone.history.navigate( self.extraParams, {trigger: true} );

					} else if ( self.fromAction == 'bookAppointment' ) {
								Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + self.extraParams['counselorId'] + '&catID=' + self.extraParams['categoryId'], {trigger: true} );
					}
					else if(self.fromAction == 'quickMessage'){

								Backbone.history.navigate("/talkItOut?from=quickMessage&counselorInfo=" + JSON.stringify(self.extraParams) , {trigger: true});
					}else if(self.fromAction == "packages_header"){

						Backbone.history.loadUrl();
					}else if (self.fromAction == "buy_package"){

						self.redirectToPayU()
					}
					else if (self.fromAction == "buy_ny_package"){
						var params = self.extraParams;
						params.callback(params.options);
					}
					else{
						var paramUrl = "" ;
						if(self.fromAction == "message"){
							var counselorInfo = self.extraParams ;
							paramUrl = "?from=message&counselorID=" + counselorInfo.id ;
						}

						//location.href = "/talkItOut" + paramUrl;
						var ret = Backbone.history.navigate("/talkItOut" + paramUrl, {trigger: true});

						if (ret === undefined) {

    						Backbone.history.loadUrl("/talkItOut" + paramUrl);
						}
					}
				}


			}).fail(function(error){
				console.log("ERROR");
				console.log(error) ;
			});

		},
		checkForPasswordEntry : function(pwd){

			if(pwd == ''){

				$("#password-form-error").removeClass("hide")
				return 0;
			}else{

				return 1;
			}
		},
		checkForUsernameEntry : function(uname){

			if(uname == ''){

				$("#username-form-error").removeClass("hide")
				return 0;
			}else{

				return 1;
			}
		},
		modalLogin : function(e){

			var self = this ;

			$(".form-error").addClass("hide")
			$(".login-error").addClass("hide")

        	var username = $(".modalLoginForm #username").val().trim();
			var pwd = $(".modalLoginForm #password").val();

			var passPass = self.checkForPasswordEntry(pwd)
			var passUname = self.checkForUsernameEntry(username)

			if(passPass == 0 || passUname == 0){

				return;
			}

			$("#login").hide() ;
			$("#login-progress").show() ;
			$("#signup-now").addClass("disabled") ;
			$("#signup-now-mobile").addClass("disabled") ;

			var loginUrl = Utils.contextPath()+"/v2/users/login" ;
			var source = "website";
			if(this.sso != undefined ){
				loginUrl = loginUrl + "?sso=" + this.sso ;
				source = "FORUM";
			}else{
				loginUrl = loginUrl ;
			}

			$.ajax({
				type: "POST",
				dataType: "JSON",
            	contentType: "application/json; charset=utf-8",
    			url: loginUrl ,
    			xhrFields: {
     				withCredentials: true
			    },

			   beforeSend :function(xhr){
			    	xhr.setRequestHeader( "Authorization", "Basic "+ btoa(username + ":" + pwd) );
			    },

			    statusCode:{
			    	401 : function(response){

			    		var responseText = response.responseText;
						var responseJson = JSON.parse(responseText) ;

						var errorMessage = responseJson.message ;
						var errorType    = responseJson.type ;

						if(errorType == "BLOCKED"){
							$(".login-error").html("We have noticed some unusual activites from this account. Please <a href='mailto:customersupport@yourdost.com'>contact us</a> to learn more. ");
						}else{
							$(".login-error").html("The username and password do not match");
						}

			    		$(".login-error").removeClass("hide") ;
			    		$("#login").show() ;
						$("#login-progress").hide() ;
						$("#signup-now").removeClass("disabled");
						$("#signup-now-mobile").removeClass("disabled");
			    	},
			    },
    			data:JSON.stringify({"shouldGenerateCookie": true,"ipSession": false})
			}).done(function( data, status, xhr ) {

				$(".login-error").addClass("hide") ;
				Raygun.setUser( data.username, false, data.email, data.firstName, data.firstName, data.id ) ;
				if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){

					mixpanel.register({
						userInfo : data ,
						orgId : data["loggableUser"]["orgId"]
					});

					var distinct_id = mixpanel.get_distinct_id();
					mixpanel.identify(data.id);
					mixpanel.track('LOGIN', {'type' : 'NORMAL', 'mediumSource' : source, 'itemName' : self.buttonDesc, 'itemMedium' : 'NORMAL'  });
					mixpanel.people.set({
	    			'username': data.username,
	    			'name' : data.username ,
	    			'$email': data.email,
	    			'id' : data.id,
 	    			'userType' : data["loggableUser"]["userType"],
					'orgId' : data["loggableUser"]["orgId"]
					});
					mixpanel.name_tag({
						nameTag: data.username
					});
				}

				window.userdata = data;

				self.model.save(data) ;
				if (self.fromPage!= 'landingPage2Message') {
					self.hideLoginModal();
				}


				$.ajax({
					url : Utils.contextPath() + "/v2/users/terms"
				}).done(function(response){

					if(response.termsAccepted == false){

						if ( self.fromPage == "landingPage2Message" ) {
							self.sendCareerMessage( data, isPending, response.termsAccepted );
						}else if ( self.fromAction == "download_free_ebook") {

							console.log( "download ebook postid" );
							console.log( self.extraParams );
							console.log( "redirecting to");
							var extraParamArray = self.extraParams;
							var postId = extraParamArray[0];
							var categoryId = extraParamArray[1];
							var successMsg = extraParamArray[2];
							var email = data.email;

							if (!email) {
        						Backbone.history.navigate("/termsUpdateModal",{trigger:true});
        					}else{
        						self.downloadEbookCall( postId, categoryId, successMsg,  email );
        					}
						}else if ( self.fromAction == "show_result_post_signup" ) {
							Backbone.history.navigate("/termsUpdateModal?from="+ self.extraParams,{trigger:true});
						} else if ( self.fromAction == "hideFurtherTips" ) {
							Backbone.history.navigate("/termsUpdateModal?from="+ self.extraParams,{trigger:true});
						}
						else{
							Backbone.history.navigate("/termsUpdateModal?from="+ self.fromAction,{trigger:true});

						}
					}else{

				$.ajax({
					url : Utils.contextPath() + "/v1/user/transaction/pending/" + data.id
				}).done(function(response){
					var isPending;
					if(response > 0){

						isPending = true;
						if ( self.fromPage == "landingPage2Message" ) {

							self.sendCareerMessage( data, isPending );

						}
						else if ( self.fromAction == "download_free_ebook") {

							console.log( "download ebook postid" );
							console.log( self.extraParams );
							console.log( "redirecting to");
							var extraParamArray = self.extraParams;
							var postId = extraParamArray[0];
							var categoryId = extraParamArray[1];
							var successMsg = extraParamArray[2];
							var email = data.email;

							if (!email) {

        						//Utils.openPopup('download-ebook-modal');
        						if (categoryId == 0) {
        							Backbone.history.navigate("/talkItOut?fromPage=ParentingPrompt&postId="+postId, {trigger: true});
        						}else {
        							Backbone.history.navigate("/talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId, {trigger: true});

        						}

        					}else{

        						self.downloadEbookCall( postId, categoryId, successMsg,  email );

        					}


						}
						else if ( self.fromPage == "landingpage2" ) {
							Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});

						}
						else if ( self.fromAction == "show_result_post_signup" ) {
							// location.href = self.extraParams;
							Backbone.history.loadUrl(self.extraParams);


						} else if ( self.fromAction == "hideFurtherTips" ) {
							console.log( "extra params "+ self.extraParams );
							Backbone.history.navigate( self.extraParams, {trigger: true} );

						}
						else {

	//						location.href = "#sessions" ;
							Backbone.history.navigate("/sessions", {trigger: true});

						}

					}else{

						isPending = false;
						console.log( self.fromPage );
						console.log( "data", data );
						var userType = data["loggableUser"]["userType"];

						if( data.uri ){
							//location.href = data.uri ;
							Backbone.history.navigate(data.uri, {trigger: true});
						}else{
							console.log(self.redirectTo) ;
							if(self.fromAction == 'home_chat'){
								Dispatcher.trigger('chatQuickCheck', 'demo', 0, '', 1, self.fromPage);
								//location.href =  Utils.chatUrl() + data.username;
							}
							else if (self.fromAction == "free_chat"){
								var params = self.extraParams;
								params.callback(params.options);
							}else if (self.fromAction == "ew_test" || self.fromAction == "mhq_test"){
								var params = self.extraParams;
								params.callback(params.options);
							}
							else if (self.fromAction == "buy_subscription"){
								var params = self.extraParams;
								params.callback(params.options);
							}
							else if (self.fromAction == "flames"){
								var params = self.extraParams;
								params.callback(params.options);
							}
							else if(self.fromAction == 'counselorChat'){

								var counselorChatUrl = self.extraParams ;
								counselorChatUrl = self.extraParams.split(/BREAKBREAK/)[0];

								var counselorID = self.extraParams.split(/BREAKBREAK/)[1];

								Dispatcher.trigger('chatQuickCheck', 'direct', counselorID, counselorChatUrl, 1, self.fromPage);

								//var chatUrl = self.extraParams + "&username=" + data.username ;
								//location.href = chatUrl ;
							}else if(self.fromAction == 'message'){
								//location.href = "/talkItOut?from=message&counselorID=" + self.extraParams ;
								Backbone.history.navigate("/talkItOut?from=message&counselorID=" + self.extraParams , {trigger: true});
							}else if(self.fromAction == 'quickMessage'){

								Backbone.history.navigate("/talkItOut?from=quickMessage&counselorInfo=" + JSON.stringify(self.extraParams) , {trigger: true});
							}
							else if(self.fromAction == 'book_appointment'){
								//location.href = "/bookAppointment";
								Backbone.history.navigate("/bookAppointment", {trigger: true});
							}else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){

								location.href = self.extredirectTo;

							}else if(self.redirectTo != undefined ){
								//location.href = "/" + self.redirectTo ;
								localStorage.setItem("fromChat", 0) ;
								Backbone.history.navigate("/" + self.redirectTo, {trigger: true});

							}
							else if ( self.fromPage == "landingpage2" ) {
								Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});
							}
							else if (self.fromPage == "landingPage2Message" ) {
								self.sendCareerMessage(data, isPending);
								//location.href = "#landingpage2";
							}
							else if ( self.fromAction == "download_free_ebook") {

								console.log( "download ebook postid" );
								console.log( self.extraParams );
								console.log( "redirecting to");
								var extraParamArray = self.extraParams;
								var postId = extraParamArray[0];
								var categoryId = extraParamArray[1];
								var successMsg = extraParamArray[2];

								var email = data.email;
								if (!email) {

        							 // Utils.openPopup('download-ebook-modal');
        							if (categoryId == 0) {

        								Backbone.history.navigate("/talkItOut?fromPage=ParentingPrompt&postId="+postId, {trigger: true});
        							}
        							else {
        								Backbone.history.navigate("/talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId, {trigger: true});
        							}

        						}else{

        							self.downloadEbookCall( postId, categoryId, successMsg, email );

        						}

							}
							else if ( self.fromAction == "show_result_post_signup" ) {
								console.log( "result "+ self.extraParams );
								Backbone.history.loadUrl(self.extraParams);

							}
							else if ( self.fromAction == "hideFurtherTips" ) {
								console.log( "modal page", self.extraParams );
								Backbone.history.navigate( self.extraParams, {trigger: true} );

							} else if ( self.fromAction == 'bookAppointment' ) {

								Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + self.extraParams['counselorId'] + '&catID=' + self.extraParams['categoryId'], {trigger: true} );
							}else if(self.fromAction == "packages_header"){

								Backbone.history.loadUrl();
							}else if (self.fromAction == "buy_package"){

								self.redirectToPayU()
							}
							else if (self.fromAction == "buy_ny_package"){
								var params = self.extraParams;
								params.callback(params.options);
							}
							else{

								if (self.fromPage == 'messages') {
									Dispatcher.trigger("openComposeMessage", self.extraParams);
									return;
								}

								//location.reload();
								console.log( "userType", userType );
								if (userType == 'VICTIM' ) {

									var ret = Backbone.history.navigate("/talkItOut", {trigger: true});

									if (ret === undefined) {

			    						Backbone.history.loadUrl("/talkItOut");
									}

								} else {
									Backbone.history.navigate(Utils.getMessageURL(data), {trigger: true});
								}

					            localStorage.setItem("fromChat", 0) ;
							}
						}
					}


				}).error(function(error){
					console.log(error)
				})
}
				}).error(function(error){
					location.href = Utils.getMessageURL(data);
				})	;

  			}).error(function(error){
  				console.log(error) ;
  				$("#login").show() ;
				$("#login-progress").hide();
  				$("#signup-now").removeClass("disabled");
				$("#signup-now-mobile").removeClass("disabled");
  			});
		},
		openSignUpModal: function(){
			this.hideLoginModal();
			Dispatcher.trigger("renderLogin", "click SIGNUP Login Page", "login", "") ;
		},
	    LoginModalPageLayout : JST["app/templates/login/login_modal.hbs"],
	    LoginPageLayout : JST["app/templates/login/login_layout.hbs"],
	    PostSignupProfileUpdatePageLayout : JST["app/templates/login/post_signup.hbs"],
	    renderHTML : function(buttonDesc, fromPage, fromAction, extraParams){
	    	var self = this;
	    	var newComer = false;

	    	$('#login-modal').remove() ;
			var currentPage = window.location.pathname;
			var loginClicked = false;
			console.log( "fromAction" );
			console.log( fromAction );
			console.log( extraParams );
			if(fromAction == "loginButton" || fromAction == "buy_subscription" || fromPage == "mpbse"){
				loginClicked = true
			}

			if ( fromPage == "landingPage2Message" ) {
				self.extraParams = extraParams;
				self.fromPage = fromPage;
				newComer = true;
			}
			if ( fromPage == "landingpage2" ) {
				// self.extraParams = extraParams;
				self.fromPage = fromPage;
				// newComer = true;
			}
			if ( fromAction == "download_free_ebook" ) {
				self.extraParams = extraParams;
				self.fromAction = fromAction;
			}

			console.log( loginClicked );
			this.$el.append(this.LoginModalPageLayout({isMobileDevice : Utils.isMobileDevice(), fromPage: fromAction, currentPage : fromPage, loginClicked: loginClicked, newComer:newComer,
				enablePromo : enable_promo }));
			this.setElement($("body")).render(buttonDesc, fromPage, fromAction, extraParams, loginClicked);

			var contextSpecificMessages = localStorage.getItem("contextSpecificMessages");

			if(contextSpecificMessages != null){
				contextSpecificMessages = JSON.parse(contextSpecificMessages);
				self.replaceModalHeaderText(contextSpecificMessages, fromAction);
			}else{
				$.ajax({

					url : "https://d3dlm19tttbkds.cloudfront.net/contextSpecificMessages.json"
				}).done(function(response){
					localStorage.setItem("contextSpecificMessages", JSON.stringify(response));
					self.replaceModalHeaderText(response, fromAction);
				}).error(function(error){
					console.log(error);
				});

			}

	    },

	    redirectToPayU : function(){

	    	var params = this.extraParams;
	    	$(".body-overlay").removeClass("hide");
	    	var userID = window.userdata.id;

	    	$.ajax({
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
				url : Utils.contextPath()+ "/v1/user/"+userID+"/package/"+params.packageId+"/amount/"+params.amount,
			}).done(function(response){

				console.log("Response ", response)
				$(".body-overlay").addClass("hide");
				if(!response.error){

					location.href = response.uri;
				}

			}).error(function(error){

				$(".body-overlay").addClass("hide");
				console.log("Error: ", error)
			})
	    },

	    replaceModalHeaderText : function(contextSpecificMessages, fromAction){

			var signupHeaderMsg = contextSpecificMessages["SIGNUP"][fromAction];
			if(signupHeaderMsg == undefined){
				signupHeaderMsg = "Sign Up - This'll be quick";
			}
			$(".signup-modal-header-div .login-modal-header").html(signupHeaderMsg);
			//$(".signup-anonimity-txt").html("Don't worry, you can anonymize yourself in the next step.")

			var loginHeaderMsg = contextSpecificMessages["LOGIN"][fromAction];
			if(loginHeaderMsg == undefined){
				loginHeaderMsg = "Login";
			}
			$(".login-modal-header-div .login-modal-header").html(loginHeaderMsg);
			//$(".login-anonimity-txt").html("Don't worry, you stay anonymous even with social login.")

	    },
	    renderHTMLToDiv: function(buttonDesc, fromPage, fromAction, divId, extraParams) {

	    	var self = this;

	    	var newComer = false;

	    	$('#login-modal').remove() ;
			var currentPage = Backbone.history.getFragment() ;
			var loginClicked = false;
			console.log( "fromAction" );
			console.log( fromAction );
			console.log( extraParams );

			console.log( loginClicked );

			console.log( divId );

			if ( fromAction == "download_free_ebook" ) {
				self.extraParams = extraParams;
				self.fromAction = fromAction;
			}

			if ( fromAction == "show_result_post_signup") {
				self.extraParams = extraParams;
				self.fromAction = fromAction;
			}
			if ( fromAction == "ew_test" || fromAction == "mhq_test") {
				self.extraParams = extraParams;
				self.fromAction = fromAction;
			}
			if(buttonDesc != undefined){
				this.buttonDesc = buttonDesc.replace("#", "") ;
				this.sourceDesc = this.buttonDesc ;
			}

			if(buttonDesc == undefined){
				this.buttonDesc = "ISSUE " + window.location.href ;
				this.sourceDesc = this.buttonDesc ;
			}
			console.log( "#" + divId );
			self.setElement("body");
			console.log(self.$el);
			console.log(self.$el.find("#" + divId) );
			self.$el.find("#" + divId).html( self.LoginModalPageLayout({isMobileDevice : Utils.isMobileDevice(), fromPage: fromAction, currentPage : fromPage, loginClicked: loginClicked, newComer:newComer,
				enablePromo : enable_promo }) );

			self.startGoogleAppLogin();
			self.setElement(self.$el.find("#" + divId));
			var contextSpecificMessages = localStorage.getItem("contextSpecificMessages");

			if(contextSpecificMessages != null){
				contextSpecificMessages = JSON.parse(contextSpecificMessages);
				self.replaceModalHeaderText(contextSpecificMessages, fromAction);
			}else{
				$.ajax({
					url : "https://d3dlm19tttbkds.cloudfront.net/contextSpecificMessages.json"
				}).done(function(response){
					localStorage.setItem("contextSpecificMessages", JSON.stringify(response));
					self.replaceModalHeaderText(response, fromAction);
				}).error(function(error){
					console.log(error);
				});

			}

			$("#modal-signupUsername").keystop( function(event){
				self.checkForUsername(event) ;
			}, 1000 ) ;


			/*$("#signup_promo_code").keystop( function(event){
				self.signUpPromoCodeExists(event) ;
			}, 1000 ) ;*/

			$("input[type=password]").keystop( function(event){
				self.checkForPassword(event) ;

			}, 1000 ) ;



			$("#modal-signupEmail").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1500 ) ;

	    },
		render: function(buttonDesc, fromPage, fromAction, extraParams, loginClicked) {

				// document.title="Login | YourDOST";
				// $('meta[name=description]').attr('content', "Login using your email id & password. Forgot Password. SignUp for a new account to chat with experts");
				// $('meta[name=title]').attr('content',"Login | YourDOST");
				// $('meta[property="og:description"]').attr('content', "Login using your email id & password. Forgot Password. SignUp for a new account to chat with experts");
				// $('meta[property="og:title"]').attr('content',"Login | YourDOST");
				// $('link[rel="canonical"]').attr('href', 'https://yourdost.com/login');

			var self = this ;

			if(self.fromAction == "buy_package"){

				if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.register === "function" ){

					mixpanel.track("Login Modal", {"itemName" : "Package_"+extraParams.packageName});
				}
			}

			Utils.openPopup('login-modal') ;

			/*FB.getLoginStatus(function(response) {
			    console.log(response);
			});*/

			this.fromAction = fromAction ;
			this.fromPage    = fromPage ;
			this.extraParams = extraParams ;
			if(buttonDesc != undefined){
				this.buttonDesc = buttonDesc.replace("#", "") ;
				this.sourceDesc = this.buttonDesc ;
			}

			if(buttonDesc == undefined){
				this.buttonDesc = "ISSUE " + window.location.href ;
				this.sourceDesc = this.buttonDesc ;
			}

			var self = this ;

			if ( typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

				mixpanel.track("Signup Popup", {"itemName" : self.buttonDesc});
			}


			// var loginClicked = false;


			if(this.sso){

				$.ajax({
					method : "GET" ,
					url : Utils.contextPath()+"/v2/users/login?sso=" + this.sso ,
 					statusCode:{
			    	401 : function(){
			    		self.startGoogleAppLogin();
						self.$el.append(self.LoginModalPageLayout({loginClicked : loginClicked, enablePromo : enable_promo}));
						if(fromPage !== "scroll-header" && fromPage !== "home_page_download_eBook_popup")
							$('body').animate({ scrollTop: 0 }, 0);

						$(".parallax-container").css("min-height","100vh");
    					$("#username").focus();
    					$('.login-modal-input label').addClass('active');
    					$('.login-modal-input i').addClass('active');
			    	},
			    	},
				}).done(function(response){
					if(response.uri){
						//location.href = response.uri ;
						Backbone.history.navigate(response.uri, {trigger: true});
					}else{
						//location.href = Utils.getMessageURL(response);
						Backbone.history.navigate(Utils.getMessageURL(response), {trigger: true});
					}

				}).error(function(error){

				});

			}else{

				self.$el.append(self.LoginModalPageLayout({loginClicked : loginClicked, enablePromo : enable_promo}));

				self.startGoogleAppLogin();

      			var fbRootLength = $("#fb-root div");
    			console.log("fbroot length " + fbRootLength.length);

				if(fromPage !== "scroll-header" && fromPage !== "home_page_download_eBook_popup")
					$('body').animate({ scrollTop: 0 }, 0);

    			$(".parallax-container").css("min-height","100vh");
    			$("#username").focus();
    			$('.login-modal-input label[username]').addClass('active');
    					$('.login-modal-input i').addClass('active');
			}

			self.model.setUnreadCount();


			$("#modal-signupUsername").keystop( function(event){
				self.checkForUsername(event) ;
			}, 1000 ) ;


			/*$("#signup_promo_code").keystop( function(event){
				self.signUpPromoCodeExists(event) ;
			}, 1000 ) ;*/

			$("input[type=password]").keystop( function(event){
				self.checkForPassword(event) ;

			}, 1000 ) ;



			$("#modal-signupEmail").keystop( function(event){
				self.checkForEmail(event) ;
			}, 1000 ) ;



			// $("#tos-check").on( "change", function(event) {
			// 	console.log("hello");
			// 	self.checkForTosCheck( event );
			// }, 1000 );
			//setTimeout(function(){$(".m-login").remove();$(".side-login-btn").remove();},10);
		},

		"proceedToHomePage" : function(e){

			var self = this;
			var data = window.userdata;
			// reset hack
			//window.userdata = "";
			console.log( 'from Page '+ self.fromPage );

			$.ajax({
					url : Utils.contextPath() + "/v2/users/terms"
				}).done(function(response){

					if(response.termsAccepted == false){

						if ( self.fromPage == "landingPage2Message" ) {
							self.sendCareerMessage( data, isPending, response.termsAccepted );
						}else if ( self.fromAction == "download_free_ebook") {

							console.log( "download ebook postid" );
							console.log( self.extraParams );
							console.log( "redirecting to");
							var extraParamArray = self.extraParams;
							var postId = extraParamArray[0];
							var categoryId = extraParamArray[1];
							var successMsg = extraParamArray[2];
							var email = data.email;

							if (!email) {

        						Backbone.history.navigate( "/termsUpdateModal",{trigger:true});

        					}else{
        						self.downloadEbookCall( postId, categoryId, successMsg,  email );
        					}
						}else if ( self.fromAction == "show_result_post_signup" ) {

							Backbone.history.navigate("/termsUpdateModal?from="+ self.extraParams,{trigger:true});

						}else if ( self.fromAction == "hideFurtherTips" ) {

							Backbone.history.navigate("/termsUpdateModal?from="+ self.extraParams,{trigger:true});

						}else{

							Backbone.history.navigate("/termsUpdateModal?from="+ self.fromAction,{trigger:true});

						}
					}else{

							$.ajax({
									url : Utils.contextPath() + "/v1/user/transaction/pending/" + data.id
								}).done(function(response){
									Utils.closePopup('post_signup_modal');
									if(response > 0){
										console.log( 'from Page '+ self.fromPage );
										isPending = true;
										if ( self.fromPage == "landingPage2Message" ) {
											console.log( "data in landingPage2Message " );
											console.log( data );
											self.sendCareerMessage( response, isPending );

										}
										else if ( self.fromPage == "landingpage2" ) {
											Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});
										}
										else if ( self.fromAction == "download_free_ebook") {

											console.log( "download ebook postid" );
											console.log( self.extraParams );
											console.log( "redirecting to");
											var extraParamArray = self.extraParams;
											var postId = extraParamArray[0];
											var categoryId = extraParamArray[1];
											var successMsg = extraParamArray[2];
											var email = data.email;

											if (!email) {

				        						//Utils.openPopup('download-ebook-modal');
				        						if (categoryId == 0) {

				        							//location.href = "#talkItOut?fromPage=ParentingPrompt&postId="+postId;
				        							Backbone.history.navigate("/talkItOut?fromPage=ParentingPrompt&postId="+postId, {trigger: true});
				        						}else {
				        							//location.href = "#talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId;
				        							Backbone.history.navigate("/talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId, {trigger: true});
				        						}

				        					}else{

				        						self.downloadEbookCall( postId, categoryId, successMsg, email );

				        					}


										}
										else if ( self.fromAction == "show_result_post_signup" ) {

											Backbone.history.loadUrl(self.extraParams);
										}
										else if ( self.fromAction == "hideFurtherTips" ) {

											Backbone.history.navigate( self.extraParams, {trigger: true} );

										}
										else {

											//location.href = "#sessions" ;
											Backbone.history.navigate("/sessions", {trigger: true});

										}
									}else{

										var userType = data[ "loggableUser" ][ "userType" ];

										console.log( 'from Page '+ self.fromPage );
										if( data.uri ){
											Backbone.history.navigate(data.uri,{trigger:true}) ;
										}else{

											console.log(self.redirectTo) ;
											if(self.fromAction == 'home_chat'){
												Dispatcher.trigger('chatQuickCheck', 'demo', 0, '', 1, self.fromPage);
												//location.href = Utils.chatUrl() + data.username;
											}
											else if (self.fromAction == "free_chat"){
												var params = self.extraParams;
												params.callback(params.options);
											}else if (self.fromAction == "ew_test" || self.fromAction == "mhq_test"){
												var params = self.extraParams;
												params.callback(params.options);
											}
											else if (self.fromAction == "buy_subscription"){
												var params = self.extraParams;
												params.callback(params.options);
											}
											else if (self.fromAction == "flames"){
												var params = self.extraParams;
												params.callback(params.options);
											}
											else if(self.fromAction == 'counselorChat'){

												var counselorUrl = self.extraParams ;
												counselorUrl = self.extraParams.split(/BREAKBREAK/)[0];
												var counselorID = self.extraParams.split(/BREAKBREAK/)[1];

												var chatUrl = counselorUrl + "&username=" + data.username ;
												Dispatcher.trigger('chatQuickCheck', 'direct', counselorID, counselorUrl, 1, self.fromPage);
												//location.href = chatUrl;
											}else if(self.fromAction == 'message'){
												//location.href = "#talkItOut?from=message&counselorID=" + self.extraParams ;
												Backbone.history.navigate("/talkItOut?from=message&counselorID=" + self.extraParams, {trigger: true});
											}else if(self.fromAction == 'quickMessage'){

												Backbone.history.navigate("/talkItOut?from=quickMessage&counselorInfo=" + JSON.stringify(self.extraParams) , {trigger: true});
											}
											else if(self.fromAction == 'book_appointment'){
												//location.href = "#bookAppointment" ;
												Backbone.history.navigate("/bookAppointment", {trigger: true});

											}else if ( self.fromPage == "landingPage2Message" ) {

												self.sendCareerMessage(data, false);

											}
											else if ( self.fromPage == "landingpage2" ) {

												Backbone.history.navigate("/talkItOut?category=1&fromPage=careercounselor",{trigger:true});

											}

											else if ( self.fromAction == "download_free_ebook") {

												console.log( "download ebook postid" );
												console.log( self.extraParams );
												console.log( "redirecting to");
												var extraParamArray = self.extraParams;
												var postId = extraParamArray[0];
												var categoryId = extraParamArray[1];
												var successMsg = extraParamArray[2];
												var email = data.email;

												if (!email) {

					        						//Utils.openPopup('download-ebook-modal');
					        							if (categoryId == 0) {

					        								Backbone.history.navigate("/talkItOut?fromPage=ParentingPrompt&postId="+postId,{trigger:true});
					        							}
					        							else {
					        								Backbone.history.navigate("/talkItOut?category="+ categoryId +"&fromPage=ParentingPrompt&postId="+postId,{trigger:true});						}

					        							}
					        						else{

					        								self.downloadEbookCall( postId, categoryId, successMsg, email );

					        							}


											}
											else if ( self.fromAction == "show_result_post_signup" ) {

												Backbone.history.loadUrl(self.extraParams);
											}
											else if ( self.fromAction == "hideFurtherTips" ) {

												Backbone.history.navigate( self.extraParams, {trigger: true} );

											}else if ( self.fromAction == 'bookAppointment' ) {

												Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + self.extraParams['counselorId'] + '&catID=' + self.extraParams['categoryId'], {trigger: true} );
											}else if(self.fromAction == "packages_header"){

												Backbone.history.loadUrl();
											}else if (self.fromAction == "buy_package"){

												self.redirectToPayU()
											}
											else if (self.fromAction == "buy_ny_package"){
												var params = self.extraParams;
												params.callback(params.options);
											}
											else if(self.extredirectTo != undefined && self.extredirectTo.search(/blog/) > -1){

												location.href = self.extredirectTo;

											}else if(self.redirectTo != undefined ){
												Backbone.history.navigate( "/" + self.redirectTo,{trigger:true}) ;
												localStorage.setItem("fromChat", 0) ;
											}
											else{

												if ( userType == 'VICTIM') {
													Backbone.history.navigate("/talkItOut",{trigger:true});
												} else {
													Backbone.history.navigate(Utils.getMessageURL(data), {trigger: true});
												}

					                            localStorage.setItem("fromChat", 0) ;
											}
										}
									}
								}).error(function(error){
									Utils.closePopup('post_signup_modal');
									console.log(error)
								})
						}
				}).error(function(error){
					location.href = Utils.getMessageURL(data);
				})	;
		},
		'showAvatar' : function(e){
			$('.page_one').hide();
			$('.page_two').show();
			var src = $('#profile_picture img').attr("src");
			var avatar_id = $('#profile_picture img').attr("id");
			$('img.avatar-img-post-signup').each(function(i){ $(this).removeClass("avatar-selected"); });
			$('img.avatar-img-post-signup[id='+ avatar_id + ']').addClass('avatar-selected');
		},
		'addPromotion' : function(e){
			if($('#promo_code').hasClass("hide")){
				$('.post_signup_promo_block').find('i').removeClass("mdi-chevron-down");
				$('.post_signup_promo_block').find('i').addClass("mdi-chevron-up");
				$('#promo_code').removeClass("hide")
			}else{
				$('.post_signup_promo_block').find('i').addClass("mdi-chevron-down");
				$('.post_signup_promo_block').find('i').removeClass("mdi-chevron-up");
				$('#promo_code').addClass("hide");
			}
		},
		'showProfileUpdate' : function(e){
			$('.page_one').show();
			$('.page_two').hide();
		},
		'changePicture' : function(e){
			var src = $('img.avatar-img-post-signup.avatar-selected').attr("src");
			var avatar_id = $('img.avatar-img-post-signup.avatar-selected').attr("id");
			$('#profile_picture img').attr("src", src);
			$('#profile_picture img').attr("id", avatar_id);
			this.showProfileUpdate();
		},
		'selectPicture' : function(e){
			$('img.avatar-img-post-signup').each(function(i){ $(this).removeClass("avatar-selected"); });
			$(e.currentTarget).addClass("avatar-selected");
		},
		'signupAddPromotion' :function(e){
			if($('.promo-block').find('i').hasClass("mdi-chevron-down") == true){
				$('.promo-block').find('i').removeClass("mdi-chevron-down");
				$('.promo-block').find('i').addClass("mdi-chevron-up");
				$("#signup_promo_code").removeClass("hide");
			}else{
				$('.promo-block').find('i').addClass("mdi-chevron-down");
				$('.promo-block').find('i').removeClass("mdi-chevron-up");
				$("#signup_promo_code").addClass("hide");
			}
		},
		'updateProfile' : function(e){

			if($(e.currentTarget).attr("disable") == "disable"){
				console.log("disabled!!!!");
				return;
			}

			var promo_code = "";
			if( $('#promo_code').css("visibility") == "visible"){
				promo_code = $('#promo_code').val();
			}

			if(promo_code.trim().length > 0){
				localStorage.setItem("promocode",promo_code);
			}else{
				localStorage.removeItem("promocode");
			}

			var userID = window.userdata.id;
			var self = this ;

			var dataToSend = {
				"promoCode" :  promo_code,
				"username" : $('#post_signup_modal #username_profile_update').val(),
				"avatar" : $('#profile_picture img').attr("id"),
				"photoLink" : $('#profile_picture img').attr("src"),
			};

			var data = JSON.stringify(dataToSend);

			$.ajax({
				method : 'POST',
				url : Utils.contextPath() + "/v2/users/" + userID + "/update/profile",
				dataType : "json" ,
				xhrFields: {
     				 withCredentials: true
			    },
				contentType: "application/json",
				data: data,
			}).done(function(response, status, xhr){
					Utils.closePopup('post_signup_modal');
					self.trackMixpanelEventForSignupWithCoupon("Social signup with coupon success");
					localStorage.removeItem("user");
					self.model.getAndSaveUser();
					self.proceedToHomePage();
			}).error(function(error){
					Utils.closePopup('post_signup_modal');
					console.log(error)
			})
		},
		'usernameExists' : function(e){

			if($('#username_profile_update').val().trim() == ""){
				$('#update_profile').attr("disable","disable");
				$('#form-error-postSignupUsername').html("Username cannot be empty");
				$('#update_profile').find('.post-sign-up-btn').css("background-color","#d2d2d1");
				$('#update_profile').find('.post-sign-up-btn').addClass("disabled");
				return;
			}

			var usernameValid = this.validateText("postSignupUsername");
			if (!usernameValid) {
				$('#update_profile').attr("disable","disable");
				$('#update_profile').find('.post-sign-up-btn').css("background-color","#d2d2d1");
				$('#update_profile').find('.post-sign-up-btn').addClass("disabled");
				return;
			}

			if( $('#username_profile_update').val() == window.userdata.username){
				$('#update_profile').removeAttr("disable");
				$('#form-error-postSignupUsername').html("");
				$('#update_profile').find('.post-sign-up-btn').css("background-color","teal");
				$('#update_profile').find('.post-sign-up-btn').removeClass("disabled");
				return;
			}
			var username = $('#username_profile_update').val();
			$.ajax({
				url : Utils.contextPath() + "/v2/users/exists?type=username&item=" + username,
				statusCode:{
            		404 : function(){
            			$('#update_profile').removeAttr("disable");
						$('#form-error-postSignupUsername').html("");
						$('#update_profile').find('.post-sign-up-btn').css("background-color","teal");
						$('#update_profile').find('.post-sign-up-btn').removeClass("disabled");
						return false;
            		}
        		},

			}).done(function(response){

					if(response == true ){
						$('#form-error-postSignupUsername').html("This username already exists");
						$('#update_profile').attr("disable","disable");
						$('#update_profile').find('.post-sign-up-btn').css("background-color","#d2d2d1");
						$('#update_profile').find('.post-sign-up-btn').addClass("disabled");
						return true;
					}

				}).error(function(){

				});
		},
		"promoCodeExists" : function(e){

			if( $('#promo_code').css("visibility") == "hidden"){
				return true;
			}

			var promo_code = $('#promo_code').val();
			$.ajax({
				url : Utils.contextPath() + "/v1/coupon/isvalid?code=" + promo_code,
				statusCode:{
            		404 : function(){
						$('#promocode_error').html("");
						$('#update_profile').find('.post-sign-up-btn').css("background-color","teal");
						$('#update_profile').find('.post-sign-up-btn').removeClass("disabled");
						return false;
            		}
        		},

			}).done(function(response){

					if(response.status == false ){
						$('#promocode_error').html(response.message);
						$('#update_profile').attr("disable","disable");
						$('#update_profile').find('.post-sign-up-btn').css("background-color","#d2d2d1");
						$('#update_profile').find('.post-sign-up-btn').addClass("disabled");
						return false;
					}else{
						$('#promocode_error').html("");
						$('#update_profile').removeAttr("disable");
						$('#update_profile').find('.post-sign-up-btn').css("background-color","teal");
						$('#update_profile').find('.post-sign-up-btn').removeClass("disabled");
						return false;
					}

				}).error(function(){

				});
		},

		"signUpPromoCodeExists" : function(e){

			if( $('#signup_promo_code').css("visibility") == "hidden"){
				return;
			}

			var promo_code = $('#signup_promo_code').val();
			$.ajax({
				url : Utils.contextPath() + "/v1/coupon/isvalid?code=" + promo_code,
				statusCode:{
            		404 : function(){
						$('#signup_promocode_error').html("");
						$("#modal-signup-btn").removeClass("disabled") ;
						$("#modal-signup-btn").removeAttr("disabled") ;
						return true;
            		}
        		},

			}).done(function(response){

					if(response.status == false ){
						$('#signup_promocode_error').html(response.message);
						$("#modal-signup-btn").addClass("disabled") ;
						$("#modal-signup-btn").attr("disabled",true) ;
						return false;
					}else{
						$('#signup_promocode_error').htnl("");
						$("#modal-signup-btn").removeClass("disabled") ;
						$("#modal-signup-btn").removeAttr("disabled") ;
						return true;
					}

				}).error(function(){

				});
		},

		"trackMixpanelEventForSignupWithCoupon" : function(event_type){
			$.ajax({
				url : Utils.contextPath() + '/v1/coupon/get' ,
			}).done(function(response){
				if(response){
					if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
						mixpanel.track(event_type, {'type' : "NORMAL", 'mediumSource' : 'website',"coupon" : response.code });
					}
				}

			}).error(function(error){
				console.log("Error");
				console.log(error) ;
			});
		}
	});

	LoginModalPage.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	LoginModalPage.prototype.clean = function() {
		this.remove();
	};

	return LoginModalPage;
});
