define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
], function( $, _, Backbone, JST, Utils ) {
	var underConstructionPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
            // this.userModel = new UserModel()
        },
		events: {},
		template: JST['app/templates/under-construction/layout.hbs'],
		render: function() {

			this.$el.html(this.template());
		}

	});
	underConstructionPage.prototype.remove = function() {
        /*$("#main-header").show()
        $(".feedback-form-btn").removeClass("hide")*/
    };
	underConstructionPage.prototype.clean = function() {
        this.remove()
    };
	return underConstructionPage;
});
