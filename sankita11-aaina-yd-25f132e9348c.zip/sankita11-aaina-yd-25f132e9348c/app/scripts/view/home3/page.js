define([
	'jquery',
	'underscore',
	'backbone',
	'view/home2/subview/articles',
  	'view/home/subview/outside_form_links',
  	'view/home3/subview/start_chat',
  	'view/home3/subview/featured_experts',
  	'view/home/subview/user_review',
	'view/home/subview/be_savior',
	'view/home/subview/share_experience',
	'view/home/subview/become_volunteer',
	'view/home2/subview/featured_in',
	'view/home2/subview/stats',
	'../../precompiled-templates',
	'smooth-scroll',
	'utils',
], function($,_, Backbone, ArticlesView, OutsideFormLinksView, StartChatView, FeaturedExpertsView,
	UserReviewView, BeSaviorView, ShareExperienceView, BecomeVolunteerView, FeaturedInView, StatsView, JST, SmoothScroll, Utils) {

	var HomePage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.startChatView = new StartChatView();
			this.featuredExpertsView = new FeaturedExpertsView();
			this.articlesView = new ArticlesView();
	      	this.outsideFormLinksView = new OutsideFormLinksView();
	      	this.beSaviorView = new BeSaviorView();
	      	this.userReviewView = new UserReviewView();
	      	this.shareExperienceView = new ShareExperienceView();
	      	this.becomeVolunteer = new BecomeVolunteerView() ;
	      	this.featuredInView  = new FeaturedInView() ;
	      	this.statsView       = new StatsView();
	      	this.iInterval = null;
	      	this.iStart = 0;
	      	window.clearInterval(this.iInterval);
		},
		events: {
      		'click .smoothscroll': 'smoothScroll',
      		'click #be-savior' : 'showBeSaviorForm' ,
      		'click #share-experience' : 'showShareExperienceForm' ,
      		'click #become-volunteer' : 'showBecomeVolunteerForm',
      		'click .go-down': 'goDown',
      		"click .go-to-testimonials": "goToTestimonials"
    	},
    	goToTestimonials: function(e){
			//location.href = "/testimonials";
			Backbone.history.navigate("/testimonials", {trigger: true});
			return true;
		},
    	showBecomeVolunteerForm : function(e){
    		this.becomeVolunteer.render() ;
    		$('select').not('.disabled').material_select();
    	},
    	showShareExperienceForm : function (e) {
    		this.shareExperienceView.render();
    	},
    	showBeSaviorForm : function (e) {
    		this.beSaviorView.render() ;
    	},
		template: JST['app/templates/home3/layout.hbs'],
		render: function() {

			this.$el.html(this.template());

			//anonymous user view rendering
			this.startChatView.render();

			this.featuredExpertsView.render();

			this.articlesView.render();

			//user review slider rendering
	      	this.userReviewView.render();

	      	this.featuredInView.render();

	      	//survey monkey form links
	      	this.outsideFormLinksView.render();

	      	this.statsView.render();

	      	var self = this;

	      	if( self.iInterval ){
	      		self.iInterval = null;
	      		self.iStart = 0;
	      		window.clearInterval(self.iInterval);
	      	}

	      	var tickerArr = ["build healthy personal relationships?", "have a more productive work-life?", "work towards your goal with enthusiasm?", "build a more confident self?", "fight societal pressure?", "improve your inner self?", "lead from within?", "share your grief?"];

	      	self.iInterval = window.setInterval(function(){

	      		self.iStart++;

				$('.text-carousel div p').animate({top:"-13px", opacity:0}, 1000, function(){
					$('.text-carousel div p').css("top", "13px");

	 				$('.text-carousel div p').html(tickerArr[self.iStart]);
	 				$('.text-carousel div p').animate({top:0,opacity:1},'slow');						
				});	      		
	 		

	      		if( self.iStart >= tickerArr.length ){
	      			self.iStart = 0;
	      		}
	      	},3000);


			return this;
		},
    	smoothScroll: function(e){

	      $('html, body').stop().animate({
	      scrollTop: $("body").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    },
	    goDown: function(e){
	      $('html, body').stop().animate({
	      scrollTop: $("#home3-articles-block").offset().top -78}, 1500,'easeInOutExpo');
	      e.preventDefault();
	    }
	});

	HomePage.prototype.remove = function() {
		window.clearInterval(this.iInterval);
		this.$el.empty();
    	this.$el.off();
    	this.undelegateEvents();
    	this.stopListening();
	};

	HomePage.prototype.clean = function() {
		window.clearInterval(this.iInterval);
		this.remove() ;
	};

	return HomePage;
});
