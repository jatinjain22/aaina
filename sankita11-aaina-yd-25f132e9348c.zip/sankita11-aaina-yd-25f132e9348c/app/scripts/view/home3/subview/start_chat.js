define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'jcarousel'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel ) {

	var StartChatView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;			
		},
		events: {
			'click #home3-start-chat-btn' : 'openSignUpNowModal' ,
		},
		openSignUpNowModal : function (e) {
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "home", "home_chat") ;
			}else{
				var username = this.userModel.getUserName() ;
				location.href = Utils.chatUrl() + username;
			}
		},
		StartChatViewLayout: JST['app/templates/home3/start_chat.hbs'],
		render: function() {

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			$(".start-chat-block").html(this.StartChatViewLayout({ "isLoggedIn" : Utils.isLoggedIn(), userType : userType }));


		}
	});

	StartChatView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	StartChatView.prototype.clean = function() {
		this.remove() ;
	};

	return StartChatView;
});
