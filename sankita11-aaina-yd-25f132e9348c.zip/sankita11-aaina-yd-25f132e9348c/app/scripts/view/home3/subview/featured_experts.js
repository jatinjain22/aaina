define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'view/leaveMessage/page' ,
	'jcarousellite'
], function($,_, Backbone, JST, Dispatcher, Utils, UserModel, LeaveMessageView ) {

	var FeaturedExpertsView = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {
			this.userModel = new UserModel() ;
			this.leaveMessage = new LeaveMessageView();
		},
		events: {
			'click .fexp-chat' : "chatCounselor",
			'click .fexp-msg'  : "msgCounselor",
		},
		msgCounselor : function(e){
			var counselorIdName = $(e.currentTarget).attr("data-attr");

			var counselorInfo = {
				id : counselorIdName.split("_")[0] ,
				name : counselorIdName.split("_")[1] ,
			};
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "home", "message", JSON.stringify(counselorInfo)) ;
			}else{
				if(!counselorIdName || counselorIdName == undefined || counselorIdName == null ){
					this.leaveMessage.render() ;
				}else{
					this.leaveMessage.render( counselorInfo ) ;
				}
				
			}

		},
		chatCounselor : function(e){
			var chatURL = $(e.currentTarget).attr("data-href") ;
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", "home", "counselorChat", chatURL ) ;
			}else{
				var username =  this.userModel.getUserName() ;
				location.href = chatURL + "&username=" + username;
			}
		},
		FeaturedExpertsViewLayout: JST['app/templates/home3/featured_experts.hbs'],
		render: function() {

			var userType = "NO_USER" ;
			if( Utils.isLoggedIn() ){
				userType = this.userModel.getUserType() ;
			}

			var self = this ;
			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/"
			}).done(function(response){
				var counselorToPrint =  response.slice(0,20) ;
				$(".featured-experts-block").html(self.FeaturedExpertsViewLayout({ counselor : counselorToPrint }));

				//$('.experts-jcarousel').jcarousel();
				//$('.experts-jcarousel').jcarousel('scroll', 0);

				$('.experts-jcarousel').jCarouselLite({
				  btnNext: '.experts-scroll-right',
				  btnPrev: '.experts-scroll-left',
				  autoCSS: false,
				});

 				$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){
						
					_.each(response, function(value, key){
						
						if( value.status == "true" && $("#chat-home2-" + key).length ){
							$("#chat-home2-" + key).removeClass("hide");
							$("#chat-home2-" + key).attr("data-href", value.url);

						}
					});
				}).error(function(error){

				});
				}).error(function(error){
				console.log(error);
			});

		}
	});

	FeaturedExpertsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();

	};

	FeaturedExpertsView.prototype.clean = function() {
		this.remove() ;
	};

	return FeaturedExpertsView;
});
