define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'model/users',
	'view/paymentPending/payment_pending',
	'utils',
	'keystop'
], function( $, _, Backbone, JST, UserModel, PaymentPendingView, Utils ) {

	var ChangePasswordPage = Backbone.View.extend({
		el: "main",
		template: JST['app/templates/changePassword/layout.hbs'],
		initialize: function() {
			this.userModel = new UserModel() ;
			this.paymentPendingView = new PaymentPendingView() ;
		},
		events: {
			'submit #change-password-form' : 'changePassword' ,
		},
		disableSubmit : function(e){
			$("#change-password").addClass("disabled");
			$("#change-password").attr("disabled", true);
		},
		enableSubmit : function(e){
			$("#change-password").removeClass("disabled");
			$("#change-password").attr("disabled", false);
		},
		checkForConfirmPassword : function(e){

			var password        = $("#new-password").val() ;
			var confirmPassword = $("#confirm-password").val() ;

			if( confirmPassword.length <= 0 ){
				$("#form-error-confirm_password").html("Please enter a valid password");
				this.disableSubmit();
				return 0 ;
			}

			if( confirmPassword.length >0){

				var pattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$/;
				if( !pattern.test(confirmPassword) ){

					$("#form-error-confirm_password").html("Password must contain atleast 8 characters, an Alphabet, 1 Number and 1 Special Character (!,@,#,$,&,*,_,-)");
					this.disableSubmit();
					return 0 ;
				}
			}

			if( password != confirmPassword ){
				$("#form-error-confirm_password").html("The password and confirm password do not match");
				this.disableSubmit();
				return 0 ;
			}

			$("#form-error-confirm_password").html("") ;
			this.enableSubmit() ;
			return 1 ;

		},
		checkForPassword : function(e){

			var password        = $("#new-password").val() ;
			var confirmPassword = $("#confirm-password").val() ;

			if( password.length <= 0 ){
				$("#form-error-password").html("Please enter a valid password");
				this.disableSubmit();
				return 0 ;
			}

			if( password.length >0){

				var pattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!_\-*#?&])[A-Za-z\d$@$!_\-*#?&]{8,}$/;
				if( !pattern.test(password) ){

					$("#form-error-password").html("Password must contain atleast 8 characters, an Alphabet, 1 Number and 1 Special Character (!,@,#,$,&,*,_,-)");
					this.disableSubmit();
					return 0 ;
				}
			}
			$("#form-error-password").html("") ;
			this.enableSubmit() ;
			if( password.length && confirmPassword.length  && password != confirmPassword ){
				$("#form-error-confirm_password").html("The password and confirm password do not match");
				this.disableSubmit();
				return 0 ;
			}
			if( password == confirmPassword ){
				$("#form-error-confirm_password").html("") ;
			}
			$("#form-error-password").html("") ;
			this.enableSubmit() ;
			return 1 ;
		},


		changePassword : function(e){

			var isValid = this.checkForPassword();
			if(!isValid){
				this.disableSubmit();
				return 0;
			}

			var isValid = this.checkForConfirmPassword();
			if(!isValid){
				this.disableSubmit();
				return 0;
			}


			$("#change-progress").removeClass("hide");
			$("#change-password").addClass("hide");

			var userID = this.userModel.getUserID();
			var dataToSend = {
				"current_password" : $("#current-password").val(),
				"password" : $("#new-password").val() ,
			};

			$.ajax({
				url    : Utils.contextPath() + "/v2/users/"+ userID +"/modify/credential" ,
				method : "POST",
				dataType : "json" ,
				contentType: "application/json",
				data : JSON.stringify(dataToSend),
									statusCode :{
						417 : function(response){

							var responseText = response.responseText;
							var responseJson = JSON.parse(responseText) ;

							var errorMessage = responseJson.message ;
							var errorType    = responseJson.type ;
							if(errorType.match("INCORRECT_PASSWORD")){
								$("#current-password-error").html(errorMessage)
								$("#current-password-error").removeClass("hide") ;
							}
							$("#change-progress").addClass("hide");
							$("#change-password").removeClass("hide");

						},
						404 : function(response){
							var responseText = response.responseText;
							var responseJson = JSON.parse(responseText) ;

							var errorMessage = responseJson.message ;
							var errorType    = responseJson.type ;
							if(errorType.match("INCORRECT_PASSWORD")){
								$("#current-password-error").html(errorMessage)
								$("#current-password-error").removeClass("hide") ;
							}
							$("#change-progress").addClass("hide");
							$("#change-password").removeClass("hide");
						}
					}

			}).done(function(response){
				console.log(response);
				$("#change-password-form").addClass("hide") ;
				$(".change-success-msg").removeClass("hide");
			}).error(function(error){
				console.log(error) ;
			});

		},
		render: function() {

			if (! Utils.isLoggedIn() ){

				location.href="/";

				return false;
			} 
			this.$el.html(this.template());

			$("#current-password").focus();

			var self = this ;

			$("#new-password").keystop( function(event){
				self.checkForPassword(event) ;
			}, 1000 ) ;
			$("#confirm-password").keystop( function(event){
				self.checkForConfirmPassword(event) ;
			}, 1000 ) ;

			if(Utils.isLoggedIn()){

				this.paymentPendingView.render() ;
			}

		}
	});

	ChangePasswordPage.prototype.remove = function() {};

	ChangePasswordPage.prototype.clean = function() {};

	return ChangePasswordPage;
});
