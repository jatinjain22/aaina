define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/users',
	'model/CounselorChatResourceModel',
	'model/blogContent',
	'clipboard'
], function($,_, Backbone, JST, Utils, EventBus, UserModel, CounselorChatResourceModel, BlogContent, Clipboard) {
	
	var CounselorChatResource = Backbone.View.extend({
		el: "main",
		CounselorChatResourceLayout: JST['app/templates/counselorChatResource/layout.hbs'],
		NavResourceContentLayout: JST['app/templates/counselorChatResource/singlenavresourcecontent.hbs'],
		NavBlogContentLayout: JST['app/templates/counselorChatResource/singlenavblogcontent.hbs'],
		NavDiscussionContentLayout: JST['app/templates/counselorChatResource/singlenavdiscussioncontent.hbs'],
		AllResourceContentLayout: JST['app/templates/counselorChatResource/allresourcecontent.hbs'],
		initialize: function(options) { 
			this.model = new CounselorChatResourceModel;
			this.userModel     = new UserModel() ;
			this.blogResource = [];
			this.discussionResource = [];
			this.referenceResource = [];
			$(document).unbind("scroll");
			this.isLoading = false;
			this.blogContent = new BlogContent();
		},
		events: {
			"click .read-more-passage": "expandPassage",
			"click #link-blog": "getBlogResource",
			"click #link-resource": "getBlogResource",
			"click #link-reference": "getReferenceResource", 
			"keyup #counselor-chat-resource-search": "enterSearch",
			"click .ccr-search-icon": "search",
			"click #link-discussion": "getForumResource",
			"click #link-resource": "render",
			"click .copy-text-link": "copyText",
			"click .method": "copyLink"
			//'scroll': 'checkScroll' 
			//"click .method": "copyText"
		},
		loadSearchItems: function(searchTerm) {
			var self = this;
			self.$el.find(".resource-list").html('');
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			$.when(
				$.ajax({
					method: "GET",
					url: self.model.getBlogUrl() + '?search="'+ searchTerm + '"', //"https://yourdost.com/blog/api/get_search_results/?search="+searchTerm,

					dataType: 'jsonp',
					cache: false
				}).done(function(response){
					return response;
					
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	}),
				
				$.ajax({
					method: "GET",
					url: self.model.getResourceUrl() + '?search="' +searchTerm + '"',
					dataType: 'jsonp',
					cache: false
				}).done(function(response){
					return response;
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	}),

				$.ajax({
					method: "GET",
					url: self.model.getDiscussionSearchUrl() + '?q="' +searchTerm + '"',
					//async: false,
					xhrFields: {
	            		withCredentials: false
	        		},
	        		cache: false
				}).done(function(response){
		
					console.log("latest_posts " + response.posts);
					return response;
					
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	})
			).then ( function(blogResource, referenceResource, discussionResource){
				//self.$el.find(".resource-list").html('');
				self.$el.find('.resource-list').append( self.NavBlogContentLayout( {post: blogResource[0].posts} ) );
				self.$el.find('.resource-list').append( self.NavDiscussionContentLayout( {topic: discussionResource[0].posts} ) );
				self.$el.find('.resource-list').append( self.NavResourceContentLayout( {post: referenceResource[0].posts} ) );

				console.log('all requests complete');
				
			});
			//this.$el.html( this.CounselorChatResourceLayout() );

		},
		loadItems: function(pageNo, loader){
			var self = this;
			//self.$el.find(".resource-list").html('');
			if(loader){
				self.$el.find(".resource-list").html('');
				self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			}
			$.when(
				$.ajax({
					method: "GET",
					url: self.model.getBlogUrl() + "?page=" + pageNo, //"https://yourdost.com/blog/api/get_recent_posts/?page=" + pageNo,
					dataType: 'jsonp',
					cache: false
				}).done(function(response){
					console.log('hello 1');
					return response;
					
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	}),
				
				$.ajax({
					method: "GET",
					url: self.model.getResourceUrl() + "?page=" + pageNo, //"http://specialfriendszone.yourdost.com/api/get_recent_posts/?page="+pageNo,
					dataType: 'jsonp',
					cache: false
				}).done(function(response){
					
					return response;
					
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	}),

				$.ajax({
					method: "GET",
					url: self.model.getDiscussionUrl(),
					//async: false,
					xhrFields: {
	            		withCredentials: false
	        		},
	        		cache: false
				}).done(function(response){
					
					//console.log("latest_posts " + response.latest_posts);
					console.log('hello 3');
					return response;
					
					
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	})
			).then ( function(blogResource, referenceResource, discussionResource){
				
				//self.$el.find('.resource-list').html('');
				self.$el.find('.popup-loader').hide();
				self.$el.find('.resource-list').append( self.NavBlogContentLayout( {post: blogResource[0].posts} ) );
				self.$el.find('.resource-list').append( self.NavDiscussionContentLayout( {topic: discussionResource[0].latest_posts} ) );
				self.$el.find('.resource-list').append( self.NavResourceContentLayout( {post: referenceResource[0].posts} ) );

				console.log('all requests complete');
			});
			//this.$el.html( this.CounselorChatResourceLayout() );
		},
		loadBlogContentByPage: function(pageNo){
			var self = this;
			pageNo = typeof pageNo !== 'undefined' ? pageNo : 1;
      		// we are starting a new load of results so set isLoading to true
      		this.isLoading = true;
      	
			$.ajax({
					method: "GET",
					url: self.model.getBlogUrl() + "?page=" + pageNo,
					dataType: 'jsonp',
					cache: false
			}).done(function(response){
					
					if (response.posts) {
						console.log('hello 1');
						self.$el.find(".resource-list").append(self.NavBlogContentLayout({ post : response.posts }));
						self.isLoading = false;
					}
					else {
						self.unbindScroll();
					}
					
			}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
		},
		loadResourceContentByPage: function(pageNo) {
			var self = this;
			console.log('loading resource content by page');
      		// we are starting a new load of results so set isLoading to true
      		this.isLoading = true;
      	
			$.ajax({
					method: "GET",
					url: self.model.getResourceUrl() + "?page=" + pageNo,
					dataType: 'jsonp',
					cache: false
			}).done(function(response){
					
					if (response.posts) {
						console.log('hello 1');
						self.$el.find(".resource-list").append(self.NavResourceContentLayout({ post : response.posts }));
						self.isLoading = false;
					}
					else {
						self.unbindScroll();
					}
					
			}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	         });
		},
		bindScroll: function(){
			var self = this;

			$(document).scroll(function() {
		        self.checkScroll();
		    });
		},
		unbindScroll: function(){
			$(document).unbind("scroll");
		},
	    checkScroll: function () {
	    	var triggerPoint = 300; // 20px from the bottom
	        //var type = $("#msg-block").attr("data-type");
	        var self = this;
	        
	        if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {
				console.log("reference resource "+ this.referenceResource);
				var pgNo = this.model.get("pgNo");
				pgNo += 1;
				console.log("page no "+ pgNo);
				this.isLoading = true;
				var element = $("#nav-items").find(".active");
				var elementText = element.text();
				console.log(elementText);
				if (elementText == 'All Resource') {
					self.bindScroll();
					console.log('hi');
					self.loadItems(pgNo);
				}
				else if (elementText == 'Blog') {
					self.bindScroll();
					self.loadBlogContentByPage(pgNo);	
				}
				else if (elementText == 'Reference') {
					self.bindScroll();
					self.loadResourceContentByPage(pgNo);
				}
				this.model.set("pgNo", pgNo);
			}
	        
	    },
		copyText: function(e) {
			console.log( $(e.currentTarget) );
			var parent = $(e.currentTarget).parent();
			var copied = parent.find('span.copied');
			if ( copied.hasClass('hide') ){
				
				copied.removeClass('hide');
				//setTimeout( 3000 );
				//copied.addClass('hide');
				setTimeout(function() {
       				copied.addClass('hide');
   				}, 800);
			}
		},
		copyLink: function(e) {
			console.log( $(e.currentTarget) );
			var parent = $(e.currentTarget);
			var copied = parent.find('span.copied');
			console.log( copied );
			if ( copied.hasClass('hide') ) {
				copied.removeClass( 'hide' );
				setTimeout(function() {
					copied.addClass('hide');
				}, 800);
			}
		},
		search: function(e) {
			
			var searchTerm = $("#counselor-chat-resource-search").val();
			console.log(searchTerm);
			var self = this;
			var element = $("#nav-items").find(".active");
			var elementText = element.text();
			self.$el.find('.resource-list').html("");
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			if (elementText == 'All Resource') {
				console.log("In all resourrce");
				self.loadSearchItems(searchTerm);
			}
			else if (elementText == 'Blog') {

				$.ajax({
					method: "GET",
					url: self.model.getBlogUrl() + '?search="' +searchTerm + '"',
					dataType: 'jsonp'
				}).done(function(response){
					console.log(response);
					self.$el.find(".resource-list").html(self.NavBlogContentLayout({ post : response.posts }));
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
			}
			else if (elementText == 'Reference') {
				$.ajax({
					method: "GET",
					url: self.model.getResourceUrl() + '?search="' +searchTerm + '"',//"http://specialfriendszone.yourdost.com/api/get_search_results/?search="+searchTerm,
					dataType: 'jsonp'
				}).done(function(response){
					console.log(response);
					self.$el.find(".resource-list").html(self.NavResourceContentLayout({ post : response.posts }));
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
			}
			else if (elementText == 'Discussion') {
				$.ajax({
					method: "GET",
					url: self.model.getDiscussionSearchUrl() + '?q="' +searchTerm + '"', //"https://forum.yourdost.com/search.json?q=" + searchTerm,
					xhrFields: {
            			withCredentials: false
        			}
				}).done(function(response){
					console.log(response);
					self.$el.find(".resource-list").html(self.NavDiscussionContentLayout({ topic : response.posts }));
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
			}
		},
		enterSearch: function(e) {
			if (e.keyCode == 13) {

				self.search();

				// $.ajax({
				// 	method: "GET",
				// 	url: "https://forum.yourdost.com/search?q="+searchTerm,
				// 	xhrFields: {
    //         			withCredentials: false
    //     			}
				// }).done(function(response){
				// 	console.log(response);
				// 	self.$el.find(".resource-list").append(self.NavDiscussionContentLayout({ post : response.posts }));
				// });
			
			}
		},
		render: function() {

			self = this;
			var userType = 'OPERATOR';
			var userType = self.userModel.getUserType();
			if(!Utils.isLoggedIn() || userType == 'VICTIM'){
				var hash = location.pathname ;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname ;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash;
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}

				
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			self.$el.html( this.CounselorChatResourceLayout( { userType : userType } ) );
  			self.bindScroll();
			this.model.set("pgNo", 1);
			self.loadItems(1, true);
			$(document).ready(function() {
    			$('select').material_select();
    			console.log('hello');

  			});
  			
  			var clipboardLink = new Clipboard('.copy-text-link');
  			var clipboardMethod = new Clipboard('.method');
  			
  			clipboardLink.on('success', function(e){
  		
    			e.clearSelection();
  			});
  			clipboardMethod.on('success', function(e){
  				e.clearSelection();
  			});
  			
			return this;
		}, 
		expandPassage: function(e) {
			console.log($(e.currentTarget));
			var parent = $(e.currentTarget).parent();
			console.log(parent);
			if (!parent.hasClass('expand')) {
				//$(e.currentTarget).addClass('hide');
				parent.addClass('expand');
			}
			else {
				//$('.read-more-passage').addClass('hide');
				parent.removeClass('expand');
			}
		},
		getBlogResource: function(e) {
			var self = this;
			self.isLoading = false;
			console.log("Loading or not " + self.isLoading);
			$('.nav-chat-resource ul a').removeClass('active');
			$(e.currentTarget).addClass('active');
			var self = this;

			this.model.set("pgNo", 1);
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			$.ajax({
				method: "GET",
				url: self.model.getBlogUrl(),
				dataType: 'jsonp'
			}).done(function(response){
				console.log(response);
				self.model.set("pgNo", 1);
				self.$el.find(".resource-list").html(self.NavBlogContentLayout({ post : response.posts }));
				
				
				//self.$el.find(".resource-list").html(self.NavContentResourceLayout({ post : response.posts }));
			}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	        });
			

		},
		getReferenceResource: function(e) {

			$('.nav-chat-resource ul a').removeClass('active');
			$(e.currentTarget).addClass('active');
			//var urlIndex =  $(e.currentTarget).data('url');
			var self = this;

			self.isLoading = false;
			this.model.set("pgNo", 1);
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			$.ajax({
				method: "GET",
				url: self.model.getResourceUrl(),
				dataType: 'jsonp'
			}).done(function(response){
				console.log(response);
				self.model.set("pgNo", 1);
				self.$el.find(".resource-list").html(self.NavResourceContentLayout({ post : response.posts }));
				
				
			}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	        });

		},
		getForumResource: function(e) {

			$('.nav-chat-resource ul a').removeClass('active');
			$(e.currentTarget).addClass('active');

			var self = this;
			self.isLoading = false;
			self.$el.find('.resource-list').html('<img class="popup-loader" src="https://d1hny4jmju3rds.cloudfront.net/cloudinary/loader.gif" width="50" height="50">');
			$.ajax({
				method: "GET",
				url: self.model.getDiscussionUrl(),
				xhrFields: {
            		withCredentials: false
        		},
				}).done(function(response){
					console.log(response);
					console.log('hello 2');
					self.$el.find(".resource-list").html(self.NavDiscussionContentLayout({ topic : response.latest_posts }));
				
				}).fail(function(error){
	          		console.log(error);
	          		$("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
	          	});
			self.bindScroll();
		}
	});

	CounselorChatResource.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.stopListening();
	};

	CounselorChatResource.prototype.clean = function() {
		this.remove();
	};

	return CounselorChatResource;
});
