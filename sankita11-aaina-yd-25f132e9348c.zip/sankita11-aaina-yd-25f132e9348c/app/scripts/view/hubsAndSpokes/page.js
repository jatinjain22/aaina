define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users',
  'Swiper'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

    var HubsPage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        this.questionText = {};
        this.selectedShapes = [];
        this.selectedShapeCount = 0;
        this.riddleAnswer = '';
        this.socialShareResponse = {};
        this.timerInterval = undefined;
        this.timerTimeout = undefined;

      },

      HubsLayout:      JST['app/templates/hubsAndSpokes/layout.hbs'],
      ArticlesLayout : JST['app/templates/hubsAndSpokes/articles.hbs'],
      MyExpertLayout : JST['app/templates/hubsAndSpokes/experts.hbs'],
      FaqsLayout :     JST['app/templates/hubsAndSpokes/faqs.hbs'],
      
      events: {
        "click .hubs-to-spoke-link": "redirectToSpokePage",
        "click .spoke-talk-to-counselor-button": "redirectToChat" 
      },

      redirectToChat : function(e) {

        var self = this;

        
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

              if ( !$(e.currentTarget).hasClass("disabled") ) {
                    var username = this.userModel.getUserName() ;
                    location.href = Utils.chatUrl() + username;
                    $(e.currentTarget).addClass("disabled");
              }
        }

      },
      redirectToSpokePage: function(e) {
        
        var self = this;
        e.preventDefault();
        var currentTarget = $(e.currentTarget);
        console.log( "currentTarget", currentTarget );
        console.log( "currentTarget ", currentTarget.context.dataset.target );
        var redirectUrl = currentTarget.context.dataset.target;
        Backbone.history.navigate( redirectUrl, {trigger: true} );
      },

      trackMixpanel : function(mixpanelIdentifier, pageNo){

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

              if ( pageNo != undefined) {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test", "pageNo": pageNo});
              }
              else {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test"});
              }


        }

      },

      shareOnFacebook: function(e) {

        var self = this;
        Utils.shareOnFacebook( self.socialShareResponse, self.url );

      },

      renderSelfHelp: function() {
         Backbone.history.navigate("/selfhelp",{trigger:true});
      },

      redirectToChat : function(e) {

        var self = this;
        self.trackMixpanel( "Talk to Expert from result screen" );
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

          if ( !$(e.currentTarget).hasClass("disabled") ) {
              var username = this.userModel.getUserName() ;
             location.href = Utils.chatUrl() + username;
              $(e.currentTarget).addClass("disabled");
          }
        }

      },

      render: function() {

        var self = this;
        var urlFragment = Backbone.history.getFragment();
        urlFragment = urlFragment.replace(/\?.*?$/, "");

        urlFragment = urlFragment.replace(/\?.*?$/, "");

        function getExperts(data){

          var id = data.h1.id;

          if(id != ""){

            id = id;
          }else{

            id = 1; 
          }

          $.ajax({

            url: Utils.contextPath() + "/v1/counselor?category="+id+"&page_number=1",
          }).done(function(response){

            self.$el.find(".hub-spoke-experts-container").html(self.MyExpertLayout({}));
            Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "EXPERTS DEALING WITH ANXIETY");

          }).error(function(response){

          })
        }

        function getFaqs(data){

          $.ajax({

            url: Utils.scriptPath() + "/faqs.json",
          }).done(function(response){

            self.$el.find(".hub-spoke-faqs-container").html(self.FaqsLayout({response:response["faq"], hub:urlFragment}));

          }).error(function(response){

          })
        }


        $.ajax({
          url: Utils.scriptPath() + "/hubAndSpokes/hub/" + urlFragment + ".json",
          cache: false
        }).done(function(response){

          getExperts(response);
          var metaTitle = response["h1"]["metaTitle"];
          var metaDescription = response["h1"]["metaDescription"];

          document.title = metaTitle;
          $('meta[name=description]').attr('content', metaDescription );
          $('meta[name=title]').attr('content', metaTitle );
          $('meta[property="og:description"]').attr('content', metaDescription );
          $('meta[property="og:title"]').attr('content', metaTitle );
          $('link[rel="canonical"]').attr('href', 'https://yourdost.com/' + urlFragment );
          self.$el.html( self.HubsLayout( {response:response, hubPage:urlFragment, faqs:response["faqs"]} ) );
          $(".pageName").html(urlFragment)

        }).error(function(err){

          console.log( err );
        
        });

        var callSwiper = function(space){

            var mySwiper = new Swiper ('.articles-slider', {
                
              loop: true,
              slidesPerView: 3,
              nextButton: '.articles-direction-left',
              prevButton: '.articles-direction-right',
          
              spaceBetween: space,
              centeredSlides: true,
              autoplay: 3000,
              breakpoints: {
                // when window width is <= 320px
                320: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 5
                },
                // when window width is <= 480px
                480: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 5
                },
                // when window width is <= 640px
                640: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 10
                },
                768: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 15
                },
                992: {
                  slidesPerView: 3,
                  spaceBetweenSlides: 15
                },
                1024: {
                  slidesPerView: 3,
                  spaceBetweenSlides: 15
                }
              }
            })  
        }

        $.ajax({
          method : "GET",
          dataType: 'jsonp',
          url : Utils.relatedArticlesBlogJson()+urlFragment//'/scripts/json/blog.json'//Utils.blogJson()//'/scripts/json/blog.json'// 
        }).done(function(response){

          self.$el.find('.hub-spoke-articles-container').html( self.ArticlesLayout( {blogResponse:response.posts} ) );  
          var space = 30;
          if(Utils.isMobileDevice()){

            space = 5
          }
          
          callSwiper(space);   
        }).error(function(error){
            
          console.log(error);
        });

          
      }

    });

  HubsPage.prototype.remove = function() {

      this.$el.empty();
      this.$el.off();
      this.unbind();
  };

  HubsPage.prototype.clean = function() {

      this.remove();

  };

    return HubsPage;
});

