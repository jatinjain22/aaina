define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users',
  'view/homeNew/subview/survey',
  'Swiper'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel, SurveyView ) {

    var SpokePage = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        this.questionText = {};
        this.selectedShapes = [];
        this.selectedShapeCount = 0;
        this.riddleAnswer = '';
        this.socialShareResponse = {};
        this.timerInterval = undefined;
        this.timerTimeout = undefined;
        this.surveyView = new SurveyView();

      },

      SpokeLayout: JST['app/templates/hubsAndSpokes/spokeLayout.hbs'],
      ArticlesLayout : JST['app/templates/hubsAndSpokes/articles.hbs'],
      MyExpertLayout : JST['app/templates/hubsAndSpokes/experts.hbs'],
      FaqsLayout :     JST['app/templates/hubsAndSpokes/faqs.hbs'],
      
      events: {
        "click .spoke-talk-to-counselor-button": "redirectToChat",
        "click .faqs-container-hub-a":"registerMixpanel"
      },

      registerMixpanel : function(e){

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

            mixpanel.track("Button Click", { "mediumSource" : "website", "itemName" : "FAQ in hubspoke Page"});
        }
      },
      
      redirectToChat : function(e) {

        var self = this;

        
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

              if ( !$(e.currentTarget).hasClass("disabled") ) {
                    var username = this.userModel.getUserName() ;
                    location.href = Utils.chatUrl() + username;
                    $(e.currentTarget).addClass("disabled");
              }
        }

      },

      trackMixpanel : function(mixpanelIdentifier, pageNo){

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

              if ( pageNo != undefined) {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test", "pageNo": pageNo});
              }
              else {
                mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : "Shape Test"});
              }


        }

      },

      shareOnFacebook: function(e) {

        var self = this;
        Utils.shareOnFacebook( self.socialShareResponse, self.url );

      },

      renderSelfHelp: function() {
         Backbone.history.navigate("/selfhelp",{trigger:true});
      },

      redirectToChat : function(e) {

        var self = this;
        self.trackMixpanel( "Talk to Expert from result screen" );
        var buttonDesc = $(e.currentTarget).attr("data-desc");
        if(!Utils.isLoggedIn()){
              Dispatcher.trigger("renderLogin", buttonDesc, "selfTest", "home_chat") ;
        }else{

          if ( !$(e.currentTarget).hasClass("disabled") ) {
              var username = this.userModel.getUserName() ;
             location.href = Utils.chatUrl() + username;
              $(e.currentTarget).addClass("disabled");
          }
        }

      },

      render: function() {

        var self = this;
        var urlFragment = Backbone.history.getFragment();


        $.ajax({
          url: Utils.scriptPath() + '/hubAndSpokes/spokes/'+ urlFragment + '.json',
          cache: false
        }).done(function(response){
          console.log( "response", response );
          var urlResponse = response;

          var metaTitle = response["h1"]["metaTitle"];
          var metaDescription = response["h1"]["metaDescription"];

          document.title = metaTitle;
          $('meta[name=description]').attr('content', metaDescription );
          $('meta[name=title]').attr('content', metaTitle );
          $('meta[property="og:description"]').attr('content', metaDescription );
          $('meta[property="og:title"]').attr('content', metaTitle );
          $('link[rel="canonical"]').attr('href', 'https://yourdost.com/' + urlFragment );
          self.$el.html( self.SpokeLayout( {response:urlResponse, hub:urlFragment, faqs:urlResponse["faqs"]} ) );  
          // self.surveyView.render();
          

        }).error(function(err){

          console.log( err );
        });



      }
    });

  SpokePage.prototype.remove = function() {

      this.$el.empty();
      this.$el.off();
      this.unbind();
  };

  SpokePage.prototype.clean = function() {

      this.remove();

  };

    return SpokePage;
});

