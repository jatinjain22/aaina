define([
  'jquery',
  'underscore',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'event/dispatcher',
  'model/users',
  'Swiper'
], function( $, _, Backbone, JST, Utils, Dispatcher, UserModel ) {

	var HubsFAQPage = Backbone.View.extend({

		el: 'main',

		initialize : function(){


		},

		FaqsMainLayout : JST['app/templates/hubsAndSpokes/faqpage.hbs'],
		FaqsLayout : JST['app/templates/hubsAndSpokes/faqs-active.hbs'],
		ArticlesLayout : JST['app/templates/hubsAndSpokes/articles.hbs'],
    MyExpertLayout : JST['app/templates/hubsAndSpokes/experts.hbs'],

		events:{

      'click .faq-page-hubs-li' : 'registerMixpanel'
		},

    registerMixpanel : function(){

       if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
             
          mixpanel.track("Button Click", { "mediumSource" : "website", "itemName" : "FAQ in FAQ Page"});
        }      
    },
		render : function(){


		    var self = this;
        var urlFragment = Backbone.history.getFragment();
        urlFragment = urlFragment.replace(/\?.*?$/, "").replace(/\/+$/, "");

        var urlFragmentArr = urlFragment.split("/");
        var urlFragmentLength = urlFragmentArr.length;

        var hubPage = "", spokePage = "", spokePageCamel = "";

        if(urlFragmentLength == 2){

          spokePage = urlFragmentArr[0];
          spokePageCamel = spokePage.charAt(0).toUpperCase()+""+spokePage.substr(1);

          this.$el.html(this.FaqsMainLayout({spokePage:spokePage,hubPage:spokePage, spokePageCamel:spokePageCamel}))
        }else if(urlFragmentLength == 3){

          spokePage = urlFragmentArr[1];
          hubPage = urlFragmentArr[0];
          spokePageCamel = hubPage.charAt(0).toUpperCase()+""+hubPage.substr(1);
          this.$el.html(this.FaqsMainLayout({spokePage:spokePage,hubPage:hubPage, spokePageCamel:spokePageCamel}))
        }


        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
             
          mixpanel.track("Home-Page", { "mediumSource" : "website", "itemName" : "HUB AND SPOKES FAQ"});
        }

        function getExperts(){

            var id = 1;

            if(hubPage == "addiction"){

              id = 22;
            }else if(hubPage == "anxiety"){

              id = 36;
            }else if(hubPage == "stress"){

              id = 11;
            }else{

              id = 1;
            }

          	$.ajax({

            	url: Utils.contextPath() + "/v1/counselor?category="+id+"&page_number=1",
          	}).done(function(response){

            	self.$el.find(".hub-spoke-experts-container").html(self.MyExpertLayout({}));
            	Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "EXPERTS DEALING WITH ANXIETY");

          	}).error(function(response){

          	})
        }

        function getFaqs(){

        	$.ajax({

            	url: Utils.scriptPath() + "/hubAndSpokes/hub/faq.json",
          	}).done(function(response){

          		self.$el.find(".hub-spoke-faqs-container").html(self.FaqsLayout({response:response[spokePage]}));
          		
          		$('.collapsible').collapsible({

			    	accordion : true
			    });
          	}).error(function(error){

          		console.log("Response ", error)
          	})
        }

        getExperts();
        getFaqs()

        var callSwiper = function(space){

            var mySwiper = new Swiper ('.articles-slider', {
                
              loop: true,
              slidesPerView: 3,
              nextButton: '.articles-direction-left',
              prevButton: '.articles-direction-right',
          
              spaceBetween: space,
              centeredSlides: true,
              autoplay: 3000,
              breakpoints: {
                // when window width is <= 320px
                320: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 5
                },
                // when window width is <= 480px
                480: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 5
                },
                // when window width is <= 640px
                640: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 10
                },
                768: {
                  slidesPerView: 'auto',
                  spaceBetweenSlides: 15
                },
                992: {
                  slidesPerView: 3,
                  spaceBetweenSlides: 15
                },
                1024: {
                  slidesPerView: 3,
                  spaceBetweenSlides: 15
                }
              }
            })  
        }

        $.ajax({
            method : "GET",
            dataType: 'jsonp',
            url : Utils.relatedArticlesBlogJson()+hubPage//'/scripts/json/blog.json'//Utils.blogJson()//'/scripts/json/blog.json'// 
        }).done(function(response){

            self.$el.find('.hub-spoke-articles-container').html( self.ArticlesLayout( {blogResponse:response.posts} ) );  
            var space = 30;
            if(Utils.isMobileDevice()){

              space = 5
            }
            
            callSwiper(space);   
          }).error(function(error){
              
            console.log(error);
          });
		}
	})

	HubsFAQPage.prototype.remove = function() {

      	this.$el.empty();
      	this.$el.off();
    	this.unbind();
	};

	HubsFAQPage.prototype.clean = function() {

	    this.remove();

	};

    return HubsFAQPage;
})