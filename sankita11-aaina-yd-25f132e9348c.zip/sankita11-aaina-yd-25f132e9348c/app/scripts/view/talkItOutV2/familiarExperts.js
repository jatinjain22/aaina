define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/talkItOut',
	'model/users',
	'view/leaveMessage/page' ,
], function( $, _, Backbone, JST, Dispatcher, Utils, TalkItOutModel, UserModel, LeaveMessage) {

	var ChatModal = Backbone.View.extend({
		el: "main",
		initialize: function() {

			this.model        = new TalkItOutModel() ;
			this.userModel    = new UserModel()      ;
			this.leaveMessage = new LeaveMessage()   ;

			this.familiarCounselors = [] ;

			_.bindAll(this)                                                  ;
			this.listenTo(Dispatcher, 'renderExpertSlider', this.renderHTML) ;			
		},
		events: {
			"click .expert-msg-btn"                 : "messageCounselor",
			"click .conversation-link"              : "redirectToMessages",
			"click .card-options"                   : "showRemoveCounselor",
			"click .remove-counselor"               : "showRemoveCounselorModal",
			"click .expert-chat-btn"                : "redirectToChat",
			"click .expert-appointment-btn"         : "redirectToAppointment",
			"click .experts-card"                   : "redirectToProfile"
 		},

 		redirectToProfile : function(e){
 			var cID = $(e.currentTarget).attr("cID");
 			var cName = $(e.currentTarget).attr("cName");

 			cName = cName.replace(/\s/g, '-');

 			location.href = "/counselor/" + cName + '-' + cID;

 		},

 		redirectToAppointment : function(e){

 			e.stopPropagation();

 			var categoryId = 'Others';
 			var counselorId = $(e.currentTarget).attr('id').split('-')[2];
 			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + counselorId + '&catID=' + categoryId, {trigger: true});
 			
 		},

		redirectToChat : function(e) {

 			e.stopPropagation();

			var chatURL = $(e.currentTarget).attr("data-href");

			if ( !$(e.currentTarget).hasClass("disabled") ) {

				if (  ( typeof fbq != 'undefined' ) ){
					fbq('track', 'Lead');					
				}

				var username =  this.userModel.getUserName() ;
				if(chatURL.search("start") > 1){
					chatURL = chatURL.replace(/\/chat\//, "/chatSession/");
					chatURL = chatURL.replace(/\/start/, '/');
				}else{
					chatURL = chatURL.replace(/\/chat\//, "/chatSession/");
					chatURL = chatURL;
				}

				var fromMsg = btoa("You have chatted with this user before");

				location.href = chatURL + "&username=" + username + "&from=" + fromMsg;
				$(e.currentTarget).addClass("disabled");
				
			}


		},

		showRemoveCounselor : function(e){

 			e.stopPropagation();

			if($(e.currentTarget).siblings(".remove-counselor").hasClass("hide")){
				$(e.currentTarget).siblings(".remove-counselor").removeClass("hide");
			}else{
				$(e.currentTarget).siblings(".remove-counselor").addClass("hide");
			}	
		},

		showRemoveCounselorModal : function(e){
 			e.stopPropagation();

			Utils.openPopup("remove-counselor-modal");

			var counselorName = $(e.currentTarget).attr("cName");

			$("#remove-counselor-modal #submit-remove-counselor").attr("cID", $(e.currentTarget).attr("cID"));
			$("#remove-counselor-modal #submit-remove-counselor").attr("cName", $(e.currentTarget).attr("cName"));

		},

		redirectToMessages : function(e){

 			e.stopPropagation();

			var counselorName = $(e.currentTarget).attr("cName");

			counselorName = counselorName.replace(/\s.*?$/, "");

			location.href = "/user/messages?s=" + counselorName;

		},
		messageCounselor : function(e){
 			e.stopPropagation();

			var counselorInfo = {
				id : $(e.currentTarget).attr("cID") ,
				name : $(e.currentTarget).attr("cName") ,
			};

			var buttonDesc = $(e.currentTarget).attr("data-desc");

			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "message", JSON.stringify(counselorInfo) ) ;
			}else{
				//this.leaveMessage.render( counselorInfo ) ;
				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorInfo.id	
					}
				});
			}

		},

		ExpertSlider     : JST['app/templates/talkItOut/familiarExpertsSlider.hbs'],
		ExpertCard     : JST['app/templates/talkItOut/expert_card.hbs'],
		renderHTML : function(container, showRemove, counselorList, from){

			if(showRemove == undefined){
				showRemove = 0;
			}

			$(container).html("");

			$(container).append(this.ExpertSlider({}));
			this.setElement($(container)).render(container, showRemove, counselorList, from);
		},
		render: function(container, showRemove, familiarCounselors, from) {
			var self = this ;

			/*var userID = self.userModel.getUserID() ;

			var url = self.model.url ;
			if(!url.match("familiar")){
				self.model.url = self.model.url + "?user=" + userID + "&familiar=true";				
			}

			//self.model.url = self.model.url + "?user=" + userID + "&familiar=true";
			self.model.fetch({
				success : function(response){
					console.log(response.attributes);

					var familiarCounselors 
					if(response.changed[0] != undefined){
						familiarCounselors = response.changed ;
					} else {
						familiarCounselors = response.attributes ;	
					}*/
					
					$.each(familiarCounselors, function(index, elem){

						var ratingHTML = "" ;
						for(index = 0; index < elem.rating; index ++ ){
							ratingHTML += '<i class="mdi-action-grade teal-text rating"></i>' ;
						}
						for(index = elem.rating; index < 5; index++){
							ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
						}

						var formattedDate = Utils.getDateString(elem.lastActive * 1000, "shortdate");

						$(container).find(".my-experts-row").append(self.ExpertCard({counselor : elem, formattedDate : formattedDate, showRemove: showRemove, ratingHTML : ratingHTML, from: from}));
					});

					// if(self.swiper){
					// 	self.swiper.destroy(true, true);
					// }


					if(familiarCounselors.length > 2 ){

						$(".my-experts-slider-prev").removeClass("hide");
						$(".my-experts-slider-next").removeClass("hide");
					}
					
						self.swiper = new Swiper ('.my-experts-slider', {

						    slidesPerView: 2,
						    nextButton: '.my-experts-slider-next',
						    prevButton: '.my-experts-slider-prev',
						    spaceBetween: 20,
						    centeredSlides: false,
						    preloadImages: true,
						    slidesOffsetBefore : 0, 
						    loop : false ,
						    breakpoints: {
							 
							    // when window width is <= 320px
							    320: {
							      slidesPerView: 1,
							      spaceBetweenSlides: 5
							    },
							    // when window width is <= 480px
							    480: {
							      slidesPerView: 1,
							      spaceBetweenSlides: 5
							    },
							    // when window width is <= 640px
							    600: {
							      slidesPerView: 1,
							      spaceBetweenSlides: 10
							    },
							    768: {
							      slidesPerView: 2,
							      spaceBetweenSlides: 20
							    },
							    992: {
							    	slidesPerView: 2,
							    	spaceBetweenSlides: 20
							    },

							}
						});

					/*}else{
						$(".my-experts-row li").first().css("margin-right", "20px");
					}*/



					$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
					}).done(function(response){

						_.each(response, function(value, key){							
							if( value.status == "true" ){
								$("#chat-btn-" + key).removeClass("hide");
								$("#chat-btn-" + key).attr("data-href", value.url);

								$("#chat-mobile-btn-" + key).removeClass("hide").css({'display':'inline-block'});
								$("#chat-mobile-btn-" + key).attr("data-href", value.url);

							}
						});

					}).error(function(error){

					});
	

			/*	}
			});*/


			return this;
		}
	});

	ChatModal.prototype.remove = function() {};

	ChatModal.prototype.clean = function() {};

	return ChatModal;
});
