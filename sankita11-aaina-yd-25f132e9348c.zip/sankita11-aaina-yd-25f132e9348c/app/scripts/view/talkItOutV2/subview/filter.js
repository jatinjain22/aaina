define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'model/filter',
	'utils',
	'purl'
], function($,_, Backbone, JST, FilterModel, Utils ) {

	var FilterView = Backbone.View.extend({
		
		el: "main",
		initialize: function() {
			this.filterModel = new FilterModel() ;
		},
		events: {
			'click #filter-close-btn'   : 'hideFilter',
		},
		hideFilter : function(e){
			$("#filter-mobile").animate({'top': '105%'}, "slow") ;
			$("body").css("overflow-y", "auto");
			$(".talkItOutV2-filter-mob-reset-apply").addClass("hide");          

		},
		FilterLayout : JST['app/templates/talkItOut/filter_v2.hbs'],
		render: function() {

			var self = this ;
			console.log('hello filter');
			this.filterModel.fetch({
				success : function( response ) {
					// delete response.attributes[0];
					delete response.attributes[3];
					// for (var i =5; i<response.attributes.length; i++) {
						// console.log('delete');
					delete response.attributes[5];
					delete response.attributes[6];
					delete response.attributes[7];
					delete response.attributes[8];
					delete response.attributes[9];

					var tempAttr = response.attributes[2];
					response.attributes[2] = response.attributes[4];
					response.attributes[4] = tempAttr;

					// }
					response.attributes[1]["filters"].reverse();
					var filtersJson = response.attributes ;
					console.log( "filtersJson ", filtersJson );
					var isLoggedIn = Utils.isLoggedIn() ;
					delete filtersJson[0];
					self.$el.find("#left-filter-block").html( self.FilterLayout({ filterData : filtersJson, isLoggedIn : isLoggedIn }) );
					var url = window.location.href ;
		    		url = url.replace("/talkItOut", "" );
					var categoryFilter = $.url( url ).param('category') ;
					
					if(Utils.isMobileDevice()){

						if(categoryFilter){

							$("#mobile-category_"+categoryFilter).attr("checked", "checked");
							if($(".filter-category input:checked").length > 0 ){	

								$(".filter-mob-cnt").removeClass("hide");
								$(".filter-mob-cnt").html($(".filter-category input:checked").length);
							}else{

								$(".filter-mob-cnt").addClass("hide");					
							}
						}
					}else{

						if(categoryFilter){

							$("#category_" + categoryFilter ).attr("checked", "checked")
						}
					}
					var searchInput = $('.talkItOutV2-filter-search');
					searchInput.keyup(function(e) {
						console.log( $(e.currentTarget) );
						console.log('hello');
					    var filter = $(this).val().toUpperCase();

					    console.log( 'filter', filter );
					    var lis = $(this).closest('form').next('ul').find('li');
					    console.log( 'lis', lis );
					    for (var i = 0; i < lis.length; i++) {
					        var name = $(lis[i]).find('label').html();
					        console.log('name', name);
					        console.log('hello 1');
					        if (name.toUpperCase().indexOf(filter) == 0) {
					        	console.log('match')
					            lis[i].style.display = 'list-item';
					        } 
					        else {
					        	console.log('not match');
					            lis[i].style.display = 'none';
					        }
					    }
					});

				},
				error : function(error){
					console.log(error) ;
				}
			});


			
		}
	});

	FilterView.prototype.remove = function() {
		this.undelegateEvents();
	};

	FilterView.prototype.clean = function() {
		this.unbind();
    	this.remove();
 
    	delete this.$el;
    	delete this.el;

	};

	return FilterView;
});