define([
	'jquery',
	'underscore',
	'backbone',
	'../../../precompiled-templates',
	'vm',
	'model/counselors_list',
	'view/talkItOutV2/subview/filter',
	'view/leaveMessage/page' ,
	'utils',
	'event/dispatcher',
	'model/users',
	'introjs',
	//'view/loaderModal/page',
	'view/home2/subview/book_appointment',
	'purl',
	'jcarousel'
], function($,_, Backbone, JST, Vm, CounselorsListModel, FilterView, LeaveMessageView, Utils, Dispatcher, UserModel, introJs, BookAppointmentView) {

	var CounselorsView = Backbone.View.extend({

		el: "main",
		initialize: function(frompage) {
			this.counselorListModel = new CounselorsListModel() ;
			this.filterView         = new FilterView()          ;
			this.userModel          = new UserModel()           ;
			this.leaveMessage       = new LeaveMessageView();
		//	this.loaderModalView    = new LoaderModalView()     ;

			this.bookAppointmentView = new BookAppointmentView();

			this.firstCounselor     = 0                         ;

			_.bindAll(this, "reRender")                ;
			Dispatcher.bind('reRender', this.reRender );
			this.amount = 0;
			this.socialShareResponse = {};
			this.donateAllowed = false;
			this.shareAllowed = true;
			this.storyAllowed = true;

			this.listStart = 0 ;
			this.offset = 8 ;

			this.categoryNameMap = {
				3: 'Love-Relationship',
				1: 'Career',
				24: 'Sexual-Wellness',
				18: 'Marriage Issues',
				5: 'Others'
			};
			this.statusInterval = 0;
			this.expertInterval = 0;

			var path = window.location.pathname
    		if( path.search("counsellors-in") > -1){

    			this.city = path.split("-")[path.split("-").length -1]
    		}
    		if( path.search("-counsellors") > -1){

    			this.cat = path.replace("-counsellors", "").replace("/","")
    		}
		},
		events: {
			'click #filter-large input[type=checkbox]' : 'filterCounselors' ,
			'click #filter-large input[type=radio]' : 'filterCounselors' ,
			'click #filter-mobile input[type=checkbox]' : 'showHideApply',
			'click #filter-mobile input[type=radio]' : 'showHideApply',
			'keyup #search-counselor' : 'showHideCloseBtn',
			'keydown #search-counselor' : 'showHideCloseBtn',
			'keypress #search-counselor' : 'searchCounselors',
			'submit #search-form-mobile' : 'searchCounselors',
			'click .search-close-btn' : 'clearSearch',
			'click #filter-check-btn' : 'filterCounselors',
			'click .filter-name' : 'filterCounselors' ,
			'click #online_true' : 'filterCounselors',
			'click .favorite-section'  : 'favoriteUser',
			'click .counselor-list-card-action-chat': 'chatCounselor',
			'click .chat-counselor'    : 'chatCounselor',
			'click .special-friend-link': 'chatSF' ,
			'click .message-counselor'  : 'messageCounselor',
			'click .counselor-list-card-action-message': 'messageCounselor',
			//'click .clear-filter' : 'clearFilters',
			'click #filter-mob-reset' : 'clearFilters',
			'click .clear-all-filter': 'clearAllFilters',
			'click .clear-single-filter' : 'clearSingleFilter',
			'click .fclear' : 'clearFilterBar' ,
			'click #coupon_notification_book_now' : "bookNow",
			'click #coupon_notification_skip' : "skipNotification",
			'click #try_again_promo' : "applyPromoPopup",
			'click #apply_promo' : "applyPromo",
			"submit #download-ebook-form" : "downloadWithEmail",
			"click #download-ebook-modal .popup-close" : "closeEbookEmailPopup",
			"click .banner-high-traffic-div a": "leaveMessageBanner",
			"click .banner-high-traffic-row-close": "closeHighTrafficBanner",
			"click .talkItOutV2-header-filter-category": "filterCounselors",
			"click .talkItOut-view-more-div": "viewMoreCounselors",
			"click .talkItOutV2-mob-browse-experts": "browseInMobile",
			"click .expand-collapse-single-filter": "expandFilter",

			'click .experts-donation-card-donation-amount-span' : 'selectAmountDonationCard',
			'keyup .experts-donation-card-donation-input-amount' : 'inputDonationAmountDonationCard',
			'click .experts-donation-card-donate-now-btn' : 'donateNowDonationCard',
			'click .experts-donation-head-spread-btn' : 'spreadTheWordExpertsCard',
			'click .close-experts-donation-card' : 'closeExpertsDonationCard',
			'click .close-experts-spread-card' : 'closeExpertsShareCard',
			'click .counselor-list-card-action-appointment': 'bookAppointment',
			"click .experts-donation-card-donate-btn":"flipDonateCard",
		},
		trackMixpanelforSpecialCard:function(){
			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	            mixpanel.track('Experts Donate Card', {'mediumSource' : 'website', 'itemName': 'Donate Card Served'});

	        }
	        	
		},
		flipDonateCard:function(){
			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	            mixpanel.track('Experts Donate Card', {'mediumSource' : 'website', 'itemName': 'Flip Donate Card'});

	        }

		},
		addDonationAndExpertSharedCard: function(randNo1, randNo2, index){

			var self = this;
			if(parseInt(randNo2) == index){

				console.log("Random-1 ", randNo1);

				if(!Utils.isLoggedIn()){

					if( !$(".experts-spread-card").is(":visible")
						&&
						typeof $.cookie("closedExpertsShareCard") == 'undefined'
						&&
						self.shareAllowed
						&&
						typeof $.cookie("expertsDonateShared") == 'undefined'
					){
						if (self.checkIfFilterIsShown()) {
							self.$el.find("#counselors-list-block").append(self.FilteredSpreadTheWordCardLayout());
						} else {
							self.$el.find("#counselors-list-block").append(self.SpreadTheWordCardLayout());
						}

					}
				}else{

					var userId = self.userModel.getUserID();
					if( !$(".experts-spread-card").is(":visible")
						&&
						typeof $.cookie("userClosedExpertsCard"+userId) == "undefined"
						&&
						self.shareAllowed
						&&
						typeof $.cookie("expertsDonateShared") == 'undefined'
					){

						if (self.checkIfFilterIsShown()) {
							self.$el.find("#counselors-list-block").append(self.FilteredSpreadTheWordCardLayout());
						} else {
							self.$el.find("#counselors-list-block").append(self.SpreadTheWordCardLayout());
						}
					}
				}
			}
			if(parseInt(randNo1) == index){
				console.log(index);
				console.log("Randoom-2 ", randNo2)

				if(!Utils.isLoggedIn()){


					if( !$(".experts-donation-card").is(":visible") && Utils.isLoggedIn()
						&&
						typeof $.cookie("closedExpertsDonationCard") == 'undefined'
						&&
						self.donateAllowed
					){
						if (self.checkIfFilterIsShown()) {
							
							self.$el.find("#counselors-list-block").append(self.FilteredDonateCardLayout());
						} else {
							
							self.$el.find("#counselors-list-block").append(self.DonateCardLayout());
						}

					}
				}else{

					var userId = self.userModel.getUserID();
					if( !$(".experts-donation-card").is(":visible")
						&&
						self.donateAllowed
						&&
						typeof $.cookie("userClosedDonationCard"+userId) == 'undefined'
					){

						if (self.checkIfFilterIsShown()) {
							self.trackMixpanelforSpecialCard();
							self.$el.find("#counselors-list-block").append(self.FilteredDonateCardLayout());
						} else {
							self.trackMixpanelforSpecialCard();
							self.$el.find("#counselors-list-block").append(self.DonateCardLayout());
						}

					}
				}
			}
			$(".experts-donation-card").height($(".counselor-list-card").height());
			$(".experts-spread-card").height($(".counselor-list-card").height());

		},
		bookAppointment: function(e) {

			var self = this;
			var buttonDesc = $(e.currentTarget).attr("data-desc");
			var counselorId = $(e.currentTarget).attr('id').split('-')[2];
			var categoryIds = self.getSelectedCategory();
			var categoryId;
			if ( categoryIds == undefined ) {
				categoryId = 'Others';
			} else {
				categoryId = self.categoryNameMap[categoryIds.split(',')[0]];
			}


			var extraParams = {
									'counselorId': counselorId,
									'categoryId': categoryId
							  	};

			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + counselorId + '&catID=' + categoryId, {trigger: true});



		},
		closeExpertsDonationCard : function(e){

			if(!Utils.isLoggedIn()){

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	            	mixpanel.track('Experts Donate Card', {'mediumSource' : 'website', 'itemName': 'Close Experts Donation Card'});

	        	}
	        	$.cookie("closedExpertsDonationCard", "yes", {expires: 30, path:'/'});
	        }else{

	        	var userId = self.userModel.getUserID();

	        	$.cookie("userClosedDonationCard"+userId, "yes", {expires: 30, path: '/'})
			}
        	$(".experts-donation-card").parent('.experts-card-v2').addClass("hide");

		},
		closeExpertsShareCard : function(e){

			if(!Utils.isLoggedIn()){

				if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	        	    mixpanel.track('Experts Share Card', {'mediumSource' : 'website', 'itemName': 'Close Experts Share Card'});

	        	}

	        	$.cookie("closedExpertsShareCard", "yes", {expires: 30, path:'/'});
	        }else{

	        	var userId = self.userModel.getUserID();

	        	$.cookie("userClosedExpertsCard"+userId, "yes", {expires: 30, path: '/'})
	        }

	        $(".experts-spread-card").parent('.experts-card-v2').addClass("hide");
		},
		spreadTheWordExpertsCard : function(e){

			var self = this;

			var targetElement = $(".experts-donation-head-spread-btn");
	        var loaderElement = $(".experts-card-spread-the-word-loader");
	        var mixpanelEvent = "Expert Card Spread The Word";

	        targetElement.addClass("hide");
	        loaderElement.removeClass("hide");

	        self.socialShareResponse["utm_campaign"] = "spread_expertscard"

	        Utils.shareOnFacebook( self.socialShareResponse, targetElement, loaderElement, mixpanelEvent ).then(function(response) {

        		console.log("Response 111---", response)

	        	if(response){

	        		console.log("Response ---", response)
	            	self.updateUserStatusShared(targetElement);
	            	targetElement.hide();
	            	targetElement.after('<div class="facebook-share-success">Thank you for spreading the word!</div>');
	            }else{

	            	targetElement.removeClass("hide");
	        		loaderElement.addClass("hide");

	            }
	        }, function(error) {

	            console.log("Failed!", error);
	        });
		},
		updateUserStatusShared : function(ele){

			if(!Utils.isLoggedIn()){


				$.cookie("expertsDonateShared", "yes", {path: '/', expires : 60})
				setTimeout(function(){

					$(".experts-spread-card").parent('.experts-card-v2').addClass("hide")
				}, 2000)
			}else{

				var userId = this.userModel.getUserID() ;
				var dataToSend = {
									"allowed":0,
									 "userId":userId,
									 "type":"SHARE"
								};
				$.ajax({
	                url : Utils.contextPath() + "/v2/users/"+userId+"/intrupts/status",
	                data:JSON.stringify(dataToSend),
	                method : 'POST',
					dataType: "JSON",
	                contentType: "application/json; charset=utf-8",
	          	}).done(function(response){

	          		ele.hide();
	          		$.cookie("expertsDonateShared", "yes", {path: '/', expires : 60})
					$(".experts-spread-card").parent('.experts-card-v2').addClass("hide")

	          	}).error(function(error){

	                console.log(error)
	                $.cookie("expertsDonateShared", "yes", {path: '/', expires : 60})
					$(".experts-spread-card").parent('.experts-card-v2').addClass("hide")
	          	});
	        }
		},

		isInt : function (value) {

		  	return 	!isNaN(value) && parseInt(Number(value)) == value && !isNaN(parseInt(value, 10));
		},
		selectAmountDonationCard : function(e){

			if($(e.currentTarget).hasClass("experts-donation-card-input-donation")){

				return;
			}

			$(".experts-donation-card-donation-amount-error").addClass("hide").html("")

			if($(e.currentTarget).hasClass("selected")){

				$(".experts-donation-card-donation-amount-span").removeClass("selected")
				$(e.currentTarget).removeClass("selected")
				this.amount = 0;
			}else{

				$(".experts-donation-card-donation-amount-span").removeClass("selected")
				$(e.currentTarget).addClass("selected")
				this.amount = $(e.currentTarget).attr("data-value");
			}

			if(this.amount == 0){

				this.amount = parseInt($(".experts-donation-card-donation-input-amount").val());
			}
		},
		inputDonationAmountDonationCard : function(e){

			jQuery(".experts-donation-card-donation-amount-span").removeClass("selected")
			this.amount = 0;
			this.amount = parseInt($(".experts-donation-card-donation-input-amount").val());

			if(!this.isInt(this.amount)){

				jQuery(".experts-donation-card-donation-amount-error").removeClass("hide").html("Please select or enter amount")
				return false;
			}
			if(this.amount < 50){

				$(".experts-donation-card-donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}

			$(".experts-donation-card-donation-amount-error").addClass("hide").html("")
			this.amount = parseInt($(".experts-donation-card-donation-input-amount").val());
		},
		donateNowDonationCard : function(){

			$(".experts-donation-card-donation-amount-error").addClass("hide").html("")

			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

	            mixpanel.track('Experts Donate Card', {'mediumSource' : 'website', 'itemName': 'Clicked Experts Donate Now'});

	        }

			var donationAmount = this.amount;
			console.log("Amount ",donationAmount);

			if(!donationAmount || donationAmount == 0 ){

				$(".experts-donation-card-donation-amount-error").removeClass("hide").html("Please select or enter amount")
				return false;
			}
			if(this.amount < 50){

				$(".experts-donation-card-donation-amount-error").removeClass("hide").html("Please avoid making a donation of less than Rs.50/- as the processing costs make it unviable for us.")
				return false;
			}
			$(".experts-donation-card-donate-now-btn").find("span").html("Redirecting...")
			$(".experts-donation-card-donation-amount-error").addClass("hide").html("")

			var userID = this.userModel.getUserID() ;

			$.ajax({
				url         : Utils.contextPath() + '/v1/user/'+ userID +'/donate/'+ donationAmount+'?source=virality',
				contentType : "application/json; charset=utf-8",
				xhrFields   : {
			    	withCredentials: true
				},
			}).done(function(response){

				if( !response.error){

					location.href = response.uri;
				}else{

					$(".experts-donation-card-donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
				}

				$(".experts-donation-card-donate-now-btn").find("span").html("Pay Securely")

			}).error(function(response){

				$(".experts-donation-card-donate-now-btn").find("span").html("Pay Securely")
				$(".experts-donation-card-donation-amount-error").removeClass("hide").html("Something went wrong. Please try again later.")
			})
		},
		expandFilter: function(e) {
			var currentTarget = $(e.currentTarget);
			if ( currentTarget.hasClass('collapseSingleFilter') ) {
				currentTarget.removeClass('collapseSingleFilter');
				$($(currentTarget).closest('div').nextAll('.collection')[0]).removeClass('collapseFilterList');
				$(currentTarget).closest('div').next('form').removeClass('collapseFilterForm');
			} else {
				currentTarget.addClass('collapseSingleFilter');
				$($(currentTarget).closest('div').nextAll('.collection')[0]).addClass('collapseFilterList');
				$(currentTarget).closest('div').next('form').addClass('collapseFilterForm');
			}

		},
		clearAllFilters: function(e) {

			var self = this;

			if($(".filter-category input:checked").length > 0){
				$(".filter-category input:checked").attr('checked', false) ;
				$(".filter-mob-cnt").addClass("hide");

			}
			if ( $('.talkItOutV2-header-filter-category').hasClass('categorySelected') ) {
				$('.talkItOutV2-header-filter-category').removeClass( 'categorySelected' );
			}
			$('.talkItOutV2-counselor-filter-tags-section .fclear').remove();

			if(self.selectedSort != undefined){
				self.selectedSort.removeClass('selected-sort');	
			}
			
			this.filterCounselors(e);

		},
		browseInMobile: function(e) {

			if ( Utils.isMobileDevice() ) {
				if ( !$('.talkItOutV2-mobile-header-bgImg').hasClass('hide') ) {
					$('.talkItOutV2-mobile-header-bgImg').addClass('hide');
				}
				$('.filter-counselor-section-2').removeClass('hide');
				$('.mob-right').removeClass('hide');
				$('#start-chatting-block').removeClass('hide');
			}
		},
		viewMoreCounselors: function(e) {

			var self = this;
			var currentTarget = $(e.currentTarget);
			console.log( 'viewMoreCounselors', currentTarget );
			currentTarget[0].remove();
			var filterQuery = localStorage.getItem( "filterQuery" );

	    	console.log( ' filterQuery from loadCounselors '+ filterQuery );

			if( filterQuery == null || filterQuery == undefined ){
				filterQuery = "" ;
			}
			if(localStorage.getItem("searchQuery")){
				filterQuery += "&" + localStorage.getItem( "searchQuery" ) ;
			}

    		var pageNo = this.counselorListModel.get( "page_number" );
    		console.log( "page no "+ pageNo );
    		pageNo += 1;
    		this.loadCounselors( pageNo, filterQuery );
    		this.counselorListModel.set( "page_number" , pageNo );

		},
		selectCategory: function(e) {

			var currentTarget = $(e.currentTarget);

			if ( currentTarget.hasClass('talkItOutV2-header-filter-category') ) {

				if ( $('.talkItOutV2-header-filter-category').hasClass('categorySelected') ) {
					$('.talkItOutV2-header-filter-category').removeClass( 'categorySelected' );
				}

				var targetID    = $(e.currentTarget).attr("id") ;
				var filterLabel = $(e.currentTarget).find('.talkItOutV2-header-filter-category-text').html();
				var headerFilter = targetID;
				sessionStorage.setItem('headerFilter', headerFilter);
				if( $(".talkItOutV2-counselor-filter-tags-section .chip").hasClass('category-chip') ) {
					$('.category-chip').remove();
				}
				if (Utils.isMobileDevice()) {
					$(".talkItOutV2-counselor-filter-tags-mobile-section").append('<div class="chip fclear z-depth-1 cpointer category-chip"'+ 'data-desc="filter clear '+ filterLabel +'"' +'id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i>' + '</div>' );
				} else {
					$(".talkItOutV2-counselor-filter-tags-section").append('<div class="chip fclear z-depth-1 cpointer category-chip"'+ 'data-desc="filter clear '+ filterLabel +'"' +'id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i>' + '</div>' );
				}


				if ( $('.talkItOutV2-counselor-filter-tags-col').hasClass('hide') ) {
					$('.talkItOutV2-counselor-filter-tags-col').removeClass('hide');
				}

				currentTarget.addClass('categorySelected');
				this.browseInMobile();
			}

		},

		getSelectedCategory: function() {

			var currentTarget = $('.talkItOutV2-header-filter-category.categorySelected');
			var category = currentTarget.attr("data-category");
			console.log( 'this is the category', category );
			return category;

		},

		getParentCat : function() {

			var currentTarget = $('.talkItOutV2-header-filter-category.categorySelected');
			var category = currentTarget.attr("data-parent-category");
			console.log( 'this is the category', category );
			return category;

		},

		closeHighTrafficBanner: function (e) {
			console.log('hello');
			$('.banner-high-traffic-row-talkitout').addClass('hide');
		},
		closeEbookEmailPopup : function(e){
    		Utils.closePopup('download-ebook-modal');
    	},

    	downloadEbookCall: function( postId, categoryId, email ) {

    		var emailJSON = {
				"email": email
			}
			console.log ( postId );
    		$.ajax({
				method : "POST",
				dataType: "JSON",
				url: Utils.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)
			}).done(function( response ) {
				console.log( response );


				//Utils.displaySuccessMsg("Thank you. The eBook download link has been sent to your email id");
				// setTimeout( function(){
				// 	location.href = "#talkItOut";
				// }, 3000)
				//redirecting to parenting category

				Backbone.history.navigate("/talkItOut?category=", {trigger: true});

				if (categoryId == 100) {
        				Backbone.history.navigate("/talkItOut", {trigger: true});
        		}
        		else {
        				Backbone.history.navigate("/talkItOut?category="+ categoryId, {trigger: true});
        		}

        		$.ajax({
					method : "GET",
					url : Utils.scriptPath() + "/ebooksOnHomePage.json",
					cache: "false"
				}).done(function(response){
					var successMsg = response[postId]['successMsg'];
					Utils.displaySuccessMsgWithDelay(successMsg, 8000);
				});
			});

    	},
    	downloadWithEmail : function(e){

    		var self = this;
        	setTimeout(function(){
    			if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

            		console.log( 'inside mixpanel' );
            		mixpanel.track('Submit', {'medium' : 'website', 'itemtype': 'submit popup', 'itemName': ' ebookPrompt_enterEmail'});

          		}
          	}, 2000);

    		var url = window.location.href ;
			url = url.replace("/talkItOut", "" );

			var postID = $.url( url ).param('postId') ;
			var categoryId = $.url( url ).param('category');


    		var email = $("#download-ebook-email").val() ;
    		$("#ebook-email-error" ).addClass("hide");
			var emailRegex = new RegExp("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$") ;

			if(email.length == 0 || !email.match(emailRegex)){
				$("#ebook-email-error" ).removeClass("hide");
				$("#ebook-email-error" ).html("Please give a valid email id") ;
				return 0 ;
			}

			Utils.closePopup('download-ebook-modal');
			self.downloadEbookCall(postID, categoryId, email);


    	},
		showHideApply : function(e){
			$(".talkItOutV2-filter-mob-reset-apply").removeClass("hide");
		},
		clearFilterBar : function(e){
			var barID = $(e.currentTarget).attr("id") ;
			var filterID = barID.replace("bar_", "")  ;

			this.removeFromCarousel(filterID)                 ;

			$("#" + filterID).attr("checked", false)  ;
			this.filterCounselors(e)                  ;
		},
		clearSingleFilter : function(e){

			var self = this ;
			var filterID = $(e.currentTarget).attr("id") ;
			var filterType = filterID.split("-")[1] ;
			if($("input[name="+ filterType +"]:checked").length){
				$.each($("input[name="+ filterType +"]:checked"), function(i, elem){
					var thisFilterID = $(elem).attr("id");
					self.removeFromCarousel(thisFilterID);
				});
				$("input[name="+ filterType +"]:checked").attr('checked', false) ;
				this.filterCounselors(e);
			}

		},
		removeFromCarousel: function(filterID){
			$("#bar_" + filterID).remove() ;

			var filterChips = $(".talkItOutV2-counselor-filter-tags-section .chip");
			var filterCategoryChips = $(".talkItOutV2-counselor-filter-tags-section .category-chip");
			var filterCategoryChipsMobile = $(".talkItOutV2-counselor-filter-tags-mobile-section .category-chip");

			if (Utils.isMobileDevice()) {

				if (filterCategoryChipsMobile.length == 0) {
					$('.talkItOutV2-header-filter-category').removeClass('categorySelected');
				}

			} else {

				if (filterCategoryChips.length == 0) {
					$('.talkItOutV2-header-filter-category').removeClass('categorySelected');
					// $('.talkItOutV2-counselor-filter-tags-mobile-section').addClass('hide');
				}
				if ( filterChips.length == 1 ) {
					$('.talkItOutV2-counselor-filter-tags-col').addClass('hide');

				}
			}


			var jcarouselWidth = $(".jcarousel").width() ;
			var filterbarsWidth = 0                      ;

			var allSelectedBars = $(".fclear") ;
			_.each(allSelectedBars, function(elem){
				filterbarsWidth += $(elem).width() ;
			});

			if( filterbarsWidth + 60  < jcarouselWidth ) {
				$(".filter-scroll-left").css("visibility", "hidden");
				$(".filter-scroll-right").css("visibility", "hidden");
			}
			$('.jcarousel').jcarousel('reload');


			if($(".filter-category input:checked").length <= 0){
				$(".filter-scroll-left").addClass("hide");
				$(".filter-scroll-right").addClass("hide");

				$(".filter-cnt-big").addClass("hide");
			}

			var title = "Online Counselors, Psychologists, Life Coaches | YourDOST"
			var desc = "List of career experts, psychologists counsellors at YourDOST to help you out with problems or need advice in career, relationships, parenting & more in India"
				
			if( typeof this.city != 'undefined' && this.city != '' ){

				window.history.pushState({urlPath : "/talkItOut?from=showAllExperts"}, "talkItOutPage", "/talkItOut?from=showAllExperts")
				this.changeMeta(title,desc);
			}
			if( typeof this.cat != 'undefined' && this.cat != '' ){

				window.history.pushState({urlPath : "/talkItOut?from=showAllExperts"}, "talkItOutPage", "/talkItOut?from=showAllExperts")
				this.changeMeta(title,desc);
			}


		},
		clearFilters : function(e){
			if($(".filter-category input:checked").length > 0){
				$(".filter-category input:checked").attr('checked', false) ;
				this.filterView.hideFilter() ;
				$(".filter-mob-cnt").addClass("hide");
				this.filterCounselors(e);
			}
		},
		leaveMessageBanner: function(e) {


			var buttonDesc = 'leaveMessageBanner';
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "message", '' ) ;
			}else{

				this.leaveMessage.render(  ) ;

			}

		},
		messageCounselor : function(e){

			var self = this;

			console.log( 'messageCounselor ', $(e.currentTarget.nextElementSibling).html() );
			var counselorIdName = $(e.currentTarget.nextElementSibling).html();
			var counselorId = counselorIdName.split("_")[0];
			var counselorName = counselorIdName.split("_")[1];

			var counselorInfo = {
				id : counselorId ,
				name : counselorName ,
			};

			var buttonDesc = $(e.currentTarget).attr("data-desc");

			if(!Utils.isLoggedIn()){

				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "quickMessage", counselorInfo ) ;


			}else{
				/*if (counselorId == '101') {
					Dispatcher.trigger('messageQuickCheck', 'demo', counselorInfo );
				} else {
					Dispatcher.trigger('messageQuickCheck', 'direct', counselorInfo );
				}*/
				Dispatcher.trigger("openComposeMessage", {
					info: {
						recipientId: counselorId
					}
				});
			}

		},
		chatSF : function(){

			var buttonDesc = $(e.currentTarget).attr("data-desc");
			if(!Utils.isLoggedIn()){
				Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "home_chat" ) ;
			}else{
				Dispatcher.trigger('chatQuickCheck', 'demo', 0, "","","talkItOut");

				/*var username     = this.userModel.getUserName() ;
				var chatStartUrl = Utils.chatUrl() + username   ;
				location.href =  chatStartUrl ;*/
				//this.loaderModalView.render(username, Utils.chatDemoWorkgroup(), chatStartUrl);

				//this.loaderModalView.render(username, Utils.chatDemoWorkgroup(), chatStartUrl);
			}

		},

		chatCounselor : function(e){

			var currentTarget = $(e.currentTarget);
			var id = $(currentTarget).attr('id');
			var counselorId = id.split('-')[2];
			var chatURL = $(e.currentTarget).attr("data-href") ;
            if(chatURL === undefined)
                return true;
			var buttonDesc = $(e.currentTarget).attr("data-desc");

			var selectedFilters = localStorage.getItem("filterQuery");
			var parentCatFilter = selectedFilters.match(/parent_category=(.*?)(\&|$)/);

			var parentCategory = "";
			if(parentCatFilter != null){
				parentCategory = parentCatFilter[1];
				chatURL += "&category=" + parentCategory ;
			}

			if(!Utils.isLoggedIn()){
				if (counselorId == '101') {
					Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "home_chat" ) ;
				} else {
					Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "counselorChat", chatURL + 'BREAKBREAK' +counselorId ) ;
				}

			}else{
				if (counselorId == '101') {
					Dispatcher.trigger('chatQuickCheck', 'demo', counselorId, chatURL, "", "talkItOut" );
				} else {
					Dispatcher.trigger('chatQuickCheck', 'direct', counselorId, chatURL, "", "talkItOut" );
				}
			}
		},
		favoriteUser : function(e){
			e.stopPropagation();
			e.preventDefault() ;

			var currentObj = $(e.currentTarget);

			if( currentObj.children().attr("class").match("mdi-action-favorite-outline") ){
				currentObj.children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
				currentObj.children().removeClass('grey-text').addClass('red-text') ;
			}else{
				currentObj.children().removeClass('mdi-action-favorite').addClass('mdi-action-favorite-outline') ;
				currentObj.children().removeClass('red-text').addClass('grey-text') ;
			}

			var userID      = this.userModel.getUserID() ;
			var targetID    = currentObj.attr("id") ;
			var counselorID = targetID.split("-")[1] ;
			$.ajax({
				method : "POST" ,
				url    : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/'+ counselorID +'/favourite'  ,
				statusCode:{
            		401 : function(){
                		//location.href = "/logout?r=talkItOut"  ;
                		Backbone.history.navigate("/logout?r=talkItOut", {trigger: true});
            		},
	        	},

			}).done(function(response){
				//console.log(response) ;
			}).error(function(error){
				console.log("Error") ;
			});

			return false ;
		},
		clearSearch : function(e){
			$("#search-counselor").val("") ;
			$(".search-close-btn").hide();
			$("#search-input-field").removeClass("l11").addClass("l12") ;
			$("#search-counselor").removeClass("valid") ;
			$("#search-form .mdi-action-search").removeClass("active") ;

			localStorage.setItem("searchQuery", "") ;
			localStorage.setItem("searchClicked", 0 ) ;
			this.reRender( localStorage.getItem("filterQuery") ) ;
		},
		searchCounselors : _.debounce(function(e){

			var searchTerm = $("#search-counselor").val() ;

			var searchQuery = "name=" + searchTerm ;
			if(searchTerm == '' || searchTerm == null || searchTerm == undefined ){
				searchQuery = '' ;
			}
			var filterQuery = "" ;
			if( localStorage.getItem("filterQuery") ){
				filterQuery += localStorage.getItem("filterQuery") + "&" + searchQuery ;
			}else{
				filterQuery += searchQuery ;
			}

			localStorage.setItem("searchQuery", searchQuery ) ;
			localStorage.setItem("searchClicked", 1 ) ;

			this.reRender( filterQuery ) ;
			return false ;
		}, 1000),
		showHideCloseBtn: function(e){
			if( $("#search-counselor").val().length > 0 ){
				$("#search-input-field").removeClass("l12").addClass("l11") ;
				$(".search-close-btn").show();
			}else{
				$("#search-input-field").removeClass("l11").addClass("l12") ;
				$(".search-close-btn").hide();
				if(localStorage.getItem("searchClicked") == 1){
					localStorage.setItem("searchClicked", 0) ;
					this.reRender(localStorage.getItem("filterQuery"));
				}
				localStorage.setItem("searchQuery", "") ;
			}
		},
		getSelectedFilters : function(e){

			var self = this ;
			var checkedFilters = $(".filter-category input:checked") ;
			var filterQuery = ""
			_.each(checkedFilters, function( checkedElem ){
				var filterChecked = checkedElem.attributes.id.value ;
				filterChecked = filterChecked.replace( /^.*?_(.*?)$/, "$1" ) ;

				filterChecked = filterChecked.replace(/BRACKETO/g, "(");
				filterChecked = filterChecked.replace(/BRACKETC/g, ")");

				var filterNameChecked = checkedElem.attributes.name.value ;
				if(filterNameChecked == "favourite"){
					var userID = self.userModel.getUserID() ;
					filterQuery += filterNameChecked + "=" + filterChecked + "&user=" + userID + "&" ;
				}else{
					filterQuery += filterNameChecked + "=" + filterChecked + "&" ;
				}

			});
			/*var categoryNo = this.getSelectedCategory();
			if ( categoryNo !== undefined ) {
				var categoryArray = JSON.parse("[" + categoryNo + "]");
				console.log( 'categoryArray', categoryArray );
				_.each(categoryArray, function(elem){
					filterQuery += "category"+ "=" + elem + '&';
				});
			}*/

			var parentCatNo = this.getParentCat();
			if(parentCatNo !== undefined){
				filterQuery += "parent_category=" + parentCatNo ;
			}

			filterQuery = filterQuery.replace( /\&$/, "" ) ;
			return filterQuery ;

		},

		filterCounselors : function(e){

			var targetID    = $(e.currentTarget).attr("id") ;
			var filterLabel = $(e.currentTarget.nextElementSibling).html();
			var filtersArr = [];
			var checkedFilters = $(".filter-category input:checked");
			_.each(checkedFilters, function (checkedElem) {
				filtersArr.push(checkedElem.attributes.id.value)
			});
            sessionStorage.setItem('filterIDsString', JSON.stringify(filtersArr));

			if($("#" + targetID + ":checked").length){

				if ( $('.talkItOutV2-counselor-filter-tags-col').hasClass('hide') ) {
					$('.talkItOutV2-counselor-filter-tags-col').removeClass('hide');
				}

				$(".filter-scroll-left").removeClass("hide");
				$(".filter-scroll-right").removeClass("hide");

				$(".filter-scroll-left").css("visibility", "hidden");
				$(".filter-scroll-right").css("visibility", "hidden");

				$(".filter-cnt-big").removeClass("hide");

				if(targetID.match("rating")){
					// $(".talkItOutV2-counselor-filter-tags-section").append('<li class="white z-depth-1 cpointer font-12 fclear" data-desc="filter clear '+ targetID +'" id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i></li>');
					if ( $(".talkItOutV2-counselor-filter-tags-section .fclear").hasClass("ratingFclear") ) {
						$(".ratingFclear").remove();
					}
					$(".talkItOutV2-counselor-filter-tags-section").append('<div class="chip fclear z-depth-1 cpointer ratingFclear"'+ 'data-desc="filter clear '+ targetID +'"' +'id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i>' + '</div>' );
				}else{
					// $(".talkItOutV2-counselor-filter-tags-section").append('<li class="white z-depth-1 cpointer font-12 fclear" data-desc="filter clear '+ filterLabel +'" id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i></li>');
					$(".talkItOutV2-counselor-filter-tags-section").append('<div class="chip fclear z-depth-1 cpointer"'+ 'data-desc="filter clear '+ filterLabel +'"' +'id="bar_'+ targetID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ targetID +'"></i>' + '</div>' );
				}
				$('.talkItOutV2-counselor-filter-tags').jcarousel('reload');

				var jcarouselWidth = $(".talkItOutV2-counselor-filter-tags").width() ;
				var filterbarsWidth = 0                      ;

				var allSelectedBars = $(".fclear") ;
				_.each(allSelectedBars, function(elem){
					filterbarsWidth += $(elem).width() ;
				});

				if( ( filterbarsWidth + 60 ) >= jcarouselWidth ){
					$(".filter-scroll-left").css("visibility", "visible");
					$(".filter-scroll-right").css("visibility", "visible");
				}
			}else{

				if(!Utils.isMobileDevice() && targetID && targetID.search("category_") == -1)
					this.removeFromCarousel(targetID);

			}

			this.selectCategory(e);
			var filterQuery = this.getSelectedFilters(e) ;

			if(targetID == "filter-check-btn"){
				this.filterView.hideFilter() ;
				if($(".filter-category input:checked").length > 0 ){
					$(".filter-mob-cnt").removeClass("hide");
					$(".filter-mob-cnt").html($(".filter-category input:checked").length);
				}else{
					$(".filter-mob-cnt").addClass("hide");
				}

			}

			localStorage.setItem("filterQuery", filterQuery);

			if(localStorage.getItem("searchQuery")){
				filterQuery += "&" + localStorage.getItem("searchQuery") ;
			}

			if (e.currentTarget.classList.value.indexOf('filter-name') > -1 ) {
				if (this.selectedSort) this.selectedSort.removeClass('selected-sort');
				if (e.currentTarget.innerHTML.toLowerCase() == (this.selectedSort && this.selectedSort.html().toLowerCase())) {
					this.selectedSort = undefined;
				} else {
					this.selectedSort = $(e.currentTarget);
					this.selectedSort.addClass('selected-sort');
				}
			}

			this.reRender( filterQuery ) ;

		},
		checkIfFilterIsShown: function(){

			if ( $('.left-filter-block-v2').hasClass('filter-block-v2-slideOut') ) {
				return true;
			} else {
				return false;
			}


		},

		reRender : function( filterQuery ) {

			var self = this;

			filterQuery = self.checkSorting(filterQuery);

			this.$el.find("#counselors-list-block").html(this.LoaderLayout()) ;
			if(filterQuery == null || filterQuery == undefined ){
				filterQuery = "" ;
			}
			if(Utils.isLoggedIn()){
				filterQuery += "&user=" + this.userModel.getUserID();
			}
			
			var pageNo = 1;
			this.counselorListModel.set( "page_number", pageNo);
			self.isLoading = true;

			self.listStart = 0 ;
			self.offset = 8 ;

			if(self.shareAllowed && typeof $.cookie("closedExpertsShareCard") == 'undefined'){
				self.offset = self.offset - 1 ;
			}

			if(self.donateAllowed && typeof $.cookie("closedExpertsDonationCard") == 'undefined'){
				self.offset = self.offset - 1 ;				
			}

			filterQuery += "&from=" + self.listStart + "&offset=" + self.offset ;


			$.ajax({
				method : "GET",
				url : Utils.contextPath() + "/v1/counselor/?" + filterQuery + "&page_number=" + pageNo
			}).done(function(response){
				$("#talkitout-main .main-loader").addClass("hide") ;
				$("#left-filter-block").removeClass("hide") ;
				var counselorList = response ;

				if(counselorList.length == 0 ){
					//self.$el.find("#counselors-list-block").html('<div class="card-preloader main-loader">No data found for selected filters</div>') ;
					self.$el.find("#counselors-list-block").html('') ;
				}else{
					self.$el.find("#counselors-list-block").html('') ;
				}

				if ( self.checkIfFilterIsShown() ) {
					self.$el.find("#counselors-list-block").append(self.FilteredSpecialFriendCardLayout());
				} else {
					self.$el.find("#counselors-list-block").append(self.SpecialFriendCardLayout());
				}

				var counselorParsed = 0 ;
				var randNo1 = Utils.getRandomInt(3, 5);
				var randNo2 = Utils.getRandomInt(6, 7);
				console.log( 'randNo1', randNo1 );
				console.log( 'randNo2', randNo2 );

				_.each(counselorList, function(elem, index){
					self.addDonationAndExpertSharedCard(randNo1, randNo2, index);
					if(elem.id != 101 && index!='page_number'){
						self.addOne(elem, index) ;
						counselorParsed ++ ;
					}
				});
				self.counselorListModel.set("counselorParsed", counselorParsed);
				if ( counselorParsed >= 7 ) {
					self.addViewMore();
				}
				$("#counselor-cnt").html(counselorParsed);

				if(Utils.isLoggedIn()){
					var userID = self.userModel.getUserID() ;
					$.ajax({
						url : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/favourite' ,
					}).done(function(response){
						_.each(response, function(eachElem){
							$("#favorite-" + eachElem ).children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
							$("#favorite-" + eachElem ).children().removeClass('grey-text').addClass('red-text') ;
						});
					}).error(function(error){
						console.log("Error");
						console.log(error) ;
					});

		            var username =  self.userModel.getUserName() ;
					$("#chat-counselor-0").attr("data-href", Utils.chatUrl() + username);

				}


	            $.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
					}).done(function(response){

						_.each(response, function(value, key){

							if( value.status == "true" ){
								$("#counselor-list-card-action-divider-"+key).removeClass("hide");
								$("#chat-counselor-" + key).removeClass("hide");
								//$("#message-counselor-" + key).addClass("col");
								$("#chat-counselor-" + key).attr("data-href", value.url);


							}
						});
					}).error(function(error){

					});
 				self.isLoading = false;
			}).fail(function(error){
				console.log(error) ;
			}) ;

		},
		addOne : function(elem, counselorIndex){

			var ratingHTML = "" ;
			for(index = 0; index < elem.rating; index ++ ){
				ratingHTML += '<i class="mdi-action-grade teal-text rating"></i>' ;
			}
			for(index = elem.rating; index < 5; index++){
				ratingHTML += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>' ;
			}

			var lastActive = elem.lastActive ;
			var hyphenatedName = elem.name.replace(/\s/g , "-");
			var counselorProfileIdentifier = hyphenatedName + '-'+elem.id;
			console.log('hyphenatedName', hyphenatedName);
			console.log('counselorProfileIdentifier', counselorProfileIdentifier);
			var formattedLastActive = "Never" ;

			console.log( 'lastActive '+ lastActive );

			if( lastActive !== undefined && lastActive!=0 ){
				formattedLastActive     = Utils.getDateDiff(new Date( lastActive * 1000  ).toISOString(), 0) ;
			}

			if( elem.numOfConversation < 10 ){
				formattedLastActive = "N/A" ;
			}

			if( elem.onlineStatus ){
				formattedLastActive = "Available Now" ;
			}

			var colorArr = Utils.backgroundColorArr() ;

			var thisCounselorColor = colorArr[ elem.id % 7 ] ;
			console.log ( $("#counselors-list-block") );
			console.log( "filter is shown ", this.checkIfFilterIsShown() );
			if ( !this.checkIfFilterIsShown() ) {
				this.$el.find("#counselors-list-block").append( this.CounselorsLayout({ isLoggedIn: Utils.isLoggedIn() , counselor : elem, ratingHTML: ratingHTML, formattedLastActive: formattedLastActive, backgroundColor : thisCounselorColor, counselorProfileIdentifier: counselorProfileIdentifier}) );
			}
			else {
				this.$el.find("#counselors-list-block").append( this.FilteredCounselorsLayout({ isLoggedIn: Utils.isLoggedIn() , counselor : elem, ratingHTML: ratingHTML, formattedLastActive: formattedLastActive, backgroundColor : thisCounselorColor, counselorProfileIdentifier: counselorProfileIdentifier }) );
			}
			$("#couselor-rating-" + elem.id).html(ratingHTML);
		},
		addIntro : function(fromAction, fromCounselor){

			var self = this ;
			if( Utils.isFirstTimeUser() == 1){
				if(screen.width <= 601){

					$("nav").addClass("introjs-fixParent") ;

					var steps = [
	                    {
	                        element: "#talkItOut-chat-btn-mobile",
	                        intro: "Share your worries with most suitable counselor",
	                        position : "bottom" ,
	                    },

	                    {
	                      element : ".button-collapse",
	                      intro : "View community discussions and messages from here",
	                      position : "bottom"
	                    }] ;

	                if($("#chat-counselor-" + this.firstCounselor).hasClass("hide")){
	                	var step2 = {
	                        element: "#message-counselor-"+this.firstCounselor,
	                        intro: "Leave a message to a particular counselor",
	                        position : "top"
	                      }
	                	steps.splice(1,0, step2) ;
	                } else {
	                	var step2 = {
	                        element: "#chat-counselor-"+this.firstCounselor,
	                        intro: "Chat online to a particular counselor",
	                        position : "top"
	                      }
	                	steps.splice(1,0,step2) ;

	                }

				}else{

					var steps = [
	                    {
	                        element: "#talkItOut-chat-btn",
	                        intro: "Share your worries with most suitable counselor",
	                        position : "bottom"
	                    },
	                    {
	                      element : "#message-link",
	                      intro : "View your private messages here",
	                      position : "top"
	                    },
	                    {
	                      element : "#discussion-url",
	                      intro : "Engage in community discussions",
	                      position : "top"
	                    }] ;

	                if($("#chat-counselor-" + this.firstCounselor).hasClass("hide")){
	                	var step2 = {
	                        element: "#message-counselor-"+this.firstCounselor,
	                        intro: "Leave a message to a particular counselor",
	                        position : "top"
	                      }
	                	steps.splice(1,0, step2) ;
	                } else {
	                	var step2 = {
	                        element: "#chat-counselor-"+this.firstCounselor,
	                        intro: "Chat online to a particular counselor",
	                        position : "top"
	                      }
	                	steps.splice(1,0,step2) ;

	                }
				}


				var options = {
                    showBullets : true ,
                    showStepNumbers: false ,
                    scrollToElement: true ,
                    tooltipClass : "z-depth-1",
                    prevLabel : "PREV" ,
                    nextLabel : "NEXT" ,
                    skipLabel : "SKIP" ,
                    doneLabel : "DONE" ,
                    steps: steps
                }

                if(Utils.isMobileDevice() == false){
                	options["tooltipPosition"] = "auto" ;
                }

                var intro = introJs("body");
                intro.setOptions(options);

                intro.onafterchange(function(){
                  if($("header").hasClass("introjs-fixParent")){
                    $(".dost-main").addClass("mtop50");
                  }else{
                    $(".dost-main").removeClass("mtop50");
                  }
                });

                intro.onbeforechange(function(){
                  var currentStep = intro._currentStep ;
                  var currentElement = intro._introItems[currentStep].element ;

                  var currentElementID = $(currentElement).attr("id") ;

                  if(currentElementID && currentElementID.match("msg-side-nav")){
                  	//$("nav").addClass("introjs-fixParent") ;
                  	$('.button-collapse').sideNav('show');
                  }

                });

                intro.onchange(function(){
                  	//$("nav").addClass("introjs-fixParent") ;

                });

                intro.onexit(function(){
                  sessionStorage.setItem("firstTimeUser", 0);
                  $(".dost-main").removeClass("mtop50");
                  if(localStorage.getItem("fromAppointment") != undefined && localStorage.getItem("fromAppointment") == 1){
					self.bookAppointmentView.render() ;
				  }
				  if(fromAction == 'message'){
				  	self.renderMessageByID(fromCounselor);
				  }

				  if(localStorage.getItem("promocode") != null){
					   self.showCouponNotification();
					}
	   		    });

                intro.oncomplete(function(){
                  sessionStorage.setItem("firstTimeUser", 0);
                  $(".dost-main").removeClass("mtop50");
                  if(localStorage.getItem("fromAppointment") != undefined && localStorage.getItem("fromAppointment") == 1){
					self.bookAppointmentView.render() ;
				  }
				  if(fromAction == 'message'){
				  	self.renderMessageByID(fromCounselor);
				  }
                });

                intro.start();

            }

		},
		renderMessageByID : function(counselorID){
			var category = {};
            var categories = {};
            $.ajax({
                	method: "GET",
                	url: Utils.contextPath()+'/category?include_faq=false'
            }).done(function(response){
            		var category = {} ;
              		_.each(response,function(cat){
                		category[cat.id] = cat.name;
                		categories["c_" + cat.id] = cat.name;
              		});
              		localStorage.setItem("categories",JSON.stringify(category));
              		localStorage.setItem("c_categories",JSON.stringify(categories));
            }).fail(function(error){});
			if(!counselorID || counselorID == undefined){
				$("#message-counselor-0").click();

			}else{
				$("#message-counselor-" + counselorID).click();
			}
		},
		bindScroll: function(){
			var self = this;
			$(window).scroll(function() {
		        self.checkScroll();
		    });
		},
		unbindScroll: function(){
			$(window).unbind("scroll");
		},
		checkScroll: function () {

	     	var triggerPoint = 100;
	    	var filterQuery = localStorage.getItem( "filterQuery" );

	    	console.log( ' filterQuery from loadCounselors '+ filterQuery );

			if( filterQuery == null || filterQuery == undefined ){
				filterQuery = "" ;
			}
			if(localStorage.getItem("searchQuery")){
				filterQuery += "&" + localStorage.getItem( "searchQuery" ) ;
			}



        	console.log( "isLoading from checkScroll " + this.isLoading );
        	if( !this.isLoading && this.el.scrollTop + this.el.clientHeight + triggerPoint > this.el.scrollHeight ) {

        		var pageNo = this.counselorListModel.get( "page_number" );
        		console.log( "page no "+ pageNo );
        		pageNo += 1;
        		this.loadCounselors( pageNo, filterQuery );
        		this.counselorListModel.set( "page_number" , pageNo );

        	}


	    },
	    getCounselors: function( pageNo, filterQuery ) {



	    	if ( filterQuery ) {

	    		return $.ajax({
	    			method : "GET",
					url : Utils.contextPath() + "/v1/counselor/?" + filterQuery + "&page_number=" + pageNo
				});

	    	}else {

	    		return $.ajax({
	    			url: Utils.contextPath() + '/v1/counselor?page_number=' + pageNo,
					type: 'GET'
	    		});

	    	}
	    },

	    checkSorting: function (filterQuery) {
	    	if (this.selectedSort) {
	    		if (this.selectedSort.html().toLowerCase() == 'conversations') {
	    			filterQuery += '&sort_by=conversation';
	    		} else {
	    			filterQuery += '&sort_by=rating';
	    		}	
	    	}
	    	return filterQuery;
	    },

	    loadCounselors: function( pageNo, filterQuery ) {

	    	var self = this;
	    	var url = window.location.href ;
    		url = url.replace("/talkItOut", "" );
    		//self.$el.find("#talkitout-main .main-loader").removeClass("hide");
			self.isLoading = true;
			self.$el.find("#counselors-list-block").append(this.LoaderLayout()) ;
			$(".main-loader").addClass("col s12 l12");

			$(".main-loader").css("margin-top", "23px");
			filterQuery = self.checkSorting(filterQuery);

			filterQuery += "&from=" + self.offset ;
			filterQuery += "&offset=" + (self.offset + 9 ) ;

			self.offset += 9 ;  

			self.getCounselors( pageNo, filterQuery ).done(function(response){
				self.$el.find("#talkitout-main .main-loader").addClass("hide") ;
				console.log( 'response' );
				console.log( response );
				if ( response.length == 0) {
					return 0;
				}

				var counselorParsed;
				if ( pageNo == 1 ) {
					self.$el.find("#left-filter-block").removeClass("hide") ;
					self.$el.find("#counselors-list-block").html('') ;
					self.$el.find("#counselors-list-block").append(self.SpecialFriendCardLayout());
					counselorParsed = 0;
				}

				var counselorList = response;
				console.log( ' counselorList ');
				console.log( counselorList );
				// if ( counselorParsed != 0) {
				counselorParsed = self.counselorListModel.get( "counselorParsed" );
				// }
				_.each(counselorList, function(elem, index){
					console.log( 'element' );
					console.log( elem );
					console.log( elem.id );
					console.log( index );
					if( elem.id != 101 &&  index!='page_number' ){
						if(counselorParsed == 0){
							self.firstCounselor = elem.id ;
						}
						self.addOne(elem, index) ;
						counselorParsed ++ ;
					}
				});
				self.counselorListModel.set("counselorParsed", counselorParsed);

				if ( counselorParsed > 7 ) {
						self.addViewMore();
				}
				$("#counselor-cnt").html(counselorParsed);

				if(Utils.isLoggedIn()){
					var userID = self.userModel.getUserID() ;
					$.ajax({
						url : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/favourite' ,
					}).done(function(response){
						_.each(response, function(eachElem){
							$("#favorite-" + eachElem ).children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
							$("#favorite-" + eachElem ).children().removeClass('grey-text').addClass('red-text') ;
						});
					}).error(function(error){
						console.log("Error");
						console.log(error) ;
					});

					var username =  self.userModel.getUserName() ;
					$("#chat-counselor-0").attr("data-href", Utils.chatUrl() + username);

				}


				$.ajax({
					url : Utils.contextPath() + '/v1/counselor/status' ,
				}).done(function(response){

					_.each(response, function(value, key){

						if( value.status == "true" ){
							$("#counselor-list-card-action-divider-"+key).removeClass("hide");
							$("#chat-counselor-" + key).removeClass("hide");
							$("#chat-counselor-" + key).attr("data-href", value.url);
						}
					});

					var fromAction    = $.url( url ).param('from');
					var fromCounselor = $.url( url ).param('counselorID');

					if(!Utils.isFirstTimeUser()){
						if(fromAction == "message"){
							//window.history.pushState('talkItOut', 'Title', '#talkItOut');
							self.renderMessageByID(fromCounselor);
						}
		                if(fromAction == 'book_appointment'){
							//window.history.pushState('talkItOut', 'Title', '#talkItOut');
							self.bookAppointmentView.render() ;
						}
					}

					if(!Utils.isMobileDevice()){

						// self.addIntro(fromAction, fromCounselor) ;
					}
					}).error(function(error){

					});
					self.isLoading = false;
					console.log( 'self.isLoading ' + self.isLoading );

			}).fail(function(error){
				console.log( error );
			});

	    },
		CounselorsLayout       : JST['app/templates/talkItOut/counselors_list_v2.hbs'],
		FilteredCounselorsLayout: JST['app/templates/talkItOut/filtered_counselors_list_v2.hbs'],
		LoaderLayout           : JST['app/templates/loader.hbs'],
		ComposeLayout          : JST['app/templates/messages/compose.hbs'],
		SpecialFriendCardLayout: JST['app/templates/talkItOut/specialFriendCard_v2.hbs'],
		FilteredSpecialFriendCardLayout: JST['app/templates/talkItOut/filtered_specialFriendCard_v2.hbs'],
		CouponNotificationLayout : JST['app/templates/talkItOut/coupon_notification.hbs'],
		AddPromoCodeLayout : JST['app/templates/talkItOut/add_promo.hbs'],
		ViewMoreLayout: JST['app/templates/talkItOut/talkItOut_viewMore.hbs'],
		DonateCardLayout : JST['app/templates/talkItOut/donate_card_v2.hbs'],
		FilteredDonateCardLayout: JST['app/templates/talkItOut/filtered_donate_card_v2.hbs'],
		SpreadTheWordCardLayout : JST['app/templates/talkItOut/share_card_v2.hbs'],
		FilteredSpreadTheWordCardLayout: JST['app/templates/talkItOut/filtered_share_card_v2.hbs'],
		addViewMore: function() {
			console.log( 'adding view more' );
			var self = this;
			console.log( self.$el.find("#counselors-list-block") );
			console.log( self.ViewMoreLayout() );
			self.$el.find("#counselors-list-block").append( self.ViewMoreLayout() );
		},
		fetchCounselors: function(){

		},

		changeMeta : function(title,desc){

			document.title= title;
			$('meta[name=description]').attr('content', desc);
			$('meta[name=title]').attr('content',title);
			$('meta[property="og:description"]').attr('content', desc);
			$('meta[property="og:title"]').attr('content',title);
	        $('link[rel="canonical"]').attr('href', window.location.href);
		},
		render: function() {


			var catObj = {

				"love-relationship" : 1,
				"career-academic" : 2,
				"sexual-wellness" : 3,
				"self-improvement" : 4,
				"friends&family" :5,
				"other" : 6
			}

			var self = this;

			if( typeof this.city != 'undefined' && this.city != '' ){

				setTimeout( function(){

					if(Utils.isMobileDevice()){

						//self.browseInMobile();
						$("#mobile-location_"+self.city.toLowerCase()).click()
						$(".filter-mob-apply-btn").click()
						self.browseInMobile();

					}else{

						$("#desk-location_"+self.city.toLowerCase()).click()
					}
					var title = "Counsellors, Psychologists & Experts in "+self.city+" | YourDOST"
					var desc = "Online chat with certified counselors, psychologists & other experts from "+self.city+" for advice & support on career, marriage, relationships, etc"
					self.changeMeta(title,desc)
				}, 1000)
				return;
			}
			if( typeof this.cat != 'undefined' && this.cat != '' ){

				var id = catObj[self.cat.toLowerCase()]
				setTimeout( function(){

					$(".talkItOutV2-header-filter-category-"+id).click();
					var title = "Counsellors, Psychologists & Experts in "+self.cat+" | YourDOST"
					var desc = "Online chat with certified counselors, psychologists & other experts for advice & support on "+self.cat
					self.changeMeta(title,desc)
				}, 1000)
				return;
			}

			localStorage.setItem("filterQuery", "" );
			localStorage.setItem("searchQuery", "") ;
			localStorage.setItem("searchClicked", 0) ;
			/*if(sessionStorage.getItem('restoreCounselorListView') !== 'true') {
				sessionStorage.removeItem('filterIDsString');
				sessionStorage.removeItem('headerFilter');
				sessionStorage.removeItem('restoreCounselorListView');
			}*/
			var url = window.location.href ;
            var pathArray = url.split('/');
            var footerCityArray = ['bangalore','mumbai','delhi','pune','bhopal','hyderabad','chennai'];
            var urlCity = pathArray[pathArray.length - 1];
            if(!(footerCityArray.indexOf(urlCity) > -1) )
                urlCity='';
    		url = url.replace("/talkItOut", "" );
			var categoryFilter = $.url( url ).param('category') ;
			var fromPage = $.url( url ).param('fromPage') ;
			var sendMessage = $.url( url ).param( 'sendMessage' );
			console.log( "fromPage " + fromPage );


			if(categoryFilter){

				this.$el.find("#talkitout-main .main-loader").addClass("hide") ;
				$('header').show();
        		$('#footer').show();
				if (categoryFilter != 100) {

					this.reRender("category=" + categoryFilter ) ;
				}
				 else {
				 	this.reRender();
				 }


				setTimeout(function(){
				$(".filter-scroll-left").removeClass("hide");
				$(".filter-scroll-right").removeClass("hide");

				$(".filter-scroll-left").css("visibility", "hidden");
				$(".filter-scroll-right").css("visibility", "hidden");

				$(".filter-cnt-big").removeClass("hide");

				var categoryDivID = "category_" + categoryFilter ;
				var filterLabel = "";

				if($("#"+categoryDivID).hasClass("talkItOutV2-header-filter-category")){

					$("#"+categoryDivID+".talkItOutV2-header-filter-category").addClass("categorySelected");
					filterLabel = $("#category_" + categoryFilter).find("span").html();
				}else{

					$("#"+categoryDivID).removeClass("categorySelected");
					filterLabel = $("#desk-category_" + categoryFilter).next().html();	
				}

				if (Utils.isMobileDevice()) {
					$(".talkItOutV2-counselor-filter-tags-mobile-section").append('<div class="chip fclear z-depth-1 cpointer category-chip"'+ 'data-desc="filter clear '+ filterLabel +'"' +'id="bar_'+ categoryDivID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ categoryDivID +'"></i>' + '</div>' );
				} else {
					$(".talkItOutV2-counselor-filter-tags-section").append('<div class="chip fclear z-depth-1 cpointer category-chip"'+ 'data-desc="filter clear '+ filterLabel +'"' +'id="bar_'+ categoryDivID+'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ categoryDivID +'"></i>' + '</div>' );
				}
				$(".talkItOutV2-counselor-filter-tags-col").removeClass("hide");
					// $(".jcarousel ul").append('<li class="white z-depth-1 cpointer font-12 fclear" data-desc="filter clear '+ filterLabel +'" id="bar_'+ categoryDivID +'">'+ filterLabel + '<i class="small font-12 mdi-navigation-close right" id="fclear_'+ categoryDivID +'"></i></li>');
					// $('.jcarousel').jcarousel('reload');

					if ( fromPage === 'EbookPrompt' ) {

						if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){

            				console.log( 'inside mixpanel' );
            				mixpanel.track('EbookPrompt', {'mediumSource' : 'website', 'itemtype': 'Popup', 'itemName': 'emailPopup_served'});

          				}
						Utils.openPopup('download-ebook-modal');
					}



					if( fromPage === 'careercounselor') {
						$('header').show();
        				$('#footer').show();
        				if ( sendMessage ){
							Utils.displaySuccessMsgWithDelay( "Your message has been sent, you will hear from us soon.<br/> We know, you may have a lot more to discuss, don't hold it back- <br/>Here are some counselors who can help you out for your career related queries:", 8000 );
						}
						else {
							Utils.displaySuccessMsgWithDelay( "Here are some counselors who can help you out for your career related queries:", 8000 );
						}
					}

				}, 2000);

				// this.bindScroll();
				return 0 ;
			}

			var self = this ;

			this.$el.find("#talkitout-main .main-loader").removeClass("hide") ;
			// this.$el.append(this.ComposeLayout());
			console.log( 'calling fetch' );

			if(Utils.isLoggedIn()){

		    	var userId = this.userModel.getUserID() ;
				$.ajax({
	                url : Utils.contextPath() + "/v2/users/"+userId+"/intrupts/status",
	                method : 'GET',
	                contentType: "application/json; charset=utf-8",
	          	}).done(function(response){

					if(response.length > 0){

		          		$.each(response, function(index){

		          			var intruptsObj = response[index];
		          			if(intruptsObj.type == "DONATE"){

		          				self.donateAllowed = intruptsObj.allowed;
		          				if(!self.donateAllowed){

		          					$(".experts-donation-card").parent('.experts-card-v2').addClass("hide")
		          				}
		          			}else if(intruptsObj.type == "SHARE"){

		          				self.shareAllowed = intruptsObj.allowed;
		          				if(!self.shareAllowed){

		          					$(".experts-share-card").parent('.experts-card-v2').addClass("hide")
		          				}
		          			}else{

		          				self.storyAllowed = intruptsObj.allowed;
		          			}
		          		})
		          	}

	          	}).error(function(error){

	          		console.log("Error ", error)
	          	})
	        }


			var pageNo = 1;
			this.counselorListModel.set( "page_number", pageNo);
			self.isLoading = true;
			if(self.shareAllowed && typeof $.cookie("closedExpertsShareCard") == 'undefined'){
				self.offset = self.offset - 1 ;
			}

			if(self.donateAllowed && typeof $.cookie("closedExpertsDonationCard") == 'undefined'){
				self.offset = self.offset - 1 ;				
			}

			// this.$el.append(this.ComposeLayout());
			this.counselorListModel.fetch({ data: {page_number: pageNo, "from" : self.listStart, offset : self.offset},//, location: urlCity},
				success : function(response) {
					self.$el.find("#talkitout-main .main-loader").addClass("hide") ;
					self.$el.find("#counselors-list-block").html('') ;
					self.$el.find("#left-filter-block").removeClass("hide") ;

					self.$el.find("#counselors-list-block").append(self.SpecialFriendCardLayout());
					var counselorList = response.attributes;

					console.log( 'counselorList' );
					console.log( counselorList )
					var counselorParsed = 0 ;
					var randNo1 = Utils.getRandomInt(3, 5);
					var randNo2 = Utils.getRandomInt(self.offset - 2, self.offset - 1);
					console.log( 'randNo1', randNo1 );
					console.log( 'randNo2', randNo2 );

					_.each(counselorList, function(elem, index){

						self.addDonationAndExpertSharedCard( randNo1, randNo2, index );
						console.log(elem);
						if(elem.id != 101 && index!='page_number'){
							if(counselorParsed == 0){
								self.firstCounselor = elem.id ;
							}
							self.addOne(elem, index) ;
							counselorParsed ++ ;
						}
					});
					self.counselorListModel.set("counselorParsed", counselorParsed);
					$("#counselor-cnt").html(counselorParsed);

					if ( counselorParsed >= (self.offset - self.listStart - 1) ) {
						self.addViewMore();
					}

					if(Utils.isLoggedIn()){
						var userID = self.userModel.getUserID() ;
						$.ajax({
							url : Utils.contextPath() + '/v2/users/'+ userID +'/counselor/favourite' ,
						}).done(function(response){
							_.each(response, function(eachElem){
								$("#favorite-" + eachElem ).children().removeClass('mdi-action-favorite-outline').addClass('mdi-action-favorite') ;
								$("#favorite-" + eachElem ).children().removeClass('grey-text').addClass('red-text') ;
							});
						}).error(function(error){
							console.log("Error");
							console.log(error) ;
						});

						var username =  self.userModel.getUserName() ;
						$("#chat-counselor-0").attr("data-href", Utils.chatUrl() + username);

					}


					$.ajax({
						url : Utils.contextPath() + '/v1/counselor/status' ,
					}).done(function(response){

						_.each(response, function(value, key){

							if( value.status == "true" ){
								$("#counselor-list-card-action-divider-"+key).removeClass("hide");
								$("#chat-counselor-" + key).removeClass("hide");
								$("#chat-counselor-" + key).attr("data-href", value.url);
							}
						});

						var fromAction    = $.url( url ).param('from');
						var fromCounselor = $.url( url ).param('counselorID');

						if(!Utils.isFirstTimeUser()){
							if(fromAction == "message"){
								//window.history.pushState('talkItOut', 'Title', '#talkItOut');
								self.renderMessageByID(fromCounselor);
							}
			                if(fromAction == 'book_appointment'){
								//window.history.pushState('talkItOut', 'Title', '#talkItOut');
								self.bookAppointmentView.render() ;
							}
						}

						// self.addIntro(fromAction, fromCounselor) ;
					}).error(function(error){

					});
					self.isLoading = false;
				},
				error : function(error){
					console.log(error) ;
				}
			});
			// self.bindScroll();

			if(localStorage.getItem("skipCouponNotification") != 1 && Utils.isFirstTimeUser() != 1){
				self.showCouponNotification();
			}

			$.ajax({
                url : Utils.scriptPath() + "/socialShare.json",
                cache: false
          	}).done(function(response){

                var url = "donate";
                self.socialShareResponse = response[ url ];

          	}).error(function(error){
                console.log(error)
            });

			if (true/*sessionStorage.getItem('restoreCounselorListView') === 'true'*/) {
				var filterString = sessionStorage.getItem('filterIDsString');
				var filtersArr = JSON.parse(filterString);
				var headerFilter = sessionStorage.getItem('headerFilter');
				setTimeout(function () {

					if (headerFilter !== null && headerFilter.length > 2) {
						$('#' + headerFilter).addClass('categorySelected');
						$('#' + headerFilter).click();
					}

					if (filtersArr !== null && filtersArr.length >= 1) {
						$('.talkIt-Out-filter-box-container').click();
						_.each(filtersArr, function (id) {
							if (id.match('rating'))
								$('#' + id).prop("checked", true);
							$('#' + id).click();
						});
					}
					sessionStorage.removeItem('filterIDsString');
					sessionStorage.removeItem('restoreCounselorListView');
					sessionStorage.removeItem('headerFilter');
				}, 1000);
				sessionStorage.removeItem('filterIDsString');
				sessionStorage.removeItem('restoreCounselorListView');
				sessionStorage.removeItem('headerFilter');

            }

            //On the fly experts availability status check for every 10 seconds.
            this.statusInterval = setInterval(function () {
                $.ajax({
                    url: Utils.contextPath() + '/v1/counselor/status',
                }).done(function (response) {
                    _.each(response, function (value, key) {
                        if (value.status == "true") {
                            if ($("#chat-counselor-" + key).hasClass("hide")) {
                                // if chat button is not present, add the button
                                $("#counselor-list-card-action-divider-" + key).removeClass("hide");
                                $("#chat-counselor-" + key).removeClass("hide");
                                $("#chat-counselor-" + key).attr("data-href", value.url);
                            } else if ($("#chat-counselor-" + key + " span").text() == "OFFLINE") {
                                // change the chat button text to 'CHAT'
                                $("#chat-counselor-" + key + " span").fadeOut(function () {
                                    $(this).text("CHAT")
                                }).fadeIn();
                                $("#chat-counselor-" + key).attr("data-href", value.url);
                            }
                        } else if (value.status == "false") {
                            //if chat button already present make it's text as 'OFFLINE'
                            if ((!$("#chat-counselor-" + key).hasClass("hide")) && $("#chat-counselor-" + key + " span").text() == "CHAT") {
                                $("#chat-counselor-" + key + " span").fadeOut(function () {
                                    $(this).text("OFFLINE")
                                }).fadeIn();
                                $("#chat-counselor-" + key).removeAttr("data-href");
                            }
                        }
                    });
                });
            }, 60 * 1000);

            // Refresh experts list view after three minutes
            this.expertInterval = setInterval(function () {

                var filterQuery = localStorage.getItem("filterQuery");
                if (filterQuery == null || filterQuery == undefined) {
                    filterQuery = "";
                }
                if (localStorage.getItem("searchQuery")) {
                    filterQuery += "&" + localStorage.getItem("searchQuery");
                }


                self.reRender(filterQuery);
            }, 3 * 60 * 1000);

		},

		"bookNow" : function(e){
			Backbone.history.navigate("/bookAppointment", {trigger: true});
		},
		"skipNotification" : function(e){
			$('#coupon-notification').hide();
			$('.apply_promo').hide();
			localStorage.setItem("skipCouponNotification",1);
		},
		"applyPromoPopup" : function(e){
			var self = this;
			$('.apply_promo').html(self.AddPromoCodeLayout());
			$("#promo_code").keystop( function(event){
						self.checkPromoCodeValidity(event) ;
			}, 500 );
		},
		"checkPromoCodeValidity" : function(e){

			var promo_code = $('#promo_code').val();
			$.ajax({
				url : Utils.contextPath() + "/v1/coupon/isvalid?code=" + promo_code,
				statusCode:{
            		404 : function(){
						$('#apply_promo').css("background-color","teal");
						$('#apply_promo').removeClass("disabled");
						$('#promo_code_error').html("");
						return true;
            		}
        		},

			}).done(function(response){

					if(response.status == false ){
						$('#promo_code_error').html(response.message);
						$('#apply_promo').attr("disable","disable");
						$('#apply_promo').css("background-color","#d2d2d1");

						var message = response.message;
						if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
						 		var coupon_error_type = "";
						 		if(message.indexOf("not exist") >=0 ){
						 			coupon_error_type = "Coupon doesn't exist";
						 		}else if(message.indexOf("expired")){
						 			coupon_error_type = "Coupon expired";
						 		}else if(message.indexOf("used up")){
						 			coupon_error_type = "Coupon has been used up";
						 		}
						 		mixpanel.track(coupon_error_type, {'type' : "NORMAL", 'mediumSource' : 'website' });
						}
						return false;

					}else{
						$('#promo_code_error').html("");
						$('#apply_promo').removeAttr("disable");
						$('#apply_promo').css("background-color","#26a69a");
						return true;
					}

				}).error(function(){

				});
		},
		"applyPromo" : function(e){

			var self = this;
			if( $('#apply_promo').attr("disable") == true ||
			$('#apply_promo').attr("disable") == "disable" ) {
				return;
			}

			var userID      = this.userModel.getUserID() ;
			var couponCode = $('#promo_code').val();

			$.ajax({
				method : "POST" ,
				url    : Utils.contextPath() + '/v1/coupon/'+ userID +'/apply/'+ couponCode,
			}).done(function(response){

				if(response == false){
					return;
				}else{

					if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
						mixpanel.track("Coupon re-entry success", {'type' : "NORMAL", 'mediumSource' : 'website' });
					}

					$('.apply_promo').hide();
					$.ajax({
							url : Utils.contextPath() + '/v1/coupon/get' ,
						}).done(function(response){
							if(response){
								var message = "";
								if(response.incentiveType == "FREE" ){
									message += " 1 free call credited. Talk it out! ";
								}else{
									if(response.type=="FIXED"){
										message += "Rs." + response.value + " " ;
									}else{
										message += response.value + "% " ;
									}
									message += " discount on your first call."
								}

								$("#coupon-notification").html(self.CouponNotificationLayout({"message" : message }));
							}

						}).error(function(error){
							console.log("Error");
							console.log(error) ;
						});
				}
			}).error(function(error){
				console.log(error) ;
			});
		},
		"showCouponNotification" : function(e){
			var self = this;
			$.ajax({
				url : Utils.contextPath() + '/v1/coupon/get' ,
			}).done(function(response){
				if(response){
					var message = "";
					if(response.incentiveType == "FREE" ){
						message += " 1 free call credited. Talk it out! ";
					}else{
						if(response.type=="FIXED"){
							message += "Rs." + response.value + " " ;
						}else{
							message += response.value + "% " ;
						}
						message += " discount on your first call."
					}

					if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
						mixpanel.track("Coupon entry success", {'type' : "NORMAL", 'mediumSource' : 'website' });
					}

					$("#coupon-notification").html(self.CouponNotificationLayout({"message" : message}));
					$("#coupon-notification").removeClass('hide');

				}else{
					var promo_code = localStorage.getItem("promocode");
					if(promo_code != null){

						$.ajax({
							url : Utils.contextPath() + "/v1/coupon/isvalid?code=" + promo_code
						}).done(function(response){

							if(response.status == false ){

								var message = response.message;
								if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.register === "function") ){
							 		var coupon_error_type = "";
							 		if(message.indexOf("not exist") >=0 ){
							 			coupon_error_type = "Coupon doesn't exist";
							 		}else if(message.indexOf("expired")){
							 			coupon_error_type = "Coupon expired";
							 		}else if(message.indexOf("used up")){
							 			coupon_error_type = "Coupon has been used up";
							 		}
							 		mixpanel.track(coupon_error_type, {'type' : "NORMAL", 'mediumSource' : 'website' });
								}
								message = message.substr(0, message.indexOf(".")+1);
								$("#coupon-notification").html(self.CouponNotificationLayout({"wrongPromo" : true, message : message}));
								$("#coupon-notification").removeClass('hide');
								localStorage.removeItem("promocode");
							}

						}).error(function(){

						});


					}
				}

			}).error(function(error){
				console.log("Error");
				console.log(error) ;
			});

		}
	});

	CounselorsView.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	clearInterval(this.statusInterval);
    	clearInterval(this.expertInterval);
    	//this.stopListening();
    	this.undelegateEvents();
    	this.unbind();
    	this.leaveMessage.remove();
	};

	CounselorsView.prototype.clean = function() {
    	this.remove();
	};

	return CounselorsView;

});
