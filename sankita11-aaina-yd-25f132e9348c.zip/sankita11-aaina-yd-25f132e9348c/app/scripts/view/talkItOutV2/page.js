define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'view/talkItOut/subview/start_chatting',
	'view/talkItOut/subview/search_bar',
	'view/talkItOutV2/subview/filter',
	'view/talkItOutV2/subview/counselors_list',
	'view/paymentPending/payment_pending',
	'utils',
	'model/users',
	'event/dispatcher',
	'view/leaveMessage/page' ,
	'introjs',
	'purl',
], function($,_, Backbone, JST, StartChattingView, SearchBarView, FilterView, CounselorsView, PaymentPendingView, Utils, UserModel, Dispatcher, LeaveMessage) {

	var TalkItOutPageV2 = Backbone.View.extend({

		el: "main",
		initialize: function() {
			var url = window.location.href ;
            console.log(url +" ll");
    		url = url.replace("/talkItOut", "" );
            console.log(url +" ll");
			this.messageExists = $.url( url ).param('messageExists') ;
			this.categoryId = $.url( url ).param('category') ;

    		this.fromPage = $.url( url ).param('from') ;
    		if (this.fromPage == 'quickMessage') {

    			this.sendCounselorInfo = JSON.parse($.url( url ).param('counselorInfo'));
    			console.log('counselorInfo', this.sendCounselorInfo);
    		}

			this.startChattingView = new StartChattingView() ;
			this.filterView        = new FilterView() ;
			this.counselorsView    = new CounselorsView() ;
			this.paymentPendingView = new PaymentPendingView() ;
			this.searchBarView     = new SearchBarView() ;
			this.userModel 		   = new UserModel() ;
			this.leaveMessage = new LeaveMessage();

	 	},
	 	template: JST['app/templates/homeNew/layout.hbs'],
		TalkItOutPageLayout : JST['app/templates/talkItOut/layout_v2.hbs'],
		TalkItOutPageMobileLayout: JST['app/templates/talkItOut/mobileLayoutv2.hbs'],
		MyExpertLayout : JST['app/templates/talkItOut/myexperts.hbs'],
		ExpertCard     : JST['app/templates/talkItOut/expert_card.hbs'],
		ExitPopupLayout     : JST['app/templates/talkItOut/exit_popup.hbs'],
		LoaderLayout           : JST['app/templates/loader.hbs'],

		events: {
			"click #remove-counselor-modal .mclose" : "closeRemoveModal",
			"click .remove-counselor-text-link" : "showRemoveReasonText",
			"click #submit-remove-counselor" : "submitRemoveCounselor",
			"click .talkIt-Out-filter-box-container": "renderFilterView",
			"click .talkItOut-filter-container-v2-close": "closeFilterView",
			"click #cancel-remove-counselor" : "closeRemoveModal",
			"click .browse-all-btn" : "browseAllExperts",
			"click .counselor-card-link":"openExpertProfile",
			"click #talkItOut-exit-popup .exit-popup-chat-now-container .exit-popup-chat-now-button":"openChatNowWithExperts",
			"click #talkItOut-exit-popup .exit-popup-action-container .exit-popup-close-text":"closeExitPopup",
			"click #talkItOut-exit-popup .close-exit-popup":"closeExitPopup"

		},

		openChatNowWithExperts: function() {
			if(!Utils.isLoggedIn()){
				// if (counselorId == '101') {
					Dispatcher.trigger("renderLogin", "ExitPopupChatNow", "talkItOut", "home_chat" ) ;
				// } else {
				// 	Dispatcher.trigger("renderLogin", buttonDesc, "talkItOut", "counselorChat", chatURL + 'BREAKBREAK' +counselorId ) ;
				// }

			}else{
				// if (counselorId == '101') {
					Dispatcher.trigger('chatQuickCheck', 'demo', '101', Utils.chatUrl(), "", "talkItOut" );
				// } else {
				// 	Dispatcher.trigger('chatQuickCheck', 'direct', counselorId, chatURL, "", "talkItOut" );
				// }
			}
			this.trackMixpanel("Button Click", { "mediumSource" : "website", 'itemName': 'Chat Now from Exit Popup' })

		},

		openExpertProfile : function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          		mixpanel.track("Button Click", { "mediumSource" : "website", 'itemName': 'See Expert Profile' });
        	}
		},
		browseAllExperts: function(e) {
			var self = this ;
			$.ajax({
				method: 'GET',
				dataType: 'JSON',
				url: Utils.contextPath() + '/v1/dashboard/ongoingCnt'
			}).done(function(response){
				var noOfPeopleOnline = parseInt(response) + 20;
				self.$el.html( self.TalkItOutPageLayout({noOfPeopleOnline: noOfPeopleOnline}) );
				self.checkForMpbseUsers()
				self.filterView.render() ;
				self.counselorsView.render() ;
				$('select').not('.disabled').material_select();
				if ( Utils.isMobileDevice() ) {

					if ( !$('.talkItOutV2-mobile-header-bgImg').hasClass('hide') ) {
						$('.talkItOutV2-mobile-header-bgImg').addClass('hide');
					}
					$('.filter-counselor-section-2').removeClass('hide');
					$('.mob-right').removeClass('hide');
					$('#start-chatting-block').removeClass('hide');
				}
			})
		},

		showAllExperts : function(e){
			var self = this ;
			$.ajax({
				method: 'GET',
				dataType: 'JSON',
				url: Utils.contextPath() + '/v1/dashboard/ongoingCnt'
			}).done(function(response){
				var noOfPeopleOnline = parseInt(response) + 20;
				self.$el.html( self.TalkItOutPageLayout({noOfPeopleOnline: noOfPeopleOnline}) );
				self.checkForMpbseUsers()
				self.filterView.render() ;
				self.counselorsView.render() ;
				$('select').not('.disabled').material_select();
				if ( Utils.isMobileDevice() ) {
					self.renderForMob();
				}
			})

			// self.startChattingView.render();
		},
		checkForMpbseUsers : function(){
			if(Utils.isLoggedIn()){
				var user = localStorage.getItem('user');
				if(JSON.parse(user)['loggableUser']['orgId'] == 9){
					$(".talkItOutV2-header-filter-category-1").addClass("hide")
					$(".talkItOutV2-header-filter-category-3").addClass("hide")
				}
			}
		},

		getParentCat : function(){
			var self = this ;

			var deferred = $.Deferred();
			$.ajax({
				method : 'GET',
				dataType : 'JSON',
				url : Utils.contextPath() + '/parentcategory'
			}).done(function(response){
				deferred.resolve(response)
			})
		},

		renderForMob:function() {
			$('.filter-counselor-section-2').addClass('hide');
			$('.mob-right').addClass('hide');
			$('#start-chatting-block').addClass('hide');
		},
		closeFilterView: function() {
			var self = this;
			$(".left-filter-block-v2").removeClass("filter-block-v2-slideOut");
			// $(".talkItOutV2-layout").removeClass("white");
			$(".talkItOutV2-layout").removeClass("adjustLayoutHeight");
			$(".talkItOutV2-counselor-filter-tags-col").removeClass("offset-l4 l8").addClass("l12");
			$("#counselors-list-block").removeClass("offset-l4 l8").addClass("l12");
			$(".experts-card-v2").removeClass("l6").addClass("l4");
			$(".talkIt-Out-filter-box-container").removeClass("talkIt-Out-filter-box-container-hide");
		},
		renderFilterView: function() {
			var self = this;
			$(".talkIt-Out-filter-box-container").addClass("talkIt-Out-filter-box-container-hide");
			$(".left-filter-block-v2").addClass("filter-block-v2-slideOut");
			// $(".talkItOutV2-layout").addClass("white");
			$(".talkItOutV2-layout").addClass("adjustLayoutHeight");
			$(".talkItOutV2-counselor-filter-tags-col").removeClass("l12").addClass("offset-l4 l8");
			$("#counselors-list-block").removeClass("l12").addClass("offset-l4 l8");
			$(".experts-card-v2").removeClass("l4").addClass("l6");
		},
		submitRemoveCounselor : function(e){

			var self = this ;

			var counselorID = $(e.currentTarget).attr("cID");
			var removeReason = $("#remove-reason").val();

			var userID = this.userModel.getUserID();

			var dataToSend = {
				userID : userID,
				counselorID : counselorID,
				type : "NOT_FAMILIAR",
				updatedBy : userID,
				reason : removeReason,
			};

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          		mixpanel.track("Submit Remove Counselor", { "mediumSource" : "website", 'itemName':  $(e.currentTarget).attr("cName") });
        	}

			$.ajax({
				url : Utils.contextPath() + "/users/blockUser",
				method : "POST",
				data : JSON.stringify(dataToSend),
				dataType: "JSON",
				contentType: "application/json; charset=utf-8",
			}).done(function(response){
				self.closeRemoveModal();
				$(".my-expert-container").html(self.LoaderLayout());
        		var userID = self.userModel.getUserID() ;

        		$.ajax({
        			url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"
        		}).done(function(response){
        			if(response.length > 0){
        				self.$el.html(self.MyExpertLayout({}));
						Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "My Experts");
						$(".my-experts-slider").css("border-bottom", "2px solid white");

        			}else{
        				self.$el.html( self.TalkItOutPageLayout() );
						self.filterView.render() ;
						self.counselorsView.render() ;
						$('select').not('.disabled').material_select();
						self.searchBarView.render() ;
						// self.startChattingView.render();
        			}
        		});
			}).error(function(error){
				console.log(error);
			})


		},

		showRemoveReasonText : function(e){
			$(".remove-counselor-text").removeClass("hide");
		},

		closeRemoveModal : function(e){
			Utils.closePopup('remove-counselor-modal');
		},

		showExitPopup: function() {

			// alert("left window");
			if($.cookie("talkItOutExitPopup") == "null" || $.cookie("talkItOutExitPopup") == null || $.cookie("talkItOutExitPopup") == undefined || $.cookie("talkItOutExitPopup") == "false") {
				this.$el.find("#talkItOut-exit-popup").html( this.ExitPopupLayout() );
				Utils.openPopup('talkItOut-exit-popup');
				// sessionStorage.talkItOutExitPopup = true;
				$.cookie("talkItOutExitPopup", "true" , {expires : 1, domain: ".yourdost.com"}) ;
			}

		},

		closeExitPopup: function(e) {



			Utils.closePopup('talkItOut-exit-popup');
			this.trackMixpanel("Button Click", { "mediumSource" : "website", 'itemName': $(e.currentTarget).attr("data-desc") })


		},

		trackMixpanel: function(action_name, action_data) {
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          		mixpanel.track(action_name, action_data);
        	}
		},

		render: function() {
			window.scrollTo(0,0);
			if (Utils.isLoggedIn()) {
				if (this.categoryId) {
					this.showAllExperts();
					return;
				} else {
					if (this.fromPage != "showAllExperts") {
						Backbone.history.navigate('/dashboard', {"trigger": true});
						return;
					}
				}
			}

			var self = this ;
				document.title="Online Counselors, Psychologists, Life Coaches | YourDOST";
				$('meta[name=description]').attr('content', "List of career experts, psychologists counsellors at YourDOST to help you out with problems or need advice in career, relationships, parenting & more in India");
				$('meta[name=title]').attr('content',"Online Counselors, Psychologists, Life Coaches | YourDOST");
				$('meta[property="og:description"]').attr('content', "List of career experts, psychologists counsellors at YourDOST to help you out with problems or need advice in career, relationships, parenting & more in India");
				$('meta[property="og:title"]').attr('content',"Online Counselors, Psychologists, Life Coaches | YourDOST");
            	$('link[rel="canonical"]').attr('href', 'https://yourdost.com/talkItOut');

		    Utils.addEvent(document, "mouseout", function(e){
		    	e ? e : window.event;
		        var from = e.relatedTarget || e.toElement;
		        if (!from || from.nodeName == "HTML") {
		            // stop your drag event here
		            // for now we can just use an alert
		            if(window.location.pathname.indexOf("/talkItOut") > -1) {
						// if(!sessionStorage.talkItOutExitPopup) {
						if($.cookie("talkItOutExitPopup") == "null" || $.cookie("talkItOutExitPopup") == null || $.cookie("talkItOutExitPopup") == undefined || $.cookie("talkItOutExitPopup") == "false") {
							//self.showExitPopup();
							self.trackMixpanel("Serve Exit Popup", { "mediumSource" : "website", 'itemName': 'Out Of Focus Exit Popup' })
						}
		            }
		        }
		    });
		    setTimeout(function(){
		    	// if(!sessionStorage.talkItOutExitPopup) {
		    	if($.cookie("talkItOutExitPopup") == "null" || $.cookie("talkItOutExitPopup") == null || $.cookie("talkItOutExitPopup") == undefined || $.cookie("talkItOutExitPopup") == "false") {
		    		//self.showExitPopup();
					self.trackMixpanel("Serve Exit Popup", { "mediumSource" : "website", 'itemName': 'Time Out Exit Popup' })
				}
		    }, 5*60*1000);
			setTimeout(function(){$(".chat-page").addClass("active");},10);
			var url = window.location.href ;
		    url = url.replace("/talkItOut", "" );
			var fromPage = $.url( url ).param('fromPage');
			$.ajax({

          		url: Utils.scriptPath() + "/banner.json",
        		cache: false
        	}).done( function( data ) {

            	if ( data.visibility == "on") {
            		// $(".page-title").css("margin-bottom", "0px !important");
            		$(".banner-high-traffic-row-talkitout").removeClass("hide");
            	}

        	}).error(function(error){

          		console.log(error)

        	});

        	if(fromPage){

        		self.$el.html(self.LoaderLayout({}));
        	}

			if(Utils.isLoggedIn()){

                var userID = self.userModel.getUserID();
                var url = window.location.href;
                var pathArray = url.split('/');
                var footerCityArray = ['bangalore', 'mumbai', 'delhi', 'pune', 'bhopal', 'hyderabad', 'chennai'];
                var urlCity = pathArray[pathArray.length - 1];
                var isFromCityLink = false;
                if (footerCityArray.indexOf(urlCity) > -1)
                    isFromCityLink = true;
                if (isFromCityLink) {
                    self.showAllExperts();
                } else {
					$.ajax({
        				url : Utils.contextPath() + '/v1/counselor/' + "?user=" + userID + "&familiar=true"
        			}).done(function(response){
	        			if(response.length > 0){
	        				var options = {};
	        				if (response.length == 1) {
	        					options.count = 'one';
	        				}
	        				self.$el.html(self.MyExpertLayout(options));

	        				$(".my-expert-container").html(self.LoaderLayout());

							if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	          					mixpanel.track("My Experts Page", { "mediumSource" : "website" });
	        				}

							Dispatcher.trigger("renderExpertSlider", ".my-expert-container", 1, response, "My Experts");
							$(".my-experts-slider").css("border-bottom", "2px solid white");

	        			}else{

	        				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
	          					mixpanel.track("Expert Listing page", { "mediumSource" : "website" });
	        				}

	        				self.showAllExperts();

	        			}

	        			if ( self.fromPage == 'quickMessage') {
	        				Dispatcher.trigger("openComposeMessage", {
	        					info: {
	        						recipientId: self.sendCounselorInfo["id"]
	        					}
	        				});
	    				}

        			});
				}


			} else {

				if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

          			mixpanel.track("Expert Listing page", { "mediumSource" : "website" });
        		}

				self.showAllExperts();

			}

			$('img.svg').each(function(){
          		console.log('image hello');
	            var $img = $(this);
	            var imgID = $img.attr('id');
	            var imgClass = $img.attr('class');
	            var imgURL = $img.attr('src');

	            $.get(imgURL, function(data) {
	            	console.log( 'image hello 1');
	                // Get the SVG tag, ignore the rest
	                var $svg = $(data).find('svg');

	                // Add replaced image's ID to the new SVG
	                if(typeof imgID !== 'undefined') {
	                    $svg = $svg.attr('id', imgID);
	                }
	                // Add replaced image's classes to the new SVG
	                if(typeof imgClass !== 'undefined') {
	                    $svg = $svg.attr('class', imgClass+' replaced-svg');
	                }

	                // Remove any invalid XML tags as per http://validator.w3.org
	                $svg = $svg.removeAttr('xmlns:a');

	                // Check if the viewport is set, if the viewport is not set the SVG wont't scale.
	                if(!$svg.attr('viewBox') && $svg.attr('height') && $svg.attr('width')) {
	                    $svg.attr('viewBox', '0 0 ' + $svg.attr('height') + ' ' + $svg.attr('width'))
	                }

	                // Replace image with new SVG
	                $img.replaceWith($svg);

	            }, 'xml');

		    });

			if(Utils.isLoggedIn()){

				this.paymentPendingView.render() ;

			}
			// this.startChattingView.render();

			if(this.messageExists =="true"){

				if(this.categoryId == "31"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on parenting? Here are some counselors who can help:", 10000 );
				}else if(this.categoryId == "13"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Don't let anger or anxiety eat you up. Here are some counselors you can talk to:", 10000);
				}else if(this.categoryId == "100"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Have some burning questions on personality development? These YourDOST counselors can help:", 10000);
				}else if(this.categoryId == "33"){

					Utils.displaySuccessMsgWithDelay( "Great! The link to your eBook has been sent to your email.<br/> Want to know more about handling exam stress? These YourDOST counselors can help:", 10000);
				}
			}

		}
	});

	TalkItOutPageV2.prototype.remove = function() {
		this.$el.empty();
    	this.$el.off();
    	this.counselorsView.clean();
    	this.unbind();
    	//this.stopListening();
	};

	TalkItOutPageV2.prototype.clean = function() {
    	this.remove();
	};

	return TalkItOutPageV2;
});
