define([
	'jquery',
	'underscore',
	'moment-timezone-data',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'model/transactions'
], function($,_, moment, Backbone, JST, Dispatcher, Utils, UserModel, UserTransactionModel ) {

	var SessionsV2View = Backbone.View.extend({

		el : 'main' ,
		initialize: function() {

			this.userModel = new UserModel() ;
			this.model = new UserTransactionModel();
			this.upcomingSession = 0 ;
		},
		events: {
			"click #usession-call" : 'makeAudioCall',
			"click #book-appointment-counselor":'bookAppointmentCounselor',
			"click #book-appointment-default":'bookAppointmentDefault',
			"click #openFeedback":'openFeedback',

		},

		SessionsLayout : JST['app/templates/sessionsV2/layout.hbs'],
		NoSessionLayout : JST['app/templates/sessionsV2/no_sessions.hbs'],
		LoaderLayout : JST['app/templates/loader.hbs'],
		FeedbackModal   : JST['app/templates/AppointmentFlow/feedback.hbs'],
		openFeedback:function(feedback){

			self.$el.append(self.FeedbackModal({feedback:resp}));
		},
		noSession : function(){
			var self = this ;
			self.$el.html(self.NoSessionLayout());
		},
		render : function(){

			if(!Utils.isLoggedIn()){
				var hash = location.pathname;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash ;
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});
	            }
				return this ;
			}

			var self = this ;
			var user_id = self.userModel.getUserID() ;
			self.$el.html(self.LoaderLayout);

			//self.$el.html(self.SessionsLayout);
			self.renderUpcomingSession();

		},
		renderUpcomingSession : function(){

			var self = this ;
			var userID = this.userModel.getUserID() ;

			$.ajax({
				url : Utils.contextPath() + '/v2/users/'+ userID +'/appointment/all'
			}).done(function(response){
				self.$el.html(self.SessionsLayout);
				console.log(response);
				if(response.length > 0){
					var appointment_requested ='';
					var appointment_upcoming ='';
					var appointment_ongoing = '';
					var appointment_today = '';
					var appointment_completed = '';
					for(var i = 0 ; i< response.length;i++ ){
						console.log("i :", i);
						console.log("status", response[i].status)
						var cId = response[i].lineItems[0].product.appointment.counselorID
						var st  = response[i].status;
						var today = new Date();
						var days = ['Sun','Mon','Tue','Thu','Fri','Sat'];
						var months = ['Jan','Feb','Mar','Apr','May','Jun','July','Aug','Sep','Oct','Nov','Dec'];
						var tommorow = new Date(today.getTime() + 24 * 60 * 60 * 1000)
						var slotStartTime = new Date(response[i].lineItems[0].product.appointment.slotStartTime);
						var slotEndTime = new Date(response[i].lineItems[0].product.appointment.slotEndTime);
						var type = response[i].lineItems[0].product.type;
						var appointment_row = '';
						var name = '';
						if(response[i].counselor != null){
							 name = response[i].counselor.firstName+" "+response[i].counselor.lastName;
						}

						var skype = 'We need your Skype ID in order to connect you. Please write in to customer support@yourdost.com';
						if(response[i].lineItems[0].product.appointment.skypeID != null && response[i].lineItems[0].product.appointment.skypeID != undefined){
							skype = 'Please be online on your Skype ID:'+response[i].lineItems[0].product.appointment.skypeID+', from about 5 minutes prior to your appointment. Your expert will call you at the time of the appointment';
						}

						if(type == 'VIDEO' && st != 'COMPLETED'){
								appointment_row = '<li class="collection-item session-element-video">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-video"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Video Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
		        									'<div class="col s3 session-element-call">'+
		        									'</div>'+
		        									'<span class=" col s10 video-subtext">'+skype+'</span>'+
		        									'</li>';
						}
						if(type === 'FACE2FACE' && st !== 'COMPLETED'){
							appointment_row = '<li class="collection-item session-element-audio">'+
												'<div class="col s1 session-element-icon">'+
												'<i class="mdi mdi-account"></i>'+
												'</div>'+
												'<div class="col s10 session-element-text">'+
												'<span><b>Face To Face Appointment </b>with <b>'+name+' </b>at '+ months[slotStartTime.getMonth()]+" "+slotStartTime.getDate()+", "+ slotStartTime.getFullYear()+'</span>'+
												'</div>'+
												'</li>';
						}
						if(today > slotStartTime && today < slotEndTime && (st == 'PAID' || st == 'SCHEDULED')){
							if(type == 'AUDIO'){
								appointment_row = '<li class="collection-item session-element-audio">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-phone"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Audio Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
		        									'<div class="col s3 session-element-call">'+
		        									'<span class="btn" id="usession-call" data-desc="CallNow_MySessions" app-id = "'+response[i].lineItems[0].product.appointment.id+'" user-id = "'+response[i].user.id+'">CALL NOW</span>'+
		        									'</div>'+
													'</li>';
							}
								appointment_ongoing += appointment_row;
						}
						if(slotEndTime > today && slotStartTime <tommorow && (st == 'PAID' || st == 'SCHEDULED')){
							if(type == 'AUDIO'){
								appointment_row = '<li class="collection-item session-element-audio">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-phone"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Audio Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
													'</li>';
							}

								appointment_today += appointment_row;
						}
						if(st == 'REQUESTED' || (slotStartTime > tommorow && (st == 'PAID'))){
							if(type == 'AUDIO'){
								appointment_row = '<li class="collection-item session-element-audio">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-phone"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Audio Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
													'</li>';
							}

								appointment_requested += appointment_row;
						}
						if(slotStartTime > tommorow &&  st == 'SCHEDULED'){
							if(type == 'AUDIO'){
								appointment_row = '<li class="collection-item session-element-audio">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-phone"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Audio Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
													'</li>';
							}

								appointment_upcoming += appointment_row;
						}
						if(st == 'COMPLETED'){
							var extra = '';
							if(response[i].lastFeedback != undefined && response[i].lastFeedback.counselor_id != 0){
							if(response[i].lastFeedback.state == 2){
								extra = '<div class=" s12 ">'
									for(star = 1 ; star <= response[i].lastFeedback.star; star++){
										extra += '<i class="mdi-action-grade teal-text rating"></i>'
									}
			        					extra += '</div>'+
			        					'<span class="btn s3 cpointer" style="margin-bottom: 10px;" id="book-appointment-counselor" counselor-id = "'+response[i].counselor.id+'">BOOK APPOINTMENT</span>';
							}else if(response[i].lastFeedback.state == 0){
								extra = '<span class="btn s3 cpointer" style="margin-bottom: 10px;" id="book-appointment-counselor"  counselor-id = "'+response[i].counselor.id+'">BOOK APPOINTMENT</span>';
							}else{
								extra = '<span class="btn s3 cpointer" id ="openFeedback" counselor-id = "'+response[i].counselor.id+'" >GIVE FEEDBACK</span>'+
			        					'<span class="btn s3 cpointer" id ="book-appointment-counselor"  counselor-id = "'+response[i].counselor.id+'" ">BOOK APPOINTMENT</span>';
							}
						}else{
							extra = '<span class="btn s3 cpointer" id ="openFeedback" counselor-id = "'+response[i].counselor.id+'" >GIVE FEEDBACK</span>'+
			        					'<span class="btn s3 cpointer" id ="book-appointment-counselor" counselor-id = "'+response[i].counselor.id+'" ">BOOK APPOINTMENT</span>';

						}
							if(type == 'AUDIO'){
								appointment_row = '<li class="collection-item session-element-completed">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-phone"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Audio Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
		        									'<div class=" col s9 extra-completed">'+extra+
			        								'</div></li>';
													'</li>';
							}
							if(type == 'VIDEO'){
								appointment_row = '<li class="collection-item session-element-completed">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-video"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Video Call </b>with <b>'+name+' </b>at '+slotStartTime.toLocaleString()+'</span>'+
		        									'</div>'+
		        									'<div class="col s3 session-element-call">'+
		        									'</div>'+
		        									'<div class=" col s9 extra-completed">'+extra+
			        								'</div></li>';
							}
							if(type == 'FACE2FACE'){
								appointment_row = '<li class="collection-item session-element-completed">'+
		        									'<div class="col s1 session-element-icon">'+
		        									'<i class="mdi mdi-account"></i>'+
		        									'</div>'+
		        									'<div class="col s8 session-element-text">'+
		        									'<span><b>Face To Face Appointment </b>with <b>'+name+' </b>at '+ months[slotStartTime.getMonth()]+" "+slotStartTime.getDate()+","+ slotStartTime.getFullYear()+'</span>'+
		        									'</div>'+
		        									'<div class="col s3 session-element-call">'+
		        									'</div>'+
		        									'<div class=" col s9 extra-completed">'+extra+
			        								'</div></li>';
							}
							appointment_completed += appointment_row;

						}

					}

					if(appointment_ongoing ==''){
						$('.appointment-ongoing').addClass('hide')
					}
					if (appointment_requested ==''){
						$('.appointment-requested').addClass('hide')
					}
					if (appointment_today ==''){
						$('.appointment-today').addClass('hide')
					}
					if (appointment_completed == ''){
						$('.appointment-completed').addClass('hide')
					}
					if (appointment_upcoming == ''){
						$('.appointment-upcoming').addClass('hide')
					}
					var renderedParts = '';
					if(appointment_ongoing !=''){
						renderedParts +="ONGOING "
					}
					if (appointment_requested !=''){
						renderedParts += "REQUESTED "
					}
					if (appointment_completed !=''){
						renderedParts += "COMPLETED "
					}
					if (appointment_today !=''){
						renderedParts += "TODAY "
					}
					if (appointment_upcoming != ''){
						renderedParts += "UPCOMING "
					}
					if(renderedParts == ''){
						renderedParts = 'No Sessions';
						self.noSession();
					}

					$('.appointment-ongoing ul').append(appointment_ongoing);
					$('.appointment-requested ul').append(appointment_requested);
					$('.appointment-today ul').append(appointment_today);
					$('.appointment-upcoming ul').append(appointment_upcoming);
					$('.appointment-completed ul').append(appointment_completed);
					if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 		mixpanel.track("My Sessions Rendered", {  "itemName" : renderedParts });
        			}
				}else{
					self.noSession();
				}
			}).error(function(error){
				console.log(error);
				self.noSession();
			});

		},
		openFeedback:function(e){
			var conId = $(e.currentTarget).attr("counselor-id")
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("Button Click", {  "itemName" : "Feedback_MySessions" });
        	}
			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + conId+ '&catID=Others', {trigger: true});
		},
		bookAppointmentCounselor:function(e){
			var conId = $(e.currentTarget).attr("counselor-id")
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("Button Click", {  "itemName" : "#APPT - Another_MySessions" });
        	}
			Backbone.history.navigate('bookAppointment?from=talkItOut&conID=' + conId+ '&catID=Others', {trigger: true});
		},
		bookAppointmentDefault:function(){
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("Button Click", {  "itemName" : "#APPT - My Sessions page" });
        	}
			Backbone.history.navigate('bookAppointment', {trigger: true});

		},
		makeAudioCall:function(e){

			var appointmentID = $("#usession-call").attr("app-id");

			var userID = $("#usession-call").attr("user-id");
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
         		 mixpanel.track("Button Click", {  "itemName" : "CallNow_MySessions" });
        	}
			$.ajax({
				url : Utils.contextPath() + '/v2/users/' + userID + '/appointment/' + appointmentID +'/call',
				method : 'POST',
				dataType: "JSON",
                contentType: "application/json; charset=utf-8",
			}).done(function(response){
				$('.session-element-call').addClass('hide');
				setTimeout(function(){
					$('.session-element-call').removeClass('hide');
					},180000);
				//$(".upcoming-session-content").html("You will receive a call on your mobile. Answering the call will connect you to your expert.");
			}).error(function(error){
				console.log(error);
			});

		},

		getDateTime : function(millis){
			// TODO
			return -1;
		},

	});


	SessionsV2View.prototype.remove = function() {};

	SessionsV2View.prototype.clean = function() {};
	return SessionsV2View;
});
