define([
	'jquery',
	'underscore',
	'backbone',
	'../../precompiled-templates',
	'utils',
	'event/dispatcher',
	'model/UserMsgModel',
	'model/users',
	'view/subTemplates/experts',
	'view/subTemplates/quotes',
	'view/subTemplates/articles',
	'view/subTemplates/signup',
	'ajax-chosen',
	'jquery-ui',
	'ui-autocomplete',
	'purl'
], function($,_, Backbone, JST, Utils, Dispatcher, UserMsgModel, UserModel, ExpertsView, QuotesView, ArticlesView, SignupView) {
	var MPBSEPage = Backbone.View.extend({
		el: "main",
		initialize: function() {
			this.model = new UserModel();
			this.experts = new ExpertsView();
			this.quotes = new QuotesView();
			this.articles = new ArticlesView();
			this.signup = new SignupView();
		},
		mainLayout : JST['app/templates/MPBSE/layout.hbs'],
		bannerLayout : JST['app/templates/MPBSE/banner.hbs'],
		events: {
			'click #mp-chat-now-btn' : 'chatNow',
			'click .mpbse-login' : 'openLogin'
		},
		redirectTochat : function(){
			Dispatcher.trigger('chatQuickCheck', 'demo', 1, "", "", "home", {});
		},
		openLogin : function(){
				if(!Utils.isLoggedIn()){
					this.scrollToForm()
				  //Dispatcher.trigger("renderLogin", "click Landing MPBSE Page", "login", "loginButton") ;
				}
		},
		chatNow : function(evt){
			if(Utils.isLoggedIn()){
				this.redirectTochat()
			}else{
				this.scrollToForm()
			}
		},
		scrollToForm : function( ){
			Utils.scrollTo("#MPBSE-signup-section");
		},
		render: function() {
			if(Utils.isLoggedIn()){
				$(".mpbse-login").remove()
			}
			var self = this;
			this.$el.html(this.mainLayout( { loggedIn : Utils.isLoggedIn() } ));
			this.sendRequest({method : "GET", url : Utils.contextPath() + "/v1/dashboard/ongoingCnt"})
			.then(function (res) {
				$("#MPBSE-banner-section").html(self.bannerLayout( {loggedIn : Utils.isLoggedIn(), onlineCount : res + 20}))
			});
			this.experts.render("MPBSE-experts-section")
			this.quotes.render("MPBSE-quotes-section")
			this.articles.render("MPBSE-articles-section")
			if(!Utils.isLoggedIn()) this.signup.render("MPBSE-signup-section")

		},
		sendRequest: function (options) {
			var deferred = $.Deferred();
			$.ajax(options)
				.done(function (response) {
					deferred.resolve(response);
				})
				.fail(function (error) {
					deferred.reject(error);
				})
				return deferred.promise();
		},
	});
	MPBSEPage.prototype.remove = function() {
		this.$el.empty();
    this.$el.off();
    this.stopListening();
	};
	MPBSEPage.prototype.clean = function() {
		this.remove();
	};
	return MPBSEPage;
});
