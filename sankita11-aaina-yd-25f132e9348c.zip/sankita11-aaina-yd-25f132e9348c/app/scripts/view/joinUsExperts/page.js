define([
  'jquery',
  'underscore',
  'event/dispatcher',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'model/users'
], function($,_, Dispatcher, Backbone, JST, Utils, UserModel ) {

    var JoinUsExpertPageView = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
      },
      
      events: {
        "click #submit-become-volunteer": "saveVolunteerInfo",
        "click .volunteer-dropdown-container #dropArrow" :"dropArrow",  
        "click .volunteer-dropdown-container #selected-volunteer-dropdown":"dropArrow",  
        "click .volunteer-dropdown-container .volunteer-drop-item":"selectFromDropDown",  
      },
      
      Layout: JST['app/templates/joinUsExperts/layout.hbs'],
      ContactUsPageSuccessLayoutTemplate : JST['app/templates/contactUs/contactUsSuccess.hbs'],

      dropArrow:function(e){
        e.stopPropagation();
        if($('.volunteer-dropdown-content').is(":visible")){
          $('.volunteer-dropdown-content').addClass('hide');

          $('.swiper-button-next').css({'top':'50%'});
          $('.swiper-button-prev').css({'top':'50%'});
        
        }else{
          $('#selected-volunteer-dropdown').focus();
          $('.volunteer-dropdown-content').removeClass('hide');
        }
      },

      selectFromDropDown:function(e){
        var self = this;
        var qualId = $(e.currentTarget).attr('data-val');
        var qualName=$(e.currentTarget).text();
        $('.volunteer-drop-item').removeClass('ex-selected-2');
        $(e.currentTarget).addClass('ex-selected-2');

        $('#selected-volunteer-dropdown').val(qualName);
        $('#selected-volunteer-dropdown').attr('data-val', qualId);
        // $('#selected-volunteer-dropdown+label').hide();
        $('#selected-volunteer-dropdown+label').addClass("active");
        $('.volunteer-dropdown-content').addClass('hide');
      },

      checkForName : function(e){

        var name = $("#volunteer-name").val().trim();
        if( !Utils.checkForNameField(name) ){
          console.log("hello");
          $("#vol-name-error").html("Please enter valid name");
          $("#vol-name-error").removeClass("hide");
          $("#volunteer-name").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-name').scrollIntoView(true);
          
          return 0 ;
        }else{
          $("#vol-name-error").addClass("hide");
          Utils.formEnableSubmit('submit-become-volunteer');
          $("#volunteer-name").addClass("valid").removeClass("invalid") ;
          return 1 ;
        }

      },
      
      checkForCity: function(e) {

        var city = $("#volunteer-city").val().trim();

        if( !Utils.checkForCityField( city ) ){

          $("#vol-city-error").html( "Please enter valid city" );
          $("#vol-city-error").removeClass("hide");
          $("#volunteer-city").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-name').scrollIntoView(true);
          
          return 0 ;
        }else{

          $("#vol-city-error").addClass("hide");
          Utils.formEnableSubmit('submit-become-volunteer');
          $("#volunteer-city").addClass("valid").removeClass("invalid") ;
          return 1 ;
        
        }
      },
      
      checkForEmail : function(e){
        var isValidEmail = Utils.formEmailCheck($("#volunteer-email").val().trim());
        if(!isValidEmail){
          $("#vol-email-error").html("Please enter valid email id");
          $("#vol-email-error").removeClass("hide");
          $("#volunteer-email").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-email').scrollIntoView(true);
          
          return 0 ;
        }else{
          $("#vol-email-error").addClass("hide");
          $("#volunteer-email").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }
      },
      
      checkForMobile : function(e){
        var isValidMobile = Utils.formMobileCheck($("#volunteer-phone").val().trim());
        if(!isValidMobile){
          $("#vol-phone-error").html("Please enter valid 10 digit phone number");
          $("#vol-phone-error").removeClass("hide");
          $("#volunteer-phone").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          // document.getElementById('volunteer-phone').scrollIntoView(true);
          
          return 0 ;
        }else{
          $("#vol-phone-error").addClass("hide");
          $("#volunteer-phone").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }
      },
      
      checkForDesc :  function(e){
        var description = $("#volunteer-desc").val().trim().trim() ;
        if( description.length < 100 ){
          $("#volunteer-desc").addClass("invalid") ;
          $("#form-error-volunteer-desc").removeClass("hide") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          return 0;
        }else{
          if($("#volunteer-desc").hasClass("invalid"))
            $("#volunteer-desc").removeClass("invalid");
          if(! $("#form-error-volunteer-desc").hasClass("hide"))
            $("#form-error-volunteer-desc").addClass("hide") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1;
        }
      },

      checkForVolunteerSkillSet :  function(e){

        var description = $("#volunteer-skill-set").val().trim().trim() ;
        if( description.length < 100 ){
          $("#volunteer-skill-set").addClass("invalid") ;
          $("#form-error-volunteer-skill-desc").removeClass("hide") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          return 0;
        }else{
          if($("#volunteer-skill-set").hasClass("invalid"))
            $("#volunteer-skill-set").removeClass("invalid");
          if(! $("#form-error-volunteer-skill-desc").hasClass("hide"))
            $("#form-error-volunteer-skill-desc").addClass("hide") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1;
        }
      },

      checkForFacebookProfileURL: function(e) {
        
        var isValidFacebookProfileUrl = Utils.formFacebookProfileUrlCheck( $( "#volunteer-fb-link" ).val().trim() );
        console.log( isValidFacebookProfileUrl );
        if( !isValidFacebookProfileUrl ){
          console.log( "hello" );
          $("#volunteer-fb-link-error").html("Please enter valid facebook profile url");
          $("#volunteer-fb-link-error").removeClass("hide");
          $("#volunteer-fb-link").addClass("invalid").removeClass("valid") ;
          Utils.formDisableSubmit('submit-become-volunteer');
          
          return 0 ;
        }else{

          $("#volunteer-fb-link-error").addClass("hide");
          $("#volunteer-fb-link").addClass("valid").removeClass("invalid") ;
          Utils.formEnableSubmit('submit-become-volunteer');
          return 1 ;
        }

      },

      attachFile: function(e) {
        var resumeName = $("#volunteer-resume").val().split('/').pop().split('\\').pop();
        $('.job-application-resume-attached-name').text( resumeName );
        $('.job-application-resume-attached-name').removeClass('hide');
        $("#volunteer-resume-error").addClass("hide")
      },

      saveVolunteerInfo : function (e) {

        if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
          mixpanel.track("Submit Form", { "mediumSource" : "website", "itemName" : 'Join Us As Expert' });
        }

        $("#volunteer-resume-error").addClass("hide")
        
        var isValidDesc = this.checkForDesc();
        var isValidVolunteerSkillSet = this.checkForVolunteerSkillSet();
        var isValidName = this.checkForName() ;
        var isValidEmail = this.checkForEmail() ;
        var isValidMobile = this.checkForMobile() ;
        var isValidCity = this.checkForCity();
        var isValidFacebookProfileUrl = this.checkForFacebookProfileURL();
        var file = $('#volunteer-resume').get(0).files[0];

        if( isValidDesc == 0 || isValidVolunteerSkillSet == 0 || isValidName == 0  || isValidEmail == 0 || isValidMobile == 0 || isValidCity == 0 || isValidFacebookProfileUrl == 0 ){
          return false;
        }

        if(!file){
          $("#volunteer-resume-error").removeClass("hide").html("Resume is required");
          return false;
        }

        if(file.type == "application/x-ms-dos-executable" || file.type == 'application/x-msdownload'){

          $("#volunteer-resume-error").removeClass("hide").html("Only PDF is allowed");
          return false;
        }

        if(file.type != "application/pdf"){

          $("#volunteer-resume-error").removeClass("hide").html("Only PDF is allowed");
          return false;
        }

        var self = this ;
        var dataToSend = new FormData();
        dataToSend.append('description', $("#volunteer-desc").val().trim());
        dataToSend.append('skills', $("#volunteer-skill-set").val().trim());
        dataToSend.append('name', $("#volunteer-name").val().trim());
        dataToSend.append('city', $("#volunteer-city").val().trim());
        dataToSend.append('email', $("#volunteer-email").val().trim());
        dataToSend.append('phone', $("#volunteer-phone").val().trim());
        dataToSend.append('qualification', $("#selected-volunteer-dropdown").val().trim());
        dataToSend.append('file', file);

        if ( $("#volunteer-fb-link").val().trim().length > 0 ) {
          dataToSend.append('profileUrlLink', $("#volunteer-fb-link").val().trim());
        }
        
        $.ajax({
          url : Utils.contextPath() + "/volunteer",
          method : "POST",
          cache: false,
          contentType: false,
          processData: false,
          data : dataToSend
        }).done(function(response){
          
          var title = "Thank you for your interest.";
          var subtitle = "We will soon get in touch with you.";
          if (!response) {
            subtitle = 'There was an error while registraion. Please try again.'
          }
          self.$el.find('.joinUsExperts-right-pane').html( self.ContactUsPageSuccessLayoutTemplate({title:title, subtitle: subtitle}) );
          
          if ( !Utils.isMobileDevice() ) {
            Utils.scrollTo(".joinUsExperts-box", 0);  
          } else {
            Utils.scrollTo(".joinUsExperts-right-pane-col", 0);
          }
          

        }).error(function(error){
          console.log(error) ;
        });

      },

      render: function() {

        var self = this;
        
        console.log( "render" );

        $.ajax({
          method : "GET",
          url : Utils.scriptPath() + "/joinUsExperts.json",
          cache: false
        }).done( function(response){

          var headerTitle = response["header-title"];
          var headerSubtitle = response["header-subtitle"];
          var textInTheBox = response["text-in-the-box"];
          var subtitleInTheBox = response["subtitle-in-the-box"];
          var leftPaneTitle = response["left-pane-title"];
          var rightPaneTitle = response["right-pane-title"];
          var joinUsExpertsDescriptions = response["left-pane-description"];
          var qualifications = response["qualifications"];

          self.$el.html( self.Layout( {headerTitle: headerTitle, headerSubtitle:headerSubtitle, textInTheBox: textInTheBox, subtitleInTheBox: subtitleInTheBox,  leftPaneTitle: leftPaneTitle, rightPaneTitle: rightPaneTitle, joinUsExpertsDescriptions: joinUsExpertsDescriptions, qualifications: qualifications} ) );  
          
          $("#volunteer-desc").keystop( function(event){
            self.checkForDesc(event) ;
          }, 1000 ) ;

          $("#volunteer-skill-set").keystop( function(event){
            self.checkForVolunteerSkillSet(event) ;
          }, 1000 ) ;

          $("#volunteer-name").keystop( function(event){
            self.checkForName(event) ;
          }, 1000 ) ;

          $("#volunteer-email").keystop( function(event){
            self.checkForEmail(event) ;
          }, 1000 ) ;

          $("#volunteer-phone").keystop( function(event){
            self.checkForMobile(event) ;
          }, 1000 ) ;

          $( "#volunteer-city" ).keystop( function(event){
            self.checkForCity(event);
          });
        
          $( "#volunteer-fb-link" ).keystop( function(event) {
            self.checkForFacebookProfileURL( event );
          });

          $( "#selected-volunteer-dropdown" ).keydown( function(event) {
            event.preventDefault();
          });

          $( "#volunteer-resume" ).change(function(event){
            self.attachFile(event);
          });

        }).error( function(error){
          console.log( error );
        });

        $(document).off().on('click',function(e){
          if(!$(e.currentTarget).parent().hasClass('volunteer-dropdown-bar')){
            if($('.volunteer-dropdown-content').is(":visible")){
              $('.volunteer-dropdown-content').addClass('hide');
            }
          }
        });
        
      
      }

  });

  JoinUsExpertPageView.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind(); 
	};

	JoinUsExpertPageView.prototype.clean = function() {

      this.remove();

	};

  return JoinUsExpertPageView;
});
