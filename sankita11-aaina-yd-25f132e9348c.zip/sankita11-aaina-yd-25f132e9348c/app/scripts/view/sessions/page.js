define([
	'jquery',
	'underscore',
	'moment-timezone-data',
	'backbone',
	'../../precompiled-templates',
	'event/dispatcher',
	'utils',
	'model/users',
	'model/transactions'
], function($,_, moment, Backbone, JST, Dispatcher, Utils, UserModel, UserTransactionModel ) {

	var SessionsView = Backbone.View.extend({

		el : 'main' ,
		history : '#history',
		initialize: function() {

			this.userModel = new UserModel() ;
			this.model = new UserTransactionModel();
			this.upcomingSession = 0 ;
		},
		events: {
			"click #usession-call" : 'makeAudioCall'
		},

		SessionsLayout : JST['app/templates/sessions/layout.hbs'],
		NoSessionLayout : JST['app/templates/sessions/no_sessions.hbs'],
		LoaderLayout : JST['app/templates/loader.hbs'],

		noSession : function(){
			var self = this ;
			var no_session_html = self.NoSessionLayout();
			self.$el.html(no_session_html);
		},

		render : function(){
			
			if(!Utils.isLoggedIn()){
				var hash = location.pathname;
				hash = hash.replace("/", "") ;
	            if(hash.match("login")){
	               //location.href = window.location.pathname;
	               Backbone.history.navigate(window.location.pathname, {trigger: true});
	            }else{
	               //location.href = "/login?r=" + hash ;   
	               Backbone.history.navigate("/login?r=" + hash, {trigger: true});                     
	            }
				return this ;
			}

			var self = this ;
			var user_id = self.userModel.getUserID() ; 

			
			self.$el.html(self.SessionsLayout);
			self.renderUpcomingSession();
			
		},
		renderUpcomingSession : function(){

			var self = this ;
			var userID = this.userModel.getUserID() ; 

			$.ajax({
				url : Utils.contextPath() + '/v2/users/'+ userID +'/appointment/current'
			}).done(function(response){
				console.log(response);
				if(response.length > 0){
					self.upcomingSession = 1 ;
					$("#upcoming-appointment").removeClass("hide");
					$('.dost-main').css({'min-height':'80%'});
					var slotStartTime = response[0].appointment.slotStartTime;
					slotStartTime =  Utils.getDateString(slotStartTime, "time");

					$("#usession-call").attr("app-id", response[0].appointment.id);
					$("#usession-call").attr("user-id", response[0].appointment.refID);
					$(".usession-time").html(slotStartTime);

				}else{
					self.noSession();
				}
			}).error(function(error){
				console.log(error);
			});

		},

		makeAudioCall:function(e){

			var appointmentID = $("#usession-call").attr("app-id");

			var userID = $("#usession-call").attr("user-id");

			$.ajax({
				url : Utils.contextPath() + '/v2/users/' + userID + '/appointment/' + appointmentID +'/call',
				method : 'POST',
				dataType: "JSON",
                contentType: "application/json; charset=utf-8",
			}).done(function(response){
				$(".upcoming-session-content").html("You will receive a call on your mobile. Answering the call will connect you to your expert.");
			}).error(function(error){
				console.log(error);
			});			

		},

		getDateTime : function(millis){
			// TODO
			return -1;
		},

	});

	
	SessionsView.prototype.remove = function() {};

	SessionsView.prototype.clean = function() {};
	return SessionsView;
});
