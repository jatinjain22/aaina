define([
  'jquery',
  'underscore',
  'event/dispatcher',
  'backbone',
  '../../precompiled-templates',
  'utils',
  'Swiper',
  'model/users',
  'model/UserMsgModel'
], function($,_, Dispatcher, Backbone, JST, Utils, Swiper, UserModel, UserMsgModel ) {

    var landingPageView2 = Backbone.View.extend({

      el: 'main',

      initialize: function() {
        this.userModel = new UserModel() ;
        this.userMsgModel = new UserMsgModel();

      },
      
      events: {
        'click .consult-now-button' : 'consultNow',
        "click #compose .mclose" : "hideCompose",
        "click .modal-consult-now-button": "sendMessage",
        "click .login-landing-page": "loginMessage",
        "click .mob-login-landing-page a": "loginMessage"
      },
      hideCompose : function(){
        Utils.closePopup('compose') ;
        $("#compose").remove();
      },
      loginMessage: function() {

        setTimeout(function(){
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){ 

            mixpanel.track('Login', {'mediumSource' : 'website', 'itemName': 'Career Counselor Landing Page Login', 'itemtype': 'career counselor landing page'});
          
          }
        }, 2000);  

        console.log( "heloo");
        if ( !Utils.isLoggedIn() ) {
         
          Dispatcher.trigger("renderLogin", "Career Counselor Landing Page Login", "landingpage2", "SignupButton") ;          
        
        }
        
      },
      
      ComposePageLayout : JST['app/templates/landingPages1/composeMessage.hbs'], 

      sendMessage: function(e) {
        //

        console.log( 'ouside mixpanel' );
        setTimeout(function(){
          
          if (  ( typeof mixpanel != 'undefined' ) && (typeof mixpanel.track === "function") ){ 

            console.log( 'inside mixpanel' );
            mixpanel.track('Send Message', {'mediumSource' : 'website', 'itemName': 'Career Counselor Landing Page Post Question Button', 'itemtype': 'career counselor landing page'});
          
          }
        }, 2000);
        
        var self = this;
        var messageBody = $("#message").val();
        
        if ( $("#message").val() ) {

            if(!Utils.isLoggedIn()){
            
              //setTimeout(function(){

                Dispatcher.trigger("renderLogin", "career landing page message modal login", "landingPage2Message", "", messageBody) ;
              //}, 500) ;
            
            }
            else {
                console.log( $("#message").val() );
                var msgJSON = {
                  "threadID":0,
                  "subject":'Career Message',
                  "content":$("#message").val(),
                  "recipients": ['101'],
                  "categoryIds": ['0']
                };

                $.ajax({
                    method: "POST",
                    url: Utils.contextPath()+'/v1/users/'+self.userMsgModel.get("userID")+'/messages',
                    data: JSON.stringify(msgJSON),
                    contentType: "application/json",
                    statusCode : {
                      417 : function(response){

                      var responseText = response.responseText;
                      var responseJson = JSON.parse(responseText) ;

                      var errorMessage = responseJson.message ; 
                      var errorType    = responseJson.type ;

                      $(".iauthentication-error").html(errorMessage);
                      $(".iauthentication-error").show() ;

                      },
                      500 : function(){
                        $(".iauthentication-error").html("Something went wrong. Please try again");
                        $(".iauthentication-error").show() ;
                      },

                    }
                    }).done(function(response){
                      
                      //self.hideCompose();
                      //Utils.displaySuccessMsg("Your message has been sent.");
                      // $(".modal-consult-now-button-div").addClass('hide');
                      // $(".modal-consult-now-question").addClass('hide');
                      // $(".consult-now-modal-acknowledgement-message").removeClass('hide');
                      console.log( "hello" );
                      var htmlResponse = '<div class="row consult-now-modal-acknowledgement-message">'
                                          + '<div class="col s12 ">'
                                          +    '<p class="teal-text">Your message has been sent. You will hear from us soon</p>'
                                          + '</div>'
                                          + '</div>';
                      self.$el.find("#acknowledge-message").html( htmlResponse );
                      
                      setTimeout( function() {
                        self.hideCompose();
                      }, 3000);

                      console.log( "successfull" );
                      //end modal
                      //return true;
                    }).fail(function(error){
                      console.log(error);
                      $("#compose-send-btn").removeClass("disabled").html('SEND NOW<i class="mdi-content-send right"></i>');
                  });
            }
            //self.hideCompose();
          }
        //setTimeout(function(){
          
        //}, 1000);
      }, 
      consultNow : function(e){

        setTimeout(function(){
          if ( typeof mixpanel != 'undefined' && (typeof mixpanel.track === "function") ){ 

            mixpanel.track('Consult Now', {'mediumSource' : 'website', 'itemName': 'Career Counselor Landing Page Consult Now Button', 'itemtype': 'career counselor landing page'});
          
          }
        }, 2000);

         var self = this;
         self.$el.append( self.ComposePageLayout() );
         //$(".msg-to-name").text( user.username );
         $(".user-header").removeClass("hide");
         $(".friend-header").addClass("hide");
         $("#send-to").addClass("hide");
        $(".user-friend").removeClass("hide");
        $(".category-field").removeClass("hide");
         $('body').css({'overflow-y' : 'hidden'});
        Utils.openPopup("compose");
        

        
      },

      LandingPageLayouttemplate : JST['app/templates/landingPages1/layout.hbs'],

      render: function() {

        console.log( 'ouside mixpanel' );
        
        setTimeout(function(){
          if (  typeof mixpanel != 'undefined'  &&  typeof mixpanel.track === "function" ){ 
            
            console.log( 'inside mixpanel' );
            mixpanel.track('Career Counselor Landing Page', {'mediumSource' : 'website', 'itemtype': 'landing page', 'itemName': 'Career Counselor Landing Page'});
          
          } 
        }, 2000);
        
        console.log( "render" );
        var self = this;

        //document.body.style.overflow = 'hidden';

        $.ajax({
          method : "GET",
          url : '/scripts/json/user_reviews_counselors.json',
          contentType: 'text/plain',
        }).done(function(response){

          if(!Utils.isLoggedIn()){
            
            var username = '';
          }else{
            var username  = self.userModel.getUserName() ;
          }

          self.$el.html( self.LandingPageLayouttemplate({reviews : response, isLoggedIn: Utils.isLoggedIn(), username: username}) );
          $('header').hide();
          $('#footer').hide();
          var mySwiper = new Swiper ('.careerpage-testimonials-1', {
            
              loop: true,
              pagination: '.careerpage-pagination',
              paginationClickable: true,
              autoplay: 10000,
          });

        }).error(function(error){

          console.log(error);
        });

        
        //this.$el.html( this.LandingPageLayouttemplate() );
        
        //return this;
      }
    });

  landingPageView2.prototype.remove = function() {
    this.$el.empty();
    this.$el.off();
    this.unbind(); 
	};

	landingPageView2.prototype.clean = function() {

      this.remove();

	};

    return landingPageView2;
});
