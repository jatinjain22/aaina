define(['handlebars'],function(Handlebars){
        
    Handlebars = Handlebars['default']  ;
    
    Handlebars.registerHelper('trimHtml', function (content, block) {

        var trimed_content = content.replace(/<\/?[^>]+(>|$)/g, "");
        
        return trimed_content;
        
    });

    return Handlebars ; 
});