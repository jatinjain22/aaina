define(['handlebars'],function(Handlebars){
	Handlebars = Handlebars['default']  ;	
	Handlebars.registerHelper('ratingHtml', function(to, block) {
		var accum = '';

		for(var i = 1; i <= to; i++ ){

			accum += '<i class="mdi-action-grade teal-text rating"></i>';
		}

		for(var j = to; j < 5; j++ ){

			accum += '<i class="mdi-action-grade grey-text text-lighten-2 rating"></i>';
		}

		return accum;

  	});

	return Handlebars ;	
});
