define(['handlebars'],function(Handlebars){

	Handlebars = Handlebars['default']  ;

	Handlebars.registerHelper('replaceBrackets', function(str, block) {
		var replacedStr = str.replace(/\(/g, "BRACKETO") ;
			replacedStr = replacedStr.replace(/\)/g, "BRACKETC");
			replacedStr = replacedStr.replace(/\//g, "SLASH");
			replacedStr = replacedStr.replace(/\./g, "DOT");
		return replacedStr ;
  	});

	return Handlebars;	
});
