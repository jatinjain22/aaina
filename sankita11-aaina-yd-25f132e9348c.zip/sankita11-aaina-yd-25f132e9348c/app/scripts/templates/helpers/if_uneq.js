define(['handlebars'],function(Handlebars){
		
	Handlebars = Handlebars['default']  ;
	
	Handlebars.registerHelper('if_uneq', function(a, b, block) {
		
		if( a != b ){
			return block.fn(this);
		}else{
			return block.inverse(this);
		}
  	});

	return Handlebars ;	
});