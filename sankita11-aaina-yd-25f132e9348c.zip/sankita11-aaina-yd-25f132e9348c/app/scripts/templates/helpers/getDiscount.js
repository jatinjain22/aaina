define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;
	Handlebars.registerHelper('getDiscount', function(discount, amount, block) {
		
		var discountAmount = (parseInt(amount)*parseInt(discount))/100;

		discount = parseInt(amount) - parseInt(discountAmount)
		
		return parseInt(discount);
  	});

	return Handlebars;	
});
