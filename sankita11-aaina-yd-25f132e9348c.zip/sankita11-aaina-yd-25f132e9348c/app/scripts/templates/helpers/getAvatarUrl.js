define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;	
	Handlebars.registerHelper('getAvatarUrl', function( avatar, block) {
		var avatarUrl = Utils.avatarToImage(avatar) ;
		return avatarUrl;
  	});

	return Handlebars;	
});
