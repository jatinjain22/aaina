define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;
	Handlebars.registerHelper('getMoreDiscount', function(discount, amount, block) {

		var discountAmount = (parseInt(amount)*parseInt(discount))/100;

		discount = parseInt(amount) - parseInt(discountAmount)

		return parseInt((parseInt(discount)*20)/100);
  	});

	return Handlebars;
});
