define(['handlebars'],function(Handlebars){
	Handlebars = Handlebars['default']  ;	
	Handlebars.registerHelper('for', function(from, to, block) {
		var accum = '';
		for(var i = from; i < to; i++ )
			accum += block.fn(i);
		return accum;

  	});

	return Handlebars ;	
});
