define(['handlebars'],function(Handlebars){
		
	Handlebars = Handlebars['default']  ;
	
	Handlebars.registerHelper('ifQuotes', function(categories, block) {
		
		var flag = 0;
		$.each(categories, function(index){

			if(categories[index].title == "Quotes" || categories[index].title == "Premium"){
				flag = 1;
				return false;
			}else{
				flag = 0;
			}
		})

		if(flag == 1){
			return;
		}else{
			return block.inverse(this);
		}
  	});

	return Handlebars ;	
});
