define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;
	Handlebars.registerHelper('formatDateString', function(dateToFormat, dateType, block) {
		var formatedDate = Utils.getDateString( dateToFormat, dateType ) ;
		return formatedDate ;
  	});

	return Handlebars;	
});
