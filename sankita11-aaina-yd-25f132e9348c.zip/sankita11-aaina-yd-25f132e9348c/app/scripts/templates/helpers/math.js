define(['handlebars'],function(Handlebars){
		
	Handlebars = Handlebars['default']  ;
	
	Handlebars.registerHelper('math', function(lvalue, operator, rvalue, options) {
		
		lvalue = parseFloat(lvalue);
    	rvalue = parseFloat(rvalue);

	    return {
	        "+": lvalue + rvalue
	    }[operator];
  	});

	return Handlebars ;	
});
