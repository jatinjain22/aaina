define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;
	Handlebars.registerHelper('getDiscountAmount', function(discount, amount, block) {

		var discountAmount = (parseInt(amount)*parseInt(discount))/100;

		return discountAmount ;
  	});

	return Handlebars;	
});
