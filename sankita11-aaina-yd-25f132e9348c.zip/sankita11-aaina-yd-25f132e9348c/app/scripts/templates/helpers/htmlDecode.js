define(['handlebars', 'utils'],function(Handlebars, Utils){

	Handlebars = Handlebars['default']  ;

	Handlebars.registerHelper('htmlDecode', function(html, block) {
		//var htmlDecode = html.replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&amp;/g,'&');
		var htmlDecode = $('<textarea />').html(html).text()
		htmlDecode = Utils.replaceUrls(htmlDecode);
		htmlDecode = htmlDecode.replace(/\n/g, "<br/>");

		return htmlDecode;
  	});

	return Handlebars;
});
