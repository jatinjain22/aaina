define(['handlebars', 'utils'],function(Handlebars, Utils){
	Handlebars = Handlebars['default']  ;
	Handlebars.registerHelper('formatDate', function(dateToFormat, showRelativeDate, block) {
		if (typeof showRelativeDate == 'undefined') {
			showRelativeDate = true;
		}
		var formatedDate = Utils.getDateDiff( dateToFormat, 1, showRelativeDate ) ;
		return formatedDate ;
  	});

	return Handlebars;	
});
