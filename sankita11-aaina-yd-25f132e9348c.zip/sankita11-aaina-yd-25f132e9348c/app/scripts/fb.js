define(['utils', 'facebook'], function(Utils){
	console.log("initializing FB");
  FB.init({
    appId      : Utils.getFBApiId(),
    version    : 'v2.4'
  });
  FB.getLoginStatus(function(response) {
    console.log(response);
  });
});