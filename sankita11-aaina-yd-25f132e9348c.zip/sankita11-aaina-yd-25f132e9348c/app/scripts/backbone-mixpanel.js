define([
  'jquery',
  'backbone',
  'console',
], function($,backbone, console){

  Backbone.View.originalDelegateEvents = Backbone.View.prototype.delegateEvents;
  Backbone.Mixpanel = new function() {

    var self = this,
        defaultOptions = {
          token: null,
          enabled: false,
          eventDataAttr: 'event',
          customData: [],
          userInfo: {},
          nameTag: ''
        },
        options = {};

    // setup the Mixpanel environment
    self.init = function(opts) {
      _.extend(options, defaultOptions, opts || {});

      return self;
    };

    // Returns a function that tracks to mixpanel and calls the original method
    //   method - (required) The method to handle an DOM event after tracking
    self.wrapEvent = function(method, defaultDescription) {
      if(!_.isFunction(method)) throw new Error("Wrapping requires a function to wrap");
      if(!defaultDescription) throw new Error("Wrapping requires a default description");

      return function(event) {
        var data = {},
            $target = $(event.currentTarget),
            description = $target.data(options.eventDataAttr) || defaultDescription;

        var eventJSON = {
          "click" : {
            "name" : "Button Click",
            "propertyName" : "itemName"
          },
          "change" : {
            "name" : "State Change",
            "propertyName" : "itemName"
          },
          "filter" : {
            "name" : "Counselor Filter",
            "propertyType" : "FilterType",
            "propertyName" : "FilterApplied"
          },
          "focusout" : {
            "name" : "Focus out",
            "propertyName" : "FieldDesc"
          },
          "keyup" : {
            "name" : "Keyup",
            "propertyName" : "itemName"
          },
          "keydown" : {
            "name" : "KeyDown",
            "propertyName" : "itemName"
          },
          "submit" : {
            "name" : "Submit",
            "propertyName" : "itemName"
          },
        }    

        dataArr = description.split(/ /);    
        var itemEvent = dataArr.shift() ;

        if( itemEvent == 'keyup' || itemEvent == 'keydown' || itemEvent == 'focusout' || itemEvent == "mouseover" || itemEvent == "mouseout" ){
          method.apply(this, arguments);
          return
        }
        
        var prop = dataArr.join(" ");
        if( itemEvent == 'click' && 
          ( prop == '#compose-send-btn' || prop == '#post-reply' ) ){

          self.trackEvent("MESSAGE", {'status':'sent-clicked'});
        }

        if(eventJSON[itemEvent] != undefined){

          if( itemEvent == 'filter' ){

            var type = dataArr.shift();

            description = eventJSON[itemEvent]["name"];
            data[eventJSON[itemEvent]["propertyType"]] = type;
            data[eventJSON[itemEvent]["propertyName"]] = dataArr.join(" ");
          }else{

            description = eventJSON[itemEvent]["name"];
            data[eventJSON[itemEvent]["propertyName"]] = dataArr.join(" ");
            
          }
        }
        data["mediumSource"] = "website" ;
        _(options.customData).each(function(key) {
          var item = $target.data(key);

          if(item) data[key] = item;
        });

        self.trackEvent(description, data);

        method.apply(this, arguments);
      }
    };
    
    // Track events to mixpanel when enabled and mixpanel is available
    //   desc - (required) The description of the event
    //   data - (optional) Any additional data included in the event
    
    self.trackEvent = function(desc, data) {

      if( !Array.isArray( window.closureDescription ) ){
        window.closureDescription = [];
      }

      data || ( data = {} );
      var key = desc;      
      if( window.closureDescription[key] === true ){
        return;
      }            
      
      window.closureDescription[key] = true;
      setTimeout(function(){
        delete window.closureDescription[key];
      }, 500)

      // where the magic happens.
      if( typeof mixpanel === 'undefined' ) return ;

      if (typeof mixpanel.track === "function") {
        
        data.mediumSource = 'website';
        mixpanel.track(desc, data);  
      }
    };

    self.delegateEvents = function(events) {
      if (!(events || (events = _.result(this, 'events')))) return;

      for(var key in events) {
        var method = events[key];
        if(!_.isFunction(method)) method = this[method];
        if(!method) throw new Error('Method "' + events[key] + '" does not exist');

        var wr = self.wrapEvent(method, key);
        events[key] = wr;

        Backbone.View.originalDelegateEvents.call(this, events);
      }
    };

    // Replace the delegateEvents function so that we can wrap each of the event
    //  handlers given via the events hash/function
    Backbone.View.prototype.delegateEvents = self.delegateEvents;

    }

    return Backbone.Mixpanel;
});
