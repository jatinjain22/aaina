define([ 'underscore',
  'backbone',
  'utils',
  '../precompiled-templates',
  'model/users'
 ], function( _, Backbone, Utils, JST, UserModel) {

  var ClientUsersModel = Backbone.Model.extend({

		  template: JST['app/templates/loader.hbs'],
    	idAttribute : 'clientUserId',
    	url : "" ,

		  initialize: function (options) {
        this.userModel = new UserModel() ;
			  var userID =  this.userModel.getUserID() ;
        this.set('userID', userID) ;
        this.url =  Utils.contextPath() + '/v1/counselor/' + this.get('userID') + '/user/list' ;
	    },
    	addWait: function(){
            $("#client-user-outter").append( this.template() );
            $(".main-loader").addClass("mmain-loader");
      },
      removeWait: function(){
        $(".main-loader").remove();
      },

      getSuperviseeUrl: function( userID ){

        return Utils.contextPath()+ '/v1/counselor/' + this.userModel.getUserID() + '/supervisee';
      
      },
      getUserID: function(){
        return this.get('userID')
      },
      setUserID: function (userID) {
        this.set('userID', userID);

      },
      setUrl: function() {
        this.url =  Utils.contextPath() + '/v1/counselor/' + this.get('userID') + '/user/list' ;
      },
      setSuperviseeSelected: function(val) {
        this.set( "superviseeSelected", val);
      },
      getSuperviseeSelected: function() {
        return this.get( "superviseeSelected" );
      }

   });
  return ClientUsersModel;
});
