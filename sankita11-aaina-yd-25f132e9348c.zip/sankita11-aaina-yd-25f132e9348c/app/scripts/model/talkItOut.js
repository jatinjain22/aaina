define([ 'underscore',
  'backbone',
  'utils'
 ], function( _, Backbone, Utils) {

  var TalkItOutModel = Backbone.Model.extend({	 
    	
    	idAttribute : 'filtersID',
    	url :  Utils.contextPath() + '/v1/counselor/' ,
    	
		  initialize: function (options) {
			
	    }
    	
   });

  return TalkItOutModel;
});