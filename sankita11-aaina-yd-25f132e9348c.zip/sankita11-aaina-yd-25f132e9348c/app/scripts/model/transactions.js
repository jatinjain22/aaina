define([
         'jquery',
	     'underscore',
	     'backbone',
	     'jCookie',
	     'utils',
	     '../precompiled-templates',
         'model/users'
], function($, _, Backbone, jCookie, Utils, JST, UserModel) {

	var UserTransactionModel = Backbone.Model.extend({

  template: JST['app/templates/loader.hbs'],

  initialize: function () {

        this.userModel = new UserModel() ;

        if(Utils.isLoggedIn()){
            var userID =  this.userModel.getUserID() ;
            this.set('userID', userID) ;
            this.url = Utils.contextPath() + '/v1/users/'+userID+'/transactions';
        }
  },
  addWait: function(){
       $("#sessions-block").append( this.template() );
  },
  removeWait: function(){
  	$("#sessions-block").remove();
  }
  
});

	return UserTransactionModel;
});
