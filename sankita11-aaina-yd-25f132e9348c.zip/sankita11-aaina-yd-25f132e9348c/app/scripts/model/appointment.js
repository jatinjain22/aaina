define([
       'jquery',
	     'underscore',
	     'backbone',
	     'utils',
       'model/users'
], function($, _, Backbone, Utils,UserModel) {

	var AppointmentModel = Backbone.Model.extend({

	    idAttribute : 'id',

      defaults: {
      category : "",
      description : "",
      counselorid : 0,
      mode : "",
      slottime: "",
      slotdate:"",
      transactionid : ""
    },


      initialize: function () {

            this.userModel = new UserModel() ;

            if(Utils.isLoggedIn()){
                this.set("userID", this.userModel.getUserID());
            }

      },
      bookAppointment:function(){

      },

	});
	return AppointmentModel ;
});
