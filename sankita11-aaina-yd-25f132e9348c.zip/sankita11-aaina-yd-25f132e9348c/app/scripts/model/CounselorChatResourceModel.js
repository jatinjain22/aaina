define([
         'jquery',
	     'underscore',
	     'backbone',
	     'jCookie',
	     'utils',
	     '../precompiled-templates'
], function($, _, Backbone, jCookie, Utils, JST) {

	var ClientHistoryMsgModel = Backbone.Model.extend({

	    idAttribute : 'chid',
		template: JST['app/templates/loader.hbs'],
    	initialize: function () {

            //set user id here from the cookie
            if(localStorage.getItem("user")){
                var userObject = JSON.parse(localStorage.getItem("user"));
                this.set("userID", userObject.id);
            }
    	},
        getBlogUrl: function() {
            var url = 'https://yourdost.com/blog/api/get_recent_posts';
            return url
        },
        getResourceUrl: function() {
            var url = 'https://specialfriendszone.yourdost.com/api/get_recent_posts';
            return url;
        },
        getDiscussionUrl: function() {
            var url = 'https://forum.yourdost.com/posts.json';
            return url;
        },
        getDiscussionSearchUrl: function() {
            var url = 'https://forum.yourdost.com/search.json'
            return url;
        },
    	parse: function(data){
    		return data;
    	},
    	setUserThreadUrl: function( threadId , type ){
    		this.url = Utils.contextPath() + '/v1/counselors/'+this.get("userID")+'/users/'+this.get("clientID")+'/messages/'+threadId+'?type='+type;
    	},
    	addWait: function(){
            $("#msg-list-block").append( this.template() );
            //$(".main-loader").addClass("mmain-loader");
    	},
    	removeWait: function(){
    		$(".main-loader").remove();
    	},
        setUserUrl: function( pno , params ){

            var queryParams = this.getQueryParamsByType( pno , params );

            this.url = Utils.contextPath() + '/v1/counselors/'+this.get("userID")+'/users/'+this.get("clientID")+'/messages?'+queryParams;
        },
        getQueryParamsByType: function( pno , params ){

            if( pno )
                pno = "&page_number="+pno;
            else
                pno = "";

            var query = pno;
            if( params ){
                query = "&"+params["search"]+pno;
            }

            return query;
        }
	});

	return ClientHistoryMsgModel;
});
