define([ 
         'jquery', 
	     'underscore', 
	     'backbone',
	     'utils'
], function($, _, Backbone, Utils) {

	var BloggerModel = Backbone.Model.extend({
		
	    idAttribute : 'bid',
    	initialize: function () {},
    	parse: function(data){
    		return data;
    	},
	    getDestressingUrl : function( limit ){

	    	if( !limit )
	    		limit = 3;

	    	var url = "https://www.googleapis.com/blogger/v3/blogs/"+
	    				Utils.getQuotesBlogId()+
	    			 "/posts?labels=de-stressing%20technique&fields=items(url,title,published,updated)&maxResults="+limit+"&key="+Utils.getBlogAPIKey();

	    	return url;
	    },
	    getQuotesUrl : function( limit ){

	    	if( !limit )
	    		limit = 3;

	    	var url = "https://www.googleapis.com/blogger/v3/blogs/"+
	    				Utils.getQuotesBlogId()+
	    			 "/posts?labels=de-stressing%20technique&fields=items(url,title,published,updated,content)&maxResults="+limit+"&key="+Utils.getBlogAPIKey();

	    	return url;
	    },
	    getArticlesUrl : function( limit ){

	    	if( !limit )
	    		limit = 3;

	    	
	    	var url = Utils.blogJson();		 

	    	return url;
	    }
	});

	return BloggerModel;
});