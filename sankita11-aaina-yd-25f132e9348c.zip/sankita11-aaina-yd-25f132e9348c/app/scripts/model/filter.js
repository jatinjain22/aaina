define([ 'underscore',
  'backbone',
  'utils'
 ], function( _, Backbone, Utils) {

  var FiltersModel = Backbone.Model.extend({	 
    	
    	idAttribute : 'filtersID',
    	url :  Utils.contextPath() + '/v1/counselor/filters' ,
    	
		  initialize: function (options) {
			
	    }
    	
   });

  return FiltersModel;
});