define([ 
         'jquery', 
	     'underscore', 
	     'backbone',
	     'jCookie',
	     'utils'
], function($, _, Backbone, jCookie, Utils) {

	var AjaxModel = Backbone.Model.extend({
		
		initialize: function () {
			this.urlRoot = Utils.contextPath();
		},
		showError:function(msg){
			
		},
		showMessage:function(msg){
			
		},
		addWait:function(){
			
		},
		removeWait:function(){
			
		}
	});
	
	return AjaxModel;
});