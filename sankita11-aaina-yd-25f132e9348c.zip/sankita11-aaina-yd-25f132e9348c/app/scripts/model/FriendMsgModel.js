define([
       'jquery',
	     'underscore',
	     'backbone',
	     'jCookie',
	     'utils',
	     '../precompiled-templates'
], function($, _, Backbone, jCookie, Utils, JST) {

	var FriendMsgModel = Backbone.Model.extend({

	    idAttribute : 'fmid',
	    defaults: {
           type: "MAIL",
           userID: "-1",
           threadId: "-1"
      },
			template: JST['app/templates/loader.hbs'],
			initialize: function () {

        //set user id here from the cookie
        if(localStorage.getItem("user")){
            var userObject = JSON.parse(localStorage.getItem("user"));
            this.set("userID", userObject.id);

            if(userObject.loggableUser.userType === "OPERATOR"){
              this.set("type", "NOT_REPLIED");
            }
        }
      },
    	parse: function(data){
    		return data;
    	},
    	setUrl: function(){
    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages?type='+this.get("type");
    	},
    	setMsgUrl: function(){
    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages/'+this.get("threadId")+'?type='+this.get("type");
    	},
    	setMsgTypeUrl: function( type , pno , params ){

    		var queryParams = this.getQueryParamsByType( type , pno , params );

    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages?'+queryParams;
    	},
    	setAddNotesUrl: function(){
    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages/'+this.get("threadId")+'/notes';
    	},
    	setAddTagUrl: function(){
    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages/'+this.get("threadId")+'/categories';
    	},
    	addWait: function(){
    		$(".msg-details-right").append( this.template() );
    	},
    	removeWait: function(){
    		$(".main-loader").remove();
    	},
      setUnreadCount: function(){

          $.ajax({
              method: "GET",
              url: Utils.contextPath()+'/v1/users/'+this.get("userID")+'/messages/count?type=unread'
          }).done(function(response){
            var count = response.count;
            $("#msg-block").find("#inbox").find(".unread").text( "("+count+")" );
            $("#msg-list-mobile").find("#minbox").find(".unread").text( "("+count+")" );
            sessionStorage.setItem("unread",response.count);
          }).fail(function(error){});


          $.ajax({
              method: "GET",
              url: Utils.contextPath()+'/v1/users/'+this.get("userID")+'/messages/count?type=exclusive_unread'
          }).done(function(response){
            var count = response.count;
            $("#msg-block").find("#exclusive").find(".unread").text( "("+count+")" );
          }).fail(function(error){});
      },
      setType: function( type ){
          localStorage.setItem("type",type);
          this.set("type",type);
      },
      getType: function(){
          return localStorage.getItem("type");
      },
      getQueryParamsByType: function( type , pno , params ){

          if( !type )
            type = "MAIL";

          if( pno )
            pno = "&page_number="+pno;
          else
            pno = "";

           var query = "";
           switch( type ){
              case 'MAIL':
                  query = "type=MAIL"+pno;
                  break;
              case 'DRAFT':
                  query = "type=DRAFT"+pno;
                  break;    
              case 'SENT_MAIL':
                  query = "type=SENT_MAIL"+pno;
                  break;
              case 'CHAT':
                  query = "type=CHAT"+pno;
                  break;
              case 'IMPORTANT':
                  query = "type=MAIL&starred=true"+pno;
                  break;
              case 'NOT_REPLIED':
                  query = "type=MAIL&not_replied=true"+pno;
                  break;
              case 'SEARCH':
                  query = "type=MAIL&"+params["search"]+pno;
                  break;
              case 'TAGS':
                  query = "type=MAIL&category="+params["cid"]+pno;
                  break;
              case 'FOLLOWED':
                  query = "type=MAIL&followed=true"+pno;
                  break;
              case 'EXCLUSIVE_MAIL':
                  query = "type=EXCLUSIVE_MAIL"+pno;
                  break;
           }
           return query;
      }
	});

	return FriendMsgModel;
});