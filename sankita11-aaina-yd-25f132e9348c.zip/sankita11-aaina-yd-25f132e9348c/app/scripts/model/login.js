define([ 
         'jquery', 
	     'underscore', 
	     'backbone',
	     'jCookie',
	     'utils'
], function($, _, Backbone, jCookie, Utils) {

	var LoginStatus = Backbone.Model.extend({
		
	    idAttribute : 'id',
    	
		initialize: function () {
			var loggedInUserString = $.cookie("loggedInUser");
			if( loggedInUserString != undefined){
				this.set(JSON.parse(loggedInUserString));
			}			
	    },
	    validation: {
    		username: {
      			required: true,
      			msg: 'Please enter a valid username'
    		}
  		},
  		getAndSaveUser : function(){

  			if(localStorage.getItem("user")){
  				return 1 ;
  			}
  			var self = this ;
  			$.ajax({
  				url : Utils.contextPath() + "/v2/users/get",
          async : false ,
  				dataType : "json" ,
  			}).done(function(response){
  				self.save(response) ;
  			}).error(function(error){
  				console.log("Error") ;
  				console.log(error) ;
  			});
  		},
  		save : function(userObject){
  			localStorage.setItem("user", JSON.stringify(userObject)) ;
        localStorage.setItem("isLoggedIn" , 1)                   ;
        $.cookie("DCU", JSON.stringify(userObject), {domain: ".yourdost.com"}) ;
  		}

	});
	return LoginStatus;
});
