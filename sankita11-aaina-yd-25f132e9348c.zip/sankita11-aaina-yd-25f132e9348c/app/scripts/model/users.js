define([ 
       'jquery', 
	     'underscore', 
	     'backbone',
	     'utils'
], function($, _, Backbone, Utils) {

	var UsersModel = Backbone.Model.extend({
		
	    idAttribute : 'id',
    	
		  initialize: function () {},

  		getAndSaveUser : function(){

        if( typeof localStorage === "null" || typeof localStorage === "undefined" ){
          return 0 ;
        }

  			if(localStorage.getItem("user")){
  				return 1 ;
  			}

  			var self = this ;
  			$.ajax({
  				url : Utils.contextPath() + "/v2/users/get",
          async : true ,
  				dataType : "json" ,
  			}).done(function(response){
  				self.save(response) ;
  			}).error(function(error){
  				console.log("Error") ;
  				console.log(error) ;
  			});

  		},

      getUserID : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        if(typeof userObject != 'undefined' && userObject != null){

          return userObject.id ;
        }else{

          return null;
        }
      },
      getUserAvatar : function(){

        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        if(userObject.avatar == null ){
          return "avatar7" ;
        }else{
          return userObject.avatar ;  
        }

      },

      getPicUrl : function(){

        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.picUrl ;  

      },
      getUserName : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.username ;
      },
  		
      getFirstName : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.firstName ;
      },

      getUserType : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.loggableUser.userType;
      },

      getUserEmail : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.email;
      },
      getUserConsent : function() {

        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }
        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.chatHistoryConsent;

      },      
      getPhoneNo : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.phone;
      },
      getSkypeID : function(){
        if(!localStorage.getItem("user")){
          this.getAndSaveUser();
        }else if($.cookie("DCU") == "null" || $.cookie("DCU") == null || $.cookie("DCU") == undefined ){
          $.cookie("DCU", localStorage.getItem("user") , {domain: ".yourdost.com"}) ;
        }

        var userObject = JSON.parse(localStorage.getItem("user")) ;

        return userObject.skypeID;
      },
      save : function(userObject){

        if ( userObject.email!= null ) {
          if(userObject.email.match(/dummy-email/)){
            userObject.email = null;
          }
        }

        localStorage.setItem("user", JSON.stringify(userObject)) ;
        localStorage.setItem("isLoggedIn" , 1)                   ;
        $.cookie("DCU", JSON.stringify(userObject), {domain: ".yourdost.com"}) ;

        Raygun.setUser( userObject.username, false, userObject.email, userObject.firstName, userObject.firstName, userObject.id ) ;
        
     },
     setUnreadCount: function(){
        if(Utils.isLoggedIn()){
            $.ajax({
                method: "GET",
                url: Utils.contextPath()+'/v1/users/'+this.get("userID")+'/messages/count?type=unread'
            }).done(function(response){
              var count = response.count;
              sessionStorage.setItem("unread",response.count);
              $(".iheader-msg-badge").text( sessionStorage.getItem("unread") );
              if( sessionStorage.getItem("unread") > 0 )
                  $(".iheader-msg-badge").removeClass("hide");
              else
                  $(".iheader-msg-badge").addClass("hide");
            }).fail(function(error){});
         }
        }

	});
	return UsersModel ;
});
