define([ 'underscore',
  'backbone',
  'model/users',
  'utils'
 ], function( _, Backbone,UserModel, Utils) {

  var CounselorListModel = Backbone.Model.extend({	 
    	
    	idAttribute : 'filtersID',
    	url :  function(){

        if(Utils.isLoggedIn()){

          var uId = this.userModel.getUserID();
          if(uId && uId != "" && uId != null){

            return Utils.contextPath() + '/v1/counselor?user='+uId;
          }else{

            return Utils.contextPath() + '/v1/counselor';
          }
        }else{

          return Utils.contextPath() + '/v1/counselor';
        }
         
      },
    	
      save : function(attributes){
        
        localStorage.setItem("counselorList", JSON.stringify(this.toJSON()));
      },

      
      filterCounselors : function( filterSelected ){

      },

		  initialize: function (options) {
			 
       this.userModel = new UserModel() ;
	    }
    	
   });

  return CounselorListModel;
});