define([
  'jquery',
  'underscore',
  'backbone'
], function($, _, Backbone){
  var BlogContent = Backbone.Collection.extend({
    url: function () {
      return 'https://yourdost.com/blog/api/get_recent_posts/?page=' + this.page + '&callback=?';
    },
    // Because twitter doesn't return an array of models by default we need
    // to point Backbone.js at the correct property
    parse: function(resp, xhr) {
      return resp.posts;
    },
    page: 1
  });

  return BlogContent;
});