define([
         'jquery',
	     'underscore',
	     'backbone',
	     'jCookie',
	     'utils',
	     '../precompiled-templates',
         'model/users'
], function($, _, Backbone, jCookie, Utils, JST, UserModel) {

	var UserMsgModel = Backbone.Model.extend({

	    idAttribute : 'mid',
	    defaults: {
		   type: "MAIL",
		   userID: "-1",
		   threadId: "-1"
		},
		template: JST['app/templates/loader.hbs'],
    	initialize: function () {

            userModel = new UserModel() ;

            if(Utils.isLoggedIn()){
                this.set("userID", userModel.getUserID());    
            }

            //set user id here from the cookie
            /*if(localStorage.getItem("user")){
                var userObject = JSON.parse(localStorage.getItem("user"));
                this.set("userID", userObject.id);
            }*/
    	},
    	parse: function(data){
    		return data;
    	},
    	setUrl: function(options){
            if (options && options.type) this.set('type', options.type);

            var userID = this.get("userID") ;

    		this.url = Utils.contextPath() + '/v1/users/'+userID+'/messages?type='+this.get("type");
    	},
    	setMsgUrl: function(options){
            if (options && options.threadId) this.set('threadId', options.threadId);
            if (options && options.type) this.set('type', options.type);
    		this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages/'+this.get("threadId")+'?type='+this.get("type");
    	},
    	addWait: function(){
            $("#msg-list-block").append( this.template() );
            //$(".main-loader").addClass("mmain-loader");
    	},
    	removeWait: function(){
    		$(".main-loader").remove();
    	},
        setUnreadCount: function(){

          $.ajax({
              method: "GET",
              url: Utils.contextPath()+'/v1/users/'+this.get("userID")+'/messages/count?type=unread'
          }).done(function(response){
            var count = response.count;
            sessionStorage.setItem("unread",response.count);
            $(".iheader-msg-badge").text( sessionStorage.getItem("unread") );
            if( sessionStorage.getItem("unread") > 0 )
                $(".iheader-msg-badge").removeClass("hide");
            else
                $(".iheader-msg-badge").addClass("hide");
          }).fail(function(error){});
        },
        setMsgTypeUrl: function( pno , params ){

            var queryParams = this.getQueryParamsByType( pno , params );

            this.url = Utils.contextPath() + '/v1/users/'+this.get("userID")+'/messages?'+queryParams;
        },
        getQueryParamsByType: function( pno , params ){

            //console.log(pno, params)
            if( pno )
                pno = "&page_number="+pno;
            else
                pno = "";

            var query = pno;
            if( params ){
                query = "&"+params["search"]+pno;
            }

            return query;
        }
	});

	return UserMsgModel;
});
