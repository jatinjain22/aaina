define([ 'underscore',
  'backbone',
  'utils'
 ], function( _, Backbone, Utils) {

  var TestimonialModel = Backbone.Model.extend({	 
    	
    	idAttribute : 'testimonialId',
    	url : Utils.contextPath() + '/testimonial' ,
    	
		  initialize: function (options) {
			
	    }
    	
   });
  return TestimonialModel;
});