define([
  'jquery',
  'moment-timezone-data',
  'autolink',
  'jstz',
  'console',
  'config',
  'raygun'
], function($,moment, AutoLinker){

	var utils  = new function () {

		//moment.tz.add('Asia/Kolkata|HMT BURT IST IST|-5R.k -6u -5u -6u|01232|-18LFR.k 1unn.k HB0 7zX0');

	    this.getDateDiff = function(dateString, showTime, showRelativeDate){

	    	if (typeof showRelativeDate == 'undefined') {
                showRelativeDate = true;
            }

	    	if(!dateString){
	    		return "";
	    	}

	    	var datePassed = dateString ;

	    	var localtz            = jstz() ;
	    	var localTimezone = localtz.timezone_name ;

	    	dateString = new Date( dateString ).toISOString();

	    	var ds = moment(dateString);
			dateString = ds.tz(localTimezone).format() ;

	    	var date = "" ;

			try {
		    	date = moment(dateString, "YYYY-MM-DD h:mm:ss");
				//throw new Error('Oops invalid date' + dateString);
			}
			catch(e) {
				console.log(e);
				Raygun.send("Date Passed = " + datePassed + "Date After Parse = " + dateString + " Local timezone = " + localTimezone ) ;
				Raygun.send(e)          ;
		    	dateString = new Date().toISOString();
		    	date = moment(dateString, "YYYY-MM-DD h:mm:ss");
			}


			var d = moment.duration(moment().diff(date));

			if (d.asDays() > 6 || !showRelativeDate){
				if(showTime != undefined && showTime == 0){
					return date.format(" Do MMM'YY");
				}else{
					return date.format(" Do MMM'YY h:mm a");
				}
			} else if ( d.asDays() < 6 && d.asDays() >= 1){

				if (d.asDays() == 1) {
					return Math.floor(d.asDays()) + " day ago";
				} else {
					return Math.floor(d.asDays()) + " days ago";
				}

			}
			if(d.asHours() < 24 && d.asHours() > 1){
				return Math.floor(d.asHours()) + " hours ago";
			} else if (d.asHours() < 1){
				if(d.asHours() < 0){
					return "0 minutes ago" ;
				}
				return Math.floor(d.asMinutes()) + " minutes ago";
			} else if (d.asMinutes() < 1){
				return Math.floor(d.asSeconds()) + " seconds ago";
			}
	    };
	    this.generateUUID = function () {
	    	var id = sixpack.generate_client_id();
	        localStorage.setItem('clientID', id);
	        return id;
	    };
	    this.getFirebaseConfig = function () {
	    	var config = firebaseConfig;
	    	return config;
	    };
	    this.setCarePlanStats = function (stats) {
	    	this.carePlanStats = stats;
	    };
	    this.fetchCarePlanStats = function () {
	    	var self = this;
	    	if (self.carePlanStats) return;
	    	self.carePlanStats = {};
	    	var firebaseConfig = self.getFirebaseConfig();
	    	firebase.initializeApp({
	    	    apiKey: firebaseConfig.apiKey,
	    	    authDomain: firebaseConfig.authDomain,
	    	    databaseURL: firebaseConfig.databaseURL,
	    	    storageBucket: firebaseConfig.storageBucket
	    	});
			var counterRef = firebase.database().ref('count');
			
	    	self.carePlanStats['counterRef'] = counterRef;
	    	counterRef.once('value', function (data) {
	    	    var list = data.val();
	    	    self.carePlanStats['planCount'] = 935 + Object.keys(list).length - 1;
	    	});
	    	counterRef.orderByChild('purchasedOn').startAt(Date.now() - 3600000).on('value', function (data) {
	    	    self.carePlanStats['lastHourCount'] = data.val() && Object.keys(data.val()).length;
	    	});
	    },
      this.updateEmotionalWellness = function(db){
        var firebaseConfig = this.getFirebaseConfig();
        if (!firebase.apps.length){
          firebase.initializeApp({
              apiKey: firebaseConfig.apiKey,
              authDomain: firebaseConfig.authDomain,
              databaseURL: firebaseConfig.databaseURL,
              storageBucket: firebaseConfig.storageBucket
          });
        }
        var clientID = this.getClientId()
        var firebaseDB = firebase.database().ref(db+'/' + clientID)
        return firebaseDB;
	  },
	  this.updateKickTheButt = function(db,userId){
        var firebaseConfig = this.getFirebaseConfig();
        if (!firebase.apps.length){
          firebase.initializeApp({
              apiKey: firebaseConfig.apiKey,
              authDomain: firebaseConfig.authDomain,
              databaseURL: firebaseConfig.databaseURL,
              storageBucket: firebaseConfig.storageBucket
          });
        }
        var userId = userId;
        var firebaseDB = firebase.database().ref(db+'/' + userId)
        return firebaseDB;
      },
      this.getClientId = function(){
        return localStorage.getItem('testID') || this.testID();
      },
      this.testID = function(){
        var id = Math.random().toString(36).substring(4);
        localStorage.setItem("testID", id)
        return id;
      },
	    this.getVariantType = function (options) {
	    	var deferred = $.Deferred();
	    	var self = this;
	    	var options = options || {};
	    	if (self[options.name]) {
	    		deferred.resolve(self[options.name]);
	    	}
	    	var clientID = localStorage.getItem('clientID') || this.generateUUID();
	    	this.session = new sixpack.Session({
	    	    client_id: clientID,
	    	    base_url: ABTestingUrl
	    	});
	    	this.session.participate(options.name, options.alternatives, function (err, res) {
	    	  if (err) deferred.reject(err);
	    	  if (res.status == 'ok') {
	    	  	self[options.name] = res.alternative.name;
	    	  	deferred.resolve(res.alternative.name);
	    	  } else {
	    	  	deferred.reject(res.status);
	    	  }
	    	});
	    	return deferred.promise();
	    };
	    this.convert = function (options) {
	    	var options = options || {};
	    	this.session.convert(options.name, options.kpi);
	    };
	    this.newYearPackagesMap = {
	    	"quit-smoking" : 8,
	    	"build-marriage-relationships" : 12,
	    	"become-stress-free" : 9,
	    	"get-organised" : 10,
	    	"build-family-relationships" : 11,
	    };
	    this.packagesMap = {
	    	"1": "post-marriage-counseling",
	    	"2": "building-self-confidence",
	    	"3": "cope-with-lose-of-someone",
	    	"4": "advice-on-exam-preparation",
	    	"5": "overcoming-loneliness",
	    	"6": "career-advice",
	    	"7": "pre-marital-counseling",
	    	"8": "quit-smoking",
	    	"9": "become-stress-free",
	    	"10": "get-organised",
	    	"11": "build-family-relationships",
	    	"12": "build-marriage-relationships",
	    	"13": "laid-off-fired-up",
	    	"14": "confident-career",
	    	"15": "develop-discipline"
	    };
	    this.getNewYearPackageId = function (identifier) {
	    	return this.newYearPackagesMap[identifier];
	    };
	    this.getSecureUrl = function (url) {
	    	var secureUrl = url;
	    	if (url && url.indexOf("https") == -1) {
	    		var path = url.split("http://")[1];
	    		secureUrl = "https://" + path;
	    	}
	    	return secureUrl;
	    };
	    this.fetchCounselorList = function (id) {
	    	var self = this;

	    	var queryParam = "" ;
	    	if(id != null && id != "" && id != undefined){
	    		queryParam = "?user=" + id ;
	    	}

	    	var deferred = $.Deferred();
	    	if (self.counselorList) {
	    		deferred.resolve(self.counselorList);
	    	} else {
	    		$.ajax({
	    			method : "GET",
	    			url : self.contextPath() + "/v1/counselor" + queryParam
	    		})
	    		.done(function (response) {
	    			self.counselorList = response;
	    			self.counselorList.map(function (counselor) {
	    				counselor.picUrl = self.getSecureUrl(counselor.picUrl);
	    				return counselor;

	    			});
	    			self.counselorList.splice(0,0,{
	    				id: 101,
	    				name: "Send it to best suitable expert",
	    				picUrl: "https://d1hny4jmju3rds.cloudfront.net/cloudinary/yourdost-mascot.jpg"
	    			})
	    			deferred.resolve(self.counselorList);
	    		})
	    		.fail(function (error) {
	    			deferred.reject(error);
	    		});
	    	}
	    	return deferred.promise();
		};
		this.fetchForumCategories = function () {
	    	var self = this;

	    	var deferred = $.Deferred();
	    	if (self.forumCategories) {
	    		deferred.resolve(self.forumCategories);
	    	} else {
	    		$.ajax({
	    			method : "GET",
	    			url : blogOrigin + "/forum/categories.json"
	    		})
	    		.done(function (response) {
	    			self.forumCategories = response.category_list.categories;
	    			deferred.resolve(self.forumCategories);
	    		})
	    		.fail(function (error) {
	    			deferred.reject(error);
	    		});
	    	}
	    	return deferred.promise();
		};
		this.fetchNewYearPackages = function () {
	    	var self = this;

	    	var deferred = $.Deferred();
	    	if (self.newYearPackages) {
	    		deferred.resolve(self.newYearPackages);
	    	} else {
	    		$.ajax({
	    			method : "GET",
	    			url : self.contextPath()+'/packages?type=1',
	    			contentType: "application/json",
	    		})
	    		.done(function (response) {
	    			self.newYearPackages = response;
	    			deferred.resolve(self.newYearPackages);
	    		})
	    		.fail(function (error) {
	    			deferred.reject(error);
	    		});
	    	}
	    	return deferred.promise();
		};
        this.appendGoogleConversion = function(amount){
            var conv_handler = window['google_trackConversion']({
                google_conversion_id: 952744213,
                google_conversion_label: 'DuNzCKHMqXMQlfKmxgM',
                google_conversion_language: "en",
                google_conversion_format: "2",
                google_conversion_color: "ffffff",
                google_remarketing_only: false,
                google_conversion_currency: "INR",
                google_conversion_value: amount,
                onload_callback : function(){
                    console.log("Hello: ",amount)
                }
            })
            if (typeof conv_handler == 'function') {
    	           conv_handler();
            }
        };
		this.getCities = function () {
	    	var self = this;

	    	var deferred = $.Deferred();
	    	if (self.cities) {
	    		deferred.resolve(self.cities);
	    	} else {
	    		$.ajax({
	    			method : "GET",
	    			url : blogOrigin + "/scripts/json/cities.json",
	    			contentType: "application/json",
	    		})
	    		.done(function (response) {
	    			self.cities = response.cities;
	    			deferred.resolve(self.cities);
	    		})
	    		.fail(function (error) {
	    			deferred.reject(error);
	    		});
	    	}
	    	return deferred.promise();
		};
	    this.getDateString = function(dateString, type){
	    	if(!dateString){
	    		return "";
	    	}

	    	var datePassed = dateString ;

	    	var localtz            = jstz() ;
	    	var localTimezone = localtz.timezone_name ;

	    	dateString = new Date( dateString ).toISOString();

	    	var ds = moment(dateString);
			dateString = ds.tz(localTimezone).format() ;

	    	var date = "" ;

			try {
		    	date = moment(dateString, "YYYY-MM-DD h:mm:ss");
				//throw new Error('Oops invalid date' + dateString);
			}
			catch(e) {
				console.log(e);
				Raygun.send("Date Passed = " + datePassed + "Date After Parse = " + dateString + " Local timezone = " + localTimezone ) ;
				Raygun.send(e)          ;
		    	dateString = new Date().toISOString();
		    	date = moment(dateString, "YYYY-MM-DD h:mm:ss");
			}

			var d = moment.duration(moment().diff(date));


			if(type == "date"){
				return date.format(" MMMM D, YYYY");
			}else if(type == "shortdate"){
				return date.format(" D MMM, YYYY");
			}else if(type == "time"){
				return date.format(" h:mm a");
			}else{
				return date.format(" Do MMM'YY h:mm a");
			}

	    };
	    this.contextPath = function(){
			var path = apiUrl;
	    	return path;
	    };
	    this.paymentGatewayKey = function () {
	    	var key = razorpayKey;
	    	return key;
	    };
	    this.paytmTransactionDetails = function () {
	    	var paytmDetails = {};
	    	paytmDetails["merchantId"] = paytmMerchantId;
	    	paytmDetails["website"] = paytmWebsite;
	    	paytmDetails["channelId"] = paytmChannelId;
	    	paytmDetails["industryTypeId"] = paytmIndustryTypeId;
	    	paytmDetails["transactionURL"] = paytmTransactionURL;

	    	return paytmDetails;
	    };
	    this.bloghomeJson = function(){

	    	var path = homeblogUrl;

	    	return path;
	    };
	    this.blogJson = function() {

	    	var path = blogUrl;

	    	return path;
	    };
        this.relatedArticlesBlogJson = function () {

            var path = relatedArticlesBlogUrl;

            return path;
        };
	    this.socialShareUrl = function() {
	    	var path = socialShareUrl;
	    	return path;
	    };
	    this.scriptPath = function() {
	    	var path = window.location.origin + "/scripts/json" ;
	    	return path ;
	    };

	    this.discussionUrl = function(){
	    	var path = discussionUrl ;
	    	return path ;
	    };

	    this.justChatUrl = function(){

	    	var path = chatUrl
	    	return path;
	    }

	    this.chatWorkgroup = function(){

	    	var path = chatWorkgroup
	    	return path;
	    }

	    this.chatUrl = function(){
	    	var path = chatUrl + "/?workgroup="+ chatDemoWorkgroup +"&noUI=true&username=";
	    	return path ;
	    };
	    this.chatDemoWorkgroup = function(){
	    	return chatDemoWorkgroup ;
	    };
	    this.scrollTo = function( element , topval ){

	    	if(!element)
	    		element = "body";

	    	if(!topval)
	    		topval = 0;

	    	$('html, body').stop().animate({
	      		scrollTop: $(element).offset().top+topval
	      	}, 1000,'easeInOutExpo');
	    };

	    this.getQuotesBlogId = function(){
	    	return "7912652585479646275";
	    };

	    this.getArticlesBlogId = function(){
	    	return "8890631677375305128";
	    };

	    this.getBlogAPIKey = function(){
	    	return "AIzaSyAZMaILc4ZnaQVnAoThxVDhqanKV0TcNeA";
	    };

	    this.isMobileDevice = function(){
	    	var isMobile = false;
	    	if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
    || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) isMobile = true;

			return isMobile ;
	    };

	    this.isIpadDevice = function(){
	    	var isIpad = false;
	    	if(/ipad/i.test(navigator.userAgent)) isIpad = true;

			return isIpad ;
	    };


	    this.openPopup = function( divID ){
	    	$("body").css("overflow", "hidden") ;
	    	if(this.isMobileDevice()){
		    	$( "#" + divID ).removeClass("modal");
		    	$( "#" + divID ).removeClass("modal-fixed-footer");
				$( "#" + divID ).addClass("fixed-position-container") ;
				$( "#" + divID ).addClass("popup-mobile") ;
				if(divID === "talkItOut-exit-popup") {
					$( "#" + divID ).animate({"top" : "20%"}, "slow") ;
				}
				else {
					$( "#" + divID ).animate({"top" : 0}, "slow") ;
					$( "#" + divID ).css("height", "100%") ;
				}
				$( "#" + divID ).css("max-height", "100%") ;

          		$(".download-app-banner").addClass("hide");
			}else{
				if ( $("#download-ebook-modal").length ) {
					$("div#lean-overlay:last").css({'display':'block', 'opacity':'0.5'});
				}
				$( '#' + divID ).openModal({dismissible: false, keyboard: true,

				complete: function() {

			    		$('body').css({'overflow-y' : 'auto'});
			    		$('.lean-overlay').remove();

			    	}
				});
			}

	    };

	    this.isLoggedInPage = function( urlHash ){

	    	var loggedInPageArr = ["message", "client", "changePassword", "profile", "cancelAppointment"] ;

	    	var loggedInPage = 0
	    	_.each(loggedInPageArr, function(page){
	    		if( urlHash.match( page ) ){
	    			loggedInPage = 1 ;
	    			return false ;
	    		}

	    	});

	    	return loggedInPage ;

	    },
	    this.closePopup = function( divID ){

	    	$('body').css({'overflow-y' : 'auto'});
	    	if(this.isMobileDevice() == true ){
	    		$( "#" + divID ).animate({"top":"105%"}, "slow") ;
	    		$(".download-app-banner").removeClass("hide");
	   		}else{
	   			console.log( $( '.modal-landing-Page2' ).length );

	   			if ( $( '.modal-landing-Page2' ).length ) {
	   				console.log( 'hello' );
	   				$("div#lean-overlay:last").css({'display':'block', 'opacity':'0.5'});
	   			}
	   			$( "#" + divID ).closeModal() ;
	   		}
	   		console.log("closed...");
	    };

	    this.backgroundColorArr = function(){
	    	var colorArr = ["red lighten-4", "cyan lighten-4", "amber lighten-4", "lime lighten-4", "light-green lighten-4", "indigo lighten-4", "blue lighten-4"];

	    	return colorArr ;
	    };

	    this.getMessageURL = function(userObject){

	    	if(!localStorage.getItem("user")){
	    		return "" ;
	    	}

	    	if( !userObject ){
	    		userObject = JSON.parse(localStorage.getItem("user")) ;
	    	}

		    if(userObject["loggableUser"]["userType"] == "OPERATOR"){
				return "/friend/messages" ;
			}else{
				return "/user/messages" ;
			}
	    };

	    this.isLoggedIn = function(){
	    	if(localStorage.getItem("isLoggedIn") == 1){
	    		return 1 ;
	    	}else{
	    		return 0 ;
	    	}
	    }

	    this.encodeString = function( str ){

	    	return btoa( str );
	    }

	    this.decodeString = function( str ){

	    	return atob( str );
	    }

	    this.displaySuccessMsg = function( str ){

	    	$(".flash_message").removeClass("hide red").addClass("slideInDown").text( str );
	    	setTimeout(function(){
	    		$(".flash_message").addClass("hide").removeClass("slideInDown").text("");
	    	},5000);
	    }

	    this.displaySuccessMsgWithDelay = function( str, delay ){

	    	console.log( 'display successMsg')
	    	$(".flash_message-1").removeClass("hide red").show().addClass("slideInDown").html( str );

	    	setTimeout(function(){
	    		$(".flash_message-1").slideUp( function(){

	    			$(".flash_message-1").addClass("hide").hide().removeClass("slideInDown").text("");
	    		})
	    	}, delay);

	    }

	    this.displayErrorMsg = function( str ){

	    	$(".flash_message").addClass("red slideInDown").removeClass("hide").text( str );
	    	setTimeout(function(){
	    		$(".flash_message").removeClass("red slideInDown").addClass("hide").text("");
	    	},5000);
	    }

	    this.encodeString = function( str ){

	    	return btoa( str );
	    }

	    this.decodeString = function( str ){

	    	return atob( str );
	    }

	    this.avatarToImage = function(avatar){
	    	var images = {
	    		"avatar1" : "/images/avatar/avatar1.png",
	    		"avatar2" : "/images/avatar/avatar2.png",
	    		"avatar3" : "/images/avatar/avatar3.png",
	    		"avatar4" : "/images/avatar/avatar4.png",
	    		"avatar5" : "/images/avatar/avatar5.png",
	    		"avatar6" : "/images/avatar/avatar6.png",
	    		"avatar7" : "/images/avatar/avatar7.png"
	    	}

	    	return images[avatar] ;
	    }

		this.getMixpanelToken = function(){
			var token = mixpanelKey ;
			return token ;
		};

	    this.addRTD = function( element ){

	    	CKEDITOR.replace( element ,{
				enterMode : CKEDITOR.ENTER_BR,
        		shiftEnterMode : CKEDITOR.ENTER_P,
        		autoParagraph : false,
				on :{
        			instanceReady : function( ev ){
            			this.focus();
        			}
    			}
			});
	    }

	    this.adjustViewPortSize = function(){

	    	if( this.isLoggedIn() )
	    	setTimeout(function(){
	    		var headerHeight = $('#main-header').height();
	            var footerHeight = $('#footer').height();
	            var windowHeight = $(window).height();
	            if( $('#main-header').hasClass("hide") ){
	              headerHeight = 0;
	            }

	            $('.dost-main').css('min-height', windowHeight - headerHeight - footerHeight + 20 );

	    	},10);
	    }

	    this.getlinkName = function(ele){
	    	var link = $(ele).attr("href") ;
	    	link = link.replace(/#/, "") ;
	    	return {itemName : link, "medium":"website"} ;
	    }

	    this.trackFooterLinks = function(e){

	    	//e.preventDefault() ;
	    	if( typeof mixpanel === 'undefined' ) return ;

	    	var that = this;
	    	if (typeof mixpanel.track_links === "function") {

	    		mixpanel.track_links( ".footer-track-link", "Footer" , this.getlinkName);
	    		mixpanel.track_links( ".ban-header-link", "Home Banner", this.getlinkName);
	    	}else{

				setTimeout(function(){

					console.log( "trying after one second :)" );
					//that.trackFooterLinks();
				}, 1000)
			}
	    }

	    this.getContent = function(ele){

	    	var content = $(ele).attr("data-desc");
	    	var link = $(ele).attr("href") ;
	    	link = link.replace(/#/, "") ;
	    	return {"itemName" : content, "itemLink" : link}
	    }

	    this.trackHomeBannerLinks = function(e){

	    	e.preventDefault() ;
	    	if( typeof mixpanel === 'undefined' ) return ;

	    	var that = this;
	    	if (typeof mixpanel.track_links === "function") {

	    		mixpanel.track( "Home Banner", {"itemName": $(e.currentTarget).attr("data-desc"), "itemLink" : $(e.currentTarget).attr("href")});
	    	}else{

				setTimeout(function(){

					console.log( "trying after one second :)" );
					//that.trackFooterLinks();
				}, 1000)
			}
	    }

	    this.trackHeaderLinks = function(e){

	    	e.preventDefault() ;

	    	if( typeof mixpanel === 'undefined' ) return ;

	    	var that = this;
			if (typeof mixpanel.track_links === "function") {

 				// safe to use the function


          mixpanel.track( "#logo-container", "Header", {"itemName": "Logo"});


           		mixpanel.track_links( ".header-track-link", "Header" , this.getlinkName);
           		mixpanel.track_links( ".header-track-mobile", "Header" , this.getlinkName);
           		mixpanel.track_links( ".track-login", "Login" , this.getlinkName);
			}else{

				setTimeout(function(){

					console.log( "trying after one second :)" );
					//that.trackHeaderLinks();
				}, 1000)

			}
	    }

	    this.formEmailCheck = function(email){
	    	if(email.length <= 0){
				return 0 ;
			}
			var pattern = /^[-a-z0-9~!$%^&*_=+}{\'?]+(\.[-a-z0-9~!$%^&*_=+}{\'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?$/i;

			if( !pattern.test(email) ){
				return 0 ;
			}
			return 1 ;
	    },
	    this.formMobileCheck = function(mobile){
	    	var regex = new RegExp("^[0-9]{10}$");
	    	if(!mobile.match(regex)){
	    		return 0 ;
	    	}
	    	return 1 ;
	    },
	    this.formEnableSubmit = function(divID){
			$("#" + divID ).removeClass("disabled");
			$("#" + divID ).attr("disabled", false);
		},

		this.formDisableSubmit = function(divID){
			$("#" + divID ).addClass("disabled");
			$("#" + divID ).attr("disabled", true);
		},
		this.JUIsplit = function( val ) {
      		return val.split( /,\s*/ );
    	},
    	this.JUIextractLast = function( term ) {
    	  	return this.JUIsplit( term ).pop();
    	}
    	this.isFirstTimeUser = function(){

    		if(sessionStorage.getItem("firstTimeUser") != undefined && sessionStorage.getItem("firstTimeUser") == 1 ){
    			return 1 ;
    		}

    		return 0 ;
    	};

        this.redirectToDiscussion = function(e){
          if( this.isLoggedIn() && ($.cookie("_t") == "" || !$.cookie("_t") || $.cookie("_t") == undefined ) ){
          location.href = this.discussionUrl() + "/session/sso?return_path=%2F" ;
          }else{
           location.href = this.discussionUrl() ;
          }
        };

        this.getFBApiId = function(){
        	return fbAPIID ;
        };

        this.getGoogleApiId = function(){
        	return googleAPIID ;
        };

        this.replaceUrls = function(text){

	       	text = AutoLinker.link(text, {stripPrefix: false});
	       	console.log(text);
	       	return text ;

        }

	    this.trackBalancePayment = function(e){

	    	if( typeof mixpanel === 'undefined' ) return ;

	    	var that = this;
	    	if (typeof mixpanel.track_links === "function") {

	    		mixpanel.track_links( ".balance-payment-info", "Balance Details" , this.getlinkName);
	    	}else{

				setTimeout(function(){

					console.log( "trying after one second :)" );
					//that.trackFooterLinks();
				}, 1000)
			}
	    }
	    this.getParentingEbookPostId = function(e){
	    	return parentingBookPostId;
	    },
	    this.checkIfArrayIsUnique = function( arr ) {

    		var map = {}, i, size;

    		for (i = 0, size = arr.length; i < size; i++){
        		if (map[arr[i]]){
            		return false;
        		}

        		map[arr[i]] = true;
    		}

    		return true;
		},
		this.getDuplicateValuesFromArray = function( arr ) {

			var sorted_arr = arr.slice().sort();
			var results = [];
			for (var i = 0; i < arr.length - 1; i++) {
    			if (sorted_arr[i + 1] == sorted_arr[i]) {
        			results.push(sorted_arr[i]);
    			}
			}
			return results;
		},

		this.checkForNameField = function( name ){

			var regex = /^[a-zA-Z ]+$/;
			return ( regex.test( name ) ) && ( name.length > 0 );

		},

		this.checkForCityField = function( city ) {

			var regex = /^[a-zA-Z]+(?:[\s-][a-zA-Z]+)*$/;
			return ( regex.test( city ) ) && ( city.length > 0 );
		},

		this.checkForStateField = function( state ) {

			var regex = /^[a-zA-Z]+(?:[\s-][a-zA-Z]+)*$/;
			return ( regex.test(state) ) && ( state.length > 0 );

		},

		this.formFacebookProfileUrlCheck = function( url ) {

			var regex = /^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]*/;
			return ( regex.test( url ) || url.length == 0);
		},

	    this.checkFromPageIsSelfHelp = function( currentPage ) {

	    	var url = window.location.href ;
            url = url.replace(currentPage, "" );
            var fromPage = $.url( url ).param('fromPage') ;
            console.log( ' fromPage ' + fromPage );
            if (fromPage == "selfhelp") {
              console.log('hello');
              $(".back-to-selfHelp").removeClass("hide");
            }
	    },

	    this.checkIfCounselorIsBlocked = function(counselorId){

	    	var self = this;
	    	return new Promise(function(resolve, reject){

				$.ajax({

					method : "GET",
					url : self.contextPath() + '/users/myBlockedCounselor',
					contentType: "application/json",
				}).done(function(response){

					id = parseInt(counselorId);
					if(response.indexOf(id) > -1){

						resolve(true)
					}else{

						resolve(false)
					}
				}).error(function(error){

					reject(error)
				})
			});
		},
	    this.shareOnFacebook = function( socialShareResponse, targetElement, loaderElement, mixpanelEvent ) {

			var self = this;
	    	return new Promise( function( resolve, reject ){

		    	var socialShareTitle = socialShareResponse["title"];
	            var socialShareDesc = socialShareResponse["description"];
	            var url = socialShareResponse["url"];
	            var socialShareUrl = self.socialShareUrl() + url + "?utm_content=" + socialShareResponse["identifier"] +'&utm_source='+ socialShareResponse["utm_source"] +'&utm_medium=' + socialShareResponse["utm_medium"];
	            var socialShareImageUrl = socialShareResponse["imageUrl"];
	            var socialShareMixpanelIdentifier = socialShareResponse["mixpanel-itemName"];


	        	console.log( 'Social Share Desc ' + socialShareDesc );
	        	console.log( 'Social Share response title ' + socialShareTitle );
	        	console.log( 'social share url ' + socialShareUrl);
	        	console.log( 'social share url ' + socialShareImageUrl);
	        	console.log( 'social share mixpanel identifier ' + socialShareMixpanelIdentifier );

	          	if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

	              mixpanel.track(mixpanelEvent, { "medium" : "website", "itemName" : socialShareMixpanelIdentifier });

	        	}

	        	$.getScript('//connect.facebook.net/en_US/sdk.js', function(){
	                FB.ui({
	                      method: 'share',
	                      picture: socialShareImageUrl,
	                      title: socialShareTitle,
	                      description: socialShareDesc,
	                      href: socialShareUrl,
	                }, function(response){

	                	targetElement.removeClass("hide");
	                    loaderElement.addClass("hide");
	                    console.log( "response", JSON.stringify(response) );
	                	if (response && !response.error_message) {

	      					resolve(true);
	    				} else {

	                    	resolve(false);
	    				}

	                }, function( error ){
	                	console.log( error );
	                });
	        	});

	    	});

	    }

	    this.downloadEbookCall = function( postId, categoryId, successMsg, email ) {

    		var self = this;

			var emailJSON = {
				"email": email
			}

			$.ajax({

				method : "POST",
				dataType: "JSON",
				url: self.contextPath() + '/ebook/'+ postId ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify(emailJSON)

			}).done(function( data ) {

				console.log( data );

				if (categoryId == 100) {
	    				Backbone.history.navigate("/talkItOut",{trigger:true});
	    		}
	    		else {
	    				Backbone.history.navigate("/talkItOut?category=" + categoryId,{trigger:true});

	    		}

	    		console.log( successMsg );
				self.displaySuccessMsgWithDelay( successMsg, 8000 );
			});
    	}

    	this.downloadEbookCallWithOutEmail = function( postId, categoryId ) {

    		Backbone.history.navigate("#talkItOut?category="+ categoryId +"&fromPage=EbookPrompt&postId="+postId,{trigger:true});

    	}

    	this.trackMixPanelForSelfTestResultPage = function( mixpanelIdentifier, itemName, type ) {

    		if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

                if (type !== undefined) {
                      mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : itemName, "type": type});
                }
                else {
                      mixpanel.track(mixpanelIdentifier, { "mediumSource" : "website", "itemName" : itemName});
                }

            }

    	}
    	this.storeSelfHelpResult = function( username, testName, answer ) {

    		var self = this;

    		var storeJSON = {
    			"testname": testName,
    			"answer": answer
    		};

    		$.ajax({

				method : "POST",
				url: self.contextPath() + "/users/" + username + "/selfhelp" ,
				contentType: "application/json; charset=utf-8",
				data: JSON.stringify( storeJSON )

			}).done(function( data ) {

				console.log(data);

			}).error( function(error){

				console.log(error);
			});
    	}

		this.bytesToSize = function(bytes) {

		    var sizes = ['Bytes', 'KB', 'MB'];
		    if (bytes == 0) return 'n/a';
		    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
		    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i];
		}

		// check for selected crop region
		this.checkForm = function() {
		    if (parseInt($('#w').val())) return true;
		    $('.error').html('Please select a crop region and then press Upload').show();
		    return false;
		};

		// update info by cropping (onChange and onSelect events handler)
		this.updateInfo = function(e) {

		    $('#x1').val(e.x);
		    $('#y1').val(e.y);
		    $('#x2').val(e.x2);
		    $('#y2').val(e.y2);

		    var rx = 100 / e.w;
			var ry = 100 / e.h;

			$('#crop-preview').css({
				width: Math.round(rx * 500) + 'px',
				height: Math.round(ry * 370) + 'px',
				marginLeft: '-' + Math.round(rx * e.x) + 'px',
				marginTop: '-' + Math.round(ry * e.y) + 'px'
			});
		};

		this.getRandomInt = function(min, max) {
 		   return Math.floor(Math.random() * (max - min + 1)) + min;
		}

		// clear info by cropping (onRelease event handler)
		this.clearInfo = function() {
		};

		this.discardDraft = function(userId, messageID) {

			var self = this;
			$.ajax({
        		method: "POST",
        		url: self.contextPath()+'/v1/users/'+ userId +'/messages/'+ messageID +'/delete',
       			contentType: "application/json"
      		}).done(function(response){
      			console.log( response );
      			if (response) {
      				self.displaySuccessMsg("Your draft has been discarded");
      			} else {
      				self.displaySuccessMsg("Sorry your draft cannot be discarded");
      			}

			}).error(function(error){
				console.log(error);
			});
		}

		this.addEvent = function(obj, evt, fn) {
	        if (obj.addEventListener) {
	            obj.addEventListener(evt, fn, false);
	        }
	        else if (obj.attachEvent) {
	            obj.attachEvent("on" + evt, fn);
	        }
	    }
	};

	return utils;

});
