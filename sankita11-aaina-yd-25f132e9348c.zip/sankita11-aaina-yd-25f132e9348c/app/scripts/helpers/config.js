var apiUrl        = "https://staging-app.yourdost.com/zion" ;
var discussionUrl = "http://staging-forum.yourdost.com"     ;
var chatUrl       = "https://staging-app.yourdost.com/chatSession" ;
var chatDemoWorkgroup = "demo@workgroup.staging-chat.yourdost.com"  ;
var chatWorkgroup = "yd@workgroup.staging-chat.yourdost.com";
var appVersion       = "2.8" ;
var raygunKey      = '';
var mixpanelKey    = 'bf5488357f171d1de1c29e3cfd0696ee';
var fbAPIID        = '866552203465941';
var googleAPIID    = '1077064249033-g7foqc48mu138l73okl9hn8fs0m89n7v.apps.googleusercontent.com';
var blogUrl        = "https://yourdost.com/blog/api/get_recent_posts?page=1";
var homeblogUrl    = "https://staging-app.yourdost.com/blog/api/get_tag_posts?tag_slug=homearticle";
var parentingBookPostId = 1214;
var blogOrigin	   = "https://staging-app.yourdost.com";
var blogURLFooter  = "http://staging-app.yourdost.com";
var ABTestingUrl = "https://eureka-test.yourdost.com";
var socialShareUrl = "https://staging-app.yourdost.com/";
var relatedArticlesBlogUrl = "https://yourdost.com/blog/api/get_tag_posts?tag_slug=";
var showZopimAppointment = 0 ;
var showZopim = 1 ;
var razorpayKey = "rzp_test_hTEL2eaiZrkFKg";
var paytmMerchantId = "YourDO58989775215618";
var paytmWebsite = "WEB_STAGING";
var paytmChannelId = "WEB";
var paytmIndustryTypeId = "Retail";
var paytmTransactionURL = "https://pguat.paytm.com/oltp-web/processTransaction";
var firebaseConfig = {
	apiKey: "AIzaSyCjz28NVWwc4PEWtPFGWTwu9O9oGMXfzpc",
	authDomain: "torrid-heat-7606.firebaseapp.com",
	databaseURL: "https://torrid-heat-7606.firebaseio.com",
	storageBucket: "torrid-heat-7606.appspot.com"
};