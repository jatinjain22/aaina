define([
  'jquery',
  'moment-timezone-data',
  'autolink',
  'utils',
  'imagesloaded',
  'masonry',
  'jstz',
  'console',
  'config',
  'raygun'
], function($,moment, AutoLinker, Utils, imagesLoaded, Masonry){ 

	var TrueColorUtils = new function() {


		this.getQuestions = function() {
			
			return $.ajax({
                url : Utils.scriptPath() + "/selfHelp/trueColor/question.json",
                cache: false
            });

		};

		this.getQuestionOptions = function() {

			return $.ajax({
				url : Utils.scriptPath() + "/selfHelp/trueColor/questionOptions.json",
				cache: false
			})
		};

		this.arrangeColorPatch = function(elem) {

			var imageLoad = new imagesLoaded( elem, function(){
                var msnry = new Masonry(elem, {

                    columnWidth: '.col',
                    itemSelector: '.col',
                    percentPosition: true,
                    originLeft: true

                });
            });
		};
		this.trackMixpanel = function(mixpanelEvent, setCount){

			var url = location.pathname;
			var itemName;
			
			if ( url == "/truecolour" ) {

				itemName = "True Colour";
			
			} else if ( url == "/truecolourpage" ){

				itemName = "True Colour Landing Page";
			}

			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){

			    var mixpanelIdentifier;
			    if (setCount === 0) {
			          mixpanelEvent = 'Self Test begin';
			          setCount = undefined;
			    }
			   
			    if ( setCount !== undefined ){

			          mixpanel.track(mixpanelEvent, { "mediumSource" : "website", "itemName" : itemName, "Page No": setCount});
			    }
			    else {

			          mixpanel.track(mixpanelEvent, { "mediumSource" : "website", "itemName" : itemName} );     

			    }
			}

        };

        this.trackMixpanelForResultPage = function( mixpanelEvent, type ) {

        	var url = location.pathname;
			var itemName;
		
			if ( url == "/truecolour/result" ) {

				itemName = "True Colour";
			
			} else if ( url == "/truecolourpage/result" ){

				itemName = "True Colour Landing Page";
			}
			
			if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){ 

				if ( type === undefined ) {
				
					mixpanel.track( mixpanelEvent, {"mediumSource": "website", "itemName": itemName })
				
				} else {
					mixpanel.track( mixpanelEvent, {"mediumSource": "website", "itemName": itemName, "type": type })

				}

			}

        };

        this.getArrayOfColorValues = function( colorCodes ) {

        	var orangeColorCode = ["A", "H", "K", "N", "S"];
			var blueColorCode = ["C", "F", "J", "O", "R"];
			var greenColorCode = ["D", "E", "L", "P", "Q"];
			var goldColorCode = ["B", "G", "I", "M", "T"];

			var orangeVal = 0;
			var blueVal = 0;
			var greenVal = 0;
			var goldVal = 0;

			var sum = {};

			console.log( 'Color Code' );
			console.log( colorCodes );

			for (var i in orangeColorCode) {
			    var dataIndex = orangeColorCode[i];
			    console.log( 'dataIndex '+ dataIndex );
			    console.log( 'color code '+ colorCodes[ '"' + dataIndex + '"'] );
			    orangeVal += colorCodes['"' + dataIndex + '"'];

			}
			sum[orangeVal] = 'Orange';
			console.log( 'Orange Val ' + orangeVal );

			for (var j in blueColorCode) {

			    var dataIndex = blueColorCode[j];
			    console.log( 'dataIndex '+ dataIndex );
			    console.log( 'color code '+ colorCodes[ '"' + dataIndex + '"'] );
			    blueVal += colorCodes['"' + dataIndex + '"'];

			}
			sum[blueVal] = 'Blue';
			console.log( 'Blue Val ' + blueVal );

			for (var k in greenColorCode) {

			    var dataIndex = greenColorCode[k];
			    console.log( 'dataIndex '+ dataIndex );
			    console.log( 'color code '+ colorCodes[ '"' + dataIndex + '"'] );
			    greenVal += colorCodes['"' + dataIndex + '"'];

			}
			sum[greenVal] = 'Green';
			console.log( 'Green Val '+ greenVal );

			for (var l in goldColorCode ) {

			    var dataIndex = goldColorCode[l];
			    console.log( 'dataIndex '+ dataIndex );
			    console.log( 'color code '+ colorCodes[ '"' + dataIndex + '"'] );
			    goldVal += colorCodes['"' + dataIndex + '"'];
			}
			sum[goldVal] = 'Gold';
			console.log( 'Gold Val ' + goldVal );

			var arrayColorValue = [blueVal, orangeVal, greenVal, goldVal, sum];
        	return arrayColorValue;
        };

	};

	return TrueColorUtils;
});