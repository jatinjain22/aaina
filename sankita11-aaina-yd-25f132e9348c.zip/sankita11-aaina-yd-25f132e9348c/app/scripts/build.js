({
    baseUrl: '.',
    mainConfigFile: 'main.js',

    out: 'dist/output.min.js',
    optimize: 'uglify2',
    inlineText: true,

    include: ['main'],
    name: '../bower_components/almond/almond',
})
