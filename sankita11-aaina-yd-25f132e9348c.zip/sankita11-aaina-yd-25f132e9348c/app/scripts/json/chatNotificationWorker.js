'use strict';

var connections = 0; // count active connections
var peers = [];
var notifData = {};

var events = {
	"CONNECTION": "CONNECTION",
	"CHAT_STARTED": "CHAT_STARTED",
	"CHAT_ENDED": "CHAT_ENDED",
	"NEW_CHAT_MESSAGE": "NEW_CHAT_MESSAGE",
	"IN_QUEUE_CONNECTION": "IN_QUEUE_CONNECTION"
};

var isChatSessionLive = false;

self.addEventListener("connect", function (e) {

	var port = e.ports[0];
	connections++;

	peers.push({
        connectionId: connections,
        port: port
    });
    console.log("new connection", {
        connectionId: connections,
        port: port
    })

    var payloadData = {
    	connectionId: connections,
    	isChatSessionLive: isChatSessionLive
    };
    for( var i in notifData) {
    	payloadData[i] = notifData[i];
    }
    port.postMessage({
        payload: payloadData,
        type: 'CONNECTION'
    });


	port.addEventListener("message", function (e) {
		console.log("message", e.data);
		// port.postMessage("Hello " + e.data + " (port #" + connections + ")");
		if(e.data.type === events.IN_QUEUE_CONNECTION) {
			/*for(var i=0; i < peers.length;i++) {
				peers[i].port.postMessage({
			        payload: {
			        	connectionId: connections
			        },
			        type: 'IN_QUEUE_CONNECTED'
			    })
			}*/
		}
		else if(e.data.type === events.CHAT_STARTED) {
			isChatSessionLive = true;
			notifData = e.data.payload;

			peers.filter(function(peer) {
				return peer.connectionId !== e.data.port;
			}).forEach(function(peer) {
				peer.port.postMessage(e.data);
			});
		}
		else if(e.data.type === events.CHAT_ENDED) {
			isChatSessionLive = false;

			peers.filter(function(peer) {
				return peer.connectionId !== e.data.port;
			}).forEach(function(peer) {
				peer.port.postMessage(e.data);
			});
		}else {
			port.postMessage("Hello " + e.data + " (port #" + connections + ")");
		}
	}, false);

	port.start();

}, false);
