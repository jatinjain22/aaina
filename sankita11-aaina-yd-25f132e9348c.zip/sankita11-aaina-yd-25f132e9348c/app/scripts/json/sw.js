var cacheName = 'header'

var offlineFundamentals = [
  'https://d1hny4jmju3rds.cloudfront.net/fired2firedup_banner.jpg',
  'https://d1hny4jmju3rds.cloudfront.net/fired2firedup_phone.png'
]

self.addEventListener("install", function(event) {
    console.log('[ServiceWorker] Installing....');
    event.waitUntil(
      caches
      .open(cacheName)
      .then(function(cache) {
          console.log('[ServiceWorker] Caching files');
          cache.addAll(offlineFundamentals);
      })
  );
});

self.addEventListener('activate',  event => {
  event.waitUntil(
      caches.keys()
      .then(function(keyList) {
        Promise.all(keyList.map(function(key) {
            if (key !== cacheName) {
              console.log('[ServiceWorker] Removing old cache ', key);
              return caches.delete(key);
            }
          })
        );
      })
  );
});

self.addEventListener('fetch', { mode : 'cors'}, event => {
  event.respondWith(
    caches.match(event.request)
    .then(function(response) {
        if(response) {
          console.log("Fulfilling "+event.request.url+" from cache.");
          return response;
        } else {
          console.log(event.request.url+" not found in cache fetching from network.");
          return fetch(event.request);
        }
    })
  );
});
