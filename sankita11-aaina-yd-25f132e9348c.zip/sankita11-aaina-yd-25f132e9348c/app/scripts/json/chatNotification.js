'use strict';

var events = {
	"CONNECTION": "CONNECTION",
	"CHAT_STARTED": "CHAT_STARTED",
	"CHAT_ENDED": "CHAT_ENDED",
	"NEW_CHAT_MESSAGE": "NEW_CHAT_MESSAGE",
	"IN_QUEUE_CONNECTION": "IN_QUEUE_CONNECTION"
};

var isWindowActive = true;
var notifData = {};
var notifTimeout;
var chatNotificationWorker;
window.onfocus = function () { 
  isWindowActive = true; 
  console.log("isWindowActive",isWindowActive);
}; 

window.onblur = function () { 
  isWindowActive = false; 
  console.log("isWindowActive",isWindowActive);
}; 
var cssID = "chat-notif-css";
if (!document.getElementById(cssID)) {
	var head  = document.getElementsByTagName('head')[0];

	var link = document.createElement('link');
	link.id = cssID;
	link.rel  = 'stylesheet';
    link.type = 'text/css';
	// link.href = "https://d1763776ly2p7c.cloudfront.net/chatNotification/chatNotification.css";
	link.href = "/scripts/json/chatNotification.css";
    link.media = 'all';
	head.appendChild(link);
}

if (typeof(window.SharedWorker) === 'undefined') {}
else {
	chatNotificationWorker = new SharedWorker("/scripts/json/chatNotificationWorker.js");

	console.log("chatNotificationWorker", chatNotificationWorker, "isWindowActive", isWindowActive);

	chatNotificationWorker.port.addEventListener("message", function(e) {
		if(e.data.type === events.CONNECTION) {
			if( window.location.pathname.indexOf("/chatSession") === -1 && e.data.payload.isChatSessionLive) {
				notifData = e.data;
				setTimeout( function() {
					showNotification();
				}, 10000);
			}
		}
		else if(e.data.type === events.CHAT_STARTED) {
			console.log("events.CHAT_STARTED", e.data);
			if( window.location.pathname.indexOf("/chatSession") === -1 && !e.data.payload.isChatWindowActive ) {
				notifData = e.data;
				showNotification();
			}


		}
		else if(e.data.type === events.CHAT_ENDED) {
			console.log("events.CHAT_ENDED", e.data);
			hideNotification();
			setTimeout(function(){
				clearTimeout(notifTimeout);
			}, 100);
		}
		console.log("message", e.data);
		// alert(JSON.stringify(e.data));
	}, false);

	chatNotificationWorker.port.start();

	chatNotificationWorker.port.postMessage({
		payload: {
			name: ""
		} ,
		type: events.IN_QUEUE_CONNECTION
	});
}

function showNotification() {

	var notificationPopupHTML = '' +
					'<i class="close-notification-popup icon dripicons-cross" onclick="hideNotification()"></i>' + 
					'<div class="notification-from-image">' +
						'<img class="img" src="'+notifData.payload.expertPicture+'">' +
					'</div>' +
					'<div class="notification-description">' +
						'<div class="notification-from-name">' + notifData.payload.expertName + '</div>' +
						// '<div class="notification-desc-text">' + notifData.payload.msgText + '</div>' +
						'<div class="notification-desc-text">Your chat session with me is LIVE in the other tab :). </div>' +
					'</div>'+
					'<div class="notification-context-image">' +
						'<img class="img" src="https://d1hny4jmju3rds.cloudfront.net/userDashboard/No_message.png">' +
					'</div>';
				// '</div>';
	var divID = "notification-popup";

	if (!document.getElementById(divID)) {
		var elemDiv = document.createElement('div');
		elemDiv.id = "notification-popup";
		elemDiv.innerHTML = notificationPopupHTML;
		document.body.appendChild(elemDiv);
		setTimeout(function(){
			elemDiv.classList.add("show-notification-popup");
		}, 100);
	}
	trackMixpanel("Chat Notification in YD", {});
}

function hideNotification() {
	var divID = "notification-popup";

	if (document.getElementById(divID)) {
		var element = document.getElementById(divID);
		element.classList.add("fadeOut");
		setTimeout(function(){
			document.body.removeChild( document.getElementById(divID) );	
		},1000)
	}

	notifTimeout = setTimeout(function(){
		showNotification();
	}, 30000)

	trackMixpanel("Button Click", {"itemName":"Close_chat_notification_YD"});
}

function trackMixpanel( action_type, action_data ){

	if(typeof mixpanel !== 'undefined' && typeof mixpanel.track == "function" ){
		
		mixpanel.track(action_type, action_data);
	}
}
