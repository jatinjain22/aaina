define([
  'jquery',
  'underscore',
  'backbone',
  'vm',
  'utils',
  'view/header/page',
  'view/packages/packages_header',
  'view/header/talkItOut',
  'view/header/messages',
  'view/footer/page',
  'view/notSupported/page',
  'backbone.viewcache'
], function ($, _, Backbone, Vm, Utils, HeaderView, PackagesHeaderView, TalkItOutHeaderView, MessageHeaderView, FooterView, NotSupportedPage, LandingPageView, LandingPageView2) {

  var AppRouter = Backbone.Router.extend({

    initialize: function(options) {
      this.appView             = options.appView;
      this.packagesHeaderView = new PackagesHeaderView();
      this.headerView          = new HeaderView();
      this.talkItOutHeaderView = new TalkItOutHeaderView();
      this.messageHeaderView = new MessageHeaderView();
      this.footerView = new FooterView();
      this.notSupportedPage = new NotSupportedPage();
     // this.landingView = new LandingPageView();
      //this.landingView2 = new LandingPageView2();
      // this.initialPageView = new InitialView();
      // this.appBannerPage = new appBannerView();
      // this.marketFooterView = new MarketFooterView();
      //this.verifyemailPageView = new VerifyEmail();

    },

    register: function (route, name, path) {

      var self = this;
      this.route(route, name, function () {

        var args = arguments;
        require([path], function (module) {

          var options = null;
          var parameters = route.match(/[:\*]\w+/g);
          if (parameters) {

            options = {};
            _.each(parameters, function(name, index) {

              options[name.substring(1)] = args[index];
            });
          }

          if (self.page) {

            self.page.remove();
          }

          self.page = Vm.create(self.appView, name, module, options);
          $('#main-header').show();
          self.headerView.render();
          self.page.render();

          function detectIE() {

            var ua = window.navigator.userAgent;
            var msie = ua.indexOf('MSIE ');
            var trident = ua.indexOf('Trident/');
            var edge = ua.indexOf('Edge/');
            if (msie > 0 || trident > 0 || edge > 0) {

              return true;
            }

            return false;
          }

          if( detectIE() && sessionStorage.getItem("insideChrome") !="true"){

            var url = window.location.href;
            self.notSupportedPage.render(url);
            $(".feedback-form-btn").hide();
            $(".home-footer").hide();
          }else{
            /*if(window.location.pathname.indexOf("online-counseling-programs") > -1){

              self.headerView.render();
              // self.packagesHeaderView.render();
              // self.footerView.render();
              $("html,body").scrollTop(0);
            }else{*/

              if (route == "careercounselor" || route == "parentingtips" || route == "tips-counselor-page"|| route == "tips-spouse-communication" || route == "truecolourpage" || route=="truecolourpage/result") {

                $('head').append('<META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">');
                $("#main-header").hide();
                $(".home-footer").hide()
                $(".feedback-form-btn").hide();
              }else{

                $(".dost-main").css({"min-height" : "93vh"})
                $(".home-footer").show()
                $(".feedback-form-btn").show();
              }
              if( window.location.hash.indexOf("/relationshipcounselor") > -1
                ||
                  window.location.pathname.indexOf("/careercounselor") > -1){
              }else{

                self.footerView.render();
              }
              if(!window.location.hash.match("#chat")){

                $("footer").removeClass("hide");
              }else{

                $("footer").addClass("hide");
              }
              $(".to-hide-landing").show() ;


              if(window.location.pathname.indexOf("/talkItOut") > -1 ){

                self.talkItOutHeaderView.render();
                if(screen.width > 600){

                  $(".hnav").removeClass("teal");
                }

                $(".talkitout-active").css({"border" : '1px solid #00bfa5'});
                $("#small-logo-container").removeClass("hide");
                $("#logo-container").addClass("hide");
                $("#main-header").removeClass("home-header").css("position","relative");
                $("#main-header").removeClass("home-header");

                if( !Utils.isMobileDevice() && $(window).width() > 993 )
                  $(".hnav").removeClass("home-header-nav").addClass("white");
                else
                  $(".hide-on-large-only").removeClass("home-header-nav").removeClass("white").addClass("teal");
                $(".dost-main").removeClass("home-dost-main");

                window.search = false;
                Utils.adjustViewPortSize();
              }else if( ( window.location.pathname.indexOf("/friend/messages") > -1 ) ||
                ( window.location.pathname.indexOf("/user/messages") > -1 ) || ( window.location.pathname.indexOf("/client") > -1 ) ){

                self.messageHeaderView.render();
                $("#small-logo-container").removeClass("hide");
                $("#logo-container").addClass("hide");

                if(screen.width > 600)
                  $(".hnav").removeClass("teal");

                $("#main-header").removeClass("home-header").css("position","relative");
                $("#main-header").removeClass("home-header");

                if( !Utils.isMobileDevice() && $(window).width() > 993 )
                  $(".hnav").removeClass("home-header-nav").addClass("white");
                else
                   $(".hide-on-large-only").removeClass("home-header-nav").removeClass("white").addClass("teal");

                $(".dost-main").removeClass("home-dost-main");
                $(".button-collapse").off('click').sideNav({

                  menuWidth: "280", // Default is 240
                  edge: 'left',
                  closeOnClick: true
                });
              }else if( route == "3"){

                window.search = false;
                self.headerView.render();
                $("#main-header").addClass("home-header").css("position","absolute");
                $(".hnav").addClass("home-header-nav teal").removeClass("white");
                $(".dost-main").removeClass("home-dost-main");
                $( window ).scroll(function() {

                  if( $(window).scrollTop() == 0 ){

                    $("#main-header").addClass("home-header").css("position","absolute");
                    $(".hnav").addClass("home-header-nav teal").removeClass("white");
                    $(".dost-main").removeClass("home-dost-main");
                  }else{

                    $("#main-header").removeClass("home-header").css("position","fixed");
                    $(".hnav").removeClass("home-header-nav teal").addClass("white");
                    $(".dost-main").removeClass("home-dost-main");
                  }
                });

                Utils.adjustViewPortSize();
              }else{

                window.search = false;

                $( window ).unbind("scroll");
                // if (!(window.location.pathname == '/' || window.location.pathname == '/!' || window.location.pathname == '/care-plan/subscribe')) {
                //   $('#main-header').show();
                //   self.headerView.render();
                // }
                if( route == "relationshipcounselor" || route == "careercounselor" ){

                  $(".to-hide-landing").hide() ;
                  $(".to-show-landing").removeClass("hide") ;
                }
                if( route == "*actions" || route == "login" || route == "2" ){

                  if(screen.width > 600){

                    $(".hnav").removeClass("teal");
                  }
                  $( window ).scroll(function() {

                    if( $(window).scrollTop() > 275 && screen.width > 600){

                      $("#scroll-up-btn").removeClass("hide");
                      // $(".start-chat-on-scroll").removeClass("hide").addClass("menu-is-sticky").addClass("animated fadeInDown");

                      if( $(".start-chat-on-scroll").length > 0 ){

                        $(".explore-menu").addClass("hide");
                        $(".user-drop-listitems").addClass("hide");
                      }
                      if($("#scroll-up-btn").length > 0){
                        // $(".hnav").hide();
                      }
                    }else{

                      $(".hnav").show();
                      if( ( window.location.pathname == "" )   || ( window.location.pathname == "/" ) ||
                          ( window.location.pathname == "/!" ) || ( window.location.pathname.indexOf("/login") > -1 ) ){

                        if( $(window).scrollTop() == 0 ){

                          $("#main-header").addClass("home-header").css("position","absolute");
                          $("#main-header").css("position","relative");
                          $(".dost-main").removeClass("home-dost-main");
                        }else{

                          $("#main-header").removeClass("home-header").css("position","fixed");
                          $(".hnav").removeClass("home-header-nav").addClass("white");
                          $(".dost-main").removeClass("home-dost-main");
                        }
                      }

                      $(".start-chat-on-scroll").removeClass("menu-is-sticky").addClass("hide");
                      $("#scroll-up-btn").addClass("hide");
                    }
                  });

                  $(".dost-main").removeClass("home-dost-main");
                }else{

                  $( window ).unbind("scroll");
                  $("#main-header").removeClass("home-header").css("position","relative");

                  if( !Utils.isMobileDevice() && !window.location.pathname.match("/faq") && !window.location.pathname.match("/talkItOut")){

                    $(".hnav").removeClass("home-header-nav").addClass("white");
                    $(".dost-main").removeClass("home-dost-main");
                   $("#small-logo-container").removeClass("hide");
                    $("#logo-container").addClass("hide");
                  }

                  $("#main-header").removeClass("hide-on-med-and-down");
                  Utils.adjustViewPortSize();
                  if(window.location.pathname.match("/counselor") && screen.width <= 600 ){

                    $(".hnav").removeClass("white").addClass("teal");
                  }

                  $(window).scroll(function(){

                      if($(window).scrollTop() > 1){

                        $(".download-app-banner").addClass("hide");
                      }else{

                      $(".download-app-banner").removeClass("hide");
                    }
                  })
                  Utils.scrollTo();
                }

                if(window.location.hash.indexOf("/faq") > -1){

                  $(window).scroll(function(){

                    if($(window).scrollTop() > 100){

                      $('.donation-head-strip').removeClass("collapsed").addClass("expanded")
                    }else{

                      $('.donation-head-strip').addClass("collapsed").removeClass("expanded")
                    }

                  })
                }


                if(window.location.hash.indexOf("/habitometer") > -1 || window.location.hash.indexOf("/selfhelp") > -1
                  ||
                  window.location.hash.indexOf("/discoverYourself") > -1 || window.location.hash.indexOf("/playbuzztest") > -1
                  ||
                  window.location.hash.indexOf("/truecolour") > -1){

                  $(".selftest-active").css({"border" : '1px solid #00bfa5'});
                }

                if( ( window.location.pathname == "" )   || ( window.location.pathname == "/" )
                    ||
                    ( window.location.pathname == "/!" ) || ( window.location.pathname.indexOf("/login") > -1 ) ){
                }else{

                  $("#small-logo-container").removeClass("hide");
                  $("#logo-container").addClass("hide");
                }
              }

              if( window.location.pathname.indexOf("/new-year-resolution") > -1
                  ||
                  window.location.pathname.indexOf("/relationships") > -1
                  ||
                  window.location.pathname.indexOf("/valentines-day") > -1
                  ||
                  window.location.pathname.indexOf("/flames-love-calculator") > -1
                  ||
                  window.location.pathname.indexOf("/flames") > -1
                  ||
                  window.location.pathname.indexOf("/womens-day-2017") > -1
                  ||
                  window.location.pathname.indexOf("/new-age-indian-woman") > -1
                  ||
                  window.location.pathname.indexOf("/lets-talk") > -1
                  ||
                  window.location.pathname.indexOf("/online-counseling-programs") > -1
                  ||
                  window.location.pathname.indexOf("/care-plan") > -1
                  ||
                  window.location.pathname.indexOf("/career") > -1
                  ||
                  window.location.pathname.indexOf("/login/sso") > -1
                  ||
                  window.location.pathname.indexOf("/mpbse") > -1
                  ||
                  window.location.pathname.indexOf("/bookAppointment") > -1
                )
              {

                  $('footer').hide();
              }

              if(window.location.pathname.indexOf("/mpbse") > -1) {
                $("#main-header").hide();
              }

              $(".button-collapse").off('click').sideNav({

                menuWidth: "280",
                edge: 'left',
                closeOnClick: true
              });
              //$(".button-collapse").sideNav("hide");
            //}
          }
        });
      })
    }
  });

  var initialize = function(options){

    var router = new AppRouter(options);

    // Default route goes first

    router.register('welcome', 'welcomePage', 'view/welcome/initial');
    router.register('*actions', 'HomePage', 'view/homeNew/page');
    router.register('2', 'HomePage', 'view/home/page');
    router.register('3', 'HomePage', 'view/home3/page');
    router.register('login', 'LoginPage', 'view/login/page');
    router.register('loginModal', 'LoginModalPage', 'view/login/modal_page');
    router.register('termsUpdateModal', 'termsUpdateModalPage', 'view/tos/modal_page');
    router.register('logout', 'LogoutPage', 'view/logout/page');
    router.register('forgetPassword', 'ForgetPasswordPage', 'view/forgetPassword/page');
    router.register('resetPassword', 'ResetPasswordPage', 'view/resetPassword/page');
    router.register('team', 'TeamsPage', 'view/teams/page');
    router.register('partners', 'PartnersPage', 'view/partners/page');
    router.register('changePassword', 'ChangePasswordPage', 'view/changePassword/page');
    router.register('signup', 'SignUpPage', 'view/signup/page');
    router.register('faq', 'FaqPage', 'view/faq/page');
    router.register('faq/:id', 'FaqSinglePage', 'view/faq/singlepage');
    router.register('review', 'ReviewView', 'view/review/review');
    router.register('testimonials', 'TestimonialPage', 'view/testimonials/page');
    router.register('termsOfService', 'TOSPage', 'view/tos/page');
    router.register('privacyPolicy', 'PrivacyPolicyPage', 'view/privacyPolicy/page');
    router.register('talkItOut', 'TalkItOutPage', 'view/talkItOutV2/page');
    router.register('talkItOutAllExperts', 'TalkItOutPage', 'view/talkItOutV2/page');
    router.register('counselor/:id', 'CounselorSinglePage', 'view/counselor/singlepageV2')
    router.register('user/messages', 'MessagePage', 'view/messages/message');
    router.register('user/messages/:id', 'SingleMessagePage', 'view/messages/singlepage');
    router.register('user/messages/:id/:type', 'SingleMessagePage', 'view/messages/singlepage');
    router.register('friend/messages', 'FriendMessagePage', 'view/messages/fpage');
    router.register('friend/messages/:id', 'FriendSingleMessagePage', 'view/messages/fsinglepage');
    router.register('friend/messages/:id/:type', 'FriendSingleMessagePage', 'view/messages/fsinglepage');
    router.register('unsubscribe', 'UnsubscribePage', 'view/unsubscribe/page');
    router.register('clientHistory', 'ClientHistoryUsersPage', 'view/clientHistory/users');
    router.register('client/:id/:name', 'ClientHistoryUserPage', 'view/clientHistory/upage');
    router.register('users/profile', 'UserPage', 'view/users/page');
    router.register('counselor/profile', 'CounselorProfilePage', 'view/counselor/page');
    router.register('cancelAppointment', 'CancelAppointmentPage', 'view/cancelAppointment/page');
    router.register('verifyemail', 'VerifyEmailPage', 'view/messages/verifyemail');
    router.register('mobileapps', 'DownloadAppPage', 'view/mobileApps/page');
    //router.register('bookAppointment', 'BookAppointmentPage', 'view/bookAppointment/page');
    router.register('paymentSuccess', 'PaymentSuccessView', 'view/bookAppointment/payment_success');
    router.register('paymentFailure', 'PaymentFailureView', 'view/bookAppointment/payment_failure');
    router.register('paymentPending', 'PaymentPendingView', 'view/bookAppointment/payment_pending');
    router.register('counselorChatResource', 'CounselorChatResource', 'view/counselorChatResource/page');
    router.register('process', 'ProcessView', 'view/process/page');
    router.register('relationshipcounselor', 'RealtionshipPageView', 'view/relationship/page');
    router.register('homeNew', 'HomePage', 'view/homeNew/page');
    router.register('sessions', 'SessionsV2ViewPage', 'view/sessionsV2/page');
    router.register('landingpage', 'landingPageView', 'view/landingPages/page');
    router.register('habitometer', 'HabitOMeterPage', 'view/selfHelp/habitometer/page');
    router.register('habitometer/result', 'HabitOMeterResultPage', 'view/selfHelp/habitometer/resultPage');
    router.register('discoverYourself', 'DiscoverYourselfPage', 'view/selfHelp/discoverYourself/page');
    router.register('discoverYourself/result', 'DiscoverYourselfResultPage', 'view/selfHelp/discoverYourself/resultPage');
    router.register('careercounselor', 'landingPageView2', 'view/landingPages2/page');
    router.register('parentingtips', 'ParentingTipsPage', 'view/parentingTips/page');
    router.register('playbuzztest', 'PlayBuzzTestPage', 'view/selfHelp/playBuzzTest/page');
    router.register('selfhelp', 'SelfHelpPage', 'view/selfHelp/page');
    router.register('contactus', 'ContactUsPage', 'view/contactUs/page');
    router.register('anythingelse', 'AnythingElseFormPage', 'view/contactUs/forms/anythingElse');
    router.register('feedback', 'ShareYourFeedbackFormPage', 'view/contactUs/forms/shareYourFeedback');
    router.register('issuesinourservice', 'IssuesInOurServiceFormPage', 'view/contactUs/forms/issuesInOurService');
    router.register('help-a-friend', 'BeASaviourFormPage', 'view/contactUs/forms/beASaviour');
    router.register('become-an-expert', 'BecomeAVolunteerFormPage', 'view/contactUs/forms/becomeAVolunteer');
    router.register('submit-guest-post', 'GuestBlogFormPage', 'view/contactUs/forms/guestBlog');
    router.register('truecolour', 'TrueColorPage', 'view/selfHelp/trueColor/page');
    router.register('truecolour/result', 'TrueColorResultPage', 'view/selfHelp/trueColor/resultPage');
    router.register('whats-your-shape', 'ShapeTestPage', 'view/selfHelp/shapeTest/page');
    router.register('whats-your-shape/result', 'ShapeTestResultPage', 'view/selfHelp/shapeTest/resultPage');
    router.register('shapetest', 'ShapeTestPage', 'view/selfHelp/shapeTest/page');
    router.register('whats-your-shape', 'ShapeTestPage', 'view/selfHelp/shapeTest/page');
    router.register('share-positive-chats', 'SharePositiveChatsPage', 'view/sharePositiveChats/page');
    router.register('tips-counselor-page', 'TipsLandingPage', 'view/tipsLandingPage/page');
    router.register('tips-spouse-communication', 'TipsLandingPage', 'view/tipsLandingPage/page');
    router.register('become-an-expert', 'JoinUsExpertPageView', 'view/joinUsExperts/page');
    router.register('truecolourpage', 'TrueColorPage', 'view/selfHelp/trueColor/page');
    router.register('truecolourpage/result', 'TrueColorResultPage', 'view/selfHelp/trueColor/resultPage' );
    router.register('anxiety', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('anxiety/:name', 'SpokePage', 'view/hubsAndSpokes/spokePage');
    router.register('counselling', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('counselling/:name', 'SpokePage', 'view/hubsAndSpokes/spokePage');
    router.register('stress', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('stress/:name', 'SpokePage', 'view/hubsAndSpokes/spokePage');
    router.register('depression', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('depression/:name', 'SpokePage', 'view/hubsAndSpokes/spokePage');
    router.register('addiction', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('addiction/:name', 'SpokePage', 'view/hubsAndSpokes/spokePage');
    router.register(':hubname/:name/faq', 'HubsFAQPage', 'view/hubsAndSpokes/faqpage');
    router.register(':hubname/faq', 'HubsFAQPage', 'view/hubsAndSpokes/faqpage');
    router.register('mental-health', 'HubsPage', 'view/hubsAndSpokes/page');
    router.register('mental-health/:name', 'HubsPage', 'view/hubsAndSpokes/spokePage');
    router.register('will-you-succeed-in-your-resolution', 'newYearQ2Page', 'view/selfHelp/newYearQ2/page');
    router.register('will-you-succeed-in-your-resolution/result', 'newYearQ2ResultPage', 'view/selfHelp/newYearQ2/result');
    router.register('decide-your-new-year-resolution','NewYearSelfHelp','view/selfHelp/newYear/page');
    router.register('decide-your-new-year-resolution/result','NewYearSelfHelp','view/selfHelp/newYear/resultPage');
    router.register('press', 'PressPage','view/press/page');
    router.register('bookAppointment', 'AppointmentFlowView','view/appointmentFlow/page');
    router.register('jobs', 'JobPage', 'view/jobs/page');
    router.register('jobs/:name', 'JobDescriptionPage', 'view/jobs/singlepage');
    router.register('counseling', 'CounselingPage','view/counseling/page');
    router.register('donate', 'DonationPage','view/donation/page');
    router.register('whydonate', 'WhyDonationPage','view/whyDonation/page');
    router.register('counselordropdown', 'CounselorDropDownPage','view/messages/counselor_dropdown');
    router.register('online-counseling-programs','PackagesPage', 'view/packages/page' );
    router.register('online-counseling-programs/:packagename','SinglePackagesPage', 'view/packages/single_page' );
    router.register('packagesmodal', 'customPackageModal','view/packages/custompackage_modal');
    router.register('online-counseling-programs/packagebooked', 'PackedBookedPage', 'view/packages/package_booked');
    router.register('online-counseling-programs/:packageId/schedule', 'PackageSchedulePage', 'view/packages/package_schedule');
    router.register('SuicidePrevention', 'SuicidePreventionPage','view/suicidePrevention/page');
    router.register('suicidePrevention', 'SuicidePreventionPage','view/suicidePrevention/page');
    router.register('Suicideprevention', 'SuicidePreventionPage','view/suicidePrevention/page');
    router.register('suicideprevention', 'SuicidePreventionPage', 'view/suicidePrevention/page');
    router.register('new-year-resolution','NewYearPackagesPage', 'view/newYearPackages/page' );
    router.register('new-year-resolution/:packagename','SingleNewYearPage', 'view/newYearPackages/single_page' );
    router.register('new-year-resolution/:packagename/plan','SchedulePage', 'view/newYearPackages/schedule_page' );
    router.register('home-variation', 'homeVariationPage', 'view/homeVariation/page');
    router.register('relationships/breakup', 'valentinePage', 'view/valentine/page');
    router.register('relationships/single', 'valentinePage', 'view/valentine/page');
    router.register('relationships/partners-expectations', 'valentinePage', 'view/valentine/page');
    router.register('valentines-day/how-to-de-stress','valentinePage', 'view/valentine/page');
    router.register('flames-love-calculator','flamesPage', 'view/flames/page');
    router.register('love-compatibility-quiz', 'loveCompatibility', 'view/selfHelp/loveCompatibility/page')
    router.register('love-compatibility-quiz/result', 'loveCompatibility', 'view/selfHelp/loveCompatibility/result')
    router.register('emotional-wellness-test', 'emotionalWellnessPage', 'view/selfHelp/emotionalWellness/page');
    router.register('emotional-wellness-test/result', 'emotionalWellnessResult','view/selfHelp/emotionalWellness/result')
    router.register('mental-health-quiz', 'mentalHealthQuiz', 'view/mentalHealthQuiz/page');
    router.register('mental-health-quiz/result', 'mentalHealthQuizResult','view/mentalHealthQuiz/result')
    router.register('flames','flamesPage', 'view/flames/page');
    router.register('dashboard','userDashboard', 'view/userDashboard/page');
    router.register('announcement','announcement', 'view/announcement/page');
    router.register('category-index','IndexPage', 'view/indexSeo/page');
    router.register('city-index','IndexPage', 'view/indexSeo/page');
    router.register('counsellors-in-:city', 'TalkItOutPage', 'view/talkItOutV2/page');
    router.register(':category-counsellors', 'TalkItOutPage', 'view/talkItOutV2/page');
    router.register('womens-day-2017','womensDayPage', 'view/womensDay/page');
    router.register('womens-day-2017/submit-your-story', 'storyFormPage', 'view/womensDay/storyForm/page');
    router.register('womens-day-2017/story/:name', 'womensDaySinglePage', 'view/womensDay/single/page')
    router.register('new-age-indian-woman', 'womensDayDacPage', 'view/womensDay/dacPage/page')
    router.register('depression/lets-talk','whoDepressionDayLandingPage', 'view/whoDepressionDay/landing_page/page');
    router.register('lets-talk','whoDepressionDayLandingPage', 'view/whoDepressionDay/landing_page/page');
    router.register('lets-talk/stories','whoDepressionDayPage', 'view/whoDepressionDay/page');
    router.register('lets-talk/share-your-story', 'whoDepressionDayStoryFormPage', 'view/whoDepressionDay/storyForm/page');
    router.register('lets-talk/story/:name', 'whoDepressionDaySinglePage', 'view/whoDepressionDay/single/page');
    router.register('care-plan/subscribe', 'subscriptionPage', 'view/subscription/page')
    router.register('career/:name', 'campaignPage', 'view/campaign/page')
    router.register('career/:name/share-your-story', 'campaignPage', 'view/campaign/storyForm/page')
    router.register('login/sso', 'ssoLoginPage', 'view/ssoLogin/page')
    router.register('mpbse', 'mpbse', 'view/mpbse/page')
    router.register('kickthebutt/welcome', 'kickTheButt', 'view/under-construction/page')
    router.register('kickthebutt/assessment-1','kickTheButt', 'view/selfHelp/kickthebutt/page')
    router.register('kickthebutt/assessment-2','kickTheButt', 'view/selfHelp/kickthebutt/page')
    router.register('kickthebutt/assessment-3','kickTheButt', 'view/selfHelp/kickthebutt/page')
    router.register('kickthebutt/assessment-4','kickTheButt', 'view/selfHelp/kickthebutt/page')
    router.register('kickthebutt/assessment-5','kickTheButt', 'view/selfHelp/kickthebutt/page')
    router.register('kickthebutt/result', 'kickTheButtResult','view/selfHelp/kickthebutt/result')
    // router.register('kickthebutt/welcome', 'underConstructionPage', 'view/under-construction/page')
    router.register('stress-test-working-professionals', 'stressTestPro', 'view/selfHelp/stressTestProfessional/page');
    router.register('stress-test-working-professionals/result', 'stressTestProResult','view/selfHelp/stressTestProfessional/result')
    //Backbone.history.start();
    Backbone.history.start({pushState:true});
   // if (!Backbone.history.start()) router.navigate('404', {trigger:true});

    // # Globally capture clicks. If they are internal and not in the pass
    // # through list, route them through Backbone's navigate method.
    $(document).on("click", "a[href^='/']", function(event){

      console.log("in router");

      var href = $(event.currentTarget).attr('href');
      console.log(href);
      //# chain 'or's for other black list routes
      var passThrough = href.indexOf('{{byepass url}}') >= 0;

      //# Allow shift+click for new tabs, etc.
      if( !passThrough && !event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey )
        event.preventDefault();

      //# Remove leading slashes and hash bangs
      var url = href.replace(/^\//,'').replace('\#\!\/','');
      console.log(url);
      //# Instruct Backbone to trigger routing events
      var hrefProp =  $(event.currentTarget).prop("href") ;
      console.log("prop");
      console.log(hrefProp);
      router.navigate( href, { trigger: true } );

      return false;
    });
  };

  // home =  function(){

  //   var homeView = Backbone.ViewCache.get();

  //   if (homeView) {

  //     homeView.delegateEvents();
  //   } else {

  //     homeView = Backbone.ViewCache.set(new HomePage());
  //     homeView.render();
  //   }
  // }

  return {
    initialize: initialize
  };

});
