'use strict';
var LIVERELOAD_PORT = 35729;
var SERVER_PORT = 9001;
var lrSnippet = require('connect-livereload')({port: LIVERELOAD_PORT});
var mountFolder = function (connect, dir) {
    return connect.static(require('path').resolve(dir));
};

// # Globbing
// for performance reasons we're only matching one level down:
// 'test/spec/{,*/}*.js'
// use this if you want to match all subfolders:
// 'test/spec/**/*.js'
// templateFramework: 'lodash'

module.exports = function (grunt) {
    // show elapsed time at the end
    require('time-grunt')(grunt);
    // load all grunt tasks
    require('load-grunt-tasks')(grunt);

    // configurable paths
    var yeomanConfig = {
        app: 'app',
        dist: 'build'
    };

    grunt.initConfig({
        yeoman: yeomanConfig,
        watch: {
            options: {
                nospawn: true,
                livereload: LIVERELOAD_PORT
            },
            livereload: {
                options: {
                    livereload: grunt.option('livereloadport') || LIVERELOAD_PORT
                },
                files: [
                    '<%= yeoman.app %>/*.html',
                    '{.tmp,<%= yeoman.app %>}/styles/{,*/}*.css',
                    '{.tmp,<%= yeoman.app %>}/scripts/{,*/}*.js',
                    '<%= yeoman.app %>/images/{,*/}*.{png,jpg,jpeg,gif,webp}',
                    '<%= yeoman.app %>/scripts/templates/*.{ejs,mustache,hbs}',
                    'test/spec/**/*.js'
                ]
            },
            jst: {
                files: [
                    '<%= yeoman.app %>/scripts/templates/**/*.hbs'
                ],
                tasks: ['jst']
            },
            handlebars: {
                files : ['<%= yeoman.app %>/templates/*.hbs', '<%= yeoman.app %>/templates/**/*.hbs'],

                //files: [
                //    '<%= yeoman.app %>/scripts/templates/**/*.hbs'
                //],
                tasks: ['handlebars']
            },
            test: {
                files: ['<%= yeoman.app %>/scripts/{,*/}*.js', 'test/spec/**/*.js'],
                tasks: ['test:true']
            }
        },
        connect: {
            options: {
                port: grunt.option('port') || SERVER_PORT,
                // change this to '0.0.0.0' to access the server from outside
                hostname: '0.0.0.0'
            },
            livereload: {
                options: {
                    middleware: function (connect) {
                        return [
                            lrSnippet,
                            mountFolder(connect, '.tmp'),
                            mountFolder(connect, yeomanConfig.app)
                        ];
                    }
                }
            },
            test: {
                options: {
                    port: 9001,
                    middleware: function (connect) {
                        return [
                            mountFolder(connect, 'test'),
                            lrSnippet,
                            mountFolder(connect, '.tmp'),
                            mountFolder(connect, yeomanConfig.app)
                        ];
                    }
                }
            },
            dist: {
                options: {
                    middleware: function (connect) {
                        return [
                            mountFolder(connect, yeomanConfig.dist)
                        ];
                    }
                }
            }
        },
        open: {
            server: {
                path: 'http://staging.yourdost.com:<%= connect.options.port %>'
            },
            test: {
                path: 'http://staging.yourdost.com:<%= connect.test.options.port %>'
            }
        },
        clean: {
            dist: ['.tmp', '<%= yeoman.dist %>/*'],
            server: '.tmp'
        },
        requirejs: {
            dist: {
                // Options: https://github.com/jrburke/r.js/blob/master/build/example.build.js
                options: {
                    appDir: '<%= yeoman.app %>',
                    baseUrl: 'scripts',
                    mainConfigFile: '<%= yeoman.app %>/scripts/main.js',
                    dir: "build",
                    optimize: 'none',
                    modules:[
                        {
                             name:'main'
                        }
                    ],
                    logLevel: 0,
                    findNestedDependencies: true,
                    fileExclusionRegExp: /^\./,
                    inlineText: true,
                    // TODO: Figure out how to make sourcemaps work with grunt-usemin
                    // https://github.com/yeoman/grunt-usemin/issues/30
                    //generateSourceMaps: true,
                    // required to support SourceMaps
                    // http://requirejs.org/docs/errors.html#sourcemapcomments
                    //preserveLicenseComments: false,
                    //useStrict: true,
                    //wrap: true
                    //uglify2: {} // https://github.com/mishoo/UglifyJS2
                }
            }
        },
        bowercopy : {
            options: {
                 srcPrefix: '<%= yeoman.app %>/bower_components'
            },
            scripts: {
                options: {
                    destPrefix: '<%= yeoman.app%>/testScripts'
                },
                files: {
                    'jquery.min.js': 'jquery/dist/jquery.min.js',
                    'backbone.min.js': 'backbone/backbone-min.js',
                    'lodash.min.js': 'lodash/dist/lodash.min.js',
                    'velocity.min.js': 'materialize/js/velocity.min.js',
                    'hammer.min.js': 'materialize/js/hammer.min.js',
                    'materialize/js/': 'materialize/js/',
                    'materialize/dist/': 'materialize/dist/',
                    'mdi/css/' : 'mdi/css/',
                    'mdi/fonts/' : 'mdi/fonts/',
                    'i18n.js': 'i18n/i18n.js',
                    'text.js': 'text/text.js',
                    'json2.js': 'json2/json2.js',
                    'moment.js': 'moment/moment.js',
                    'async.js': 'async/lib/async.js',
                    'console.min.js': 'console/console.min.js',
                    'strophe.min.js': 'strophe/strophe.min.js',
                    'jquery-ui.min.js': 'jquery-ui/jquery-ui.min.js',
                    'keymaster.js': 'keymaster/keymaster.js',
                    'require-handlebars-plugin/hbs.js': 'require-handlebars-plugin/hbs.js',
                    'require-handlebars-plugin/hbs/': 'require-handlebars-plugin/hbs/',
                    'jquery.cookie.js': 'jquery.cookie/jquery.cookie.js',
                    'jquery.sieve.min.js': 'jquery.sieve/dist/jquery.sieve.min.js',
                    "handlebars.min.js": 'handlebars/handlebars.min.js',
                    "jquery.notebook.js": 'jquery-notebook/src/js/jquery.notebook.js',
                    "backbone.datagrid.min.js": 'backbone-datagrid/dist/backbone.datagrid.min.js',
                    "underscore.string.min.js": 'underscore.string/dist/underscore.string.min.js',
                    "backbone.paginator.min.js": 'backbone.paginator/lib/backbone.paginator.min.js',
                    "backbone.queryparams.min.js": 'backbone-queryparams/backbone.queryparams.min.js',
                    "backbone-associations-min.js": 'backbone-associations/backbone-associations-min.js',
                    "backbone-localstorage.min.js": 'backbone-localstorage/backbone-localstorage.min.js',
                    "backbone-validation-min.js": 'backbone-validation/dist/backbone-validation-min.js',
                    "ajax-chosen/ajax-chosen.min.js": 'ajax-chosen/lib/ajax-chosen.min.js',
                    "ajax-chosen/data.json": 'ajax-chosen/data.json',
                    "chosen/chosen.jquery.min.js":'chosen/chosen.jquery.min.js',
                    "chosen/chosen-sprite.png" : "chosen/chosen-sprite.png" ,
                    "chosen/chosen-sprite@2x.png" : "chosen/chosen-sprite@2x.png" ,
                    'ckeditor':'ckeditor/ckeditor.js',
                    'ckeditor/lang/' : 'ckeditor/lang/',
                    'ckeditor/plugins/' : 'ckeditor/plugins/',
                    'ckeditor/skins/' : 'ckeditor/skins/',
                    'ckeditor/contents.css' : 'ckeditor/contents.css',
                    'ckeditor/styles.js' : 'ckeditor/styles.js',
                    'ckeditor/config.js' : 'ckeditor/config.js',
                    'ckeditor/build-config.js' : 'ckeditor/build-config.js',
                    'ckeditor/samples/' : 'ckeditor/samples' ,
                    'modernizr':'modernizr/modernizr.js' ,
                    'requirejs' : 'requirejs/require.js' ,
                    'chosen/chosen.min.css' : 'chosen/chosen.min.css'
                }
            }
        },
        useminPrepare: {
            html: '<%= yeoman.app %>/index.html',
            options: {
                dest: '<%= yeoman.dist %>'
            }
        },
        usemin: {
            css: ['<%= yeoman.dist %>/styles/{,*/}*.css'],
            options: {
                dirs: ['<%= yeoman.dist %>']
            }
        },
        imagemin: {
            dist: {
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>/images',
                    src: '{,*/}*.{png,jpg,jpeg}',
                    dest: '<%= yeoman.dist %>/images'
                }]
            }
        },
        cssmin: {
            dist: {
                files: {
                    '<%= yeoman.dist %>/styles/dost.css': [
                        '.tmp/styles/{,*/}*.css',
                        '<%= yeoman.app %>/styles/{,*/}*.css'
                    ],
                    '<%= yeoman.dist %>/styles/vendor.css': [
                        '<%= yeoman.app %>/bower_components/materialize/dist/css/materialize.min.css',
                        '<%= yeoman.app %>/bower_components/mdi/css/materialdesignicons.min.css',
                        '<%= yeoman.app %>/scripts/vendor/jquery-ui/jquery-ui.min.css',
                        '<%= yeoman.app %>/bower_components/chosen/chosen.min.css',
						'<%= yeoman.app %>/bower_components/intro.js/minified/introjs.min.css',
                        '<%= yeoman.app %>/bower_components/datetimepicker/jquery.datetimepicker.css',
                        '<%= yeoman.app %>/bower_components/Swiper/dist/css/swiper.min.css',
                        '<%= yeoman.app %>/dripicons/webfont.css'
                    ]
                }
            }
        },
        htmlmin: {
            dist: {
                options: {
                    /*removeCommentsFromCDATA: true,
                    // https://github.com/yeoman/grunt-usemin/issues/44
                    //collapseWhitespace: true,
                    collapseBooleanAttributes: true,
                    removeAttributeQuotes: true,
                    removeRedundantAttributes: true,
                    useShortDoctype: true,
                    removeEmptyAttributes: true,
                    removeOptionalTags: true*/
                },
                files: [{
                    expand: true,
                    cwd: '<%= yeoman.app %>',
                    src: '*.html',
                    dest: '<%= yeoman.dist %>'
                }]
            }
        },
        copy: {
            dist: {
                files: [{
                    expand: true,
                    dot: true,
                    cwd: '<%= yeoman.app %>',
                    dest: '<%= yeoman.dist %>',
                    src: [
                        '*.{ico,txt}',
                        'images/{,*/}*.{webp,gif}',
                        'styles/fonts/{,*/}*.*',
                    ]
                }, {
                    src: 'node_modules/apache-server-configs/dist/.htaccess',
                    dest: '<%= yeoman.dist %>/.htaccess'
                },{
                    src: 'app/dripicons/fonts',
                    dest: '<%= yeoman.dist %>/font'
                }]
            }
        },
        bower: {
            all: {
                rjsConfig: '<%= yeoman.app %>/scripts/main.js'
            }
        },
        jst: {
            options: {
                amd: true
            },
            compile: {
                files: {
                    '.tmp/scripts/templates.js': ['<%= yeoman.app %>/templates/**/*.hbs']
                }
            }
        },
        handlebars: {
            options: {
								processContent: function(content, filepath) {
						    	content = content.replace(/^[\x20\t]+/mg, '').replace(/[\x20\t]+$/mg, '');
						    	content = content.replace(/^[\r\n]+/, '').replace(/[\r\n]*$/, '\n');
						    	return content;
							  },
                amd: true,
                wrapped: true,
                //helpers : require('<%= yeoman.app %>/scripts/templates/helpers/if_eq.js'),
               compilerOptions: {
                    knownHelpers: {
                      "if_eq": true,
                      "if_uneq":true,
                      "ifQuotes":true,
                      "ifCond":true,
                      "trimHtml":true,
                      "formatDate": true,
                      "for": true,
                      "getDiscountAmount":true,
                      "getDiscount" : true,
                      "getMoreDiscount" : true,
                      "ratingHtml":true,
                      "getAvatarUrl": true,
                      "htmlDecode": true,
                      "replaceBrackets": true,
                      "formatDateString" : true,
                      "math": true,
                      "debug": true,
                      "if_even": true
                   },
                    knownHelpersOnly: true
                }

            },
            files: {
                files : {
                   '<%= yeoman.app %>/scripts/precompiled-templates.js': ['<%= yeoman.app %>/templates/*.hbs', '<%= yeoman.app %>/templates/**/*.hbs']
                }
            }
        },
        rev: {
            dist: {
                files: {
                    src: [
                        '<%= yeoman.dist %>/scripts/{,*/}*.js',
                        '<%= yeoman.dist %>/styles/{,*/}*.css',
                        '<%= yeoman.dist %>/images/{,*/}*.{png,jpg,jpeg,gif,webp}',
                        '/styles/fonts/{,*/}*.*',
                    ]
                }
            }
        }
    });

    grunt.registerTask('createDefaultTemplate', function () {
        grunt.file.write('.tmp/scripts/templates.js', 'this.JST = this.JST || {};');
    });

    grunt.registerTask('bowerCopy', function(){
        grunt.task.run(['bowercopy']);
    });

    grunt.registerTask('server', function (target) {
        grunt.log.warn('The `server` task has been deprecated. Use `grunt serve` to start a server.');
        grunt.task.run(['serve' + (target ? ':' + target : '')]);
    });


    grunt.registerTask('serve', function (target) {
        if (target === 'dist') {
            return grunt.task.run(['open:server', 'connect:dist:keepalive']);
        }

        if (target === 'test') {
            return grunt.task.run([
                'clean:server',
                'createDefaultTemplate',
                'jst',
                'connect:test',
                'open:test',
                'watch'
            ]);
        }

        grunt.task.run([
            'clean:server',
            'createDefaultTemplate',
            'jst',
            'handlebars',
            'connect:livereload',
            'open:server',
            'watch'
        ]);
    });

    grunt.registerTask('test', function (isConnected) {
        isConnected = Boolean(isConnected);
        var testTasks = [
                'clean:server',
                'createDefaultTemplate',
                'jst',
                'connect:test',
                'mocha',
            ];

        if(!isConnected) {
            return grunt.task.run(testTasks);
        } else {
            // already connected so not going to connect again, remove the connect:test task
            testTasks.splice(testTasks.indexOf('connect:test'), 1);
            return grunt.task.run(testTasks);
        }
    });

    grunt.registerTask('build', [
        'clean:dist',
        'createDefaultTemplate',
        'jst',
        'handlebars',
        //'requirejs',
        'htmlmin',
        'cssmin',
        'copy',
        'usemin'
    ]);

    grunt.registerTask('default', [
        'jshint',
        'test',
        'build'
    ]);
};
